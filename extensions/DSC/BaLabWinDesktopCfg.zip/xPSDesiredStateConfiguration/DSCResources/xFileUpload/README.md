# Description

Provides a mechanism to configure and manage multiple xGroup resources with
common settings but different names

# Description

This resource is used to create and delete restore points.
System Protection must be enabled on at least one drive for
this module to work.

System restore points are only applicable to workstation
operating systems. Server operating systems are not supported.

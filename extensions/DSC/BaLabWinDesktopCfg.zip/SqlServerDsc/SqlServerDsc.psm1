#Region '.\prefix.ps1' -1

using module .\Modules\DscResource.Base

$script:dscResourceCommonModulePath = Join-Path -Path $PSScriptRoot -ChildPath 'Modules/DscResource.Common'
Import-Module -Name $script:dscResourceCommonModulePath

# TODO: The goal would be to remove this, when no classes and public or private functions need it.
$script:sqlServerDscCommonModulePath = Join-Path -Path $PSScriptRoot -ChildPath 'Modules/SqlServerDsc.Common'
Import-Module -Name $script:sqlServerDscCommonModulePath

$script:localizedData = Get-LocalizedData -DefaultUICulture 'en-US'
#EndRegion '.\prefix.ps1' 11
#Region '.\Enum\001.InstallAction.ps1' -1

<#
    .SYNOPSIS
        The possible states for the commands and DSC resources with the parameter
        Action.
#>
enum InstallAction
{
    Install = 1
    Repair
    Uninstall
}
#EndRegion '.\Enum\001.InstallAction.ps1' 12
#Region '.\Enum\001.ReportServerEdition.ps1' -1

<#
    .SYNOPSIS
        The possible states for the commands and DSC resources that handles
        SQL Server Reporting Services or Power BI Report Server and uses the
        parameter Edition.
#>
enum ReportServerEdition
{
    Developer = 1
    Evaluation
    ExpressAdvanced
}
#EndRegion '.\Enum\001.ReportServerEdition.ps1' 13
#Region '.\Enum\002.ServerPermission.ps1' -1

<#
    .SYNOPSIS
        The possible server permissions that can be granted, denied, or revoked.

    .NOTES
        The available permissions can be seen in the ServerPermission Class documentation:
        https://learn.microsoft.com/en-us/dotnet/api/microsoft.sqlserver.management.smo.serverpermission
#>
enum SqlServerPermission
{
    # cSpell:ignore securables
    AdministerBulkOperations = 1
    AlterAnyAvailabilityGroup
    AlterAnyConnection
    AlterAnyCredential
    AlterAnyDatabase
    AlterAnyEndpoint
    AlterAnyEventNotification
    AlterAnyEventSession
    AlterAnyEventSessionAddEvent
    AlterAnyEventSessionAddTarget
    AlterAnyEventSessionDisable
    AlterAnyEventSessionDropEvent
    AlterAnyEventSessionDropTarget
    AlterAnyEventSessionEnable
    AlterAnyEventSessionOption
    AlterAnyLinkedServer
    AlterAnyLogin
    AlterAnyServerAudit
    AlterAnyServerRole
    AlterResources
    AlterServerState
    AlterSettings
    AlterTrace
    AuthenticateServer
    ConnectAnyDatabase
    ConnectSql
    ControlServer
    CreateAnyDatabase
    CreateAnyEventSession
    CreateAvailabilityGroup
    CreateDdlEventNotification
    CreateEndpoint
    CreateLogin
    CreateServerRole
    CreateTraceEventNotification
    DropAnyEventSession
    ExternalAccessAssembly
    ImpersonateAnyLogin
    SelectAllUserSecurables
    Shutdown
    UnsafeAssembly
    ViewAnyCryptographicallySecuredDefinition
    ViewAnyDatabase
    ViewAnyDefinition
    ViewAnyErrorLog
    ViewAnyPerformanceDefinition
    ViewAnySecurityDefinition
    ViewServerPerformanceState
    ViewServerSecurityAudit
    ViewServerSecurityState
    ViewServerState
}
#EndRegion '.\Enum\002.ServerPermission.ps1' 64
#Region '.\Classes\001.SqlReason.ps1' -1

<#
    .SYNOPSIS
        The reason a property of a DSC resource is not in desired state.

    .DESCRIPTION
        A DSC resource can have a read-only property `Reasons` that the compliance
        part (audit via Azure Policy) of Azure AutoManage Machine Configuration
        uses. The property Reasons holds an array of SqlReason. Each SqlReason
        explains why a property of a DSC resource is not in desired state.
#>

class SqlReason
{
    [DscProperty()]
    [System.String]
    $Code

    [DscProperty()]
    [System.String]
    $Phrase
}
#EndRegion '.\Classes\001.SqlReason.ps1' 22
#Region '.\Classes\002.DatabaseFileSpec.ps1' -1

<#
    .SYNOPSIS
        Defines a data file specification for a database file group.

    .DESCRIPTION
        This class represents a data file specification that can be used when
        creating a new database. It contains the properties needed to define
        a data file without requiring an existing database or file group SMO object.

    .PARAMETER Name
        The logical name of the data file.

    .PARAMETER FileName
        The physical file path for the data file. This must be a valid path
        on the SQL Server instance.

    .PARAMETER Size
        The initial size of the data file in kilobytes. If not specified,
        SQL Server will use its default initial size.

    .PARAMETER MaxSize
        The maximum size to which the data file can grow in kilobytes.
        If not specified, the file can grow without limit (or up to disk space).

    .PARAMETER Growth
        The amount by which the data file grows when it needs more space.
        The value is in kilobytes if GrowthType is KB, or a percentage if
        GrowthType is Percent. If not specified, SQL Server will use its
        default growth setting.

    .PARAMETER GrowthType
        Specifies whether the Growth value is in kilobytes (KB) or percent (Percent).
        If not specified, defaults to KB.

    .PARAMETER IsPrimaryFile
        Specifies that this file is the primary file in the PRIMARY file group.
        Only one file in the PRIMARY file group should be marked as the primary file.
        This property is typically used for the first file in the PRIMARY file group.

    .NOTES
        This class is used to specify data file configurations when creating a new
        database via New-SqlDscDatabase. Unlike SMO DataFile objects, these
        specification objects can be created without an existing database context.

    .EXAMPLE
        $fileSpec = [DatabaseFileSpec]::new()
        $fileSpec.Name = 'MyDatabase_Data'
        $fileSpec.FileName = 'C:\SQLData\MyDatabase.mdf'
        $fileSpec.Size = 102400  # 100 MB in KB
        $fileSpec.Growth = 10240  # 10 MB in KB
        $fileSpec.GrowthType = 'KB'

        Creates a new data file specification with a specific size and growth settings.

    .EXAMPLE
        [DatabaseFileSpec] @{
            Name = 'MyDatabase_Data'
            FileName = 'C:\SQLData\MyDatabase.mdf'
            IsPrimaryFile = $true
        }

        Creates a new primary data file specification using hashtable syntax.
#>
class DatabaseFileSpec
{
    [System.String]
    $Name

    [System.String]
    $FileName

    [System.Nullable[System.Double]]
    $Size

    [System.Nullable[System.Double]]
    $MaxSize

    [System.Nullable[System.Double]]
    $Growth

    [ValidateSet('KB', 'MB', 'Percent')]
    [System.String]
    $GrowthType

    [System.Boolean]
    $IsPrimaryFile = $false

    DatabaseFileSpec()
    {
    }

    DatabaseFileSpec([System.String] $name, [System.String] $fileName)
    {
        $this.Name = $name
        $this.FileName = $fileName
    }
}
#EndRegion '.\Classes\002.DatabaseFileSpec.ps1' 98
#Region '.\Classes\002.DatabasePermission.ps1' -1

<#
    .SYNOPSIS
        The possible database permission states.

    .PARAMETER State
        The state of the permission.

    .PARAMETER Permission
        The permissions to be granted or denied for the user in the database.

    .NOTES
        The DSC properties specifies the attribute Mandatory but State was meant
        to be attribute Key, but those attributes are not honored correctly during
        compilation in the current implementation of PowerShell DSC. If the
        attribute would have been left as Key then it would not have been possible
        to add an identical instance of DatabasePermission in two separate DSC
        resource instances in a DSC configuration. The Key property only works
        on the top level DSC properties. E.g. two resources instances of
        SqlDatabasePermission in a DSC configuration trying to grant the database
        permission 'connect' in two separate databases would have failed compilation
        as a the property State would have been seen as "duplicate resource".

        Since it is not possible to use the attribute Key the State property is
        evaluate during runtime so that no two states are enforcing the same
        permission.

        This class cannot inherit a parent class. If it would have, then the
        DSC resource (e.g. SqlDatabasePermission) that uses the complex type fail
        with the error:

            "The 'Permission' property with type 'DatabasePermission' of DSC resource
            class 'SqlDatabasePermission' is not supported."

        The method Equals() returns $false if type is not the same on both sides
        of the comparison. There was a thought to throw an exception if the object
        being compared was of another type, but since there was issues with using
        for example [ServerPermission[]], it was left out. This can be the correct
        way since if moving for example [ServerPermission[]] to the left side and
        the for example [ServerPermission] to the right side, then the left side
        array is filtered with the matching values on the right side. This is the
        normal behavior for other types.

    .EXAMPLE
        [DatabasePermission] @{}

        Initializes a new instance of the DatabasePermission class without any
        property values.

    .EXAMPLE
        [DatabasePermission] @{ State = 'Grant'; Permission = @('Connect', 'Select') }

        Initializes a new instance of the DatabasePermission class with property
        values.

#>
class DatabasePermission : IComparable, System.IEquatable[Object]
{
    [DscProperty(Mandatory)]
    [ValidateSet('Grant', 'GrantWithGrant', 'Deny')]
    [System.String]
    $State

    [DscProperty(Mandatory)]
    [AllowEmptyCollection()]
    [ValidateSet(
        'AdministerDatabaseBulkOperations',
        'Alter',
        'AlterAnyApplicationRole',
        'AlterAnyAssembly',
        'AlterAnyAsymmetricKey',
        'AlterAnyCertificate',
        'AlterAnyColumnEncryptionKey',
        'AlterAnyColumnMasterKey',
        'AlterAnyContract',
        'AlterAnyDatabaseAudit',
        'AlterAnyDatabaseDdlTrigger',
        'AlterAnyDatabaseEventNotification',
        'AlterAnyDatabaseEventSession',
        'AlterAnyDatabaseEventSessionAddEvent',
        'AlterAnyDatabaseEventSessionAddTarget',
        'AlterAnyDatabaseEventSessionDisable',
        'AlterAnyDatabaseEventSessionDropEvent',
        'AlterAnyDatabaseEventSessionDropTarget',
        'AlterAnyDatabaseEventSessionEnable',
        'AlterAnyDatabaseEventSessionOption',
        'AlterAnyDatabaseScopedConfiguration',
        'AlterAnyDataspace',
        'AlterAnyExternalDataSource',
        'AlterAnyExternalFileFormat',
        'AlterAnyExternalJob',
        'AlterAnyExternalLanguage',
        'AlterAnyExternalLibrary',
        'AlterAnyExternalStream',
        'AlterAnyFulltextCatalog',
        'AlterAnyMask',
        'AlterAnyMessageType',
        'AlterAnyRemoteServiceBinding',
        'AlterAnyRole',
        'AlterAnyRoute',
        'AlterAnySchema',
        'AlterAnySecurityPolicy',
        'AlterAnySensitivityClassification',
        'AlterAnyService',
        'AlterAnySymmetricKey',
        'AlterAnyUser',
        'AlterLedger',
        'AlterLedgerConfiguration',
        'Authenticate',
        'BackupDatabase',
        'BackupLog',
        'Checkpoint',
        'Connect',
        'ConnectReplication',
        'Control',
        'CreateAggregate',
        'CreateAnyDatabaseEventSession',
        'CreateAssembly',
        'CreateAsymmetricKey',
        'CreateCertificate',
        'CreateContract',
        'CreateDatabase',
        'CreateDatabaseDdlEventNotification',
        'CreateDefault',
        'CreateExternalLanguage',
        'CreateExternalLibrary',
        'CreateFulltextCatalog',
        'CreateFunction',
        'CreateMessageType',
        'CreateProcedure',
        'CreateQueue',
        'CreateRemoteServiceBinding',
        'CreateRole',
        'CreateRoute',
        'CreateRule',
        'CreateSchema',
        'CreateService',
        'CreateSymmetricKey',
        'CreateSynonym',
        'CreateTable',
        'CreateType',
        'CreateUser',
        'CreateView',
        'CreateXmlSchemaCollection',
        'Delete',
        'DropAnyDatabaseEventSession',
        'EnableLedger',
        'Execute',
        'ExecuteAnyExternalEndpoint',
        'ExecuteAnyExternalScript',
        'Insert',
        'KillDatabaseConnection',
        'OwnershipChaining',
        'References',
        'Select',
        'Showplan',
        'SubscribeQueryNotifications',
        'TakeOwnership',
        'Unmask',
        'Update',
        'ViewAnyColumnEncryptionKeyDefinition',
        'ViewAnyColumnMasterKeyDefinition',
        'ViewAnySensitivityClassification',
        'ViewCryptographicallySecuredDefinition',
        'ViewDatabasePerformanceState',
        'ViewDatabaseSecurityAudit',
        'ViewDatabaseSecurityState',
        'ViewDatabaseState',
        'ViewDefinition',
        'ViewLedgerContent',
        'ViewPerformanceDefinition',
        'ViewSecurityDefinition'
    )]
    [System.String[]]
    $Permission

    DatabasePermission ()
    {
    }

    [System.Boolean] Equals([System.Object] $object)
    {
        $isEqual = $false

        if ($object -is $this.GetType())
        {
            if ($this.Grant -eq $object.Grant)
            {
                if (-not (Compare-Object -ReferenceObject $this.Permission -DifferenceObject $object.Permission))
                {
                    $isEqual = $true
                }
            }
        }

        return $isEqual
    }

    [System.Int32] CompareTo([Object] $object)
    {
        [System.Int32] $returnValue = 0

        if ($null -eq $object)
        {
            return 1
        }

        if ($object -is $this.GetType())
        {
            <#
                Less than zero    - The current instance precedes the object specified by the CompareTo
                                    method in the sort order.
                Zero              - This current instance occurs in the same position in the sort order
                                    as the object specified by the CompareTo method.
                Greater than zero - This current instance follows the object specified by the CompareTo
                                    method in the sort order.
            #>
            $returnValue = 0

            # Order objects in the order 'Grant', 'GrantWithGrant', 'Deny'.
            switch ($this.State)
            {
                'Grant'
                {
                    if ($object.State -in @('GrantWithGrant', 'Deny'))
                    {
                        # This current instance precedes $object
                        $returnValue = -1
                    }
                }

                'GrantWithGrant'
                {
                    if ($object.State -in @('Grant'))
                    {
                        # This current instance follows $object
                        $returnValue = 1
                    }

                    if ($object.State -in @('Deny'))
                    {
                        # This current instance precedes $object
                        $returnValue = -1
                    }
                }

                'Deny'
                {
                    if ($object.State -in @('Grant', 'GrantWithGrant'))
                    {
                        # This current instance follows $object
                        $returnValue = 1
                    }
                }
            }
        }
        else
        {
            $errorMessage = $script:localizedData.InvalidTypeForCompare -f @(
                $this.GetType().FullName,
                $object.GetType().FullName
            )

            New-ArgumentException -ArgumentName 'Object' -Message $errorMessage
        }

        return $returnValue
    }

    [System.String] ToString()
    {
        $concatenatedPermission = ($this.Permission | Sort-Object) -join ', '

        return ('{0}: {1}' -f $this.State, $concatenatedPermission)
    }
}
#EndRegion '.\Classes\002.DatabasePermission.ps1' 276
#Region '.\Classes\002.ServerPermission.ps1' -1

<#
    .SYNOPSIS
        The possible server permission states.

    .PARAMETER State
        The state of the permission.

    .PARAMETER Permission
        The permissions to be granted or denied for the user in the database.

    .NOTES
        The DSC properties specifies the attribute Mandatory but State was meant
        to be attribute Key, but those attributes are not honored correctly during
        compilation in the current implementation of PowerShell DSC. If the
        attribute would have been left as Key then it would not have been possible
        to add an identical instance of ServerPermission in two separate DSC
        resource instances in a DSC configuration. The Key property only works
        on the top level DSC properties. E.g. two resources instances of
        SqlPermission in a DSC configuration trying to grant the database
        permission 'AlterAnyDatabase' in two separate databases would have failed compilation
        as a the property State would have been seen as "duplicate resource".

        Since it is not possible to use the attribute Key the State property is
        evaluate during runtime so that no two states are enforcing the same
        permission.

        This class cannot inherit a parent class. If it would have, then the
        DSC resource (e.g. SqlServerPermission) that uses the complex type fail
        with the error:

            "The 'Permission' property with type 'ServerPermission' of DSC resource
            class 'SqlServerPermission' is not supported."

        The method Equals() returns $false if type is not the same on both sides
        of the comparison. There was a thought to throw an exception if the object
        being compared was of another type, but since there was issues with using
        for example [ServerPermission[]], it was left out. This can be the correct
        way since if moving for example [ServerPermission[]] to the left side and
        the for example [ServerPermission] to the right side, then the left side
        array is filtered with the matching values on the right side. This is the
        normal behavior for other types.

    .EXAMPLE
        [ServerPermission] @{}

        Initializes a new instance of the ServerPermission class without any
        property values.

    .EXAMPLE
        [ServerPermission] @{ State = 'Grant'; Permission = @('ConnectSql', 'ViewServerState') }

        Initializes a new instance of the ServerPermission class with property
        values.
#>
class ServerPermission : IComparable, System.IEquatable[Object]
{
    [DscProperty(Mandatory)]
    [ValidateSet('Grant', 'GrantWithGrant', 'Deny')]
    [System.String]
    $State

    [DscProperty(Mandatory)]
    [AllowEmptyCollection()]
    [ValidateSet(
        'AdministerBulkOperations',
        'AlterAnyServerAudit',
        'AlterAnyCredential',
        'AlterAnyConnection',
        'AlterAnyDatabase',
        'AlterAnyEventNotification',
        'AlterAnyEndpoint',
        'AlterAnyLogin',
        'AlterAnyLinkedServer',
        'AlterResources',
        'AlterServerState',
        'AlterSettings',
        'AlterTrace',
        'AuthenticateServer',
        'ControlServer',
        'ConnectSql',
        'CreateAnyDatabase',
        'CreateDdlEventNotification',
        'CreateEndpoint',
        'CreateTraceEventNotification',
        'Shutdown',
        'ViewAnyDefinition',
        'ViewAnyDatabase',
        'ViewServerState',
        'ExternalAccessAssembly',
        'UnsafeAssembly',
        'AlterAnyServerRole',
        'CreateServerRole',
        'AlterAnyAvailabilityGroup',
        'CreateAvailabilityGroup',
        'AlterAnyEventSession',
        'SelectAllUserSecurables',
        'ConnectAnyDatabase',
        'ImpersonateAnyLogin'
    )]
    [System.String[]]
    $Permission

    ServerPermission ()
    {
    }

    <#
        TODO: It was not possible to move this to a parent class. But since these are
              generic functions for DatabasePermission and ServerPermission we
              could make this a private function.
    #>
    [System.Boolean] Equals([System.Object] $object)
    {
        $isEqual = $false

        if ($object -is $this.GetType())
        {
            if ($this.Grant -eq $object.Grant)
            {
                if (-not (Compare-Object -ReferenceObject $this.Permission -DifferenceObject $object.Permission))
                {
                    $isEqual = $true
                }
            }
        }

        return $isEqual
    }

    <#
        TODO: It was not possible to move this to a parent class. But since these are
              generic functions for DatabasePermission and ServerPermission we
              could make this a private function.
    #>
    [System.Int32] CompareTo([Object] $object)
    {
        [System.Int32] $returnValue = 0

        if ($null -eq $object)
        {
            return 1
        }

        if ($object -is $this.GetType())
        {
            <#
                Less than zero    - The current instance precedes the object specified by the CompareTo
                                    method in the sort order.
                Zero              - This current instance occurs in the same position in the sort order
                                    as the object specified by the CompareTo method.
                Greater than zero - This current instance follows the object specified by the CompareTo
                                    method in the sort order.
            #>
            $returnValue = 0

            # Order objects in the order 'Grant', 'GrantWithGrant', 'Deny'.
            switch ($this.State)
            {
                'Grant'
                {
                    if ($object.State -in @('GrantWithGrant', 'Deny'))
                    {
                        # This current instance precedes $object
                        $returnValue = -1
                    }
                }

                'GrantWithGrant'
                {
                    if ($object.State -in @('Grant'))
                    {
                        # This current instance follows $object
                        $returnValue = 1
                    }

                    if ($object.State -in @('Deny'))
                    {
                        # This current instance precedes $object
                        $returnValue = -1
                    }
                }

                'Deny'
                {
                    if ($object.State -in @('Grant', 'GrantWithGrant'))
                    {
                        # This current instance follows $object
                        $returnValue = 1
                    }
                }
            }
        }
        else
        {
            $errorMessage = $script:localizedData.InvalidTypeForCompare -f @(
                $this.GetType().FullName,
                $object.GetType().FullName
            )

            New-ArgumentException -ArgumentName 'Object' -Message $errorMessage
        }

        return $returnValue
    }

    [System.String] ToString()
    {
        $concatenatedPermission = ($this.Permission | Sort-Object) -join ', '

        return ('{0}: {1}' -f $this.State, $concatenatedPermission)
    }
}
#EndRegion '.\Classes\002.ServerPermission.ps1' 213
#Region '.\Classes\004.DatabaseFileGroupSpec.ps1' -1

<#
    .SYNOPSIS
        Defines a file group specification for a database.

    .DESCRIPTION
        This class represents a file group specification that can be used when
        creating a new database. It contains the properties needed to define
        a file group and its associated data files without requiring an existing
        database SMO object.

    .PARAMETER Name
        The name of the file group. For the primary file group, this should be 'PRIMARY'.

    .PARAMETER Files
        An array of DatabaseFileSpec objects that define the data files belonging
        to this file group. At least one file must be specified for each file group.

    .PARAMETER ReadOnly
        Specifies whether the file group is read-only. If not specified, defaults
        to $false (read-write).

    .PARAMETER IsDefault
        Specifies whether this file group should be the default file group for
        new objects. If not specified, defaults to $false. Typically, only the
        PRIMARY file group or one custom file group should be marked as default.

    .NOTES
        This class is used to specify file group configurations when creating a new
        database via New-SqlDscDatabase. Unlike SMO FileGroup objects, these
        specification objects can be created without an existing database context.

        When creating a database, you typically need at least one file group named
        'PRIMARY' which contains the primary data file. Additional file groups can
        be added for organizing data files.

    .EXAMPLE
        $primaryFile = [DatabaseFileSpec] @{
            Name = 'MyDatabase_Primary'
            FileName = 'C:\SQLData\MyDatabase.mdf'
            IsPrimaryFile = $true
        }

        $primaryFileGroup = [DatabaseFileGroupSpec]::new()
        $primaryFileGroup.Name = 'PRIMARY'
        $primaryFileGroup.Files = @($primaryFile)

        Creates a PRIMARY file group specification with one primary data file.

    .EXAMPLE
        $dataFile1 = [DatabaseFileSpec] @{
            Name = 'MyDatabase_Data1'
            FileName = 'D:\SQLData\MyDatabase_Data1.ndf'
            Size = 204800  # 200 MB
        }

        $dataFile2 = [DatabaseFileSpec] @{
            Name = 'MyDatabase_Data2'
            FileName = 'D:\SQLData\MyDatabase_Data2.ndf'
            Size = 204800  # 200 MB
        }

        $secondaryFileGroup = [DatabaseFileGroupSpec] @{
            Name = 'SECONDARY'
            Files = @($dataFile1, $dataFile2)
        }

        Creates a SECONDARY file group specification with two data files.

    .EXAMPLE
        [DatabaseFileGroupSpec] @{
            Name = 'PRIMARY'
            Files = @(
                [DatabaseFileSpec] @{
                    Name = 'MyDB_Primary'
                    FileName = 'C:\SQLData\MyDB.mdf'
                }
            )
        }

        Creates a PRIMARY file group using hashtable syntax with an embedded file spec.
#>
class DatabaseFileGroupSpec
{
    [System.String]
    $Name

    [DatabaseFileSpec[]]
    $Files

    [System.Boolean]
    $ReadOnly = $false

    [System.Boolean]
    $IsDefault = $false

    DatabaseFileGroupSpec()
    {
    }

    DatabaseFileGroupSpec([System.String] $name)
    {
        $this.Name = $name
    }

    DatabaseFileGroupSpec([System.String] $name, [DatabaseFileSpec[]] $files)
    {
        $this.Name = $name
        $this.Files = $files
    }
}
#EndRegion '.\Classes\004.DatabaseFileGroupSpec.ps1' 111
#Region '.\Classes\004.StartupParameters.ps1' -1

<#
    .SYNOPSIS
        A class to handle startup parameters of a manged computer service object.

    .EXAMPLE
        $startupParameters = [StartupParameters]::Parse(((Get-SqlDscManagedComputer).Services | ? type -eq 'SqlServer').StartupParameters)
        $startupParameters | fl
        $startupParameters.ToString()

        Parses the startup parameters of the database engine default instance on the
        current node, and then outputs the resulting object. Also shows how the object
        can be turned back to a startup parameters string by calling ToString().

    .NOTES
        This class supports an array of data file paths, log file paths, and error
        log paths though currently it seems that there can only be one of each.
        This class was made with arrays in case there is an unknown edge case where
        it is possible to have more than one of those paths.
#>
class StartupParameters
{
    [System.String[]]
    $DataFilePath

    [System.String[]]
    $LogFilePath

    [System.String[]]
    $ErrorLogPath

    [System.UInt32[]]
    $TraceFlag

    [System.UInt32[]]
    $InternalTraceFlag

    StartupParameters ()
    {
    }

    static [StartupParameters] Parse([System.String] $InstanceStartupParameters)
    {
        Write-Debug -Message (
            $script:localizedData.StartupParameters_DebugParsingStartupParameters -f 'StartupParameters.Parse()', $InstanceStartupParameters
        )

        $startupParameters = [StartupParameters]::new()

        $startupParameterValues = $InstanceStartupParameters -split ';'

        $startupParameters.TraceFlag = [System.UInt32[]] @(
            $startupParameterValues |
                Where-Object -FilterScript {
                    $_ -cmatch '^-T\d+'
                } |
                ForEach-Object -Process {
                    [System.UInt32] $_.TrimStart('-T')
                }
        )

        Write-Debug -Message (
            $script:localizedData.StartupParameters_DebugFoundTraceFlags -f 'StartupParameters.Parse()', ($startupParameters.TraceFlag -join ', ')
        )

        $startupParameters.DataFilePath = [System.String[]] @(
            $startupParameterValues |
                Where-Object -FilterScript {
                    $_ -cmatch '^-d'
                } |
                ForEach-Object -Process {
                    $_.TrimStart('-d')
                }
        )

        $startupParameters.LogFilePath = [System.String[]] @(
            $startupParameterValues |
                Where-Object -FilterScript {
                    $_ -cmatch '^-l'
                } |
                ForEach-Object -Process {
                    $_.TrimStart('-l')
                }
        )

        $startupParameters.ErrorLogPath = [System.String[]] @(
            $startupParameterValues |
                Where-Object -FilterScript {
                    $_ -cmatch '^-e'
                } |
                ForEach-Object -Process {
                    $_.TrimStart('-e')
                }
        )

        $startupParameters.InternalTraceFlag = [System.UInt32[]] @(
            $startupParameterValues |
                Where-Object -FilterScript {
                    $_ -cmatch '^-t\d+'
                } |
                ForEach-Object -Process {
                    [System.UInt32] $_.TrimStart('-t')
                }
        )

        return $startupParameters
    }

    [System.String] ToString()
    {
        $startupParametersValues = [System.String[]] @()

        if ($this.DataFilePath)
        {
            $startupParametersValues += $this.DataFilePath |
                ForEach-Object -Process {
                    '-d{0}' -f $_
                }
        }

        if ($this.ErrorLogPath)
        {
            $startupParametersValues += $this.ErrorLogPath |
                ForEach-Object -Process {
                    '-e{0}' -f $_
                }
        }

        if ($this.LogFilePath)
        {
            $startupParametersValues += $this.LogFilePath |
                ForEach-Object -Process {
                    '-l{0}' -f $_
                }
        }

        if ($this.TraceFlag)
        {
            $startupParametersValues += $this.TraceFlag |
                ForEach-Object -Process {
                    '-T{0}' -f $_
                }
        }

        if ($this.InternalTraceFlag)
        {
            $startupParametersValues += $this.InternalTraceFlag |
                ForEach-Object -Process {
                    '-t{0}' -f $_
                }
        }

        return $startupParametersValues -join ';'
    }
}
#EndRegion '.\Classes\004.StartupParameters.ps1' 155
#Region '.\Classes\011.SqlResourceBase.ps1' -1

<#
    .SYNOPSIS
        The SqlResource base have generic properties and methods for the class-based
        resources.

    .PARAMETER InstanceName
        The name of the _SQL Server_ instance to be configured. Default value is
        `'MSSQLSERVER'`.

    .PARAMETER ServerName
        The host name of the _SQL Server_ to be configured. Default value is the
        current computer name.

    .PARAMETER Credential
        Specifies the credential to use to connect to the _SQL Server_ instance.

        If parameter **Credential'* is not provided then the resource instance is
        run using the credential that runs the configuration.

    .PARAMETER Reasons
        Returns the reason a property is not in desired state.
#>
class SqlResourceBase : ResourceBase
{
    <#
        Property for holding the server connection object.
        This should be an object of type [Microsoft.SqlServer.Management.Smo.Server]
        but using that type fails the build process currently.
        See issue https://github.com/dsccommunity/DscResource.DocGenerator/issues/121.
    #>
    hidden [System.Object] $SqlServerObject

    [DscProperty(Key)]
    [System.String]
    $InstanceName

    [DscProperty()]
    [System.String]
    $ServerName = (Get-ComputerName)

    [DscProperty()]
    [PSCredential]
    $Credential

    [DscProperty(NotConfigurable)]
    [SqlReason[]]
    $Reasons

    # Passing the module's base directory to the base constructor.
    SqlResourceBase () : base ($PSScriptRoot)
    {
        $this.SqlServerObject = $null
    }

    <#
        Returns and reuses the server connection object. If the server connection
        object does not exist a connection to the SQL Server instance will occur.

        This should return an object of type [Microsoft.SqlServer.Management.Smo.Server]
        but using that type fails the build process currently.
        See issue https://github.com/dsccommunity/DscResource.DocGenerator/issues/121.
    #>
    hidden [System.Object] GetServerObject()
    {
        if (-not $this.SqlServerObject)
        {
            $connectSqlDscDatabaseEngineParameters = @{
                ServerName   = $this.ServerName
                InstanceName = $this.InstanceName
                ErrorAction  = 'Stop'
            }

            if ($this.Credential)
            {
                $connectSqlDscDatabaseEngineParameters.Credential = $this.Credential
            }

            $this.SqlServerObject = Connect-SqlDscDatabaseEngine @connectSqlDscDatabaseEngineParameters
        }

        return $this.SqlServerObject
    }
}
#EndRegion '.\Classes\011.SqlResourceBase.ps1' 84
#Region '.\Classes\020.SqlAgentAlert.ps1' -1

<#
    .SYNOPSIS
        The `SqlAgentAlert` DSC resource is used to create, modify, or remove
        _SQL Server Agent_ alerts.

    .DESCRIPTION
        The `SqlAgentAlert` DSC resource is used to create, modify, or remove
        _SQL Server Agent_ alerts.

        An alert can be switched between a system-message–based alert and a severity-based
        alert by specifying the corresponding parameter. The alert type will be switched
        accordingly.

        The built-in parameter **PSDscRunAsCredential** can be used to run the resource
        as another user. The resource will then authenticate to the _SQL Server_
        instance as that user. It is also possible to use impersonation via the
        **Credential** parameter.

        ## Requirements

        * Target machine must be running Windows Server 2012 or later.
        * Target machine must be running SQL Server Database Engine 2012 or later.
        * Target machine must have access to the SQLPS PowerShell module or the SqlServer
          PowerShell module.

        ## Known issues

        All issues are not listed here, see [here for all open issues](https://github.com/dsccommunity/SqlServerDsc/issues?q=is%3Aissue+is%3Aopen+in%3Atitle+SqlAgentAlert).

        ### Property **Reasons** does not work with **PSDscRunAsCredential**

        When using the built-in parameter **PSDscRunAsCredential** the read-only
        property **Reasons** will return empty values for the properties **Code**
        and **Phrase**. The built-in property **PSDscRunAsCredential** does not work
        together with class-based resources that use advanced types, such as the
        **Reasons** parameter.

        ### Using **Credential** property

        SQL Authentication and Group Managed Service Accounts are not supported as
        impersonation credentials. Currently, only Windows Integrated Security is
        supported.

        For Windows Authentication the username must either be provided with the User
        Principal Name (UPN), e.g., `username@domain.local`, or, if using a non‑domain
        account (for example, a local Windows Server account), the username must be
        provided without the NetBIOS name, e.g., `username`. Using the NetBIOS name,
        for example `DOMAIN\username`, will not work.

        See more information in [Credential Overview](https://github.com/dsccommunity/SqlServerDsc/wiki/CredentialOverview).

    .PARAMETER Name
        The name of the _SQL Server Agent_ alert.

    .PARAMETER Ensure
        Specifies if the _SQL Server Agent_ alert should be present or absent.
        Default value is `'Present'`.

    .PARAMETER Severity
        The severity of the _SQL Server Agent_ alert. Valid range is 1 to 25.
        Cannot be used together with **MessageId**.

    .PARAMETER MessageId
        The message id of the _SQL Server Agent_ alert. Valid range is 1 to 2147483647.
        Cannot be used together with **Severity**.

    .EXAMPLE
        Invoke-DscResource -ModuleName SqlServerDsc -Name SqlAgentAlert -Method Get -Property @{
            InstanceName = 'MSSQLSERVER'
            Name         = 'Alert1'
        }

        This example shows how to get the current state of the _SQL Server Agent_
        alert named **Alert1**.

    .EXAMPLE
        Invoke-DscResource -ModuleName SqlServerDsc -Name SqlAgentAlert -Method Test -Property @{
            InstanceName = 'MSSQLSERVER'
            Name         = 'Alert1'
            Ensure       = 'Present'
            Severity     = 16
        }

        This example shows how to test if the _SQL Server Agent_ alert named
        **Alert1** is in the desired state.

    .EXAMPLE
        Invoke-DscResource -ModuleName SqlServerDsc -Name SqlAgentAlert -Method Set -Property @{
            InstanceName = 'MSSQLSERVER'
            Name         = 'Alert1'
            Ensure       = 'Present'
            Severity     = 16
        }

        This example shows how to set the desired state for the _SQL Server Agent_
        alert named **Alert1** with severity level 16.

    .EXAMPLE
        Invoke-DscResource -ModuleName SqlServerDsc -Name SqlAgentAlert -Method Set -Property @{
            InstanceName = 'MSSQLSERVER'
            Name         = 'Alert1'
            Ensure       = 'Present'
            MessageId    = 50001
        }

        This example shows how to set the desired state for the _SQL Server Agent_
        alert named **Alert1** with message ID 50001.

    .EXAMPLE
        Invoke-DscResource -ModuleName SqlServerDsc -Name SqlAgentAlert -Method Set -Property @{
            InstanceName = 'MSSQLSERVER'
            Name         = 'Alert1'
            Ensure       = 'Absent'
        }

        This example shows how to remove the _SQL Server Agent_ alert named
        **Alert1**.
#>
[DscResource(RunAsCredential = 'Optional')]
class SqlAgentAlert : SqlResourceBase
{
    [DscProperty(Key)]
    [System.String]
    $Name

    [DscProperty()]
    [ValidateSet('Present', 'Absent')]
    [System.String]
    $Ensure = 'Present'

    [DscProperty()]
    [ValidateRange(1, 25)]
    [Nullable[System.Int32]]
    $Severity

    [DscProperty()]
    [ValidateRange(1, 2147483647)]
    [Nullable[System.Int32]]
    $MessageId

    SqlAgentAlert () : base ()
    {
        # Property names that cannot be enforced
        $this.ExcludeDscProperties = @(
            'InstanceName',
            'ServerName',
            'Credential',
            'Name'
        )
    }

    [SqlAgentAlert] Get()
    {
        # Call base implementation to get current state
        $currentState = ([ResourceBase] $this).Get()

        return $currentState
    }

    [System.Boolean] Test()
    {
        # Call base implementation to test current state
        $inDesiredState = ([ResourceBase] $this).Test()

        return $inDesiredState
    }

    [void] Set()
    {
        # Call base implementation to set desired state
        ([ResourceBase] $this).Set()
    }

    hidden [void] AssertProperties([System.Collections.Hashtable] $properties)
    {
        # Validate that at least one of Severity or MessageId is specified
        $assertAtLeastOneParams = @{
            BoundParameterList   = $properties
            AtLeastOneList       = @('Severity', 'MessageId')
            IfEqualParameterList = @{
                Ensure = 'Present'
            }
        }

        Assert-BoundParameter @assertAtLeastOneParams

        # Validate that both Severity and MessageId are not specified
        $assertMutuallyExclusiveParams = @{
            BoundParameterList       = $properties
            MutuallyExclusiveList1   = @('Severity')
            MutuallyExclusiveList2   = @('MessageId')
            IfEqualParameterList     = @{
                Ensure = 'Present'
            }
        }

        Assert-BoundParameter @assertMutuallyExclusiveParams

        # When Ensure is 'Absent', Severity and MessageId must not be set
        $assertAbsentParams = @{
            BoundParameterList   = $properties
            NotAllowedList       = @('Severity', 'MessageId')
            IfEqualParameterList = @{
                Ensure = 'Absent'
            }
        }

        Assert-BoundParameter @assertAbsentParams
    }

    hidden [System.Collections.Hashtable] GetCurrentState([System.Collections.Hashtable] $properties)
    {
        $serverObject = $this.GetServerObject()

        Write-Verbose -Message ($this.localizedData.SqlAgentAlert_GettingCurrentState -f $this.Name, $this.InstanceName)

        $currentState = @{
            InstanceName = $this.InstanceName
            ServerName   = $this.ServerName
            Name         = $this.Name
            Ensure       = 'Absent'
        }

        $alertObject = $serverObject | Get-SqlDscAgentAlert -Name $this.Name -ErrorAction 'SilentlyContinue'

        if ($alertObject)
        {
            Write-Verbose -Message ($this.localizedData.SqlAgentAlert_AlertExists -f $this.Name)

            $currentState.Ensure = 'Present'

            # Get the current severity and message ID
            if ($alertObject.Severity -gt 0)
            {
                $currentState.Severity = $alertObject.Severity
            }

            if ($alertObject.MessageId -gt 0)
            {
                $currentState.MessageId = $alertObject.MessageId
            }
        }
        else
        {
            Write-Verbose -Message ($this.localizedData.SqlAgentAlert_AlertDoesNotExist -f $this.Name)
        }

        return $currentState
    }

    hidden [void] Modify([System.Collections.Hashtable] $properties)
    {
        $serverObject = $this.GetServerObject()

        if ($this.Ensure -eq 'Present')
        {
            $alertObject = $serverObject | Get-SqlDscAgentAlert -Name $this.Name -ErrorAction 'SilentlyContinue'

            if ($null -eq $alertObject)
            {
                Write-Verbose -Message ($this.localizedData.SqlAgentAlert_CreatingAlert -f $this.Name)

                $newAlertParameters = @{
                    ServerObject = $serverObject
                    Name         = $this.Name
                    ErrorAction  = 'Stop'
                }

                if ($properties.ContainsKey('Severity'))
                {
                    $newAlertParameters.Severity = $properties.Severity
                }

                if ($properties.ContainsKey('MessageId'))
                {
                    $newAlertParameters.MessageId = $properties.MessageId
                }

                $null = New-SqlDscAgentAlert @newAlertParameters
            }
            else
            {
                Write-Verbose -Message ($this.localizedData.SqlAgentAlert_UpdatingAlert -f $this.Name)

                $setAlertParameters = @{
                    AlertObject = $alertObject
                    ErrorAction = 'Stop'
                }

                $needsUpdate = $false

                if ($properties.ContainsKey('Severity') -and $alertObject.Severity -ne $properties.Severity)
                {
                    $setAlertParameters.Severity = $properties.Severity
                    $needsUpdate = $true
                }

                if ($properties.ContainsKey('MessageId') -and $alertObject.MessageId -ne $properties.MessageId)
                {
                    $setAlertParameters.MessageId = $properties.MessageId
                    $needsUpdate = $true
                }

                if ($needsUpdate)
                {
                    $null = Set-SqlDscAgentAlert @setAlertParameters
                }
                else
                {
                    Write-Verbose -Message ($this.localizedData.SqlAgentAlert_NoChangesNeeded -f $this.Name)
                }
            }
        }
        else # Ensure = 'Absent'
        {
            Write-Verbose -Message ($this.localizedData.SqlAgentAlert_RemovingAlert -f $this.Name)

            $null = $serverObject | Remove-SqlDscAgentAlert -Name $this.Name -Force -ErrorAction 'Stop'
        }
    }
}
#EndRegion '.\Classes\020.SqlAgentAlert.ps1' 322
#Region '.\Classes\020.SqlAudit.ps1' -1

<#
    .SYNOPSIS
        The `SqlAudit` DSC resource is used to create, modify, or remove
        server audits.

    .DESCRIPTION
        The `SqlAudit` DSC resource is used to create, modify, or remove
        server audits.

        The built-in parameter **PSDscRunAsCredential** can be used to run the resource
        as another user. The resource will then authenticate to the SQL Server
        instance as that user. It also possible to instead use impersonation by the
        parameter **Credential**.

        ## Requirements

        * Target machine must be running Windows Server 2012 or later.
        * Target machine must be running SQL Server Database Engine 2012 or later.
        * Target machine must have access to the SQLPS PowerShell module or the SqlServer
          PowerShell module.

        ## Known issues

        All issues are not listed here, see [here for all open issues](https://github.com/dsccommunity/SqlServerDsc/issues?q=is%3Aissue+is%3Aopen+in%3Atitle+SqlAudit).

        ### Property **Reasons** does not work with **PSDscRunAsCredential**

        When using the built-in parameter **PSDscRunAsCredential** the read-only
        property **Reasons** will return empty values for the properties **Code**
        and **Phrase. The built-in property **PSDscRunAsCredential** does not work
        together with class-based resources that using advanced type like the parameter
        **Reasons** have.

        ### Using **Credential** property

        SQL Authentication and Group Managed Service Accounts is not supported as
        impersonation credentials. Currently only Windows Integrated Security is
        supported to use as credentials.

        For Windows Authentication the username must either be provided with the User
        Principal Name (UPN), e.g. `username@domain.local` or if using non-domain
        (for example a local Windows Server account) account the username must be
        provided without the NetBIOS name, e.g. `username`. Using the NetBIOS name, e.g
        using the format `DOMAIN\username` will not work.

        See more information in [Credential Overview](https://github.com/dsccommunity/SqlServerDsc/wiki/CredentialOverview).

    .PARAMETER Name
        The name of the audit.

    .PARAMETER LogType
        Specifies the to which log an audit logs to. Mutually exclusive to parameter
        **Path**.

    .PARAMETER Path
        Specifies the destination path for a file audit. Mutually exclusive to parameter
        **LogType**.

    .PARAMETER Filter
        Specifies the filter that should be used on the audit.

    .PARAMETER MaximumFiles
        Specifies the number of files on disk. Mutually exclusive to parameter
        **MaximumRolloverFiles**. Mutually exclusive to parameter **LogType**.

    .PARAMETER MaximumFileSize
        Specifies the maximum file size in units by parameter **MaximumFileSizeUnit**.
        If this is specified the parameter **MaximumFileSizeUnit** must also be
        specified. Mutually exclusive to parameter **LogType**. Minimum allowed value
        is 2 (MB). It also allowed to set the value to 0 which mean unlimited file
        size.

    .PARAMETER MaximumFileSizeUnit
        Specifies the unit that is used for the file size.
        If this is specified the parameter **MaximumFileSize** must also be
        specified. Mutually exclusive to parameter **LogType**.

    .PARAMETER MaximumRolloverFiles
        Specifies the amount of files on disk before SQL Server starts reusing
        the files. Mutually exclusive to parameter **MaximumFiles** and **LogType**.

    .PARAMETER OnFailure
        Specifies what should happen when writing events to the store fails.
        This can be `Continue`, `FailOperation`, or `Shutdown`.

    .PARAMETER QueueDelay
        Specifies the maximum delay before a event is written to the store.
        When set to low this could impact server performance.
        When set to high events could be missing when a server crashes.

    .PARAMETER ReserveDiskSpace
        Specifies if the needed file space should be reserved. only needed
        when writing to a file log. Mutually exclusive to parameter **LogType**.

    .PARAMETER Enabled
        Specifies if the audit should be enabled. Defaults to `$false`.

    .PARAMETER Ensure
        Specifies if the server audit should be present or absent. If set to `Present`
        the audit will be added if it does not exist, or updated if the audit exist.
        If `Absent` then the audit will be removed from the server. Defaults to
        `Present`.

    .PARAMETER Force
        Specifies if it is allowed to re-create the server audit if a current audit
        exist with the same name but of a different audit type. Defaults to `$false`
        not allowing server audits to be re-created.

    .EXAMPLE
        Invoke-DscResource -ModuleName SqlServerDsc -Name SqlAudit -Method Get -Property @{
            ServerName           = 'localhost'
            InstanceName         = 'SQL2017'
            Credential           = (Get-Credential -UserName 'myuser@company.local' -Message 'Password:')
            Name                 = 'Log1'
        }

        This example shows how to call the resource using Invoke-DscResource.
#>
[DscResource(RunAsCredential = 'Optional')]
class SqlAudit : SqlResourceBase
{
    [DscProperty(Key)]
    [System.String]
    $Name

    [DscProperty()]
    [ValidateSet('SecurityLog', 'ApplicationLog')]
    [System.String]
    $LogType

    # The Path is evaluated if exist in AssertProperties().
    [DscProperty()]
    [System.String]
    $Path

    [DscProperty()]
    [System.String]
    $AuditFilter

    [DscProperty()]
    [Nullable[System.UInt32]]
    $MaximumFiles

    [DscProperty()]
    # There is an extra evaluation in AssertProperties() for this range.
    [ValidateRange(0, 2147483647)]
    [Nullable[System.UInt32]]
    $MaximumFileSize

    [DscProperty()]
    [ValidateSet('Megabyte', 'Gigabyte', 'Terabyte')]
    [System.String]
    $MaximumFileSizeUnit

    [DscProperty()]
    [ValidateRange(0, 2147483647)]
    [Nullable[System.UInt32]]
    $MaximumRolloverFiles

    [DscProperty()]
    [ValidateSet('Continue', 'FailOperation', 'Shutdown')]
    [System.String]
    $OnFailure

    [DscProperty()]
    # There is an extra evaluation in AssertProperties() for this range.
    [ValidateRange(0, 2147483647)]
    [Nullable[System.UInt32]]
    $QueueDelay

    [DscProperty()]
    [ValidatePattern('^[0-9a-fA-F]{8}-(?:[0-9a-fA-F]{4}-){3}[0-9a-fA-F]{12}$')]
    [System.String]
    $AuditGuid

    [DscProperty()]
    [Nullable[System.Boolean]]
    $ReserveDiskSpace

    [DscProperty()]
    [Nullable[System.Boolean]]
    $Enabled

    [DscProperty()]
    [Ensure]
    $Ensure = [Ensure]::Present

    [DscProperty()]
    [Nullable[System.Boolean]]
    $Force

    SqlAudit () : base ()
    {
        # These properties will not be enforced.
        $this.ExcludeDscProperties = @(
            'ServerName'
            'InstanceName'
            'Name'
            'Credential'
            'Force'
        )
    }

    [SqlAudit] Get()
    {
        # Call the base method to return the properties.
        return ([ResourceBase] $this).Get()
    }

    [System.Boolean] Test()
    {
        # Call the base method to test all of the properties that should be enforced.
        return ([ResourceBase] $this).Test()
    }

    [void] Set()
    {
        # Call the base method to enforce the properties.
        ([ResourceBase] $this).Set()
    }

    <#
        Base method Get() call this method to get the current state as a hashtable.
        The parameter properties will contain the key properties.
    #>
    hidden [System.Collections.Hashtable] GetCurrentState([System.Collections.Hashtable] $properties)
    {
        Write-Verbose -Message (
            $this.localizedData.EvaluateServerAudit -f @(
                $properties.Name,
                $properties.InstanceName
            )
        )

        $currentStateCredential = $null

        if ($this.Credential)
        {
            <#
                This does not work, even if username is set, the method Get() will
                return an empty PSCredential-object. Kept it here so it at least
                return a Credential object.
            #>
            $currentStateCredential = [PSCredential]::new(
                $this.Credential.UserName,
                [SecureString]::new()
            )
        }

        <#
            Only set key property Name if the audit exist. Base class will set it
            and handle Ensure.
        #>
        $currentState = @{
            Credential   = $currentStateCredential
            InstanceName = $properties.InstanceName
            ServerName   = $this.ServerName
            Force        = $this.Force
        }

        $serverObject = $this.GetServerObject()

        $auditObjectArray = $serverObject |
            Get-SqlDscAudit -Name $properties.Name -ErrorAction 'SilentlyContinue'

        # Pick the only object in the array.
        $auditObject = $auditObjectArray | Select-Object -First 1

        if ($auditObject)
        {
            $currentState.Name = $properties.Name

            if ($auditObject.DestinationType -in @('ApplicationLog', 'SecurityLog'))
            {
                $currentState.LogType = $auditObject.DestinationType.ToString()
            }

            if ($auditObject.FilePath)
            {
                # Remove trailing slash or backslash.
                $currentState.Path = $auditObject.FilePath -replace '[\\|/]*$'
            }

            $currentState.AuditFilter = $auditObject.Filter
            $currentState.MaximumFiles = [System.UInt32] $auditObject.MaximumFiles
            $currentState.MaximumFileSize = [System.UInt32] $auditObject.MaximumFileSize

            # The value of MaximumFileSizeUnit can be zero, so have to check against $null
            if ($null -ne $auditObject.MaximumFileSizeUnit)
            {
                $convertedMaximumFileSizeUnit = (
                    @{
                        0 = 'Megabyte'
                        1 = 'Gigabyte'
                        2 = 'Terabyte'
                    }
                ).($auditObject.MaximumFileSizeUnit.value__)

                $currentState.MaximumFileSizeUnit = $convertedMaximumFileSizeUnit
            }

            $currentState.MaximumRolloverFiles = [System.UInt32] $auditObject.MaximumRolloverFiles
            $currentState.OnFailure = $auditObject.OnFailure
            $currentState.QueueDelay = [System.UInt32] $auditObject.QueueDelay
            $currentState.AuditGuid = $auditObject.Guid
            $currentState.ReserveDiskSpace = $auditObject.ReserveDiskSpace
            $currentState.Enabled = $auditObject.Enabled
        }

        return $currentState
    }

    <#
        Base method Set() call this method with the properties that should be
        enforced are not in desired state. It is not called if all properties
        are in desired state. The variable $properties contain the properties
        that are not in desired state.
    #>
    hidden [void] Modify([System.Collections.Hashtable] $properties)
    {
        $serverObject = $this.GetServerObject()
        $auditObject = $null

        if ($properties.Keys -contains 'Ensure')
        {
            # Evaluate the desired state for property Ensure.
            switch ($properties.Ensure)
            {
                'Present'
                {
                    # Create the audit since it was missing. Always created disabled.
                    $auditObject = $this.CreateAudit()
                }

                'Absent'
                {
                    # Remove the audit since it was present
                    $serverObject | Remove-SqlDscAudit -Name $this.Name -Force
                }
            }
        }
        else
        {
            <#
                Update any properties not in desired state if the audit should be present.
                At this point it is assumed the audit exist since Ensure property was
                in desired state.

                If the desired state happens to be Absent then ignore any properties not
                in desired state (user have in that case wrongly added properties to an
                "absent configuration").
            #>
            if ($this.Ensure -eq [Ensure]::Present)
            {
                $auditObjectArray = $serverObject |
                    Get-SqlDscAudit -Name $this.Name -ErrorAction 'Stop'

                # Pick the only object in the array.
                $auditObject = $auditObjectArray | Select-Object -First 1

                if ($auditObject)
                {
                    $auditIsWrongType = (
                        # If $auditObject.DestinationType is not null.
                        $null -ne $auditObject.DestinationType -and (
                            # Path is not in desired state but the audit is not of type File.
                            $properties.ContainsKey('Path') -and $auditObject.DestinationType -ne 'File'
                        ) -or (
                            # LogType is not in desired state but the audit is of type File.
                            $properties.ContainsKey('LogType') -and $auditObject.DestinationType -eq 'File'
                        )
                    )

                    # Does the audit need to be re-created?
                    if ($auditIsWrongType)
                    {
                        if ($this.Force -eq $true)
                        {
                            $auditObject | Remove-SqlDscAudit -Force

                            $auditObject = $this.CreateAudit()
                        }
                        else
                        {
                            New-InvalidOperationException -Message $this.localizedData.AuditIsWrongType
                        }
                    }
                    else
                    {
                        <#
                            Should evaluate DestinationType so that is does not try to set a
                            File audit property when audit type is of a Log-type.
                        #>
                        if ($null -ne $auditObject.DestinationType -and $auditObject.DestinationType -ne 'File')
                        {
                            # Look for file audit properties not in desired state
                            $fileAuditProperty = $properties.Keys.Where({
                                    $_ -in @(
                                        'Path'
                                        'MaximumFiles'
                                        'MaximumFileSize'
                                        'MaximumFileSizeUnit'
                                        'MaximumRolloverFiles'
                                        'ReserveDiskSpace'
                                    )
                                })

                            # If a property was found, throw an exception.
                            if ($fileAuditProperty.Count -gt 0)
                            {
                                New-InvalidOperationException -Message ($this.localizedData.AuditOfWrongTypeForUseWithProperty -f $auditObject.DestinationType)
                            }
                        }

                        # Get all optional properties that has an assigned value.
                        $assignedOptionalDscProperties = $this | Get-DscProperty -HasValue -Attribute 'Optional' -ExcludeName @(
                            # Remove optional properties that is not an audit property.
                            'ServerName'
                            'Ensure'
                            'Force'
                            'Credential'

                            # Remove this audit property since it must be handled later.
                            'Enabled'
                        )

                        <#
                            Only call Set when there is a property to Set. The property
                            Enabled was ignored, so it could be the only one that was
                            not in desired state (Enabled is handled later).
                        #>
                        if ($assignedOptionalDscProperties.Count -gt 0)
                        {
                            <#
                                This calls Set-SqlDscAudit to set all the desired value
                                even if they were in desired state. Then the no logic is
                                needed to make sure we call using the correct parameter
                                set that Set-SqlDscAudit requires.
                            #>
                            $auditObject | Set-SqlDscAudit @assignedOptionalDscProperties -Force
                        }
                    }
                }
            }
        }

        <#
            If there is an audit object either from a newly created or fetched from
            current state, and if the desired state is Present, evaluate if the
            audit should be enable or disable.
        #>
        if ($auditObject -and $this.Ensure -eq [Ensure]::Present -and $properties.Keys -contains 'Enabled')
        {
            switch ($properties.Enabled)
            {
                $true
                {
                    $serverObject | Enable-SqlDscAudit -Name $this.Name -Force
                }

                $false
                {
                    $serverObject | Disable-SqlDscAudit -Name $this.Name -Force
                }
            }
        }
    }

    <#
        Base method Assert() call this method with the properties that was assigned
        a value.
    #>
    hidden [void] AssertProperties([System.Collections.Hashtable] $properties)
    {
        # The properties MaximumFiles and MaximumRolloverFiles are mutually exclusive.
        $assertBoundParameterParameters = @{
            BoundParameterList     = $properties
            MutuallyExclusiveList1 = @(
                'MaximumFiles'
            )
            MutuallyExclusiveList2 = @(
                'MaximumRolloverFiles'
            )
        }

        Assert-BoundParameter @assertBoundParameterParameters

        # LogType is mutually exclusive from any of the File audit properties.
        $assertBoundParameterParameters = @{
            BoundParameterList     = $properties
            MutuallyExclusiveList1 = @(
                'LogType'
            )
            MutuallyExclusiveList2 = @(
                'Path'
                'MaximumFiles'
                'MaximumFileSize'
                'MaximumFileSizeUnit'
                'MaximumRolloverFiles'
                'ReserveDiskSpace'
            )
        }

        Assert-BoundParameter @assertBoundParameterParameters

        # Get all assigned *FileSize properties.
        $assignedSizeProperty = $properties.Keys.Where({
                $_ -in @(
                    'MaximumFileSize',
                    'MaximumFileSizeUnit'
                )
            })

        <#
            Neither or both of the properties MaximumFileSize and MaximumFileSizeUnit
            must be assigned.
        #>
        if ($assignedSizeProperty.Count -eq 1)
        {
            $errorMessage = $this.localizedData.BothFileSizePropertiesMustBeSet

            New-ArgumentException -ArgumentName 'MaximumFileSize, MaximumFileSizeUnit' -Message $errorMessage
        }

        <#
            Since we cannot use [ValidateScript()], and it is no possible to exclude
            a value in the [ValidateRange()], evaluate so 1 is not assigned.
        #>
        if ($properties.Keys -contains 'MaximumFileSize' -and $properties.MaximumFileSize -eq 1)
        {
            $errorMessage = $this.localizedData.MaximumFileSizeValueInvalid

            New-ArgumentException -ArgumentName 'MaximumFileSize' -Message $errorMessage
        }

        <#
            Since we cannot use [ValidateScript()], and it is no possible to exclude
            a value in the [ValidateRange()], evaluate so 1-999 is not assigned.
        #>
        if ($properties.Keys -contains 'QueueDelay' -and $properties.QueueDelay -in 1..999)
        {
            $errorMessage = $this.localizedData.QueueDelayValueInvalid

            New-ArgumentException -ArgumentName 'QueueDelay' -Message $errorMessage
        }

        # ReserveDiskSpace can only be used with MaximumFiles.
        if ($properties.Keys -contains 'ReserveDiskSpace' -and $properties.Keys -notcontains 'MaximumFiles')
        {
            $errorMessage = $this.localizedData.ReservDiskSpaceWithoutMaximumFiles

            New-ArgumentException -ArgumentName 'ReserveDiskSpace' -Message $errorMessage
        }

        # Test so that the path exists.
        if ($properties.Keys -contains 'Path' -and -not (Test-Path -Path $properties.Path))
        {
            $errorMessage = $this.localizedData.PathInvalid -f $properties.Path

            New-ArgumentException -ArgumentName 'Path' -Message $errorMessage
        }
    }

    <#
        Create and returns the desired audit object. Always created disabled.

        This should return an object of type [Microsoft.SqlServer.Management.Smo.Audit]
        but using that type fails the build process currently.
        See issue https://github.com/dsccommunity/DscResource.DocGenerator/issues/121.
    #>
    hidden [System.Object] CreateAudit()
    {
        # Get all properties that has an assigned value.
        $assignedDscProperties = $this | Get-DscProperty -HasValue -Attribute @(
            'Key'
            'Optional'
        ) -ExcludeName @(
            # Remove properties that is not an audit property.
            'InstanceName'
            'ServerName'
            'Ensure'
            'Force'
            'Credential'

            # Remove this audit property since it must be handled later.
            'Enabled'
        )

        if ($assignedDscProperties.Keys -notcontains 'LogType' -and $assignedDscProperties.Keys -notcontains 'Path')
        {
            New-InvalidOperationException -Message $this.localizedData.CannotCreateNewAudit
        }

        $serverObject = $this.GetServerObject()

        $auditObject = $serverObject | New-SqlDscAudit @assignedDscProperties -Force -PassThru

        return $auditObject
    }
}
#EndRegion '.\Classes\020.SqlAudit.ps1' 601
#Region '.\Classes\020.SqlDatabasePermission.ps1' -1

<#
    .SYNOPSIS
        The `SqlDatabasePermission` DSC resource is used to grant, deny or revoke
        permissions for a user in a database.

    .DESCRIPTION
        The `SqlDatabasePermission` DSC resource is used to grant, deny or revoke
        permissions for a user in a database. For more information about permissions,
        please read the article [Permissions (Database Engine)](https://docs.microsoft.com/en-us/sql/relational-databases/security/permissions-database-engine).

        > [!CAUTION]
        > When revoking permission with PermissionState 'GrantWithGrant', both the
        > grantee and _all the other users the grantee has granted the same permission_
        > _to_, will also get their permission revoked.

        ## Requirements

        * Target machine must be running Windows Server 2012 or later.
        * Target machine must be running SQL Server Database Engine 2012 or later.

        ## Known issues

        All issues are not listed here, see [here for all open issues](https://github.com/dsccommunity/SqlServerDsc/issues?q=is%3Aissue+is%3Aopen+in%3Atitle+SqlDatabasePermission).

        ### `PSDscRunAsCredential` not supported

        The built-in property `PSDscRunAsCredential` does not work with class-based
        resources that using advanced type like the parameters `Permission` and
        `Reasons` has. Use the parameter `Credential` instead of `PSDscRunAsCredential`.

        ### Using `Credential` property.

        SQL Authentication and Group Managed Service Accounts is not supported as
        impersonation credentials. Currently only Windows Integrated Security is
        supported to use as credentials.

        For Windows Authentication the username must either be provided with the User
        Principal Name (UPN), e.g. 'username@domain.local' or if using non-domain
        (for example a local Windows Server account) account the username must be
        provided without the NetBIOS name, e.g. 'username'. The format 'DOMAIN\username'
        will not work.

        See more information in [Credential Overview](https://github.com/dsccommunity/SqlServerDsc/wiki/CredentialOverview).

        ### Invalid values during compilation

        The parameter Permission is of type `[DatabasePermission]`. If a property
        in the type is set to an invalid value an error will occur, correct the
        values in the properties to valid values.
        This happens when the values are validated against the `[ValidateSet()]`
        of the resource. When there is an invalid value the following error will
        be thrown when the configuration is run (it will not show during compilation):

        ```plaintext
        Failed to create an object of PowerShell class SqlDatabasePermission.
            + CategoryInfo          : InvalidOperation: (root/Microsoft/...ConfigurationManager:String) [], CimException
            + FullyQualifiedErrorId : InstantiatePSClassObjectFailed
            + PSComputerName        : localhost
        ```

    .PARAMETER DatabaseName
        The name of the database.

    .PARAMETER Name
        The name of the user that should be granted or denied the permission.

    .PARAMETER Permission
        An array of database permissions to enforce. Any permission that is not
        part of the desired state will be revoked.

        Must provide all permission states (`Grant`, `Deny`, `GrantWithGrant`) with
        at least an empty string array for the advanced type `DatabasePermission`'s
        property `Permission`.

        Valid permission names can be found in the article [DatabasePermissionSet Class properties](https://docs.microsoft.com/en-us/dotnet/api/microsoft.sqlserver.management.smo.databasepermissionset#properties).

        This is an array of CIM instances of advanced type `DatabasePermission` from
        the namespace `root/Microsoft/Windows/DesiredStateConfiguration`.

    .PARAMETER PermissionToInclude
        An array of database permissions to include to the current state. The
        current state will not be affected unless the current state contradict the
        desired state. For example if the desired state specifies a deny permissions
        but in the current state that permission is granted, that permission will
        be changed to be denied.

        Valid permission names can be found in the article [DatabasePermissionSet Class properties](https://docs.microsoft.com/en-us/dotnet/api/microsoft.sqlserver.management.smo.databasepermissionset#properties).

        This is an array of CIM instances of advanced type `DatabasePermission` from
        the namespace `root/Microsoft/Windows/DesiredStateConfiguration`.

    .PARAMETER PermissionToExclude
        An array of database permissions to exclude (revoke) from the current state.

        Valid permission names can be found in the article [DatabasePermissionSet Class properties](https://docs.microsoft.com/en-us/dotnet/api/microsoft.sqlserver.management.smo.databasepermissionset#properties).

        This is an array of CIM instances of advanced type `DatabasePermission` from
        the namespace `root/Microsoft/Windows/DesiredStateConfiguration`.

    .EXAMPLE
        Invoke-DscResource -ModuleName SqlServerDsc -Name SqlDatabasePermission -Method Get -Property @{
            ServerName           = 'localhost'
            InstanceName         = 'SQL2017'
            DatabaseName         = 'AdventureWorks'
            Credential           = (Get-Credential -UserName 'myuser@company.local' -Message 'Password:')
            Name                 = 'INSTANCE\SqlUser'
            Permission           = [Microsoft.Management.Infrastructure.CimInstance[]] @(
                (
                    New-CimInstance -ClientOnly -Namespace root/Microsoft/Windows/DesiredStateConfiguration -ClassName DatabasePermission -Property @{
                            State = 'Grant'
                            Permission = @('select')
                    }
                )
                (
                    New-CimInstance -ClientOnly -Namespace root/Microsoft/Windows/DesiredStateConfiguration -ClassName DatabasePermission -Property @{
                        State = 'GrantWithGrant'
                        Permission = [System.String[]] @()
                    }
                )
                (
                    New-CimInstance -ClientOnly -Namespace root/Microsoft/Windows/DesiredStateConfiguration -ClassName DatabasePermission -Property @{
                        State = 'Deny'
                        Permission = [System.String[]] @()
                    }
                )
            )
        }

        This example shows how to call the resource using Invoke-DscResource.

    .NOTES
        The built-in property `PsDscRunAsCredential` is not supported on this DSC
        resource as it uses a complex type (another class as the type for a DSC
        property). If the property `PsDscRunAsCredential` would be used, then the
        complex type will not return any values from Get(). This is most likely an
        issue (bug) with _PowerShell DSC_. Instead (as a workaround) the property
        `Credential` must be used to specify how to connect to the _SQL Server_
        instance.
#>

[DscResource(RunAsCredential = 'NotSupported')]
class SqlDatabasePermission : SqlResourceBase
{
    [DscProperty(Key)]
    [System.String]
    $DatabaseName

    [DscProperty(Key)]
    [System.String]
    $Name

    [DscProperty()]
    [DatabasePermission[]]
    $Permission

    [DscProperty()]
    [DatabasePermission[]]
    $PermissionToInclude

    [DscProperty()]
    [DatabasePermission[]]
    $PermissionToExclude

    SqlDatabasePermission() : base ()
    {
        # These properties will not be enforced.
        $this.ExcludeDscProperties = @(
            'ServerName'
            'InstanceName'
            'DatabaseName'
            'Name'
            'Credential'
        )
    }

    [SqlDatabasePermission] Get()
    {
        # Call the base method to return the properties.
        return ([ResourceBase] $this).Get()
    }

    [System.Boolean] Test()
    {
        # Call the base method to test all of the properties that should be enforced.
        return ([ResourceBase] $this).Test()
    }

    [void] Set()
    {
        # Call the base method to enforce the properties.
        ([ResourceBase] $this).Set()
    }

    <#
        Base method Get() call this method to get the current state as a hashtable.
        The parameter properties will contain the key properties.
    #>
    hidden [System.Collections.Hashtable] GetCurrentState([System.Collections.Hashtable] $properties)
    {
        $currentStateCredential = $null

        if ($this.Credential)
        {
            <#
                This does not work, even if username is set, the method Get() will
                return an empty PSCredential-object. Kept it here so it at least
                return a Credential object.
            #>
            $currentStateCredential = [PSCredential]::new(
                $this.Credential.UserName,
                [SecureString]::new()
            )
        }

        $currentState = @{
            Credential = $currentStateCredential
            Permission = [DatabasePermission[]] @()
        }

        Write-Verbose -Message (
            $this.localizedData.EvaluateDatabasePermissionForPrincipal -f @(
                $properties.Name,
                $properties.DatabaseName,
                $properties.InstanceName
            )
        )

        $serverObject = $this.GetServerObject()

        $databasePermissionInfo = $serverObject |
            Get-SqlDscDatabasePermission -DatabaseName $this.DatabaseName -Name $this.Name -ErrorAction 'SilentlyContinue'

        # If permissions was returned, build the current permission array of [DatabasePermission].
        if ($databasePermissionInfo)
        {
            [DatabasePermission[]] $currentState.Permission = $databasePermissionInfo | ConvertTo-SqlDscDatabasePermission
        }

        # Always return all State; 'Grant', 'GrantWithGrant', and 'Deny'.
        foreach ($currentPermissionState in @('Grant', 'GrantWithGrant', 'Deny'))
        {
            if ($currentState.Permission.State -notcontains $currentPermissionState)
            {
                [DatabasePermission[]] $currentState.Permission += [DatabasePermission] @{
                    State      = $currentPermissionState
                    Permission = @()
                }
            }
        }

        $isPropertyPermissionToIncludeAssigned = $this | Test-DscProperty -Name 'PermissionToInclude' -HasValue

        if ($isPropertyPermissionToIncludeAssigned)
        {
            $currentState.PermissionToInclude = [DatabasePermission[]] @()

            # Evaluate so that the desired state is present in the current state.
            foreach ($desiredIncludePermission in $this.PermissionToInclude)
            {
                <#
                    Current state will always have all possible states, so this
                    will always return one item.
                #>
                $currentStatePermissionForState = $currentState.Permission |
                    Where-Object -FilterScript {
                        $_.State -eq $desiredIncludePermission.State
                    }

                $currentStatePermissionToInclude = [DatabasePermission] @{
                    State      = $desiredIncludePermission.State
                    Permission = @()
                }

                foreach ($desiredIncludePermissionName in $desiredIncludePermission.Permission)
                {
                    if ($currentStatePermissionForState.Permission -contains $desiredIncludePermissionName)
                    {
                        <#
                            If the permission exist in the current state, add the
                            permission to $currentState.PermissionToInclude so that
                            the base class's method Compare() sees the property as
                            being in desired state (when the property PermissionToInclude
                            in the current state and desired state are equal).
                        #>
                        $currentStatePermissionToInclude.Permission += $desiredIncludePermissionName
                    }
                    else
                    {
                        Write-Verbose -Message (
                            $this.localizedData.DesiredPermissionAreAbsent -f @(
                                $desiredIncludePermissionName
                            )
                        )
                    }
                }

                [DatabasePermission[]] $currentState.PermissionToInclude += $currentStatePermissionToInclude
            }
        }

        $isPropertyPermissionToExcludeAssigned = $this | Test-DscProperty -Name 'PermissionToExclude' -HasValue

        if ($isPropertyPermissionToExcludeAssigned)
        {
            $currentState.PermissionToExclude = [DatabasePermission[]] @()

            # Evaluate so that the desired state is missing from the current state.
            foreach ($desiredExcludePermission in $this.PermissionToExclude)
            {
                <#
                    Current state will always have all possible states, so this
                    will always return one item.
                #>
                $currentStatePermissionForState = $currentState.Permission |
                    Where-Object -FilterScript {
                        $_.State -eq $desiredExcludePermission.State
                    }

                $currentStatePermissionToExclude = [DatabasePermission] @{
                    State      = $desiredExcludePermission.State
                    Permission = @()
                }

                foreach ($desiredExcludedPermissionName in $desiredExcludePermission.Permission)
                {
                    if ($currentStatePermissionForState.Permission -contains $desiredExcludedPermissionName)
                    {
                        Write-Verbose -Message (
                            $this.localizedData.DesiredAbsentPermissionArePresent -f @(
                                $desiredExcludedPermissionName
                            )
                        )
                    }
                    else
                    {
                        <#
                            If the permission does _not_ exist in the current state, add
                            the permission to $currentState.PermissionToExclude so that
                            the base class's method Compare() sees the property as being
                            in desired state (when the property PermissionToExclude in
                            the current state and desired state are equal).
                        #>
                        $currentStatePermissionToExclude.Permission += $desiredExcludedPermissionName
                    }
                }

                [DatabasePermission[]] $currentState.PermissionToExclude += $currentStatePermissionToExclude
            }
        }

        return $currentState
    }

    <#
        Base method Set() call this method with the properties that should be
        enforced are not in desired state. It is not called if all properties
        are in desired state. The variable $properties contain the properties
        that are not in desired state.
    #>
    hidden [void] Modify([System.Collections.Hashtable] $properties)
    {
        $serverObject = $this.GetServerObject()

        $testSqlDscIsDatabasePrincipalParameters = @{
            ServerObject      = $serverObject
            DatabaseName      = $this.DatabaseName
            Name              = $this.Name
            ExcludeFixedRoles = $true
        }

        # This will test wether the database and the principal exist.
        $isDatabasePrincipal = Test-SqlDscIsDatabasePrincipal @testSqlDscIsDatabasePrincipalParameters

        if (-not $isDatabasePrincipal)
        {
            $missingPrincipalMessage = $this.localizedData.NameIsMissing -f @(
                $this.Name,
                $this.DatabaseName,
                $this.InstanceName
            )

            New-InvalidOperationException -Message $missingPrincipalMessage
        }

        # This holds each state and their permissions to be revoked.
        [DatabasePermission[]] $permissionsToRevoke = @()
        [DatabasePermission[]] $permissionsToGrantOrDeny = @()

        if ($properties.ContainsKey('Permission'))
        {
            $keyProperty = $this | Get-DscProperty -Attribute 'Key'

            $currentState = $this.GetCurrentState($keyProperty)

            <#
                Evaluate if there are any permissions that should be revoked
                from the current state.
            #>
            foreach ($currentDesiredPermissionState in $properties.Permission)
            {
                $currentPermissionsForState = $currentState.Permission |
                    Where-Object -FilterScript {
                        $_.State -eq $currentDesiredPermissionState.State
                    }

                foreach ($permissionName in $currentPermissionsForState.Permission)
                {
                    if ($permissionName -notin $currentDesiredPermissionState.Permission)
                    {
                        # Look for an existing object in the array.
                        $updatePermissionToRevoke = $permissionsToRevoke |
                            Where-Object -FilterScript {
                                $_.State -eq $currentDesiredPermissionState.State
                            }

                        # Update the existing object in the array, or create a new object
                        if ($updatePermissionToRevoke)
                        {
                            $updatePermissionToRevoke.Permission += $permissionName
                        }
                        else
                        {
                            [DatabasePermission[]] $permissionsToRevoke += [DatabasePermission] @{
                                State      = $currentPermissionsForState.State
                                Permission = $permissionName
                            }
                        }
                    }
                }
            }

            <#
                At least one permission were missing or should have not be present
                in the current state. Grant or Deny all permission assigned to the
                property Permission regardless if they were already present or not.
            #>
            [DatabasePermission[]] $permissionsToGrantOrDeny = $properties.Permission
        }

        if ($properties.ContainsKey('PermissionToExclude'))
        {
            <#
                At least one permission were present in the current state. Revoke
                all permission assigned to the property PermissionToExclude
                regardless if they were already revoked or not.
            #>
            [DatabasePermission[]] $permissionsToRevoke = $properties.PermissionToExclude
        }

        if ($properties.ContainsKey('PermissionToInclude'))
        {
            <#
                At least one permission were missing or should have not be present
                in the current state. Grant or Deny all permission assigned to the
                property Permission regardless if they were already present or not.
            #>
            [DatabasePermission[]] $permissionsToGrantOrDeny = $properties.PermissionToInclude
        }

        # Revoke all the permissions set in $permissionsToRevoke
        if ($permissionsToRevoke)
        {
            foreach ($currentStateToRevoke in $permissionsToRevoke)
            {
                $revokePermissionSet = $currentStateToRevoke | ConvertFrom-SqlDscDatabasePermission

                $setSqlDscDatabasePermissionParameters = @{
                    ServerObject = $serverObject
                    DatabaseName = $this.DatabaseName
                    Name         = $this.Name
                    Permission   = $revokePermissionSet
                    State        = 'Revoke'
                    Force        = $true
                }

                if ($currentStateToRevoke.State -eq 'GrantWithGrant')
                {
                    $setSqlDscDatabasePermissionParameters.WithGrant = $true
                }

                try
                {
                    Set-SqlDscDatabasePermission @setSqlDscDatabasePermissionParameters
                }
                catch
                {
                    $errorMessage = $this.localizedData.FailedToRevokePermissionFromCurrentState -f @(
                        $this.Name,
                        $this.DatabaseName
                    )

                    New-InvalidOperationException -Message $errorMessage -ErrorRecord $_
                }
            }
        }

        if ($permissionsToGrantOrDeny)
        {
            foreach ($currentDesiredPermissionState in $permissionsToGrantOrDeny)
            {
                # If there is not an empty array, change permissions.
                if (-not [System.String]::IsNullOrEmpty($currentDesiredPermissionState.Permission))
                {
                    $permissionSet = $currentDesiredPermissionState | ConvertFrom-SqlDscDatabasePermission

                    $setSqlDscDatabasePermissionParameters = @{
                        ServerObject = $serverObject
                        DatabaseName = $this.DatabaseName
                        Name         = $this.Name
                        Permission   = $permissionSet
                        Force        = $true
                    }

                    try
                    {
                        switch ($currentDesiredPermissionState.State)
                        {
                            'GrantWithGrant'
                            {
                                Set-SqlDscDatabasePermission @setSqlDscDatabasePermissionParameters -State 'Grant' -WithGrant
                            }

                            default
                            {
                                Set-SqlDscDatabasePermission @setSqlDscDatabasePermissionParameters -State $currentDesiredPermissionState.State
                            }
                        }
                    }
                    catch
                    {
                        $errorMessage = $this.localizedData.FailedToSetPermission -f @(
                            $this.Name,
                            $this.DatabaseName
                        )

                        New-InvalidOperationException -Message $errorMessage -ErrorRecord $_
                    }
                }
            }
        }
    }

    <#
        Base method Assert() call this method with the properties that was assigned
        a value.
    #>
    hidden [void] AssertProperties([System.Collections.Hashtable] $properties)
    {
        # PermissionToInclude and PermissionToExclude should be mutually exclusive from Permission
        $assertBoundParameterParameters = @{
            BoundParameterList     = $properties
            MutuallyExclusiveList1 = @(
                'Permission'
            )
            MutuallyExclusiveList2 = @(
                'PermissionToInclude'
                'PermissionToExclude'
            )
        }

        Assert-BoundParameter @assertBoundParameterParameters

        # Get all assigned permission properties.
        $assignedPermissionProperty = $properties.Keys.Where({
                $_ -in @(
                    'Permission',
                    'PermissionToInclude',
                    'PermissionToExclude'
                )
            })

        # Must include either of the permission properties.
        if ([System.String]::IsNullOrEmpty($assignedPermissionProperty))
        {
            $errorMessage = $this.localizedData.MustAssignOnePermissionProperty

            New-ArgumentException -ArgumentName 'Permission, PermissionToInclude, PermissionToExclude' -Message $errorMessage
        }

        foreach ($currentAssignedPermissionProperty in $assignedPermissionProperty)
        {
            # One State cannot exist several times in the same resource instance.
            $permissionStateGroupCount = @(
                $properties.$currentAssignedPermissionProperty |
                    Group-Object -NoElement -Property 'State' -CaseSensitive:$false |
                    Select-Object -ExpandProperty 'Count'
            )

            if ($permissionStateGroupCount -gt 1)
            {
                $errorMessage = $this.localizedData.DuplicatePermissionState

                New-ArgumentException -ArgumentName $currentAssignedPermissionProperty -Message $errorMessage
            }

            # A specific permission must only exist in one permission state.
            $permissionGroupCount = $properties.$currentAssignedPermissionProperty.Permission |
                Group-Object -NoElement -CaseSensitive:$false |
                Select-Object -ExpandProperty 'Count'

            if ($permissionGroupCount -gt 1)
            {
                $errorMessage = $this.localizedData.DuplicatePermissionBetweenState

                New-ArgumentException -ArgumentName $currentAssignedPermissionProperty -Message $errorMessage
            }
        }

        if ($properties.Keys -contains 'Permission')
        {
            # Each State must exist once.
            $missingPermissionState = (
                $properties.Permission.State -notcontains 'Grant' -or
                $properties.Permission.State -notcontains 'GrantWithGrant' -or
                $properties.Permission.State -notcontains 'Deny'
            )

            if ($missingPermissionState)
            {
                $errorMessage = $this.localizedData.MissingPermissionState

                New-ArgumentException -ArgumentName 'Permission' -Message $errorMessage
            }
        }

        <#
            Each permission state in the properties PermissionToInclude and PermissionToExclude
            must have specified at minimum one permission.
        #>
        foreach ($currentAssignedPermissionProperty in @('PermissionToInclude', 'PermissionToExclude'))
        {
            if ($properties.Keys -contains $currentAssignedPermissionProperty)
            {
                foreach ($currentDatabasePermission in $properties.$currentAssignedPermissionProperty)
                {
                    if ($currentDatabasePermission.Permission.Count -eq 0)
                    {
                        $errorMessage = $this.localizedData.MustHaveMinimumOnePermissionInState -f $currentAssignedPermissionProperty

                        New-ArgumentException -ArgumentName $currentAssignedPermissionProperty -Message $errorMessage
                    }
                }
            }
        }
    }
}
#EndRegion '.\Classes\020.SqlDatabasePermission.ps1' 647
#Region '.\Classes\020.SqlPermission.ps1' -1

<#
    .SYNOPSIS
        The `SqlPermission` DSC resource is used to grant, deny or revoke
        server permissions for a login.

    .DESCRIPTION
        The `SqlPermission` DSC resource is used to grant, deny or revoke
        Server permissions for a login. For more information about permissions,
        please read the article [Permissions (Database Engine)](https://docs.microsoft.com/en-us/sql/relational-databases/security/permissions-database-engine).

        > [!CAUTION]
        > When revoking permission with PermissionState 'GrantWithGrant', both the
        > grantee and _all the other users the grantee has granted the same permission_
        > _to_, will also get their permission revoked.

        ## Requirements

        * Target machine must be running Windows Server 2012 or later.
        * Target machine must be running SQL Server Database Engine 2012 or later.
        * Target machine must have access to the SQLPS PowerShell module or the SqlServer
          PowerShell module.

        ## Known issues

        All issues are not listed here, see [here for all open issues](https://github.com/dsccommunity/SqlServerDsc/issues?q=is%3Aissue+is%3Aopen+in%3Atitle+SqlPermission).

        ### `PSDscRunAsCredential` not supported

        The built-in property `PSDscRunAsCredential` does not work with class-based
        resources that using advanced type like the parameters `Permission` and
        `Reasons` has. Use the parameter `Credential` instead of `PSDscRunAsCredential`.

        ### Using `Credential` property.

        SQL Authentication and Group Managed Service Accounts is not supported as
        impersonation credentials. Currently only Windows Integrated Security is
        supported to use as credentials.

        For Windows Authentication the username must either be provided with the User
        Principal Name (UPN), e.g. 'username@domain.local' or if using non-domain
        (for example a local Windows Server account) account the username must be
        provided without the NetBIOS name, e.g. 'username'. The format 'DOMAIN\username'
        will not work.

        See more information in [Credential Overview](https://github.com/dsccommunity/SqlServerDsc/wiki/CredentialOverview).

        ### Invalid values during compilation

        The parameter Permission is of type `[ServerPermission]`. If a property
        in the type is set to an invalid value an error will occur, correct the
        values in the properties to valid values.
        This happens when the values are validated against the `[ValidateSet()]`
        of the resource. When there is an invalid value the following error will
        be thrown when the configuration is run (it will not show during compilation):

        ```plaintext
        Failed to create an object of PowerShell class SqlPermission.
            + CategoryInfo          : InvalidOperation: (root/Microsoft/...ConfigurationManager:String) [], CimException
            + FullyQualifiedErrorId : InstantiatePSClassObjectFailed
            + PSComputerName        : localhost
        ```

    .PARAMETER Name
        The name of the user that should be granted or denied the permission.

    .PARAMETER Permission
        An array of server permissions to enforce. Any permission that is not
        part of the desired state will be revoked.

        Must provide all permission states (`Grant`, `Deny`, `GrantWithGrant`) with
        at least an empty string array for the advanced type `ServerPermission`'s
        property `Permission`.

        Valid permission names can be found in the article [ServerPermissionSet Class properties](https://docs.microsoft.com/en-us/dotnet/api/microsoft.sqlserver.management.smo.serverpermissionset#properties).

        This is an array of CIM instances of advanced type `ServerPermission` from
        the namespace `root/Microsoft/Windows/DesiredStateConfiguration`.

    .PARAMETER PermissionToInclude
        An array of server permissions to include to the current state. The
        current state will not be affected unless the current state contradict the
        desired state. For example if the desired state specifies a deny permissions
        but in the current state that permission is granted, that permission will
        be changed to be denied.

        Valid permission names can be found in the article [ServerPermissionSet Class properties](https://docs.microsoft.com/en-us/dotnet/api/microsoft.sqlserver.management.smo.serverpermissionset#properties).

        This is an array of CIM instances of advanced type `ServerPermission` from
        the namespace `root/Microsoft/Windows/DesiredStateConfiguration`.

    .PARAMETER PermissionToExclude
        An array of server permissions to exclude (revoke) from the current state.

        Valid permission names can be found in the article [ServerPermissionSet Class properties](https://docs.microsoft.com/en-us/dotnet/api/microsoft.sqlserver.management.smo.serverpermissionset#properties).

        This is an array of CIM instances of advanced type `ServerPermission` from
        the namespace `root/Microsoft/Windows/DesiredStateConfiguration`.

    .EXAMPLE
        Invoke-DscResource -ModuleName SqlServerDsc -Name SqlPermission -Method Get -Property @{
            ServerName           = 'localhost'
            InstanceName         = 'SQL2017'
            Credential           = (Get-Credential -UserName 'myuser@company.local' -Message 'Password:')
            Name                 = 'INSTANCE\SqlUser'
            Permission           = [Microsoft.Management.Infrastructure.CimInstance[]] @(
                (
                    New-CimInstance -ClientOnly -Namespace root/Microsoft/Windows/DesiredStateConfiguration -ClassName ServerPermission -Property @{
                            State = 'Grant'
                            Permission = @('select')
                    }
                )
                (
                    New-CimInstance -ClientOnly -Namespace root/Microsoft/Windows/DesiredStateConfiguration -ClassName ServerPermission -Property @{
                        State = 'GrantWithGrant'
                        Permission = [System.String[]] @()
                    }
                )
                (
                    New-CimInstance -ClientOnly -Namespace root/Microsoft/Windows/DesiredStateConfiguration -ClassName ServerPermission -Property @{
                        State = 'Deny'
                        Permission = [System.String[]] @()
                    }
                )
            )
        }

        This example shows how to call the resource using Invoke-DscResource.

    .NOTES
        The built-in property `PsDscRunAsCredential` is not supported on this DSC
        resource as it uses a complex type (another class as the type for a DSC
        property). If the property `PsDscRunAsCredential` would be used, then the
        complex type will not return any values from Get(). This is most likely an
        issue (bug) with _PowerShell DSC_. Instead (as a workaround) the property
        `Credential` must be used to specify how to connect to the SQL Server
        instance.
#>

[DscResource(RunAsCredential = 'NotSupported')]
class SqlPermission : SqlResourceBase
{
    [DscProperty(Key)]
    [System.String]
    $Name

    [DscProperty()]
    [ServerPermission[]]
    $Permission

    [DscProperty()]
    [ServerPermission[]]
    $PermissionToInclude

    [DscProperty()]
    [ServerPermission[]]
    $PermissionToExclude

    SqlPermission() : base ()
    {
        # These properties will not be enforced.
        $this.ExcludeDscProperties = @(
            'ServerName'
            'InstanceName'
            'Name'
            'Credential'
        )
    }

    [SqlPermission] Get()
    {
        # Call the base method to return the properties.
        return ([ResourceBase] $this).Get()
    }

    [System.Boolean] Test()
    {
        # Call the base method to test all of the properties that should be enforced.
        return ([ResourceBase] $this).Test()
    }

    [void] Set()
    {
        # Call the base method to enforce the properties.
        ([ResourceBase] $this).Set()
    }

    <#
        Base method Get() call this method to get the current state as a hashtable.
        The parameter properties will contain the key properties.
    #>
    hidden [System.Collections.Hashtable] GetCurrentState([System.Collections.Hashtable] $properties)
    {
        $currentStateCredential = $null

        if ($this.Credential)
        {
            <#
                This does not work, even if username is set, the method Get() will
                return an empty PSCredential-object. Kept it here so it at least
                return a Credential object.
            #>
            $currentStateCredential = [PSCredential]::new(
                $this.Credential.UserName,
                [SecureString]::new()
            )
        }

        $currentState = @{
            Credential = $currentStateCredential
            Permission = [ServerPermission[]] @()
        }

        Write-Verbose -Message (
            $this.localizedData.EvaluateServerPermissionForPrincipal -f @(
                $properties.Name,
                $properties.InstanceName
            )
        )

        $serverObject = $this.GetServerObject()

        $serverPermissionInfo = $serverObject |
            Get-SqlDscServerPermission -Name $this.Name -ErrorAction 'SilentlyContinue'

        # If permissions was returned, build the current permission array of [ServerPermission].
        if ($serverPermissionInfo)
        {
            [ServerPermission[]] $currentState.Permission = $serverPermissionInfo | ConvertTo-SqlDscServerPermission
        }

        # Always return all State; 'Grant', 'GrantWithGrant', and 'Deny'.
        foreach ($currentPermissionState in @('Grant', 'GrantWithGrant', 'Deny'))
        {
            if ($currentState.Permission.State -notcontains $currentPermissionState)
            {
                [ServerPermission[]] $currentState.Permission += [ServerPermission] @{
                    State      = $currentPermissionState
                    Permission = @()
                }
            }
        }

        $isPropertyPermissionToIncludeAssigned = $this | Test-DscProperty -Name 'PermissionToInclude' -HasValue

        if ($isPropertyPermissionToIncludeAssigned)
        {
            $currentState.PermissionToInclude = [ServerPermission[]] @()

            # Evaluate so that the desired state is present in the current state.
            foreach ($desiredIncludePermission in $this.PermissionToInclude)
            {
                <#
                    Current state will always have all possible states, so this
                    will always return one item.
                #>
                $currentStatePermissionForState = $currentState.Permission |
                    Where-Object -FilterScript {
                        $_.State -eq $desiredIncludePermission.State
                    }

                $currentStatePermissionToInclude = [ServerPermission] @{
                    State      = $desiredIncludePermission.State
                    Permission = @()
                }

                foreach ($desiredIncludePermissionName in $desiredIncludePermission.Permission)
                {
                    if ($currentStatePermissionForState.Permission -contains $desiredIncludePermissionName)
                    {
                        <#
                            If the permission exist in the current state, add the
                            permission to $currentState.PermissionToInclude so that
                            the base class's method Compare() sees the property as
                            being in desired state (when the property PermissionToInclude
                            in the current state and desired state are equal).
                        #>
                        $currentStatePermissionToInclude.Permission += $desiredIncludePermissionName
                    }
                    else
                    {
                        Write-Verbose -Message (
                            $this.localizedData.DesiredPermissionAreAbsent -f @(
                                $desiredIncludePermissionName
                            )
                        )
                    }
                }

                [ServerPermission[]] $currentState.PermissionToInclude += $currentStatePermissionToInclude
            }
        }

        $isPropertyPermissionToExcludeAssigned = $this | Test-DscProperty -Name 'PermissionToExclude' -HasValue

        if ($isPropertyPermissionToExcludeAssigned)
        {
            $currentState.PermissionToExclude = [ServerPermission[]] @()

            # Evaluate so that the desired state is missing from the current state.
            foreach ($desiredExcludePermission in $this.PermissionToExclude)
            {
                <#
                    Current state will always have all possible states, so this
                    will always return one item.
                #>
                $currentStatePermissionForState = $currentState.Permission |
                    Where-Object -FilterScript {
                        $_.State -eq $desiredExcludePermission.State
                    }

                $currentStatePermissionToExclude = [ServerPermission] @{
                    State      = $desiredExcludePermission.State
                    Permission = @()
                }

                foreach ($desiredExcludedPermissionName in $desiredExcludePermission.Permission)
                {
                    if ($currentStatePermissionForState.Permission -contains $desiredExcludedPermissionName)
                    {
                        Write-Verbose -Message (
                            $this.localizedData.DesiredAbsentPermissionArePresent -f @(
                                $desiredExcludedPermissionName
                            )
                        )
                    }
                    else
                    {
                        <#
                            If the permission does _not_ exist in the current state, add
                            the permission to $currentState.PermissionToExclude so that
                            the base class's method Compare() sees the property as being
                            in desired state (when the property PermissionToExclude in
                            the current state and desired state are equal).
                        #>
                        $currentStatePermissionToExclude.Permission += $desiredExcludedPermissionName
                    }
                }

                [ServerPermission[]] $currentState.PermissionToExclude += $currentStatePermissionToExclude
            }
        }

        return $currentState
    }

    <#
        Base method Set() call this method with the properties that should be
        enforced are not in desired state. It is not called if all properties
        are in desired state. The variable $properties contain the properties
        that are not in desired state.
    #>
    hidden [void] Modify([System.Collections.Hashtable] $properties)
    {
        $serverObject = $this.GetServerObject()

        $testSqlDscIsLoginParameters = @{
            ServerObject = $serverObject
            Name         = $this.Name
        }

        # This will test wether the principal exist.
        $isLogin = Test-SqlDscIsLogin @testSqlDscIsLoginParameters

        if (-not $isLogin)
        {
            $missingPrincipalMessage = $this.localizedData.NameIsMissing -f @(
                $this.Name,
                $this.InstanceName
            )

            New-InvalidOperationException -Message $missingPrincipalMessage
        }

        # This holds each state and their permissions to be revoked.
        [ServerPermission[]] $permissionsToRevoke = @()
        [ServerPermission[]] $permissionsToGrantOrDeny = @()

        if ($properties.ContainsKey('Permission'))
        {
            $keyProperty = $this | Get-DscProperty -Attribute 'Key'

            $currentState = $this.GetCurrentState($keyProperty)

            <#
                Evaluate if there are any permissions that should be revoked
                from the current state.
            #>
            foreach ($currentDesiredPermissionState in $properties.Permission)
            {
                $currentPermissionsForState = $currentState.Permission |
                    Where-Object -FilterScript {
                        $_.State -eq $currentDesiredPermissionState.State
                    }

                foreach ($permissionName in $currentPermissionsForState.Permission)
                {
                    if ($permissionName -notin $currentDesiredPermissionState.Permission)
                    {
                        # Look for an existing object in the array.
                        $updatePermissionToRevoke = $permissionsToRevoke |
                            Where-Object -FilterScript {
                                $_.State -eq $currentDesiredPermissionState.State
                            }

                        # Update the existing object in the array, or create a new object
                        if ($updatePermissionToRevoke)
                        {
                            $updatePermissionToRevoke.Permission += $permissionName
                        }
                        else
                        {
                            [ServerPermission[]] $permissionsToRevoke += [ServerPermission] @{
                                State      = $currentPermissionsForState.State
                                Permission = $permissionName
                            }
                        }
                    }
                }
            }

            <#
                At least one permission were missing or should have not be present
                in the current state. Grant or Deny all permission assigned to the
                property Permission regardless if they were already present or not.
            #>
            [ServerPermission[]] $permissionsToGrantOrDeny = $properties.Permission
        }

        if ($properties.ContainsKey('PermissionToExclude'))
        {
            <#
                At least one permission were present in the current state. Revoke
                all permission assigned to the property PermissionToExclude
                regardless if they were already revoked or not.
            #>
            [ServerPermission[]] $permissionsToRevoke = $properties.PermissionToExclude
        }

        if ($properties.ContainsKey('PermissionToInclude'))
        {
            <#
                At least one permission were missing or should have not be present
                in the current state. Grant or Deny all permission assigned to the
                property Permission regardless if they were already present or not.
            #>
            [ServerPermission[]] $permissionsToGrantOrDeny = $properties.PermissionToInclude
        }

        # Revoke all the permissions set in $permissionsToRevoke
        if ($permissionsToRevoke)
        {
            <#
                TODO: Could verify with $sqlServerObject.EnumServerPermissions($Principal, $desiredPermissionSet)
                      which permissions are not already revoked.
            #>
            foreach ($currentStateToRevoke in $permissionsToRevoke)
            {
                $revokePermissionSet = $currentStateToRevoke | ConvertFrom-SqlDscServerPermission

                $setSqlDscServerPermissionParameters = @{
                    ServerObject = $serverObject
                    Name         = $this.Name
                    Permission   = $revokePermissionSet
                    State        = 'Revoke'
                    Force        = $true
                }

                if ($currentStateToRevoke.State -eq 'GrantWithGrant')
                {
                    $setSqlDscServerPermissionParameters.WithGrant = $true
                }

                try
                {
                    Set-SqlDscServerPermission @setSqlDscServerPermissionParameters
                }
                catch
                {
                    $errorMessage = $this.localizedData.FailedToRevokePermissionFromCurrentState -f @(
                        $this.Name
                    )

                    New-InvalidOperationException -Message $errorMessage -ErrorRecord $_
                }
            }
        }

        if ($permissionsToGrantOrDeny)
        {
            <#
                TODO: Could verify with $sqlServerObject.EnumServerPermissions($Principal, $desiredPermissionSet)
                      which permissions are not already set.
            #>
            foreach ($currentDesiredPermissionState in $permissionsToGrantOrDeny)
            {
                # If there is not an empty array, change permissions.
                if (-not [System.String]::IsNullOrEmpty($currentDesiredPermissionState.Permission))
                {
                    $permissionSet = $currentDesiredPermissionState | ConvertFrom-SqlDscServerPermission

                    $setSqlDscServerPermissionParameters = @{
                        ServerObject = $serverObject
                        Name         = $this.Name
                        Permission   = $permissionSet
                        Force        = $true
                    }

                    try
                    {
                        switch ($currentDesiredPermissionState.State)
                        {
                            'GrantWithGrant'
                            {
                                Set-SqlDscServerPermission @setSqlDscServerPermissionParameters -State 'Grant' -WithGrant
                            }

                            default
                            {
                                Set-SqlDscServerPermission @setSqlDscServerPermissionParameters -State $currentDesiredPermissionState.State
                            }
                        }
                    }
                    catch
                    {
                        $errorMessage = $this.localizedData.FailedToSetPermission -f @(
                            $this.Name
                        )

                        New-InvalidOperationException -Message $errorMessage -ErrorRecord $_
                    }
                }
            }
        }
    }

    <#
        Base method Assert() call this method with the properties that was assigned
        a value.
    #>
    hidden [void] AssertProperties([System.Collections.Hashtable] $properties)
    {
        # PermissionToInclude and PermissionToExclude should be mutually exclusive from Permission
        $assertBoundParameterParameters = @{
            BoundParameterList     = $properties
            MutuallyExclusiveList1 = @(
                'Permission'
            )
            MutuallyExclusiveList2 = @(
                'PermissionToInclude'
                'PermissionToExclude'
            )
        }

        Assert-BoundParameter @assertBoundParameterParameters

        # Get all assigned permission properties.
        $assignedPermissionProperty = $properties.Keys.Where({
                $_ -in @(
                    'Permission',
                    'PermissionToInclude',
                    'PermissionToExclude'
                )
            })

        # Must include either of the permission properties.
        if ([System.String]::IsNullOrEmpty($assignedPermissionProperty))
        {
            $errorMessage = $this.localizedData.MustAssignOnePermissionProperty

            New-ArgumentException -ArgumentName 'Permission, PermissionToInclude, PermissionToExclude' -Message $errorMessage
        }

        foreach ($currentAssignedPermissionProperty in $assignedPermissionProperty)
        {
            # One State cannot exist several times in the same resource instance.
            $permissionStateGroupCount = @(
                $properties.$currentAssignedPermissionProperty |
                    Group-Object -NoElement -Property 'State' -CaseSensitive:$false |
                    Select-Object -ExpandProperty 'Count'
            )

            if ($permissionStateGroupCount -gt 1)
            {
                $errorMessage = $this.localizedData.DuplicatePermissionState

                New-ArgumentException -ArgumentName $currentAssignedPermissionProperty -Message $errorMessage
            }

            # A specific permission must only exist in one permission state.
            $permissionGroupCount = $properties.$currentAssignedPermissionProperty.Permission |
                Group-Object -NoElement -CaseSensitive:$false |
                Select-Object -ExpandProperty 'Count'

            if ($permissionGroupCount -gt 1)
            {
                $errorMessage = $this.localizedData.DuplicatePermissionBetweenState

                New-ArgumentException -ArgumentName $currentAssignedPermissionProperty -Message $errorMessage
            }
        }

        if ($properties.Keys -contains 'Permission')
        {
            # Each State must exist once.
            $missingPermissionState = (
                $properties.Permission.State -notcontains 'Grant' -or
                $properties.Permission.State -notcontains 'GrantWithGrant' -or
                $properties.Permission.State -notcontains 'Deny'
            )

            if ($missingPermissionState)
            {
                $errorMessage = $this.localizedData.MissingPermissionState

                New-ArgumentException -ArgumentName 'Permission' -Message $errorMessage
            }
        }

        <#
            Each permission state in the properties PermissionToInclude and PermissionToExclude
            must have specified at minimum one permission.
        #>
        foreach ($currentAssignedPermissionProperty in @('PermissionToInclude', 'PermissionToExclude'))
        {
            if ($properties.Keys -contains $currentAssignedPermissionProperty)
            {
                foreach ($currentServerPermission in $properties.$currentAssignedPermissionProperty)
                {
                    if ($currentServerPermission.Permission.Count -eq 0)
                    {
                        $errorMessage = $this.localizedData.MustHaveMinimumOnePermissionInState -f $currentAssignedPermissionProperty

                        New-ArgumentException -ArgumentName $currentAssignedPermissionProperty -Message $errorMessage
                    }
                }
            }
        }
    }
}
#EndRegion '.\Classes\020.SqlPermission.ps1' 640
#Region '.\Classes\020.SqlRSSetup.ps1' -1

<#
    .SYNOPSIS
        The `SqlRSSetup` DSC resource is used to install, repair, or uninstall
        SQL Server Reporting Services (SSRS) or Power BI Report Server (PBIRS).

    .DESCRIPTION
        The `SqlRSSetup` DSC resource is used to install, repair, or uninstall
        SQL Server Reporting Services (SSRS) or Power BI Report Server (PBIRS).

        The built-in parameter **PSDscRunAsCredential** can be used to run the resource
        as another user. The resource will then install as that user, otherwise
        install as SYSTEM.

        >[!TIP]
        >To install Microsoft SQL Server Reporting Services 2016 (or older),
        >please use the resource SqlSetup instead.

        > [!IMPORTANT]
        > When using the action 'Uninstall' and the target node to begin with
        > requires a restart, on the first run the Microsoft SQL Server Reporting
        > Services instance will not be uninstalled, but instead exits with code
        > 3010 and the node will be, by default, restarted. On the second run after
        > restart, the Microsoft SQL Server Reporting Services instance will be
        > uninstalled. If the parameter SuppressRestart is used, then the node must
        > be restarted manually before the Microsoft SQL Server Reporting Services
        > instance will be successfully uninstalled.
        >
        > The Microsoft SQL Server Reporting Services log will indicate that a
        > restart is required by outputting; "*No action was taken as a system
        > reboot is required (0x8007015E)*". The log is default located in the
        > SSRS folder in `%TEMP%`, e.g. `C:\Users\<user>\AppData\Local\Temp\SSRS`.


        ## Requirements

        * Target machine must be running Windows Server 2012 or later.
        * Target machine must have access to the SQL Server Reporting Services or
          Power BI Report Server installation media.
        * SYSTEM account or the users passed in the credentials for the `PsDscRunAsCredential`
          common parameter must have permissions to connect to the location
          where the _Microsoft SQL Server Reporting Services_ or _Microsoft Power_
          _BI Report Server_ media is placed.
        * The parameter `AcceptLicensingTerms` must be set to `$true`.
        * The parameter `InstanceName` can only be set to `SSRS` or `PBIRS` since there
          is no way to change the instance name.

        ## Known issues

        * When using action 'Uninstall', the same version of the executable as the
          version of the installed product must be used. If not, sometimes the uninstall
          is successful (because the executable returns exit code 0) but the instance
          was not actually removed.

        All issues are not listed here, see [here for all open issues](https://github.com/dsccommunity/SqlServerDsc/issues?q=is%3Aissue+is%3Aopen+in%3Atitle+SqlRSSetup).

    .PARAMETER InstanceName
        Specifies the instance name for the Reporting Services instance. This
        must be either `'SSRS'` for SQL Server Reporting Services or `'PBIRS'` for
        Power BI Report Server.

    .PARAMETER Action
        Specifies the action to take for the Reporting Services instance.
        This can be 'Install', 'Repair', or 'Uninstall'.

    .PARAMETER AcceptLicensingTerms
        Required parameter for Install and Repair actions to be able to run unattended.
        By specifying this parameter you acknowledge the acceptance of all license terms
        and notices for the specified features, the terms and notices that the setup
        executable normally asks for.

    .PARAMETER MediaPath
        Specifies the path where to find the SQL Server installation media. On this
        path the SQL Server setup executable must be found.

    .PARAMETER ProductKey
        Specifies the product key to use for the installation or repair, e.g.
        '12345-12345-12345-12345-12345'. This parameter is mutually exclusive with
        the parameter Edition.

    .PARAMETER EditionUpgrade
        Upgrades the edition of the installed product. Requires that either the
        ProductKey or the Edition parameter is also assigned. By default no edition
        upgrade is performed.

    .PARAMETER Edition
        Specifies a free custom edition to use for the installation or repair. This
        parameter is mutually exclusive with the parameter ProductKey.

    .PARAMETER LogPath
        Specifies the file path where to write the log files, e.g. 'C:\Logs\Install.log'.
        By default log files are created under %TEMP%.

    .PARAMETER InstallFolder
        Specifies the folder where to install the product, e.g. 'C:\Program Files\SSRS'.
        By default the product is installed under the default installation folder.

        Reporting Services: %ProgramFiles%\Microsoft SQL Server Reporting Services
        Power BI Report Server: %ProgramFiles%\Microsoft Power BI Report Server

    .PARAMETER SuppressRestart
        Suppresses the restart of the computer after the installation, repair, or
        uninstallation is finished. By default the computer is restarted after the
        operation is finished.

    .PARAMETER ForceRestart
        Forces a restart of the computer after the installation, repair, or
        uninstallation is finished, regardless of the operation's outcome. This
        parameter overrides SuppressRestart.

    .PARAMETER VersionUpgrade
        Specifies whether to upgrade the version of the installed product. By default,
        no version upgrade is performed.

        If this parameter is specified the installed product version will be compared
        against the product version of the setup executable. If the installed product
        version is lower than the product version of the setup executable, the setup
        will perform an upgrade. If the installed product version is equal to or higher
        than the product version of the setup executable, no upgrade will be performed.

    .PARAMETER Timeout
        Specifies how long to wait for the setup process to finish. Default value
        is `7200` seconds (2 hours). If the setup process does not finish before
        this time, an exception will be thrown.

    .NOTES
        The property InstanceName is the key property for this resource. It does
        not use a ValidateSet or Enum due to a limitation. A ValidateSet() or Enum
        would not allow a `$null` value to be set for the property. Setting
        a `$null` value is needed to be able to determine if the instance is
        installed or not. Due to this limitation the property is evaluated in
        the AssertProperties() method to have one of the valid values.

        Known issues:
        - Using `VersionUpgrade` with Microsoft SQL Server 2017 Reporting Services
          does not work because that version does not set a product version in the
          registry. So there is nothing to compare against the setup executable
          product version. It does set a current version, but that does not correlate
          to the product version. This apparently by design with Microsoft SQL Server
          2017 Reporting Services.

    .EXAMPLE
        Configuration Example
        {
            Import-DscResource -ModuleName SqlServerDsc

            Node localhost
            {
                SqlRSSetup 'InstallSSRS'
                {
                    InstanceName        = 'SSRS'
                    Action              = 'Install'
                    AcceptLicensingTerms = $true
                    MediaPath           = 'E:\SQLServerReportingServices.exe'
                    InstallFolder       = 'C:\Program Files\Microsoft SQL Server Reporting Services'
                    SuppressRestart     = $true
                }
            }
        }

        This example shows how to install SQL Server Reporting Services.
#>
[DscResource(RunAsCredential = 'Optional')]
class SqlRSSetup : ResourceBase
{
    [DscProperty(Key)]
    [System.String]
    $InstanceName

    [DscProperty(Mandatory)]
    [InstallAction]
    $Action

    [DscProperty(Mandatory)]
    [System.Boolean]
    $AcceptLicensingTerms

    [DscProperty(Mandatory)]
    [System.String]
    $MediaPath

    [DscProperty()]
    [System.String]
    $ProductKey

    [DscProperty()]
    [Nullable[System.Boolean]]
    $EditionUpgrade

    [DscProperty()]
    [ReportServerEdition]
    $Edition

    [DscProperty()]
    [System.String]
    $LogPath

    [DscProperty()]
    [System.String]
    $InstallFolder

    [DscProperty()]
    [Nullable[System.Boolean]]
    $SuppressRestart

    [DscProperty()]
    [Nullable[System.Boolean]]
    $ForceRestart

    [DscProperty()]
    [Nullable[System.Boolean]]
    $VersionUpgrade

    [DscProperty()]
    [ValidateRange(0, 2147483647)]
    [Nullable[System.UInt32]]
    $Timeout = 7200

    SqlRSSetup () : base ($PSScriptRoot)
    {
        # These properties will not be enforced.
        $this.ExcludeDscProperties = @(
            'Action'
            'AcceptLicensingTerms'
            'MediaPath'
            'ProductKey'
            'EditionUpgrade'
            'Edition'
            'LogPath'
            'InstallFolder'
            'SuppressRestart'
            'Timeout'
            'ForceRestart'
            'VersionUpgrade'
        )
    }

    [SqlRSSetup] Get()
    {
        # Call the base method to return the properties.
        return ([ResourceBase] $this).Get()
    }

    [System.Boolean] Test()
    {
        # Call the base method to test all of the properties that should be enforced.
        $baseTestResult = ([ResourceBase] $this).Test()

        # If $baseTestResult -eq $true, then the InstanceName exists.
        # If $baseTestResult -eq $false, then the InstanceName does not exist.

        $actionStateResult = $baseTestResult

        if ($this.Action -eq 'Repair' -and -not $baseTestResult)
        {
            # Instance is not installed, so it is not possible to perform a repair.
            $actionStateResult = $true
        }

        if ($this.Action -in @('Uninstall', 'Repair'))
        {
            if ($baseTestResult)
            {
                # Instance is installed, it should be uninstalled or repaired.
                $actionStateResult = $false
            }
            else
            {
                <#
                    Instance is not installed, or it is not possible to perform a
                    repair since the instance is uninstalled.
                #>
                $actionStateResult = $true
            }
        }

        $inDesiredState = $true

        <#
            The product version is evaluated if action is Install, instance is
            installed and VersionUpgrade is set to $true.
        #>
        if ($this.Action -eq 'Install' -and $baseTestResult)
        {
            if ($this.EditionUpgrade)
            {
                $currentState = Get-SqlDscRSSetupConfiguration -InstanceName $this.InstanceName

                if ([System.String]::IsNullOrEmpty($currentState.EditionId))
                {
                    New-InvalidResultException -Message (
                        $this.localizedData.CannotDetermineEdition -f $this.InstanceName
                    )
                }

                $currentEdition = ConvertTo-SqlDscEditionName -Id $currentState.EditionId

                if ($currentEdition.Edition -ne $this.Edition)
                {
                    $inDesiredState = $false

                    Write-Verbose -Message (
                        $this.localizedData.NotDesiredEdition -f @(
                            $currentEdition.Edition,
                            $this.InstanceName,
                            $this.Edition
                        )
                    )
                }
            }

            if ($this.VersionUpgrade)
            {
                $fileVersion = Get-FileProductVersion -Path $this.MediaPath -ErrorAction 'Stop'

                if ($fileVersion)
                {
                    $currentState = Get-SqlDscRSSetupConfiguration -InstanceName $this.InstanceName

                    if ([System.String]::IsNullOrEmpty($currentState.ProductVersion))
                    {
                        New-InvalidResultException -Message (
                            $this.localizedData.CannotDetermineProductVersion -f $this.InstanceName
                        )
                    }

                    $installedVersion = [System.Version] $currentState.ProductVersion

                    if ($installedVersion -lt $fileVersion)
                    {
                        $inDesiredState = $false

                        Write-Verbose -Message (
                            $this.localizedData.NotDesiredProductVersion -f @(
                                $fileVersion.ToString(),
                                $this.InstanceName,
                                $installedVersion.ToString()
                            )
                        )
                    }
                }
            }
        }

        return ($actionStateResult -and $inDesiredState)
    }

    [void] Set()
    {
        # Call the base method to enforce the properties.
        ([ResourceBase] $this).Set()
    }

    <#
        Base method Get() call this method to get the current state as a hashtable.
        The parameter properties will contain the key properties.
    #>
    hidden [System.Collections.Hashtable] GetCurrentState([System.Collections.Hashtable] $properties)
    {
        Write-Verbose -Message (
            $this.localizedData.Getting_Information_Instance -f @(
                $properties.InstanceName
            )
        )

        $currentState = @{
            # This must be set to the correct valid value for base method Get() to work.
            InstanceName  = $null
            InstallFolder = $null
        }

        # Get the configuration if installed
        $rsConfiguration = Get-SqlDscRSSetupConfiguration -InstanceName $properties.InstanceName

        if ($rsConfiguration)
        {
            # Instance is installed
            Write-Verbose -Message (
                $this.localizedData.Instance_Installed -f $properties.InstanceName
            )

            $currentState.InstanceName = $rsConfiguration.InstanceName
            $currentState.InstallFolder = $rsConfiguration.InstallFolder
        }
        else
        {
            # Instance is not installed
            Write-Verbose -Message (
                $this.localizedData.Instance_NotInstalled -f $properties.InstanceName
            )
        }

        return $currentState
    }

    <#
        Base method Set() call this method with the properties that are not in
        desired state and should be enforced. It is not called if all properties
        are in desired state. The variable $properties contains only the properties
        that are not in desired state.
    #>
    hidden [void] Modify([System.Collections.Hashtable] $properties)
    {
        $getDscPropertyParameters = @{
            HasValue             = $true
            IgnoreZeroEnumValue  = $true
            Attribute            = @(
                'Optional'
                'Mandatory'
            )
            ExcludeName = @(
                # Remove mandatory property that is not a command parameter.
                'Action'

                # Remove optional property that is not a command parameter.
                'VersionUpgrade'
            )
        }

        # The command parameters are the same for all actions.
        if ($this.Action -eq 'Uninstall')
        {
            # Only retrieve properties that are needed for Uninstall
            $getDscPropertyParameters.Name = @(
                'MediaPath'
                'LogPath'
                'SuppressRestart'
                'Timeout'
            )
        }

        $commandParameters = $this |
            Get-DscProperty @getDscPropertyParameters

        $exitCode = $null

        # Switch based on the action to perform
        if ($this.InstanceName -eq 'SSRS')
        {
            switch ($this.Action)
            {
                'Install'
                {
                    Write-Verbose -Message $this.localizedData.Installing_ReportingServices

                    $exitCode = Install-SqlDscReportingService @commandParameters -PassThru -Force -ErrorAction 'Stop'

                    break
                }

                'Repair'
                {
                    Write-Verbose -Message $this.localizedData.Repairing_ReportingServices

                    $exitCode = Repair-SqlDscReportingService @commandParameters -PassThru -Force -ErrorAction 'Stop'

                    break
                }

                'Uninstall'
                {
                    Write-Verbose -Message $this.localizedData.Uninstalling_ReportingServices

                    $exitCode = Uninstall-SqlDscReportingService @commandParameters -PassThru -Force -ErrorAction 'Stop'

                    break
                }
            }
        }
        elseif ($this.InstanceName -eq 'PBIRS')
        {
            switch ($this.Action)
            {
                'Install'
                {
                    Write-Verbose -Message $this.localizedData.Installing_PowerBIReportServer

                    $exitCode = Install-SqlDscBIReportServer @commandParameters -PassThru -Force -ErrorAction 'Stop'

                    break
                }

                'Repair'
                {
                    Write-Verbose -Message $this.localizedData.Repairing_PowerBIReportServer

                    $exitCode = Repair-SqlDscBIReportServer @commandParameters -PassThru -Force -ErrorAction 'Stop'

                    break
                }

                'Uninstall'
                {
                    Write-Verbose -Message $this.localizedData.Uninstalling_PowerBIReportServer

                    $exitCode = Uninstall-SqlDscBIReportServer @commandParameters -PassThru -Force -ErrorAction 'Stop'

                    break
                }
            }
        }

        <#
            If ForceRestart is set it will always restart, and override SuppressRestart.
            If the exit code is 3010, then a restart is required.
        #>
        if ($this.ForceRestart -or ($exitCode -eq 3010 -and -not $this.SuppressRestart))
        {
            Set-DscMachineRebootRequired
        }
    }

    <#
        Base method Assert() call this method with the properties that was assigned
        a value.
    #>
    hidden [void] AssertProperties([System.Collections.Hashtable] $properties)
    {
        # TODO: Most or all of these checks are done in the Install, Uninstall or Repair-commands. We should remove them here if possible.

        # Verify that the instance name is valid.
        if ($properties.InstanceName -notin @('SSRS', 'PBIRS'))
        {
            New-ArgumentException -ArgumentName 'InstanceName' -Message ($this.localizedData.InstanceName_Invalid -f $properties.InstanceName)
        }

        # Verify that AcceptLicensingTerms is specified for Install and Repair actions.
        if ($properties.Action -in @('Install', 'Repair') -and -not $properties.AcceptLicensingTerms)
        {
            New-ArgumentException -ArgumentName 'AcceptLicensingTerms' -Message $this.localizedData.AcceptLicensingTerms_Required
        }

        # ProductKey and Edition are mutually exclusive.
        $assertBoundParameterParameters = @{
            BoundParameterList     = $properties
            MutuallyExclusiveList1 = @('ProductKey')
            MutuallyExclusiveList2 = @('Edition')
        }

        Assert-BoundParameter @assertBoundParameterParameters

        # Verify that MediaPath is valid.
        if (-not (Test-Path -Path $properties.MediaPath))
        {
            New-ArgumentException -ArgumentName 'MediaPath' -Message (
                $this.localizedData.MediaPath_Invalid -f $properties.MediaPath
            )
        }

        if ((Test-Path -Path $properties.MediaPath) -and (Get-Item -Path $properties.MediaPath).Extension -ne '.exe')
        {
            New-ArgumentException -ArgumentName 'MediaPath' -Message (
                $this.localizedData.MediaPath_DoesNotHaveRequiredExtension -f $properties.MediaPath
            )
        }

        # Must have specified either ProductKey or Edition.
        if ($properties.Action -eq 'Install' -and $properties.Keys -notcontains 'Edition' -and $properties.Keys -notcontains 'ProductKey')
        {
            New-ArgumentException -ArgumentName 'Edition, ProductKey' -Message $this.localizedData.EditionOrProductKeyMissing
        }

        # EditionUpgrade requires either ProductKey or Edition for Install and Repair actions.
        if ($properties.Action -in @('Repair') -and $properties.EditionUpgrade -and -not ($properties.ProductKey -or $properties.Edition))
        {
            New-ArgumentException -ArgumentName 'EditionUpgrade' -Message $this.localizedData.EditionUpgrade_RequiresKeyOrEdition
        }

        # LogPath validation if specified.
        if ($properties.Keys -contains 'LogPath')
        {
            # Verify that the log path parent directory exists.
            $logDirectory = Split-Path -Path $properties.LogPath -Parent

            if (-not (Test-Path -Path $logDirectory))
            {
                New-ArgumentException -ArgumentName 'LogPath' -Message (
                    $this.localizedData.LogPath_ParentMissing -f $logDirectory
                )
            }
        }

        # InstallFolder validation if specified for Install action.
        if ($properties.Action -eq 'Install' -and $properties.Keys -contains 'InstallFolder')
        {
            # Verify that the install folder parent directory exists.
            $installDirectory = Split-Path -Path $properties.InstallFolder -Parent

            if (-not (Test-Path -Path $installDirectory))
            {
                New-ArgumentException -ArgumentName 'InstallFolder' -Message (
                    $this.localizedData.InstallFolder_ParentMissing -f $installDirectory
                )
            }
        }
    }

    <#
        Base method Normalize() call this method with the properties that was assigned
        a value.
    #>
    hidden [void] NormalizeProperties([System.Collections.Hashtable] $properties)
    {
        $this.InstanceName = $properties.InstanceName.ToUpper()

        # Use array intersection for more efficient filtering
        $pathProperties = @(
            'MediaPath'
            'InstallFolder'
            'LogPath'
        ) |
            Where-Object -FilterScript {
                $properties.ContainsKey($_)
            }

        foreach ($property in $pathProperties)
        {
            $formatPathParameters = @{
                Path                         = $properties.$property
                EnsureDriveLetterRoot        = $true
                NoTrailingDirectorySeparator = $true
                ErrorAction                  = 'Stop'
            }

            # Normalize the property to lower case.
            $this.$property = Format-Path @formatPathParameters
        }
    }
}
#EndRegion '.\Classes\020.SqlRSSetup.ps1' 629
#Region '.\Private\Assert-Feature.ps1' -1

<#
    .SYNOPSIS
        Assert that a feature is supported by a Microsoft SQL Server major version.

    .DESCRIPTION
        Assert that a feature is supported by a Microsoft SQL Server major version.

    .PARAMETER Feature
       Specifies the feature to evaluate.

    .PARAMETER ProductVersion
       Specifies the product version of the Microsoft SQL Server. At minimum the
       major version must be provided.

    .EXAMPLE
        Assert-Feature -Feature 'RS' -ProductVersion '14'

        Throws an exception if the feature is not supported.

    .OUTPUTS
        None.
#>
function Assert-Feature
{
    [CmdletBinding()]
    param
    (
        [Parameter(Mandatory = $true, ValueFromPipeline = $true)]
        [System.String[]]
        $Feature,

        [Parameter(Mandatory = $true)]
        [System.String]
        $ProductVersion
    )

    process
    {
        foreach ($currentFeature in $Feature)
        {
            if (-not ($currentFeature | Test-SqlDscIsSupportedFeature -ProductVersion $ProductVersion))
            {
                $PSCmdlet.ThrowTerminatingError(
                    [System.Management.Automation.ErrorRecord]::new(
                        ($script:localizedData.Feature_Assert_NotSupportedFeature -f $currentFeature, $ProductVersion),
                        'AF0001', # cSpell: disable-line
                        [System.Management.Automation.ErrorCategory]::InvalidOperation,
                        $currentFeature
                    )
                )
            }
        }
    }
}
#EndRegion '.\Private\Assert-Feature.ps1' 55
#Region '.\Private\Assert-ManagedServiceType.ps1' -1

<#
    .SYNOPSIS
        Assert that a computer managed service is of a certain type.

    .DESCRIPTION
        Assert that a computer managed service is of a certain type. If it is the
        wrong type an exception is thrown.

    .PARAMETER ServiceObject
        Specifies the Service object to evaluate.

    .PARAMETER ServiceType
        Specifies the normalized service type to evaluate.

    .EXAMPLE
        $serviceObject = Get-SqlDscManagedComputerService -ServiceType 'DatabaseEngine'
        Assert-ManagedServiceType -ServiceObject $serviceObject -ServiceType 'DatabaseEngine'

        Asserts that the computer managed service object is of the type Database Engine.

    .EXAMPLE
        $serviceObject = Get-SqlDscManagedComputerService -ServiceType 'DatabaseEngine'
        $serviceObject | Assert-ManagedServiceType -ServiceType 'DatabaseEngine'

        Asserts that the computer managed service object is of the type Database Engine.

    .OUTPUTS
        None.
#>
function Assert-ManagedServiceType
{
    [System.Diagnostics.CodeAnalysis.SuppressMessageAttribute('UseSyntacticallyCorrectExamples', '', Justification = 'Because the rule does not yet support parsing the code when a parameter type is not available. The ScriptAnalyzer rule UseSyntacticallyCorrectExamples will always error in the editor due to https://github.com/indented-automation/Indented.ScriptAnalyzerRules/issues/8.')]
    [OutputType()]
    [CmdletBinding()]
    param
    (
        [Parameter(Mandatory = $true, ValueFromPipeline = $true)]
        [Microsoft.SqlServer.Management.Smo.Wmi.Service]
        $ServiceObject,

        [Parameter(Mandatory = $true)]
        [ValidateSet('DatabaseEngine', 'SqlServerAgent', 'Search', 'IntegrationServices', 'AnalysisServices', 'ReportingServices', 'SQLServerBrowser', 'NotificationServices')]
        [System.String]
        $ServiceType
    )

    process
    {
        $normalizedServiceType = ConvertFrom-ManagedServiceType -ServiceType $ServiceObject.Type

        if ($normalizedServiceType -ne $ServiceType)
        {
            $PSCmdlet.ThrowTerminatingError(
                [System.Management.Automation.ErrorRecord]::new(
                    ($script:localizedData.ManagedServiceType_Assert_WrongServiceType -f $ServiceType, $normalizedServiceType),
                    'AMST0001', # cSpell: disable-line
                    [System.Management.Automation.ErrorCategory]::InvalidOperation,
                    $ServiceObject
                )
            )
        }
    }
}
#EndRegion '.\Private\Assert-ManagedServiceType.ps1' 64
#Region '.\Private\Assert-SetupActionProperties.ps1' -1

<#
    .SYNOPSIS
        Assert that the bound parameters are set as required

    .DESCRIPTION
        Assert that required parameters has been specified, and throws an exception if not.

    .PARAMETER Property
       A hashtable containing the parameters to evaluate. Normally this is set to
       $PSBoundParameters.

    .PARAMETER SetupAction
       A string value representing the setup action that is gonna be executed.

    .EXAMPLE
        Assert-SetupActionProperties -Property $PSBoundParameters -SetupAction 'Install'

        Throws an exception if the bound parameters are not in the correct state.

    .OUTPUTS
        None.

    .NOTES
        This function is used by the command Invoke-SetupAction to verify that
        the bound parameters are in the required state.
#>
function Assert-SetupActionProperties
{
    [System.Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSUseSingularNouns', '', Justification = 'The command uses plural noun to describe that it contain a collection of asserts.')]
    [CmdletBinding()]
    param
    (
        [Parameter(Mandatory = $true)]
        [System.Collections.Hashtable]
        $Property,

        [Parameter(Mandatory = $true)]
        [System.String]
        $SetupAction
    )

    if ($Property.ContainsKey('Features'))
    {
        $setupExecutableFileVersion = $Property.MediaPath |
            Join-Path -ChildPath 'setup.exe' |
            Get-FileVersionInformation

        $Property.Features |
            Assert-Feature -ProductVersion $setupExecutableFileVersion.ProductVersion
    }

    # If one of the properties PBStartPortRange and PBEndPortRange are specified, then both must be specified.
    $assertParameters = @('PBStartPortRange', 'PBEndPortRange')

    $assertRequiredCommandParameterParameters = @{
        BoundParameterList = $Property
        RequiredParameter  = $assertParameters
        IfParameterPresent = $assertParameters
    }

    Assert-BoundParameter @assertRequiredCommandParameterParameters

    # The parameter UseSqlRecommendedMemoryLimits is mutually exclusive to SqlMinMemory and SqlMaxMemory.
    Assert-BoundParameter -BoundParameterList $Property -MutuallyExclusiveList1 @(
        'UseSqlRecommendedMemoryLimits'
    ) -MutuallyExclusiveList2 @(
        'SqlMinMemory'
        'SqlMaxMemory'
    )

    # If Role is set to SPI_AS_NewFarm then the specific parameters are required.
    if ($Property.ContainsKey('Role') -and $Property.Role -eq 'SPI_AS_NewFarm')
    {
        Assert-BoundParameter -BoundParameterList $Property -RequiredParameter @(
            'FarmAccount'
            'FarmPassword'
            'Passphrase'
            'FarmAdminiPort' # cspell: disable-line
        )
    }

    # If the parameter SecurityMode is set to 'SQL' then the parameter SAPwd is required.
    if ($Property.ContainsKey('SecurityMode') -and $Property.SecurityMode -eq 'SQL')
    {
        Assert-BoundParameter -BoundParameterList $Property -RequiredParameter @('SAPwd')
    }

    # If the parameter FileStreamLevel is set and is greater or equal to 2 then the parameter FileStreamShareName is required.
    if ($Property.ContainsKey('FileStreamLevel') -and $Property.FileStreamLevel -ge 2)
    {
        Assert-BoundParameter -BoundParameterList $Property -RequiredParameter @('FileStreamShareName')
    }

    # If a *SvcAccount is specified then the accompanying *SvcPassword must be set unless it is a (global) managed service account, virtual account, or a built-in account.
    $accountProperty = @(
        'PBEngSvcAccount'
        'PBDMSSvcAccount' # cSpell: disable-line
        'AgtSvcAccount'
        'ASSvcAccount'
        'FarmAccount'
        'SqlSvcAccount'
        'ISSvcAccount'
        'RSSvcAccount'
    )

    foreach ($currentAccountProperty in $accountProperty)
    {
        if ($currentAccountProperty -in $Property.Keys)
        {
            # If not (global) managed service account, virtual account, or a built-in account.
            if ((Test-AccountRequirePassword -Name $Property.$currentAccountProperty))
            {
                $assertPropertyName = $currentAccountProperty -replace 'Account', 'Password'

                Assert-BoundParameter -BoundParameterList $Property -RequiredParameter $assertPropertyName
            }
        }
    }

    # If feature AzureExtension is specified then the all the Azure* parameters must be set (except AzureArcProxy).
    if ($Property.ContainsKey('Features') -and $Property.Features -contains 'AZUREEXTENSION') # cSpell: disable-line
    {
        Assert-BoundParameter -BoundParameterList $Property -RequiredParameter @(
            'AzureSubscriptionId'
            'AzureResourceGroup'
            'AzureRegion'
            'AzureTenantId'
            'AzureServicePrincipal'
            'AzureServicePrincipalSecret'
            'ProductCoveredBySA'
        )
    }

    if ($SetupAction -in @('CompleteImage'))
    {
        # If feature is SQLENGINE, then InstanceId, SqlSvcAccount and AgtSvcAccount are mandatory.
        if ($Property.ContainsKey('Features') -and $Property.Features -contains 'SQLENGINE')
        {
            Assert-BoundParameter -BoundParameterList $Property -RequiredParameter @(
                'InstanceId'
                'SqlSvcAccount'
                'AgtSvcAccount'
            )
        }
    }

    if ($SetupAction -in @('PrepareImage'))
    {
        # If feature is SQLENGINE, then InstanceId is mandatory.
        if ($Property.ContainsKey('Features') -and $Property.Features -contains 'SQLENGINE')
        {
            Assert-BoundParameter -BoundParameterList $Property -RequiredParameter @(
                'InstanceId'
            )
        }
    }

    if ($SetupAction -in @('InstallFailoverCluster', 'PrepareFailoverCluster', 'AddNode'))
    {
        # If feature is SQLENGINE, then for specified setup actions the parameter AgtSvcAccount is mandatory.
        if ($Property.ContainsKey('Features') -and $Property.Features -contains 'SQLENGINE')
        {
            Assert-BoundParameter -BoundParameterList $Property -RequiredParameter @('AgtSvcAccount')
        }

        # The parameter ASSvcAccount is mandatory if feature AS is installed and setup action is InstallFailoverCluster, PrepareFailoverCluster, or AddNode.
        if ($Property.ContainsKey('Features') -and $Property.Features -contains 'AS')
        {
            Assert-BoundParameter -BoundParameterList $Property -RequiredParameter @('ASSvcAccount')
        }

        # The parameter SqlSvcAccount is mandatory if feature SQLENGINE is installed and setup action is InstallFailoverCluster, PrepareFailoverCluster, or AddNode.
        if ($Property.ContainsKey('Features') -and $Property.Features -contains 'SQLENGINE')
        {
            Assert-BoundParameter -BoundParameterList $Property -RequiredParameter @('SqlSvcAccount')
        }

        # The parameter ISSvcAccount is mandatory if feature IS is installed and setup action is InstallFailoverCluster, PrepareFailoverCluster, or AddNode.
        if ($Property.ContainsKey('Features') -and $Property.Features -contains 'IS')
        {
            Assert-BoundParameter -BoundParameterList $Property -RequiredParameter @('ISSvcAccount')
        }

        if ($Property.ContainsKey('Features') -and $Property.Features -contains 'RS')
        {
            Assert-BoundParameter -BoundParameterList $Property -RequiredParameter @('RSSvcAccount')
        }
    }

    # The ASServerMode value PowerPivot is not allowed when parameter set is InstallFailoverCluster or CompleteFailoverCluster.
    if ($SetupAction -in ('InstallFailoverCluster', 'CompleteFailoverCluster'))
    {
        if ($Property.ContainsKey('ASServerMode') -and $Property.ASServerMode -eq 'PowerPivot')
        {
            $PSCmdlet.ThrowTerminatingError(
                [System.Management.Automation.ErrorRecord]::new(
                    ($script:localizedData.InstallSqlServerProperties_ASServerModeInvalidValue -f $SetupAction),
                    'ASAP0001', # cSpell: disable-line
                    [System.Management.Automation.ErrorCategory]::InvalidOperation,
                    'Command parameters'
                )
            )
        }
    }

    # The ASServerMode value PowerPivot is not allowed when parameter set is InstallFailoverCluster or CompleteFailoverCluster.
    if ($SetupAction -in ('AddNode'))
    {
        if ($Property.ContainsKey('RsInstallMode') -and $Property.RsInstallMode -ne 'FilesOnlyMode')
        {
            $PSCmdlet.ThrowTerminatingError(
                [System.Management.Automation.ErrorRecord]::new(
                    ($script:localizedData.InstallSqlServerProperties_RsInstallModeInvalidValue -f $SetupAction),
                    'ASAP0002', # cSpell: disable-line
                    [System.Management.Automation.ErrorCategory]::InvalidOperation,
                    'Command parameters'
                )
            )
        }
    }

    if ($SetupAction -in ('Install'))
    {
        if ($Property.ContainsKey('Features') -and $Property.Features -contains 'SQLENGINE')
        {
            Assert-BoundParameter -BoundParameterList $Property -RequiredParameter @(
                'SqlSysAdminAccounts'
            )
        }

        if ($Property.ContainsKey('Features') -and $Property.Features -contains 'AS')
        {
            Assert-BoundParameter -BoundParameterList $Property -RequiredParameter @(
                'ASSysAdminAccounts'
            )
        }
    }
}
#EndRegion '.\Private\Assert-SetupActionProperties.ps1' 239
#Region '.\Private\ConvertFrom-ManagedServiceType.ps1' -1

<#
    .SYNOPSIS
        Converts a managed service type name to a normalized service type name.

    .DESCRIPTION
        Converts a managed service type name to its normalized service type name
        equivalent.

    .PARAMETER ServiceType
        Specifies the managed service type to convert to the correct normalized
        service type name.

    .EXAMPLE
        ConvertFrom-ManagedServiceType -ServiceType 'SqlServer'

        Returns the normalized service type name 'DatabaseEngine' .
#>
function ConvertFrom-ManagedServiceType
{
    [System.Diagnostics.CodeAnalysis.SuppressMessageAttribute('UseSyntacticallyCorrectExamples', '', Justification = 'Because the rule does not yet support parsing the code when a parameter type is not available. The ScriptAnalyzer rule UseSyntacticallyCorrectExamples will always error in the editor due to https://github.com/indented-automation/Indented.ScriptAnalyzerRules/issues/8.')]
    [CmdletBinding()]
    param
    (
        [Parameter(Mandatory = $true, ValueFromPipeline = $true)]
        [Microsoft.SqlServer.Management.Smo.Wmi.ManagedServiceType]
        $ServiceType
    )

    process
    {
        # Map the normalized service type to a valid value from the managed service type.
        switch ($ServiceType)
        {
            'SqlServer'
            {
                $serviceTypeValue = 'DatabaseEngine'

                break
            }

            'SqlAgent'
            {
                $serviceTypeValue = 'SqlServerAgent'

                break
            }

            'Search'
            {
                $serviceTypeValue = 'Search'

                break
            }

            'SqlServerIntegrationService'
            {
                $serviceTypeValue = 'IntegrationServices'

                break
            }

            'AnalysisServer'
            {
                $serviceTypeValue = 'AnalysisServices'

                break
            }

            'ReportServer'
            {
                $serviceTypeValue = 'ReportingServices'

                break
            }

            'SqlBrowser'
            {
                $serviceTypeValue = 'SQLServerBrowser'

                break
            }

            'NotificationServer'
            {
                $serviceTypeValue = 'NotificationServices'

                break
            }

            default
            {
                <#
                    This catches any future values in the enum ManagedServiceType
                    that are not yet supported.
                #>
                $writeErrorParameters = @{
                    Message      = $script:localizedData.ManagedServiceType_ConvertFrom_UnknownServiceType -f $ServiceType
                    Category     = 'InvalidOperation'
                    ErrorId      = 'CFMST0001' # CSpell: disable-line
                    TargetObject = $ServiceType
                }

                Write-Error @writeErrorParameters

                break
            }
        }

        return $serviceTypeValue
    }
}
#EndRegion '.\Private\ConvertFrom-ManagedServiceType.ps1' 112
#Region '.\Private\ConvertTo-AuditNewParameterSet.ps1' -1

<#
    .SYNOPSIS
        Converts audit object properties to parameters for New-SqlDscAudit.

    .DESCRIPTION
        This helper function analyzes an existing audit object and returns a hashtable
        of parameters that can be splatted to New-SqlDscAudit to recreate the audit
        with the same configuration.

    .PARAMETER AuditObject
        The audit object to analyze.

    .PARAMETER AuditGuid
        Optional GUID to set on the audit. If not specified, the existing GUID is used.

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine
        $auditObject = $serverObject.Audits['MyAudit']
        $parameters = ConvertTo-AuditNewParameterSet -AuditObject $auditObject

        Converts an existing audit object to a parameter set that can be used with New-SqlDscAudit.

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine
        $auditObject = $serverObject.Audits['MyAudit']
        $parameters = ConvertTo-AuditNewParameterSet -AuditObject $auditObject -AuditGuid '12345678-1234-1234-1234-123456789012'

        Converts an existing audit object to a parameter set with a custom GUID.

    .INPUTS
        None

        This function does not accept pipeline input.

    .OUTPUTS
        System.Collections.Hashtable

        Returns a hashtable of parameters for New-SqlDscAudit.
#>
function ConvertTo-AuditNewParameterSet
{
    [CmdletBinding()]
    [OutputType([System.Collections.Hashtable])]
    param
    (
        [Parameter(Mandatory = $true)]
        [Microsoft.SqlServer.Management.Smo.Audit]
        $AuditObject,

        [Parameter()]
        [System.String]
        $AuditGuid
    )

    $parameters = @{
        ServerObject = $AuditObject.Parent
        Name         = $AuditObject.Name
    }

    # Determine LogType or Path based on DestinationType
    switch ($AuditObject.DestinationType)
    {
        'ApplicationLog'
        {
            $parameters['LogType'] = 'ApplicationLog'
        }

        'SecurityLog'
        {
            $parameters['LogType'] = 'SecurityLog'
        }

        'File'
        {
            $parameters['Path'] = $AuditObject.FilePath

            # Add file size parameters if set (not unlimited)
            if ($AuditObject.MaximumFileSize -gt 0)
            {
                $parameters['MaximumFileSize'] = $AuditObject.MaximumFileSize

                # Convert SMO unit to parameter value
                $parameters['MaximumFileSizeUnit'] = switch ($AuditObject.MaximumFileSizeUnit)
                {
                    'MB'
                    {
                        'Megabyte'
                    }
                    'GB'
                    {
                        'Gigabyte'
                    }
                    'TB'
                    {
                        'Terabyte'
                    }
                }
            }

            # Add MaximumFiles or MaximumRolloverFiles (mutually exclusive)
            if ($AuditObject.MaximumFiles -gt 0)
            {
                $parameters['MaximumFiles'] = $AuditObject.MaximumFiles

                if ($AuditObject.ReserveDiskSpace)
                {
                    $parameters['ReserveDiskSpace'] = $true
                }
            }
            elseif ($AuditObject.MaximumRolloverFiles -gt 0)
            {
                $parameters['MaximumRolloverFiles'] = $AuditObject.MaximumRolloverFiles
            }
        }
    }

    # Add optional parameters if they have values
    if ($null -ne $AuditObject.OnFailure)
    {
        $parameters['OnFailure'] = $AuditObject.OnFailure
    }

    if ($AuditObject.QueueDelay -gt 0)
    {
        $parameters['QueueDelay'] = $AuditObject.QueueDelay
    }

    if ($AuditObject.Filter)
    {
        $parameters['AuditFilter'] = $AuditObject.Filter
    }

    # Use provided GUID or existing GUID
    if ($PSBoundParameters.ContainsKey('AuditGuid'))
    {
        $parameters['AuditGuid'] = $AuditGuid
    }
    elseif ($AuditObject.Guid -and $AuditObject.Guid -ne '00000000-0000-0000-0000-000000000000')
    {
        $parameters['AuditGuid'] = $AuditObject.Guid
    }

    return $parameters
}
#EndRegion '.\Private\ConvertTo-AuditNewParameterSet.ps1' 145
#Region '.\Private\ConvertTo-FormattedParameterDescription.ps1' -1

<#
    .SYNOPSIS
        Converts a hashtable of bound parameters into a formatted string for ShouldProcess descriptions.

    .DESCRIPTION
        This function takes a hashtable of bound parameters and formats them into a readable string
        for use in ShouldProcess verbose descriptions. It excludes non-settable parameters and
        formats each parameter as 'ParameterName: Value'.

    .PARAMETER BoundParameters
        Hashtable of bound parameters (typically $PSBoundParameters).

    .PARAMETER Exclude
        Array of parameter names to exclude from the formatted output.

    .OUTPUTS
        System.String

        Returns a formatted string with parameters and their values.

    .EXAMPLE
        $formattedText = ConvertTo-FormattedParameterDescription -BoundParameters $PSBoundParameters -Exclude @('ServerObject', 'Name', 'Force')

        Returns a formatted string like:
        "
            EmailAddress: 'admin@company.com'
            CategoryName: 'Notifications'
        "
#>
function ConvertTo-FormattedParameterDescription
{
    [CmdletBinding()]
    [OutputType([System.String])]
    param
    (
        [Parameter(Mandatory = $true)]
        [System.Collections.Hashtable]
        $BoundParameters,

        [Parameter()]
        [System.String[]]
        $Exclude = @()
    )

    $parameterDescriptions = @()

    foreach ($parameter in ($BoundParameters.Keys | Sort-Object))
    {
        if ($parameter -notin $Exclude)
        {
            $raw = $BoundParameters[$parameter]

            $value = if ($raw -is [System.Security.SecureString])
            {
                '***'
            }
            elseif ($raw -is [System.Management.Automation.PSCredential])
            {
                $raw.UserName
            }
            elseif ($raw -is [System.Array])
            {
                ($raw -join ', ')
            }
            else
            {
                $raw
            }

            $parameterDescriptions += "$parameter`: '$value'"
        }
    }

    if ($parameterDescriptions.Count -gt 0)
    {
        return "`r`n    " + ($parameterDescriptions -join "`r`n    ")
    }
    else
    {
        return " $($script:localizedData.ConvertTo_FormattedParameterDescription_NoParametersToUpdate)"
    }
}
#EndRegion '.\Private\ConvertTo-FormattedParameterDescription.ps1' 83
#Region '.\Private\ConvertTo-ManagedServiceType.ps1' -1

<#
    .SYNOPSIS
        Converts a normalized service type name to a managed service type name.

    .DESCRIPTION
        Converts a normalized service type name to its managed service type name
        equivalent.

    .PARAMETER ServiceType
        Specifies the normalized service type to convert to the correct manged
        service type.

    .EXAMPLE
        ConvertTo-ManagedServiceType -ServiceType 'DatabaseEngine'

        Returns the manged service type name for the normalized service type 'DatabaseEngine'.
#>
function ConvertTo-ManagedServiceType
{
    [CmdletBinding()]
    param
    (
        [Parameter(Mandatory = $true, ValueFromPipeline = $true)]
        [ValidateSet('DatabaseEngine', 'SqlServerAgent', 'Search', 'IntegrationServices', 'AnalysisServices', 'ReportingServices', 'SQLServerBrowser', 'NotificationServices')]
        [System.String]
        $ServiceType
    )

    process
    {
        # Map the normalized service type to a valid value from the managed service type.
        switch ($ServiceType)
        {
            'DatabaseEngine'
            {
                $serviceTypeValue = 'SqlServer'

                break
            }

            'SqlServerAgent'
            {
                $serviceTypeValue = 'SqlAgent'

                break
            }

            'Search'
            {
                $serviceTypeValue = 'Search'

                break
            }

            'IntegrationServices'
            {
                $serviceTypeValue = 'SqlServerIntegrationService'

                break
            }

            'AnalysisServices'
            {
                $serviceTypeValue = 'AnalysisServer'

                break
            }

            'ReportingServices'
            {
                $serviceTypeValue = 'ReportServer'

                break
            }

            'SQLServerBrowser'
            {
                $serviceTypeValue = 'SqlBrowser'

                break
            }

            'NotificationServices'
            {
                $serviceTypeValue = 'NotificationServer'

                break
            }
        }

        return $serviceTypeValue -as [Microsoft.SqlServer.Management.Smo.Wmi.ManagedServiceType]
    }
}
#EndRegion '.\Private\ConvertTo-ManagedServiceType.ps1' 94
#Region '.\Private\ConvertTo-RedactedText.ps1' -1

<#
    .SYNOPSIS
        Redacts a text from one or more specified phrases.

    .DESCRIPTION
        Redacts a text using best effort from one or more specified phrases. For
        it to work the sensitiv phrases must be known and passed into the parameter
        RedactText. If any single character in a phrase is wrong the sensitiv
        information will not be redacted. The redaction is case-insensitive.

    .PARAMETER Text
        Specifies the text that will be redacted.

    .PARAMETER RedactPhrase
        Specifies one or more phrases to redact from the text. Text strings will
        be escaped so they will not be interpreted as regular expressions (RegEx).

    .PARAMETER RedactWith
        Specifies a phrase that will be used as redaction.

    .EXAMPLE
        ConvertTo-RedactedText -Text 'My secret phrase: secret123' -RedactPhrase 'secret123'

        Returns the text with the phrases redacted with the default redaction phrase.

    .EXAMPLE
        ConvertTo-RedactedText -Text 'My secret phrase: secret123' -RedactPhrase 'secret123' -RedactWith '----'

        Returns the text with the phrases redacted to '----'.
#>
function ConvertTo-RedactedText
{
    [CmdletBinding()]
    param
    (
        [Parameter(Mandatory = $true, ValueFromPipeline = $true)]
        [System.String]
        $Text,

        [Parameter(Mandatory = $true)]
        [System.String[]]
        $RedactPhrase,

        [Parameter()]
        [System.String]
        $RedactWith = '*******'
    )

    process
    {
        $redactedText = $Text

        foreach ($redactString in $RedactPhrase)
        {
            <#
                Escaping the string to handle strings which could look like
                regular expressions, like passwords.
            #>
            $escapedRedactedString = [System.Text.RegularExpressions.Regex]::Escape($redactString)

            $redactedText = $redactedText -ireplace $escapedRedactedString, $RedactWith # cSpell: ignore ireplace
        }

        return $redactedText
    }
}
#EndRegion '.\Private\ConvertTo-RedactedText.ps1' 67
#Region '.\Private\Get-AgentAlertObject.ps1' -1

<#
    .SYNOPSIS
        Gets a SQL Agent Alert object from the JobServer.

    .DESCRIPTION
        Gets a SQL Agent Alert object from the JobServer based on the specified name.

    .PARAMETER ServerObject
        Specifies the SQL Server object.

    .PARAMETER Name
        Specifies the name of the SQL Agent Alert.

    .OUTPUTS
        Microsoft.SqlServer.Management.Smo.Agent.Alert

        Returns the SQL Agent Alert object when an alert with the specified name is found.

    .OUTPUTS
        None.

        When no alert with the specified name is found.

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine
        Get-AgentAlertObject -ServerObject $serverObject -Name 'MyAlert'

        Gets the SQL Agent Alert named 'MyAlert'.
#>
function Get-AgentAlertObject
{
    [CmdletBinding()]
    [OutputType([Microsoft.SqlServer.Management.Smo.Agent.Alert])]
    param
    (
        [Parameter(Mandatory = $true)]
        [Microsoft.SqlServer.Management.Smo.Server]
        $ServerObject,

        [Parameter(Mandatory = $true)]
        [System.String]
        $Name
    )

    Write-Verbose -Message ($script:localizedData.Get_AgentAlertObject_GettingAlert -f $Name)

    $alertObject = $ServerObject.JobServer.Alerts | Where-Object -FilterScript { $_.Name -eq $Name }

    return $alertObject
}
#EndRegion '.\Private\Get-AgentAlertObject.ps1' 51
#Region '.\Private\Get-AgentOperatorObject.ps1' -1

<#
    .SYNOPSIS
        Retrieves a SQL Server Agent Operator object.

    .DESCRIPTION
        This private function retrieves a SQL Server Agent Operator object using the provided
        parameters. If the operator is not found, it throws a non-terminating error. Callers
        can use -ErrorAction to control error behavior.

    .PARAMETER ServerObject
        Specifies the server object on which to retrieve the operator.

    .PARAMETER Name
        Specifies the name of the operator to retrieve.

    .PARAMETER Refresh
        Specifies whether to refresh the operators collection before retrieving the operator.
        When specified, the function calls Refresh() on the JobServer.Operators collection.

    .INPUTS
        None.

    .OUTPUTS
        Microsoft.SqlServer.Management.Smo.Agent.Operator

        Returns the operator object if found.

    .EXAMPLE
        $operatorObject = Get-AgentOperatorObject -ServerObject $serverObject -Name 'TestOperator'

        Returns the SQL Agent Operator object for 'TestOperator', throws error if not found.

    .EXAMPLE
        $operatorObject = Get-AgentOperatorObject -ServerObject $serverObject -Name 'TestOperator' -Refresh

        Returns the SQL Agent Operator object for 'TestOperator' after refreshing the operators collection.
#>
function Get-AgentOperatorObject
{
    [CmdletBinding()]
    [OutputType([Microsoft.SqlServer.Management.Smo.Agent.Operator])]
    param
    (
        [Parameter(Mandatory = $true)]
        [Microsoft.SqlServer.Management.Smo.Server]
        $ServerObject,

        [Parameter(Mandatory = $true)]
        [System.String]
        $Name,

        [Parameter()]
        [System.Management.Automation.SwitchParameter]
        $Refresh
    )

    Write-Verbose -Message ($script:localizedData.Get_AgentOperatorObject_GettingOperator -f $Name)

    if ($Refresh)
    {
        Write-Verbose -Message $script:localizedData.Get_AgentOperatorObject_RefreshingOperators
        $ServerObject.JobServer.Operators.Refresh()
    }

    $operatorObject = $ServerObject.JobServer.Operators[$Name]

    if ($null -eq $operatorObject)
    {
        $errorMessage = $script:localizedData.AgentOperator_NotFound -f $Name

        Write-Error -Message $errorMessage -Category 'ObjectNotFound' -ErrorId 'GAOO0001' -TargetObject $Name

        return $null
    }

    return $operatorObject
}
#EndRegion '.\Private\Get-AgentOperatorObject.ps1' 78
#Region '.\Private\Get-CommandParameter.ps1' -1

<#
    .SYNOPSIS
        Gets command parameters excluding specified ones.

    .DESCRIPTION
        This private function filters command parameters by excluding specified parameter names,
        common parameters, and optional common parameters. It returns an array of parameter names
        that can be used to set properties on objects.

    .PARAMETER Command
        Specifies the command information object containing parameter definitions.

    .PARAMETER Exclude
        Specifies an optional array of parameter names to exclude from the result.
        Common parameters and optional common parameters are always excluded.

    .INPUTS
        None.

    .OUTPUTS
        System.String[]

        Returns an array of parameter names that are not excluded.

    .EXAMPLE
        $settableProperties = Get-CommandParameter -Command $MyInvocation.MyCommand -Exclude @('ServerObject', 'Name', 'PassThru', 'Force')

        Returns all parameters except the excluded ones and common parameters.

    .EXAMPLE
        $settableProperties = Get-CommandParameter -Command $MyInvocation.MyCommand

        Returns all parameters except common parameters and optional common parameters.
#>
function Get-CommandParameter
{
    [CmdletBinding()]
    [OutputType([System.String[]])]
    param
    (
        [Parameter(Mandatory = $true)]
        [System.Management.Automation.FunctionInfo]
        $Command,

        [Parameter()]
        [System.String[]]
        $Exclude = @()
    )

    $parametersWithoutCommon = Remove-CommonParameter -Hashtable $Command.Parameters

    $settableProperties = $parametersWithoutCommon.Keys | Where-Object -FilterScript { $_ -notin $Exclude }

    return $settableProperties
}
#EndRegion '.\Private\Get-CommandParameter.ps1' 56
#Region '.\Private\Get-FileVersionInformation.ps1' -1

<#
    .SYNOPSIS
        Returns the version information for a file.

    .DESCRIPTION
        Returns the version information for a file.

    .PARAMETER FilePath
        Specifies the file for which to return the version information.

    .EXAMPLE
        Get-FileVersionInformation -FilePath 'E:\setup.exe'

        Returns the version information for the file setup.exe.

    .EXAMPLE
        Get-FileVersionInformation -FilePath (Get-Item -Path 'E:\setup.exe')

        Returns the version information for the file setup.exe.

    .OUTPUTS
        [System.String]
#>
function Get-FileVersionInformation
{
    [OutputType([System.Diagnostics.FileVersionInfo])]
    [CmdletBinding()]
    param
    (
        [Parameter(Mandatory = $true, ValueFromPipeline = $true)]
        [System.IO.FileInfo]
        $FilePath
    )

    process
    {
        $originalErrorActionPreference = $ErrorActionPreference

        $ErrorActionPreference = 'Stop'

        $file = Get-Item -Path $FilePath -ErrorAction 'Stop'

        $ErrorActionPreference = $originalErrorActionPreference

        if ($file.PSIsContainer)
        {
            $PSCmdlet.ThrowTerminatingError(
                [System.Management.Automation.ErrorRecord]::new(
                    $script:localizedData.FileVersionInformation_Get_FilePathIsNotFile,
                    'GFPVI0001', # cSpell: disable-line
                    [System.Management.Automation.ErrorCategory]::InvalidArgument,
                    $file.FullName
                )
            )
        }

        return $file.VersionInfo
    }
}
#EndRegion '.\Private\Get-FileVersionInformation.ps1' 60
#Region '.\Private\Get-SMOModuleCalculatedVersion.ps1' -1

<#
    .SYNOPSIS
        Returns the calculated version of an SMO PowerShell module.

    .DESCRIPTION
        Returns the calculated version of an SMO PowerShell module.

        For SQLServer, the version is calculated using the System.Version
        field with '-preview' appended for pre-release versions . For
        example: 21.1.1 or 22.0.49-preview

        For SQLPS, the version is calculated using the path of the module. For
        example:
        C:\Program Files (x86)\Microsoft SQL Server\130\Tools\PowerShell\Modules
        returns 130

    .PARAMETER PSModuleInfo
        Specifies the PSModuleInfo object for which to return the calculated version.

    .EXAMPLE
        Get-SMOModuleCalculatedVersion -PSModuleInfo (Get-Module -Name 'sqlps')

        Returns the calculated version as a string.

    .OUTPUTS
        [System.String]
#>
function Get-SMOModuleCalculatedVersion
{
    [OutputType([System.String])]
    [CmdletBinding()]
    param
    (
        [Parameter(Mandatory = $true, ValueFromPipeline = $true)]
        [System.Management.Automation.PSModuleInfo]
        $PSModuleInfo
    )

    process
    {
        $version = $null

        if ($PSModuleInfo.Name -eq 'SQLPS')
        {
            <#
                Parse the build version number '120', '130' from the Path.
                Older version of SQLPS did not have correct versioning.
            #>
            $version = $PSModuleInfo.Path -replace '.*\\(\d{2})(\d)\\.*', '$1.$2'
        }
        else
        {
            $version = $PSModuleInfo.Version.ToString()

            if ($PSModuleInfo.PrivateData.PSData.Prerelease)
            {
                $version = '{0}-{1}' -f $PSModuleInfo.Version, $PSModuleInfo.PrivateData.PSData.Prerelease
            }
        }

        return $version
    }
}
#EndRegion '.\Private\Get-SMOModuleCalculatedVersion.ps1' 64
#Region '.\Private\Invoke-ReportServerSetupAction.ps1' -1

<#
    .SYNOPSIS
        Executes setup using the provided setup executable.

    .DESCRIPTION
        Executes Reporting Services or BI Report Server setup using the provided setup executable.

        See the link in the commands help for information on each parameter.

    .PARAMETER Install
        Specifies that a new installation should be performed.

    .PARAMETER Uninstall
        Specifies that an uninstallation should be performed.

    .PARAMETER Repair
        Specifies that a repair should be performed on an existing installation.

    .PARAMETER AcceptLicensingTerms
        Required parameter to be able to run unattended install. By specifying this
        parameter you acknowledge the acceptance of all license terms and notices for
        the specified features, the terms and notices that the setup executable
        normally asks for.

    .PARAMETER MediaPath
        Specifies the path where to find the SQL Server installation media. On this
        path the SQL Server setup executable must be found.

    .PARAMETER ProductKey
        Specifies the product key to use for the installation, e.g. '12345-12345-12345-12345-12345'.
        This parameter is mutually exclusive with the parameter Edition.

    .PARAMETER EditionUpgrade
        Upgrades the edition of the installed product. Requires that either the
        ProductKey or the Edition parameter is also assigned. By default no edition
        upgrade is performed.

    .PARAMETER Edition
        Specifies a free custom edition to use for the installation. This parameter
        is mutually exclusive with the parameter ProductKey.

    .PARAMETER LogPath
        Specifies the file path where to write the log files, e.g. 'C:\Logs\Install.log'.
        By default log files are created under %TEMP%.

    .PARAMETER InstallFolder
        Specifies the folder where to install the product, e.g. 'C:\Program Files\SSRS'.
        By default the product is installed under the default installation folder.

        Reporting Services: %ProgramFiles%\Microsoft SQL Server Reporting Services
        PI Report Server: %ProgramFiles%\Microsoft Power BI Report Server

    .PARAMETER SuppressRestart
        Suppresses the restart of the computer after the installation is finished.
        By default the computer is restarted after the installation is finished.

    .PARAMETER Timeout
        Specifies how long to wait for the setup process to finish. Default value
        is `7200` seconds (2 hours). If the setup process does not finish before
        this time, an exception will be thrown.

    .PARAMETER Force
        If specified the command will not ask for confirmation. Same as if Confirm:$false
        is used.

    .PARAMETER PassThru
        If specified the command will return the setup process exit code.

    .LINK
        https://learn.microsoft.com/en-us/power-bi/report-server/install-report-server
        https://learn.microsoft.com/en-us/sql/reporting-services/install-windows/install-reporting-services

    .OUTPUTS
        When PassThru is specified the function will return the setup process exit
        code as System.Int32. Otherwise, the function does not generate any output.

    .EXAMPLE
        Invoke-ReportServerSetupAction -Install -AcceptLicensingTerms -MediaPath 'E:\SQLServerReportingServices.exe'

        Installs SQL Server Reporting Services with default settings.

    .EXAMPLE
        Invoke-ReportServerSetupAction -Install -AcceptLicensingTerms -MediaPath 'E:\SQLServerReportingServices.exe' -ProductKey '12345-12345-12345-12345-12345'

        Installs SQL Server Reporting Services using a product key.

    .EXAMPLE
        Invoke-ReportServerSetupAction -Install -AcceptLicensingTerms -MediaPath 'E:\PowerBIReportServer.exe' -Edition 'Evaluation' -InstallFolder 'C:\Program Files\Power BI Report Server'

        Installs Power BI Report Server in evaluation edition to a custom folder.

    .EXAMPLE
        Invoke-ReportServerSetupAction -Install -AcceptLicensingTerms -MediaPath 'E:\SQLServerReportingServices.exe' -ProductKey '12345-12345-12345-12345-12345' -EditionUpgrade -LogPath 'C:\Logs\SSRS_Install.log'

        Installs SQL Server Reporting Services and upgrades the edition using a product key. Also specifies a custom log path.

    .EXAMPLE
        Invoke-ReportServerSetupAction -Repair -AcceptLicensingTerms -MediaPath 'E:\SQLServerReportingServices.exe'

        Repairs an existing installation of SQL Server Reporting Services.

    .EXAMPLE
        Invoke-ReportServerSetupAction -Uninstall -MediaPath 'E:\SQLServerReportingServices.exe' -Force

        Uninstalls SQL Server Reporting Services without prompting for confirmation.

    .EXAMPLE
        $exitCode = Invoke-ReportServerSetupAction -Install -AcceptLicensingTerms -MediaPath 'E:\SQLServerReportingServices.exe' -PassThru

        Installs SQL Server Reporting Services and returns the setup process exit code.
#>
function Invoke-ReportServerSetupAction
{
    [CmdletBinding(SupportsShouldProcess = $true, ConfirmImpact = 'High')]
    [OutputType([System.Int32])]
    param
    (
        [Parameter(ParameterSetName = 'Install', Mandatory = $true)]
        [System.Management.Automation.SwitchParameter]
        $Install,

        [Parameter(ParameterSetName = 'Uninstall', Mandatory = $true)]
        [System.Management.Automation.SwitchParameter]
        $Uninstall,

        [Parameter(ParameterSetName = 'Repair', Mandatory = $true)]
        [System.Management.Automation.SwitchParameter]
        $Repair,

        [Parameter(ParameterSetName = 'Install', Mandatory = $true)]
        [Parameter(ParameterSetName = 'Repair', Mandatory = $true)]
        [System.Management.Automation.SwitchParameter]
        $AcceptLicensingTerms,

        [Parameter(Mandatory = $true)]
        [ValidateScript({
                if (-not (Test-Path -Path $_ -PathType 'Leaf'))
                {
                    throw $script:localizedData.ReportServerSetupAction_ReportServerExecutableNotFound
                }

                return $true
            })]
        [System.String]
        $MediaPath,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'Repair')]
        [System.String]
        $ProductKey,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'Repair')]
        [System.Management.Automation.SwitchParameter]
        $EditionUpgrade,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'Repair')]
        [ValidateSet('Developer', 'Evaluation', 'ExpressAdvanced')]
        [System.String]
        $Edition,

        [Parameter()]
        [System.String]
        $LogPath,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'Repair')]
        [ValidateScript({
                $parentInstallFolder = Split-Path -Path $_ -Parent

                if (-not (Test-Path -Path $parentInstallFolder))
                {
                    throw $script:localizedData.ReportServerSetupAction_InstallFolderNotFound
                }

                return $true
            })]
        [System.String]
        $InstallFolder,

        [Parameter()]
        [System.Management.Automation.SwitchParameter]
        $SuppressRestart,

        [Parameter()]
        [System.UInt32]
        $Timeout = 7200,

        [Parameter()]
        [System.Management.Automation.SwitchParameter]
        $Force,

        [Parameter()]
        [System.Management.Automation.SwitchParameter]
        $PassThru
    )

    $previousErrorActionPreference = $ErrorActionPreference

    $ErrorActionPreference = 'Stop'

    if ($Force.IsPresent -and -not $Confirm)
    {
        $ConfirmPreference = 'None'
    }

    $originalErrorActionPreference = $ErrorActionPreference

    $ErrorActionPreference = 'Stop'

    Assert-ElevatedUser -ErrorAction 'Stop'

    $ErrorActionPreference = $originalErrorActionPreference

    $assertBoundParameters = @{
        BoundParameterList     = $PSBoundParameters
        MutuallyExclusiveList1 = @(
            'Edition'
        )
        MutuallyExclusiveList2 = @(
            'ProductKey'
        )
    }

    # Either ProductKey or Edition must be specified, never both.
    Assert-BoundParameter @assertBoundParameters

    # If EditionUpgrade is specified then the parameter ProductKey or Edition must be specified.
    $assertBoundParameters = @{
        BoundParameterList = $PSBoundParameters
        IfParameterPresent = @('EditionUpgrade')
        RequiredParameter  = ('ProductKey', 'Edition')
        RequiredBehavior   = 'Any'
    }

    Assert-BoundParameter @assertBoundParameters

    $ErrorActionPreference = $previousErrorActionPreference

    # Sensitive values.
    $sensitiveValue = @()

    # Default action is install or upgrade.
    $setupArgument = '/quiet /IAcceptLicenseTerms'

    if ($Uninstall.IsPresent)
    {
        $setupArgument += ' /uninstall'
    }
    elseif ($Repair.IsPresent)
    {
        $setupArgument += ' /repair'
    }

    if ($ProductKey)
    {
        $setupArgument += ' /PID={0}' -f $ProductKey

        $sensitiveValue += @(
            $ProductKey
        )
    }

    if ($EditionUpgrade.IsPresent)
    {
        $setupArgument += ' /EditionUpgrade'
    }

    if ($Edition)
    {
        $editionMap = @{
            Developer       = 'Dev'
            Evaluation      = 'Eval'
            ExpressAdvanced = 'ExprAdv'
        }

        $setupArgument += ' /Edition={0}' -f $editionMap.$Edition
    }

    if ($LogPath)
    {
        $setupArgument += ' /log "{0}"' -f $LogPath
    }

    if ($InstallFolder)
    {
        $setupArgument += ' /InstallFolder="{0}"' -f $InstallFolder
    }

    if ($SuppressRestart.IsPresent)
    {
        $setupArgument += ' /norestart'
    }

    $verboseSetupArgument = $setupArgument

    # Obfuscate sensitive values.
    foreach ($currentSensitiveValue in $sensitiveValue)
    {
        $escapedRegExString = [System.Text.RegularExpressions.Regex]::Escape($currentSensitiveValue)

        $verboseSetupArgument = $verboseSetupArgument -replace $escapedRegExString, '********'
    }

    # Clear sensitive values.
    $sensitiveValue = $null

    Write-Verbose -Message ($script:localizedData.ReportServerSetupAction_SetupArguments -f $verboseSetupArgument)

    $verboseDescriptionMessage = $script:localizedData.ReportServerSetupAction_ShouldProcessVerboseDescription -f $PSCmdlet.ParameterSetName
    $verboseWarningMessage = $script:localizedData.ReportServerSetupAction_ShouldProcessVerboseWarning -f $PSCmdlet.ParameterSetName
    $captionMessage = $script:localizedData.ReportServerSetupAction_ShouldProcessCaption

    if ($PSCmdlet.ShouldProcess($verboseDescriptionMessage, $verboseWarningMessage, $captionMessage))
    {
        $expandedMediaPath = [System.Environment]::ExpandEnvironmentVariables($MediaPath)

        $startProcessParameters = @{
            FilePath     = $expandedMediaPath
            ArgumentList = $setupArgument
            Timeout      = $Timeout
        }

        # Clear setupArgument to remove any sensitive values.
        $setupArgument = $null

        # Run setup executable.
        $processExitCode = Start-SqlSetupProcess @startProcessParameters

        $setupExitMessage = ($script:localizedData.SetupAction_SetupExitMessage -f $processExitCode)

        if ($processExitCode -eq 3010)
        {
            Write-Warning -Message (
                '{0} {1}' -f $setupExitMessage, $script:localizedData.SetupAction_SetupSuccessfulRebootRequired
            )
        }
        elseif ($processExitCode -ne 0)
        {
            $PSCmdlet.ThrowTerminatingError(
                [System.Management.Automation.ErrorRecord]::new(
                    $setupExitMessage,
                    'IRS0001', # cspell: disable-line
                    [System.Management.Automation.ErrorCategory]::InvalidOperation,
                    $PSCmdlet.ParameterSetName
                )
            )
        }
        else
        {
            Write-Verbose -Message (
                '{0} {1}' -f $setupExitMessage, ($script:localizedData.SetupAction_SetupSuccessful)
            )
        }

        if ($PassThru.IsPresent)
        {
            return $processExitCode
        }
    }
}
#EndRegion '.\Private\Invoke-ReportServerSetupAction.ps1' 363
#Region '.\Private\Invoke-SetupAction.ps1' -1

<#
    .SYNOPSIS
        Executes an setup action using Microsoft SQL Server setup executable.

    .DESCRIPTION
        Executes an setup action using Microsoft SQL Server setup executable.

        See the link in the commands help for information on each parameter. The
        link points to SQL Server command line setup documentation.

    .PARAMETER Install
        Specifies the setup action Install.

    .PARAMETER Uninstall
        Specifies the setup action Uninstall.

    .PARAMETER PrepareImage
        Specifies the setup action PrepareImage.

    .PARAMETER CompleteImage
        Specifies the setup action CompleteImage.

    .PARAMETER Upgrade
        Specifies the setup action Upgrade.

    .PARAMETER EditionUpgrade
        Specifies the setup action EditionUpgrade.

    .PARAMETER Repair
        Specifies the setup action Repair.

    .PARAMETER RebuildDatabase
        Specifies the setup action RebuildDatabase.

    .PARAMETER InstallFailoverCluster
        Specifies the setup action InstallFailoverCluster.

    .PARAMETER PrepareFailoverCluster
        Specifies the setup action PrepareFailoverCluster.

    .PARAMETER CompleteFailoverCluster
        Specifies the setup action CompleteFailoverCluster.

    .PARAMETER AddNode
        Specifies the setup action AddNode.

    .PARAMETER RemoveNode
        Specifies the setup action RemoveNode.

    .PARAMETER ConfigurationFile
        Specifies an configuration file to use during SQL Server setup. This
        parameter cannot be used together with any of the setup actions, but instead
        it is expected that the configuration file specifies what setup action to
        run.

    .PARAMETER AcceptLicensingTerms
        Required parameter to be able to run unattended install. By specifying this
        parameter you acknowledge the acceptance of all license terms and notices for
        the specified features, the terms and notices that the Microsoft SQL Server
        setup executable normally asks for.

    .PARAMETER MediaPath
        Specifies the path where to find the SQL Server installation media. On this
        path the SQL Server setup executable must be found.

    .PARAMETER Timeout
        Specifies how long to wait for the setup process to finish. Default value
        is `7200` seconds (2 hours). If the setup process does not finish before
        this time, an exception will be thrown.

    .PARAMETER Force
        If specified the command will not ask for confirmation. Same as if Confirm:$false
        is used.

    .PARAMETER SuppressPrivacyStatementNotice
        See the notes section for more information.

    .PARAMETER IAcknowledgeEntCalLimits
        See the notes section for more information.

    .PARAMETER InstanceName
        See the notes section for more information.

    .PARAMETER Enu
        See the notes section for more information.

    .PARAMETER UpdateEnabled
        See the notes section for more information.

    .PARAMETER UpdateSource
        See the notes section for more information.

    .PARAMETER Features
        See the notes section for more information.

    .PARAMETER Role
        See the notes section for more information.

    .PARAMETER InstallSharedDir
        See the notes section for more information.

    .PARAMETER InstallSharedWowDir
        See the notes section for more information.

    .PARAMETER InstanceDir
        See the notes section for more information.

    .PARAMETER InstanceId
        See the notes section for more information.

    .PARAMETER PBEngSvcAccount
        See the notes section for more information.

    .PARAMETER PBEngSvcPassword
        See the notes section for more information.

    .PARAMETER PBEngSvcStartupType
        See the notes section for more information.

    .PARAMETER PBDMSSvcAccount
        See the notes section for more information.

    .PARAMETER PBDMSSvcPassword
        See the notes section for more information.

    .PARAMETER PBDMSSvcStartupType
        See the notes section for more information.

    .PARAMETER PBStartPortRange
        See the notes section for more information.

    .PARAMETER PBEndPortRange
        See the notes section for more information.

    .PARAMETER PBScaleOut
        See the notes section for more information.

    .PARAMETER ProductKey
        See the notes section for more information.

    .PARAMETER AgtSvcAccount
        See the notes section for more information.

    .PARAMETER AgtSvcPassword
        See the notes section for more information.

    .PARAMETER AgtSvcStartupType
        See the notes section for more information.

    .PARAMETER ASBackupDir
        See the notes section for more information.

    .PARAMETER ASCollation
        See the notes section for more information.

    .PARAMETER ASConfigDir
        See the notes section for more information.

    .PARAMETER ASDataDir
        See the notes section for more information.

    .PARAMETER ASLogDir
        See the notes section for more information.

    .PARAMETER ASTempDir
        See the notes section for more information.

    .PARAMETER ASServerMode
        See the notes section for more information.

    .PARAMETER ASSvcAccount
        See the notes section for more information.

    .PARAMETER ASSvcPassword
        See the notes section for more information.

    .PARAMETER ASSvcStartupType
        See the notes section for more information.

    .PARAMETER ASSysAdminAccounts
        See the notes section for more information.

    .PARAMETER ASProviderMSOLAP
        See the notes section for more information.

    .PARAMETER FarmAccount
        See the notes section for more information.

    .PARAMETER FarmPassword
        See the notes section for more information.

    .PARAMETER Passphrase
        See the notes section for more information.

    .PARAMETER FarmAdminiPort
        See the notes section for more information.

    .PARAMETER BrowserSvcStartupType
        See the notes section for more information.

    .PARAMETER FTUpgradeOption
        See the notes section for more information.

    .PARAMETER EnableRanU
        See the notes section for more information.

    .PARAMETER InstallSqlDataDir
        See the notes section for more information.

    .PARAMETER SqlBackupDir
        See the notes section for more information.

    .PARAMETER SecurityMode
        See the notes section for more information.

    .PARAMETER SAPwd
        See the notes section for more information.

    .PARAMETER SqlCollation
        See the notes section for more information.

    .PARAMETER AddCurrentUserAsSqlAdmin
        See the notes section for more information.

    .PARAMETER SqlSvcAccount
        See the notes section for more information.

    .PARAMETER SqlSvcPassword
        See the notes section for more information.

    .PARAMETER SqlSvcStartupType
        See the notes section for more information.

    .PARAMETER SqlSysAdminAccounts
        See the notes section for more information.

    .PARAMETER SqlTempDbDir
        See the notes section for more information.

    .PARAMETER SqlTempDbLogDir
        See the notes section for more information.

    .PARAMETER SqlTempDbFileCount
        See the notes section for more information.

    .PARAMETER SqlTempDbFileSize
        See the notes section for more information.

    .PARAMETER SqlTempDbFileGrowth
        See the notes section for more information.

    .PARAMETER SqlTempDbLogFileSize
        See the notes section for more information.

    .PARAMETER SqlTempDbLogFileGrowth
        See the notes section for more information.

    .PARAMETER SqlUserDbDir
        See the notes section for more information.

    .PARAMETER SqlSvcInstantFileInit
        See the notes section for more information.

    .PARAMETER SqlUserDbLogDir
        See the notes section for more information.

    .PARAMETER SqlMaxDop
        See the notes section for more information.

    .PARAMETER UseSqlRecommendedMemoryLimits
        See the notes section for more information.

    .PARAMETER SqlMinMemory
        See the notes section for more information.

    .PARAMETER SqlMaxMemory
        See the notes section for more information.

    .PARAMETER FileStreamLevel
        See the notes section for more information.

    .PARAMETER FileStreamShareName
        See the notes section for more information.

    .PARAMETER ISSvcAccount
        See the notes section for more information.

    .PARAMETER ISSvcPassword
        See the notes section for more information.

    .PARAMETER ISSvcStartupType
        See the notes section for more information.

    .PARAMETER AllowUpgradeForSSRSSharePointMode
        See the notes section for more information.

    .PARAMETER NpEnabled
        See the notes section for more information.

    .PARAMETER TcpEnabled
        See the notes section for more information.

    .PARAMETER RsInstallMode
        See the notes section for more information.

    .PARAMETER RSSvcAccount
        See the notes section for more information.

    .PARAMETER RSSvcPassword
        See the notes section for more information.

    .PARAMETER RSSvcStartupType
        See the notes section for more information.

    .PARAMETER MPYCacheDirectory
        See the notes section for more information.

    .PARAMETER MRCacheDirectory
        See the notes section for more information.

    .PARAMETER SqlInstJava
        See the notes section for more information.

    .PARAMETER SqlJavaDir
        See the notes section for more information.

    .PARAMETER FailoverClusterGroup
        See the notes section for more information.

    .PARAMETER FailoverClusterDisks
        See the notes section for more information.

    .PARAMETER FailoverClusterNetworkName
        See the notes section for more information.

    .PARAMETER FailoverClusterIPAddresses
        See the notes section for more information.

    .PARAMETER ConfirmIPDependencyChange
        See the notes section for more information.

    .PARAMETER FailoverClusterRollOwnership
        See the notes section for more information.

    .PARAMETER AzureSubscriptionId
        See the notes section for more information.

    .PARAMETER AzureResourceGroup
        See the notes section for more information.

    .PARAMETER AzureRegion
        See the notes section for more information.

    .PARAMETER AzureTenantId
        See the notes section for more information.

    .PARAMETER AzureServicePrincipal
        See the notes section for more information.

    .PARAMETER AzureServicePrincipalSecret
        See the notes section for more information.

    .PARAMETER AzureArcProxy
        See the notes section for more information.

    .PARAMETER SkipRules
        See the notes section for more information.

    .PARAMETER ProductCoveredBySA
        See the notes section for more information.

    .LINK
        https://docs.microsoft.com/en-us/sql/database-engine/install-windows/install-sql-server-from-the-command-prompt

    .OUTPUTS
        None.

    .EXAMPLE
        Invoke-SetupAction -Install -AcceptLicensingTerms -InstanceName 'MyInstance' -Features 'SQLENGINE' -SqlSysAdminAccounts @('MyAdminAccount') -MediaPath 'E:\'

        Installs the database engine for the named instance MyInstance.

    .EXAMPLE
        Invoke-SetupAction -Install -AcceptLicensingTerms -InstanceName 'MyInstance' -Features 'SQLENGINE','ARC' -SqlSysAdminAccounts @('MyAdminAccount') -MediaPath 'E:\' -AzureSubscriptionId 'MySubscriptionId' -AzureResourceGroup 'MyRG' -AzureRegion 'West-US' -AzureTenantId 'MyTenantId' -AzureServicePrincipal 'MyPrincipalName' -AzureServicePrincipalSecret ('MySecret' | ConvertTo-SecureString -AsPlainText -Force)

        Installs the database engine for the named instance MyInstance and onboard the server to Azure Arc.

    .EXAMPLE
        Invoke-SetupAction -Install -AcceptLicensingTerms -MediaPath 'E:\' -AzureSubscriptionId 'MySubscriptionId' -AzureResourceGroup 'MyRG' -AzureRegion 'West-US' -AzureTenantId 'MyTenantId' -AzureServicePrincipal 'MyPrincipalName' -AzureServicePrincipalSecret ('MySecret' | ConvertTo-SecureString -AsPlainText -Force)

        Installs the Azure Arc Agent on the server.

    .EXAMPLE
        Invoke-SetupAction -ConfigurationFile 'MySqlConfig.ini' -MediaPath 'E:\'

        Installs SQL Server using the configuration file 'MySqlConfig.ini'.

    .EXAMPLE
        Invoke-SetupAction -Uninstall -InstanceName 'MyInstance' -Features 'SQLENGINE' -MediaPath 'E:\'

        Uninstalls the database engine from the named instance MyInstance.

    .EXAMPLE
        Invoke-SetupAction -PrepareImage -AcceptLicensingTerms -Features 'SQLENGINE' -InstanceId 'MyInstance' -MediaPath 'E:\'

        Prepares the server for using the database engine for an instance named 'MyInstance'.

    .EXAMPLE
        Invoke-SetupAction -CompleteImage -AcceptLicensingTerms -InstanceId 'MSSQLSERVER' -SqlSvcAccount 'NT Service\MSSQLSERVER' -AgtSvcAccount 'NT Service\MSSQLSERVER' -MediaPath 'E:\'

        Completes install on a server that was previously prepared (by using prepare image).

    .EXAMPLE
        Invoke-SetupAction -Upgrade -AcceptLicensingTerms -InstanceName 'MyInstance' -MediaPath 'E:\'

        Upgrades the instance 'MyInstance' with the SQL Server version that is provided by the media path.

    .EXAMPLE
        Invoke-SetupAction -EditionUpgrade -AcceptLicensingTerms -ProductKey 'NewEditionProductKey' -InstanceName 'MyInstance' -MediaPath 'E:\'

        Upgrades the instance 'MyInstance' with the SQL Server edition that is provided by the media path.

    .EXAMPLE
        Invoke-SetupAction -Repair -InstanceName 'MyInstance' -MediaPath 'E:\'

        Repairs all installed features of the instance 'MyInstance'.

    .EXAMPLE
        Invoke-SetupAction -RebuildDatabase -InstanceName 'MyInstance' -SqlSysAdminAccounts @('MyAdminAccount') -MediaPath 'E:\'

        Rebuilds the database of the instance 'MyInstance'.

    .EXAMPLE
        Invoke-SetupAction -InstallFailoverCluster -AcceptLicensingTerms -InstanceName 'MyInstance' -Features 'SQLENGINE' -InstallSqlDataDir 'D:\MSSQL\Data' -SqlSysAdminAccounts @('MyAdminAccount') -FailoverClusterNetworkName 'TestCluster01A' -FailoverClusterIPAddresses 'IPv4;192.168.0.46;ClusterNetwork1;255.255.255.0' -MediaPath 'E:\'

        Installs the database engine in a failover cluster with the instance name 'MyInstance'.

    .EXAMPLE
        Invoke-SetupAction -PrepareFailoverCluster -AcceptLicensingTerms -InstanceName 'MyInstance' -Features 'SQLENGINE' -MediaPath 'E:\'

        Prepares to installs the database engine in a failover cluster with the instance name 'MyInstance'.

    .EXAMPLE
        Invoke-SetupAction -CompleteFailoverCluster -InstanceName 'MyInstance' -InstallSqlDataDir 'D:\MSSQL\Data' -SqlSysAdminAccounts @('MyAdminAccount') -FailoverClusterNetworkName 'TestCluster01A' -FailoverClusterIPAddresses 'IPv4;192.168.0.46;ClusterNetwork1;255.255.255.0' -MediaPath 'E:\'

        Completes the install of the database engine in the failover cluster with the instance name 'MyInstance'.

    .EXAMPLE
        Invoke-SetupAction -AddNode -AcceptLicensingTerms -InstanceName 'MyInstance' -FailoverClusterIPAddresses 'IPv4;192.168.0.46;ClusterNetwork1;255.255.255.0' -MediaPath 'E:\'

        Adds the node to the failover cluster for the instance 'MyInstance'.

    .EXAMPLE
        Invoke-SetupAction -RemoveNode -InstanceName 'MyInstance' -MediaPath 'E:\'

        Removes the node from the failover cluster of the instance 'MyInstance'.

    .NOTES
        The parameters are intentionally not described since it would take a lot
        of effort to keep them up to date. Instead there is a link that points to
        the SQL Server command line setup documentation which will stay relevant.

        For RebuildDatabase the parameter SAPwd must be set if the instance was
        installed with SecurityMode = 'SQL'.

        SQL Server Repair action does not accept the FEATURES parameter. Although
        Microsoft's documentation lists /FEATURES as required for the Repair action,
        the actual SQL Server setup executable (tested with SQL Server 2017 and
        SQL Server 2022) rejects this parameter with the error: "The setting
        'FEATURES' is not allowed when the value of setting 'ACTION' is 'Repair'."
        SQL Server automatically repairs all installed features during a repair
        operation.
#>
function Invoke-SetupAction
{
    # cSpell: ignore PBDMS Admini AZUREEXTENSION BSTR
    [CmdletBinding(SupportsShouldProcess = $true, ConfirmImpact = 'High')]
    [OutputType()]
    param
    (
        [Parameter(ParameterSetName = 'Install', Mandatory = $true)]
        [Parameter(ParameterSetName = 'InstallRole', Mandatory = $true)]
        [Parameter(ParameterSetName = 'InstallAzureArcAgent', Mandatory = $true)]
        [System.Management.Automation.SwitchParameter]
        $Install,

        [Parameter(ParameterSetName = 'Uninstall', Mandatory = $true)]
        [System.Management.Automation.SwitchParameter]
        $Uninstall,

        [Parameter(ParameterSetName = 'PrepareImage', Mandatory = $true)]
        [System.Management.Automation.SwitchParameter]
        $PrepareImage,

        [Parameter(ParameterSetName = 'CompleteImage', Mandatory = $true)]
        [System.Management.Automation.SwitchParameter]
        $CompleteImage,

        [Parameter(ParameterSetName = 'Upgrade', Mandatory = $true)]
        [System.Management.Automation.SwitchParameter]
        $Upgrade,

        [Parameter(ParameterSetName = 'EditionUpgrade', Mandatory = $true)]
        [System.Management.Automation.SwitchParameter]
        $EditionUpgrade,

        [Parameter(ParameterSetName = 'Repair', Mandatory = $true)]
        [System.Management.Automation.SwitchParameter]
        $Repair,

        [Parameter(ParameterSetName = 'RebuildDatabase', Mandatory = $true)]
        [System.Management.Automation.SwitchParameter]
        $RebuildDatabase,

        [Parameter(ParameterSetName = 'InstallFailoverCluster', Mandatory = $true)]
        [System.Management.Automation.SwitchParameter]
        $InstallFailoverCluster,

        [Parameter(ParameterSetName = 'PrepareFailoverCluster', Mandatory = $true)]
        [System.Management.Automation.SwitchParameter]
        $PrepareFailoverCluster,

        [Parameter(ParameterSetName = 'CompleteFailoverCluster', Mandatory = $true)]
        [System.Management.Automation.SwitchParameter]
        $CompleteFailoverCluster,

        [Parameter(ParameterSetName = 'AddNode', Mandatory = $true)]
        [System.Management.Automation.SwitchParameter]
        $AddNode,

        [Parameter(ParameterSetName = 'RemoveNode', Mandatory = $true)]
        [System.Management.Automation.SwitchParameter]
        $RemoveNode,

        [Parameter(ParameterSetName = 'UsingConfigurationFile', Mandatory = $true)]
        [ValidateScript({
                if (-not (Test-Path -Path $_))
                {
                    throw $script:localizedData.Invoke_SetupAction_ConfigurationFileNotFound
                }

                return $true
            })]
        [System.String]
        $ConfigurationFile,

        [Parameter(ParameterSetName = 'Install', Mandatory = $true)]
        [Parameter(ParameterSetName = 'InstallRole', Mandatory = $true)]
        [Parameter(ParameterSetName = 'InstallAzureArcAgent', Mandatory = $true)]
        [Parameter(ParameterSetName = 'PrepareImage', Mandatory = $true)]
        [Parameter(ParameterSetName = 'Upgrade', Mandatory = $true)]
        [Parameter(ParameterSetName = 'EditionUpgrade', Mandatory = $true)]
        [Parameter(ParameterSetName = 'InstallFailoverCluster', Mandatory = $true)]
        [Parameter(ParameterSetName = 'PrepareFailoverCluster', Mandatory = $true)]
        [Parameter(ParameterSetName = 'AddNode', Mandatory = $true)]
        [Parameter(ParameterSetName = 'CompleteImage', Mandatory = $true)]
        [System.Management.Automation.SwitchParameter]
        $AcceptLicensingTerms,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [System.Management.Automation.SwitchParameter]
        $SuppressPrivacyStatementNotice,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [Parameter(ParameterSetName = 'PrepareImage')]
        [Parameter(ParameterSetName = 'InstallFailoverCluster')]
        [Parameter(ParameterSetName = 'PrepareFailoverCluster')]
        [Parameter(ParameterSetName = 'AddNode')]
        [System.Management.Automation.SwitchParameter]
        $IAcknowledgeEntCalLimits,

        [Parameter(Mandatory = $true)]
        [ValidateScript({
                if (-not (Test-Path -Path (Join-Path -Path $_ -ChildPath 'setup.exe')))
                {
                    throw $script:localizedData.Invoke_SetupAction_MediaPathNotFound
                }

                return $true
            })]
        [System.String]
        $MediaPath,

        [Parameter(ParameterSetName = 'Install', Mandatory = $true)]
        [Parameter(ParameterSetName = 'Uninstall', Mandatory = $true)]
        [Parameter(ParameterSetName = 'Upgrade', Mandatory = $true)]
        [Parameter(ParameterSetName = 'EditionUpgrade', Mandatory = $true)]
        [Parameter(ParameterSetName = 'Repair', Mandatory = $true)]
        [Parameter(ParameterSetName = 'RebuildDatabase', Mandatory = $true)]
        [Parameter(ParameterSetName = 'InstallFailoverCluster', Mandatory = $true)]
        [Parameter(ParameterSetName = 'PrepareFailoverCluster', Mandatory = $true)]
        [Parameter(ParameterSetName = 'CompleteFailoverCluster', Mandatory = $true)]
        [Parameter(ParameterSetName = 'AddNode', Mandatory = $true)]
        [Parameter(ParameterSetName = 'RemoveNode', Mandatory = $true)]
        [Parameter(ParameterSetName = 'CompleteImage')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [System.String]
        $InstanceName,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [Parameter(ParameterSetName = 'PrepareImage')]
        [Parameter(ParameterSetName = 'CompleteImage')]
        [Parameter(ParameterSetName = 'Upgrade')]
        [Parameter(ParameterSetName = 'Repair')]
        [Parameter(ParameterSetName = 'InstallFailoverCluster')]
        [Parameter(ParameterSetName = 'PrepareFailoverCluster')]
        [Parameter(ParameterSetName = 'CompleteFailoverCluster')]
        [Parameter(ParameterSetName = 'AddNode')]
        [System.Management.Automation.SwitchParameter]
        $Enu,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [Parameter(ParameterSetName = 'PrepareImage')]
        [Parameter(ParameterSetName = 'Upgrade')]
        [Parameter(ParameterSetName = 'InstallFailoverCluster')]
        [Parameter(ParameterSetName = 'PrepareFailoverCluster')]
        [Parameter(ParameterSetName = 'AddNode')]
        [System.Management.Automation.SwitchParameter]
        $UpdateEnabled,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [Parameter(ParameterSetName = 'PrepareImage')]
        [Parameter(ParameterSetName = 'Upgrade')]
        [Parameter(ParameterSetName = 'InstallFailoverCluster')]
        [Parameter(ParameterSetName = 'PrepareFailoverCluster')]
        [Parameter(ParameterSetName = 'AddNode')]
        [System.String]
        $UpdateSource,

        [Parameter(ParameterSetName = 'Install', Mandatory = $true)]
        [Parameter(ParameterSetName = 'PrepareImage', Mandatory = $true)]
        [Parameter(ParameterSetName = 'Uninstall', Mandatory = $true)]
        [Parameter(ParameterSetName = 'InstallFailoverCluster', Mandatory = $true)]
        [Parameter(ParameterSetName = 'PrepareFailoverCluster', Mandatory = $true)]
        [Parameter(ParameterSetName = 'InstallRole')]
        [ValidateSet(
            'SQL',
            'SQLEngine', # Part of parent feature SQL
            'Replication', # Part of parent feature SQL
            'FullText', # Part of parent feature SQL
            'DQ', # Part of parent feature SQL
            'PolyBase', # Part of parent feature SQL
            'PolyBaseCore', # Part of parent feature SQL
            'PolyBaseJava', # Part of parent feature SQL
            'AdvancedAnalytics', # Part of parent feature SQL
            'SQL_INST_MR', # Part of parent feature SQL
            'SQL_INST_MPY', # Part of parent feature SQL
            'SQL_INST_JAVA', # Part of parent feature SQL
            'AS',
            'RS',
            'RS_SHP',
            'RS_SHPWFE', # cspell: disable-line
            'DQC',
            'IS',
            'IS_Master', # Part of parent feature IS
            'IS_Worker', # Part of parent feature IS
            'MDS',
            'SQL_SHARED_MPY',
            'SQL_SHARED_MR',
            'Tools',
            'BC', # Part of parent feature Tools
            'Conn', # Part of parent feature Tools
            'DREPLAY_CTLR', # Part of parent feature Tools (cspell: disable-line)
            'DREPLAY_CLT', # Part of parent feature Tools (cspell: disable-line)
            'SNAC_SDK', # Part of parent feature Tools (cspell: disable-line)
            'SDK', # Part of parent feature Tools
            'LocalDB', # Part of parent feature Tools
            'AZUREEXTENSION'
        )]
        [System.String[]]
        $Features,

        [Parameter(ParameterSetName = 'InstallRole', Mandatory = $true)]
        [ValidateSet(
            'ALLFeatures_WithDefaults',
            'SPI_AS_NewFarm',
            'SPI_AS_ExistingFarm'
        )]
        [System.String]
        $Role,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [Parameter(ParameterSetName = 'PrepareImage')]
        [Parameter(ParameterSetName = 'InstallFailoverCluster')]
        [Parameter(ParameterSetName = 'PrepareFailoverCluster')]
        [System.String]
        $InstallSharedDir,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [Parameter(ParameterSetName = 'PrepareImage')]
        [Parameter(ParameterSetName = 'InstallFailoverCluster')]
        [Parameter(ParameterSetName = 'PrepareFailoverCluster')]
        [System.String]
        $InstallSharedWowDir,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [Parameter(ParameterSetName = 'PrepareImage')]
        [Parameter(ParameterSetName = 'Upgrade')]
        [Parameter(ParameterSetName = 'InstallFailoverCluster')]
        [Parameter(ParameterSetName = 'PrepareFailoverCluster')]
        [System.String]
        $InstanceDir,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [Parameter(ParameterSetName = 'PrepareImage')]
        [Parameter(ParameterSetName = 'CompleteImage')]
        [Parameter(ParameterSetName = 'Upgrade')]
        [Parameter(ParameterSetName = 'InstallFailoverCluster')]
        [Parameter(ParameterSetName = 'PrepareFailoverCluster')]
        [System.String]
        $InstanceId,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [Parameter(ParameterSetName = 'PrepareImage')]
        [Parameter(ParameterSetName = 'CompleteImage')]
        [Parameter(ParameterSetName = 'Repair')]
        [Parameter(ParameterSetName = 'InstallFailoverCluster')]
        [Parameter(ParameterSetName = 'PrepareFailoverCluster')]
        [Parameter(ParameterSetName = 'AddNode')]
        [System.String]
        $PBEngSvcAccount,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [Parameter(ParameterSetName = 'PrepareImage')]
        [Parameter(ParameterSetName = 'CompleteImage')]
        [Parameter(ParameterSetName = 'Repair')]
        [Parameter(ParameterSetName = 'InstallFailoverCluster')]
        [Parameter(ParameterSetName = 'PrepareFailoverCluster')]
        [Parameter(ParameterSetName = 'AddNode')]
        [System.Security.SecureString]
        $PBEngSvcPassword,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [Parameter(ParameterSetName = 'PrepareImage')]
        [Parameter(ParameterSetName = 'CompleteImage')]
        [Parameter(ParameterSetName = 'Repair')]
        [Parameter(ParameterSetName = 'InstallFailoverCluster')]
        [Parameter(ParameterSetName = 'PrepareFailoverCluster')]
        [Parameter(ParameterSetName = 'AddNode')]
        [ValidateSet('Automatic', 'Disabled', 'Manual')]
        [System.String]
        $PBEngSvcStartupType,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [System.String]
        $PBDMSSvcAccount, # cspell: disable-line

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [System.Security.SecureString]
        $PBDMSSvcPassword, # cspell: disable-line

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [ValidateSet('Automatic', 'Disabled', 'Manual')]
        [System.String]
        $PBDMSSvcStartupType, # cspell: disable-line

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [Parameter(ParameterSetName = 'PrepareImage')]
        [Parameter(ParameterSetName = 'CompleteImage')]
        [Parameter(ParameterSetName = 'Repair')]
        [Parameter(ParameterSetName = 'InstallFailoverCluster')]
        [Parameter(ParameterSetName = 'PrepareFailoverCluster')]
        [Parameter(ParameterSetName = 'AddNode')]
        [System.UInt16]
        $PBStartPortRange,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [Parameter(ParameterSetName = 'PrepareImage')]
        [Parameter(ParameterSetName = 'CompleteImage')]
        [Parameter(ParameterSetName = 'Repair')]
        [Parameter(ParameterSetName = 'InstallFailoverCluster')]
        [Parameter(ParameterSetName = 'PrepareFailoverCluster')]
        [Parameter(ParameterSetName = 'AddNode')]
        [System.UInt16]
        $PBEndPortRange,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [Parameter(ParameterSetName = 'PrepareImage')]
        [Parameter(ParameterSetName = 'CompleteImage')]
        [Parameter(ParameterSetName = 'Repair')]
        [Parameter(ParameterSetName = 'InstallFailoverCluster')]
        [Parameter(ParameterSetName = 'PrepareFailoverCluster')]
        [Parameter(ParameterSetName = 'AddNode')]
        [System.Management.Automation.SwitchParameter]
        $PBScaleOut,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [Parameter(ParameterSetName = 'CompleteImage')]
        [Parameter(ParameterSetName = 'Upgrade')]
        [Parameter(ParameterSetName = 'InstallFailoverCluster')]
        [Parameter(ParameterSetName = 'PrepareFailoverCluster')]
        [Parameter(ParameterSetName = 'CompleteFailoverCluster')]
        [Parameter(ParameterSetName = 'AddNode')]
        [Parameter(ParameterSetName = 'EditionUpgrade', Mandatory = $true)]
        [System.String]
        $ProductKey, # This is argument PID but $PID is reserved variable.

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [Parameter(ParameterSetName = 'CompleteImage')]
        [Parameter(ParameterSetName = 'InstallFailoverCluster')]
        [Parameter(ParameterSetName = 'PrepareFailoverCluster')]
        [Parameter(ParameterSetName = 'AddNode')]
        [System.String]
        $AgtSvcAccount,

        [Parameter(ParameterSetName = 'UsingConfigurationFile')]
        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [Parameter(ParameterSetName = 'CompleteImage')]
        [Parameter(ParameterSetName = 'InstallFailoverCluster')]
        [Parameter(ParameterSetName = 'PrepareFailoverCluster')]
        [Parameter(ParameterSetName = 'AddNode')]
        [System.Security.SecureString]
        $AgtSvcPassword,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [Parameter(ParameterSetName = 'CompleteImage')]
        [ValidateSet('Automatic', 'Disabled', 'Manual')]
        [System.String]
        $AgtSvcStartupType,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [Parameter(ParameterSetName = 'InstallFailoverCluster')]
        [Parameter(ParameterSetName = 'CompleteFailoverCluster')]
        [System.String]
        $ASBackupDir,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [Parameter(ParameterSetName = 'InstallFailoverCluster')]
        [Parameter(ParameterSetName = 'CompleteFailoverCluster')]
        [System.String]
        $ASCollation,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [Parameter(ParameterSetName = 'InstallFailoverCluster')]
        [Parameter(ParameterSetName = 'CompleteFailoverCluster')]
        [System.String]
        $ASConfigDir,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [Parameter(ParameterSetName = 'InstallFailoverCluster')]
        [Parameter(ParameterSetName = 'CompleteFailoverCluster')]
        [System.String]
        $ASDataDir,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [Parameter(ParameterSetName = 'InstallFailoverCluster')]
        [Parameter(ParameterSetName = 'CompleteFailoverCluster')]
        [System.String]
        $ASLogDir,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [Parameter(ParameterSetName = 'InstallFailoverCluster')]
        [Parameter(ParameterSetName = 'CompleteFailoverCluster')]
        [System.String]
        $ASTempDir,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [Parameter(ParameterSetName = 'InstallFailoverCluster')]
        [Parameter(ParameterSetName = 'CompleteFailoverCluster')]
        [ValidateSet('Multidimensional', 'PowerPivot', 'Tabular')]
        [System.String]
        $ASServerMode,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [Parameter(ParameterSetName = 'InstallFailoverCluster')]
        [Parameter(ParameterSetName = 'PrepareFailoverCluster')]
        [Parameter(ParameterSetName = 'AddNode')]
        [System.String]
        $ASSvcAccount,

        [Parameter(ParameterSetName = 'UsingConfigurationFile')]
        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [Parameter(ParameterSetName = 'InstallFailoverCluster')]
        [Parameter(ParameterSetName = 'PrepareFailoverCluster')]
        [Parameter(ParameterSetName = 'AddNode')]
        [System.Security.SecureString]
        $ASSvcPassword,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [Parameter(ParameterSetName = 'InstallFailoverCluster')]
        [ValidateSet('Automatic', 'Disabled', 'Manual')]
        [System.String]
        $ASSvcStartupType,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [Parameter(ParameterSetName = 'InstallFailoverCluster')]
        [Parameter(ParameterSetName = 'CompleteFailoverCluster')]
        [System.String[]]
        $ASSysAdminAccounts,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [Parameter(ParameterSetName = 'InstallFailoverCluster')]
        [Parameter(ParameterSetName = 'CompleteFailoverCluster')]
        [System.Management.Automation.SwitchParameter]
        $ASProviderMSOLAP,

        [Parameter(ParameterSetName = 'InstallRole')]
        [System.String]
        $FarmAccount,

        [Parameter(ParameterSetName = 'InstallRole')]
        [System.Security.SecureString]
        $FarmPassword,

        [Parameter(ParameterSetName = 'InstallRole')]
        [System.Security.SecureString]
        $Passphrase,

        [Parameter(ParameterSetName = 'InstallRole')]
        [ValidateRange(0, 65536)]
        [System.UInt16]
        $FarmAdminiPort, # cspell: disable-line

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [Parameter(ParameterSetName = 'CompleteImage')]
        [Parameter(ParameterSetName = 'Upgrade')]
        [ValidateSet('Automatic', 'Disabled', 'Manual')]
        [System.String]
        $BrowserSvcStartupType,

        [Parameter(ParameterSetName = 'Upgrade')]
        [ValidateSet('Rebuild', 'Reset', 'Import')]
        [System.String]
        $FTUpgradeOption,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [Parameter(ParameterSetName = 'CompleteImage')]
        [System.Management.Automation.SwitchParameter]
        $EnableRanU,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [Parameter(ParameterSetName = 'CompleteImage')]
        [Parameter(ParameterSetName = 'InstallFailoverCluster', Mandatory = $true)]
        [Parameter(ParameterSetName = 'CompleteFailoverCluster', Mandatory = $true)]
        [System.String]
        $InstallSqlDataDir,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [Parameter(ParameterSetName = 'CompleteImage')]
        [Parameter(ParameterSetName = 'InstallFailoverCluster')]
        [Parameter(ParameterSetName = 'CompleteFailoverCluster')]
        [System.String]
        $SqlBackupDir,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [Parameter(ParameterSetName = 'CompleteImage')]
        [Parameter(ParameterSetName = 'InstallFailoverCluster')]
        [Parameter(ParameterSetName = 'CompleteFailoverCluster')]
        [ValidateSet('SQL')]
        [System.String]
        $SecurityMode,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [Parameter(ParameterSetName = 'CompleteImage')]
        [Parameter(ParameterSetName = 'RebuildDatabase')]
        [Parameter(ParameterSetName = 'InstallFailoverCluster')]
        [Parameter(ParameterSetName = 'CompleteFailoverCluster')]
        [System.Security.SecureString]
        $SAPwd,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [Parameter(ParameterSetName = 'CompleteImage')]
        [Parameter(ParameterSetName = 'RebuildDatabase')]
        [Parameter(ParameterSetName = 'InstallFailoverCluster')]
        [Parameter(ParameterSetName = 'CompleteFailoverCluster')]
        [System.String]
        $SqlCollation,

        [Parameter(ParameterSetName = 'InstallRole')]
        [System.Management.Automation.SwitchParameter]
        $AddCurrentUserAsSqlAdmin,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [Parameter(ParameterSetName = 'CompleteImage')]
        [Parameter(ParameterSetName = 'InstallFailoverCluster')]
        [Parameter(ParameterSetName = 'PrepareFailoverCluster')]
        [Parameter(ParameterSetName = 'AddNode')]
        [System.String]
        $SqlSvcAccount,

        [Parameter(ParameterSetName = 'UsingConfigurationFile')]
        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [Parameter(ParameterSetName = 'CompleteImage')]
        [Parameter(ParameterSetName = 'InstallFailoverCluster')]
        [Parameter(ParameterSetName = 'PrepareFailoverCluster')]
        [Parameter(ParameterSetName = 'AddNode')]
        [System.Security.SecureString]
        $SqlSvcPassword,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [Parameter(ParameterSetName = 'CompleteImage')]
        [Parameter(ParameterSetName = 'InstallFailoverCluster')]
        [ValidateSet('Automatic', 'Disabled', 'Manual')]
        [System.String]
        $SqlSvcStartupType,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'CompleteImage')]
        [Parameter(ParameterSetName = 'RebuildDatabase', Mandatory = $true)]
        [Parameter(ParameterSetName = 'InstallFailoverCluster', Mandatory = $true)]
        [Parameter(ParameterSetName = 'CompleteFailoverCluster', Mandatory = $true)]
        [Parameter(ParameterSetName = 'InstallRole')]
        [System.String[]]
        $SqlSysAdminAccounts,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [Parameter(ParameterSetName = 'CompleteImage')]
        [Parameter(ParameterSetName = 'RebuildDatabase')]
        [Parameter(ParameterSetName = 'InstallFailoverCluster')]
        [Parameter(ParameterSetName = 'CompleteFailoverCluster')]
        [System.String]
        $SqlTempDbDir,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [Parameter(ParameterSetName = 'CompleteImage')]
        [Parameter(ParameterSetName = 'RebuildDatabase')]
        [Parameter(ParameterSetName = 'InstallFailoverCluster')]
        [Parameter(ParameterSetName = 'CompleteFailoverCluster')]
        [System.String]
        $SqlTempDbLogDir,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [Parameter(ParameterSetName = 'CompleteImage')]
        [Parameter(ParameterSetName = 'RebuildDatabase')]
        [Parameter(ParameterSetName = 'InstallFailoverCluster')]
        [Parameter(ParameterSetName = 'CompleteFailoverCluster')]
        [System.UInt16]
        $SqlTempDbFileCount,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [Parameter(ParameterSetName = 'CompleteImage')]
        [Parameter(ParameterSetName = 'RebuildDatabase')]
        [Parameter(ParameterSetName = 'InstallFailoverCluster')]
        [Parameter(ParameterSetName = 'CompleteFailoverCluster')]
        [ValidateRange(4, 262144)]
        [System.UInt16]
        $SqlTempDbFileSize,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [Parameter(ParameterSetName = 'CompleteImage')]
        [Parameter(ParameterSetName = 'RebuildDatabase')]
        [Parameter(ParameterSetName = 'InstallFailoverCluster')]
        [Parameter(ParameterSetName = 'CompleteFailoverCluster')]
        [ValidateRange(0, 1024)]
        [System.UInt16]
        $SqlTempDbFileGrowth,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [Parameter(ParameterSetName = 'CompleteImage')]
        [Parameter(ParameterSetName = 'RebuildDatabase')]
        [Parameter(ParameterSetName = 'InstallFailoverCluster')]
        [Parameter(ParameterSetName = 'CompleteFailoverCluster')]
        [ValidateRange(4, 262144)]
        [System.UInt16]
        $SqlTempDbLogFileSize,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [Parameter(ParameterSetName = 'CompleteImage')]
        [Parameter(ParameterSetName = 'RebuildDatabase')]
        [Parameter(ParameterSetName = 'InstallFailoverCluster')]
        [Parameter(ParameterSetName = 'CompleteFailoverCluster')]
        [ValidateRange(0, 1024)]
        [System.UInt16]
        $SqlTempDbLogFileGrowth,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [Parameter(ParameterSetName = 'CompleteImage')]
        [Parameter(ParameterSetName = 'InstallFailoverCluster')]
        [Parameter(ParameterSetName = 'CompleteFailoverCluster')]
        [System.String]
        $SqlUserDbDir,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [System.Management.Automation.SwitchParameter]
        $SqlSvcInstantFileInit,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [Parameter(ParameterSetName = 'CompleteImage')]
        [Parameter(ParameterSetName = 'InstallFailoverCluster')]
        [Parameter(ParameterSetName = 'CompleteFailoverCluster')]
        [System.String]
        $SqlUserDbLogDir,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [ValidateRange(0, 32767)]
        [System.UInt16]
        $SqlMaxDop,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [System.Management.Automation.SwitchParameter]
        $UseSqlRecommendedMemoryLimits,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [ValidateRange(0, 2147483647)]
        [System.UInt32]
        $SqlMinMemory,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [ValidateRange(0, 2147483647)]
        [System.UInt32]
        $SqlMaxMemory,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [Parameter(ParameterSetName = 'CompleteImage')]
        [Parameter(ParameterSetName = 'InstallFailoverCluster')]
        [Parameter(ParameterSetName = 'PrepareFailoverCluster')]
        [ValidateRange(0, 3)]
        [System.UInt16]
        $FileStreamLevel,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [Parameter(ParameterSetName = 'CompleteImage')]
        [Parameter(ParameterSetName = 'InstallFailoverCluster')]
        [Parameter(ParameterSetName = 'PrepareFailoverCluster')]
        [System.String]
        $FileStreamShareName,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [Parameter(ParameterSetName = 'Upgrade')]
        [Parameter(ParameterSetName = 'InstallFailoverCluster')]
        [Parameter(ParameterSetName = 'PrepareFailoverCluster')]
        [Parameter(ParameterSetName = 'AddNode')]
        [System.String]
        $ISSvcAccount,

        [Parameter(ParameterSetName = 'UsingConfigurationFile')]
        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [Parameter(ParameterSetName = 'Upgrade')]
        [Parameter(ParameterSetName = 'InstallFailoverCluster')]
        [Parameter(ParameterSetName = 'PrepareFailoverCluster')]
        [Parameter(ParameterSetName = 'AddNode')]
        [System.Security.SecureString]
        $ISSvcPassword,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [Parameter(ParameterSetName = 'Upgrade')]
        [Parameter(ParameterSetName = 'InstallFailoverCluster')]
        [Parameter(ParameterSetName = 'PrepareFailoverCluster')]
        [ValidateSet('Automatic', 'Disabled', 'Manual')]
        [System.String]
        $ISSvcStartupType,

        [Parameter(ParameterSetName = 'Upgrade')]
        [System.Management.Automation.SwitchParameter]
        $AllowUpgradeForSSRSSharePointMode,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [Parameter(ParameterSetName = 'CompleteImage')]
        [System.Management.Automation.SwitchParameter]
        $NpEnabled,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [Parameter(ParameterSetName = 'CompleteImage')]
        [System.Management.Automation.SwitchParameter]
        $TcpEnabled,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [Parameter(ParameterSetName = 'CompleteImage')]
        [Parameter(ParameterSetName = 'InstallFailoverCluster')]
        [Parameter(ParameterSetName = 'PrepareFailoverCluster')]
        [Parameter(ParameterSetName = 'CompleteFailoverCluster')]
        [Parameter(ParameterSetName = 'AddNode')]
        [ValidateSet('SharePointFilesOnlyMode', 'DefaultNativeMode', 'FilesOnlyMode')]
        [System.String]
        $RsInstallMode,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [Parameter(ParameterSetName = 'CompleteImage')]
        [Parameter(ParameterSetName = 'InstallFailoverCluster')]
        [Parameter(ParameterSetName = 'PrepareFailoverCluster')]
        [Parameter(ParameterSetName = 'AddNode')]
        [System.String]
        $RSSvcAccount,

        [Parameter(ParameterSetName = 'UsingConfigurationFile')]
        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [Parameter(ParameterSetName = 'CompleteImage')]
        [Parameter(ParameterSetName = 'InstallFailoverCluster')]
        [Parameter(ParameterSetName = 'PrepareFailoverCluster')]
        [Parameter(ParameterSetName = 'AddNode')]
        [System.Security.SecureString]
        $RSSvcPassword,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [Parameter(ParameterSetName = 'CompleteImage')]
        [Parameter(ParameterSetName = 'InstallFailoverCluster')]
        [Parameter(ParameterSetName = 'PrepareFailoverCluster')]
        [ValidateSet('Automatic', 'Disabled', 'Manual')]
        [System.String]
        $RSSvcStartupType,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [System.String]
        $MPYCacheDirectory,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [System.String]
        $MRCacheDirectory,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [System.Management.Automation.SwitchParameter]
        $SqlInstJava,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [System.String]
        $SqlJavaDir,

        [Parameter(ParameterSetName = 'InstallFailoverCluster')]
        [Parameter(ParameterSetName = 'CompleteFailoverCluster')]
        [System.String]
        $FailoverClusterGroup,

        [Parameter(ParameterSetName = 'InstallFailoverCluster')]
        [Parameter(ParameterSetName = 'CompleteFailoverCluster')]
        [System.String[]]
        $FailoverClusterDisks,

        [Parameter(ParameterSetName = 'InstallFailoverCluster', Mandatory = $true)]
        [Parameter(ParameterSetName = 'CompleteFailoverCluster', Mandatory = $true)]
        [System.String]
        $FailoverClusterNetworkName,

        [Parameter(ParameterSetName = 'InstallFailoverCluster', Mandatory = $true)]
        [Parameter(ParameterSetName = 'CompleteFailoverCluster', Mandatory = $true)]
        [Parameter(ParameterSetName = 'AddNode', Mandatory = $true)]
        [System.String[]]
        $FailoverClusterIPAddresses,

        [Parameter(ParameterSetName = 'CompleteFailoverCluster')]
        [Parameter(ParameterSetName = 'AddNode')]
        [Parameter(ParameterSetName = 'RemoveNode')]
        [System.Management.Automation.SwitchParameter]
        $ConfirmIPDependencyChange,

        [Parameter(ParameterSetName = 'Upgrade')]
        [ValidateRange(0, 2)]
        [System.UInt16]
        $FailoverClusterRollOwnership,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [Parameter(ParameterSetName = 'InstallAzureArcAgent', Mandatory = $true)]
        [System.String]
        $AzureSubscriptionId,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [Parameter(ParameterSetName = 'InstallAzureArcAgent', Mandatory = $true)]
        [System.String]
        $AzureResourceGroup,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [Parameter(ParameterSetName = 'InstallAzureArcAgent', Mandatory = $true)]
        [System.String]
        $AzureRegion,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [Parameter(ParameterSetName = 'InstallAzureArcAgent', Mandatory = $true)]
        [System.String]
        $AzureTenantId,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [Parameter(ParameterSetName = 'InstallAzureArcAgent', Mandatory = $true)]
        [System.String]
        $AzureServicePrincipal,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [Parameter(ParameterSetName = 'InstallAzureArcAgent', Mandatory = $true)]
        [System.Security.SecureString]
        $AzureServicePrincipalSecret,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [Parameter(ParameterSetName = 'InstallAzureArcAgent')]
        [System.String]
        $AzureArcProxy,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [Parameter(ParameterSetName = 'InstallFailoverCluster')]
        [Parameter(ParameterSetName = 'EditionUpgrade')]
        [System.String[]]
        $SkipRules,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [Parameter(ParameterSetName = 'CompleteImage')]
        [Parameter(ParameterSetName = 'Upgrade')]
        [Parameter(ParameterSetName = 'InstallFailoverCluster')]
        [Parameter(ParameterSetName = 'PrepareFailoverCluster')]
        [Parameter(ParameterSetName = 'CompleteFailoverCluster')]
        [Parameter(ParameterSetName = 'AddNode')]
        [Parameter(ParameterSetName = 'EditionUpgrade')]
        [System.Management.Automation.SwitchParameter]
        $ProductCoveredBySA,

        [Parameter()]
        [System.UInt32]
        $Timeout = 7200,

        [Parameter()]
        [System.Management.Automation.SwitchParameter]
        $Force
    )

    $originalErrorActionPreference = $ErrorActionPreference

    $ErrorActionPreference = 'Stop'

    if ($Force.IsPresent -and -not $Confirm)
    {
        $ConfirmPreference = 'None'
    }

    Assert-ElevatedUser -ErrorAction 'Stop'

    switch ($PSCmdlet.ParameterSetName)
    {
        'InstallRole'
        {
            $setupAction = 'Install'

            break
        }

        'InstallAzureArcAgent'
        {
            $setupAction = 'Install'

            <#
                For this setup action the parameter Features is not part of the
                parameter set, so this can be safely set.
            #>
            $PSBoundParameters.Features = @('AZUREEXTENSION')

            break
        }

        default
        {
            $setupAction = $PSCmdlet.ParameterSetName

            break
        }
    }

    Assert-SetupActionProperties -Property $PSBoundParameters -SetupAction $setupAction -ErrorAction 'Stop'

    $ErrorActionPreference = $originalErrorActionPreference

    $setupArgument = '/QUIET /ACTION={0}' -f $setupAction

    if ($DebugPreference -in @('Continue', 'Inquire'))
    {
        $setupArgument += ' /INDICATEPROGRESS' # cspell: disable-line
    }

    if ($AcceptLicensingTerms.IsPresent)
    {
        $setupArgument += ' /IACCEPTSQLSERVERLICENSETERMS' # cspell: disable-line

        if ($PSBoundParameters.ContainsKey('Features'))
        {
            if ($PSBoundParameters.Features -contains 'SQL_SHARED_MR' )
            {
                $setupArgument += ' /IACCEPTROPENLICENSETERMS' # cspell: disable-line
            }

            if ($PSBoundParameters.Features -contains 'SQL_SHARED_MPY' )
            {
                $setupArgument += ' /IACCEPTPYTHONLICENSETERMS' # cspell: disable-line
            }
        }
    }

    $ignoreParameters = @(
        $PSCmdlet.ParameterSetName
        'Install' # Must add this exclusively because of parameter set InstallAzureArcAgent
        'AcceptLicensingTerms'
        'MediaPath'
        'Timeout'
        'Force'
    )

    $ignoreParameters += [System.Management.Automation.PSCmdlet]::CommonParameters
    $ignoreParameters += [System.Management.Automation.PSCmdlet]::OptionalCommonParameters

    $boundParameterName = $PSBoundParameters.Keys.Where({ $_ -notin $ignoreParameters })

    $sensitiveValue = @()

    $pathParameter = @(
        'InstallSharedDir'
        'InstallSharedWowDir'
        'InstanceDir'
        'ASBackupDir'
        'ASConfigDir'
        'ASDataDir'
        'ASLogDir'
        'ASTempDir'
        'InstallSqlDataDir'
        'SqlBackupDir'
        'SqlTempDbDir'
        'SqlTempDbLogDir'
        'SqlUserDbDir'
        'SqlUserDbLogDir'
        'MPYCacheDirectory'
        'MRCacheDirectory'
        'SqlJavaDir'
    )

    <#
        Remove trialing backslash from paths so they are not interpreted as
        escape-characters for a double-quote.
        See issue https://github.com/dsccommunity/SqlServerDsc/issues/1254.
    #>
    $boundParameterName.Where( { $_ -in $pathParameter } ).ForEach({
            # Must not change paths that reference a root directory (they are handle differently later)
            if ($PSBoundParameters.$_ -notmatch '^[a-zA-Z]:\\$')
            {
                $PSBoundParameters.$_ = $PSBoundParameters.$_.TrimEnd('\')
            }
        })

    # Loop through all bound parameters and build arguments for the setup executable.
    foreach ($parameterName in $boundParameterName)
    {
        # Make sure parameter is upper-case.
        $parameterName = $parameterName.ToUpper()

        $setupArgument += ' /{0}' -f $parameterName

        switch ($parameterName)
        {
            <#
                Must be handled differently because it is an array and have a comma
                separating the values, and the value shall be upper-case.
            #>
            { $_ -in @('FEATURES', 'ROLE') }
            {
                $setupArgument += '={0}' -f ($PSBoundParameters.$parameterName.ToUpper() -join ',')

                break
            }

            # Must be handled differently because the value MUST be upper-case.
            'ASSERVERMODE' # cspell: disable-line
            {
                $setupArgument += '={0}' -f $PSBoundParameters.$parameterName.ToUpper()

                break
            }

            # Must be handled differently because the parameter name could not be $PID.
            'PRODUCTKEY' # cspell: disable-line
            {
                # Remove the argument that was added above.
                $setupArgument = $setupArgument -replace ' \/{0}' -f $parameterName

                $sensitiveValue += $PSBoundParameters.$parameterName

                $setupArgument += ' /PID="{0}"' -f $PSBoundParameters.$parameterName

                break
            }

            # Must be handled differently because the argument name shall have an underscore in the argument.
            'SQLINSTJAVA' # cspell: disable-line
            {
                # Remove the argument that was added above.
                $setupArgument = $setupArgument -replace ' \/{0}' -f $parameterName

                $setupArgument += ' /SQL_INST_JAVA'

                break
            }

            # Must be handled differently because each value shall be separated by a semi-colon.
            'FAILOVERCLUSTERDISKS' # cspell: disable-line
            {
                $setupArgument += '="{0}"' -f ($PSBoundParameters.$parameterName -join ';')

                break
            }

            # Must be handled differently because two parameters shall become one argument.
            { $_ -in ('PBSTARTPORTRANGE', 'PBENDPORTRANGE') } # cspell: disable-line
            {
                # Remove the argument that was added above.
                $setupArgument = $setupArgument -replace ' \/{0}' -f $parameterName

                # Only set argument if it is not present already.
                if ($setupArgument -notmatch '\/PBPORTRANGE') # cspell: disable-line
                {
                    # cspell: disable-next
                    $setupArgument += ' /PBPORTRANGE={0}-{1}' -f $PSBoundParameters.PBStartPortRange, $PSBoundParameters.PBEndPortRange
                }

                break
            }

            { $PSBoundParameters.$parameterName -is [System.Management.Automation.SwitchParameter] }
            {
                <#
                    If a switch parameter is not included below then those arguments
                    shall not have any value after argument name, e.g. '/ENU'.
                #>
                switch ($parameterName)
                {
                    # Arguments that shall have the value set to the boolean numeric representation.
                    { $parameterName -in ('ASPROVIDERMSOLAP', 'NPENABLED', 'TCPENABLED', 'CONFIRMIPDEPENDENCYCHANGE') } # cspell: disable-line
                    {
                        $setupArgument += '={0}' -f [System.Byte] $PSBoundParameters.$parameterName.ToBool()

                        break
                    }

                    <#
                        Arguments that shall have the value set to the boolean string representation.
                        Excluding parameter names that shall be handled differently, those arguments
                        shall not have any value after argument name, e.g. '/ENU'.
                    #>
                    { $parameterName -in @('UPDATEENABLED', 'PBSCALEOUT', 'SQLSVCINSTANTFILEINIT', 'ALLOWUPGRADEFORSSRSSHAREPOINTMODE', 'ADDCURRENTUSERASSQLADMIN', 'IACKNOWLEDGEENTCALLIMITS') } # cspell: disable-line
                    {
                        $setupArgument += '={0}' -f $PSBoundParameters.$parameterName.ToString()

                        break
                    }
                }

                break
            }

            <#
                Must be handled differently because it is an numeric value and does not need to
                be surrounded by double-quote.
            #>
            { $PSBoundParameters.$parameterName | Test-IsNumericType }
            {
                $setupArgument += '={0}' -f ($PSBoundParameters.$parameterName -join '" "')

                break
            }

            <#
                Must be handled differently because it is an array and have a space
                separating the values, and each value is surrounded by double-quote.
            #>
            { $PSBoundParameters.$parameterName -is [System.Array] }
            {
                $setupArgument += '="{0}"' -f ($PSBoundParameters.$parameterName -join '" "')

                break
            }

            { $PSBoundParameters.$parameterName -is [System.Security.SecureString] }
            {
                $secureString = $PSBoundParameters.$parameterName

                if ($PSVersionTable.PSVersion -ge '6.0')
                {
                    $passwordClearText = $secureString | ConvertFrom-SecureString -AsPlainText
                }
                else
                {
                    # Workaround to convert SecureString to plain text in Windows PowerShell.
                    $binaryStringPointer = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($secureString)
                    $passwordClearText = [System.Runtime.InteropServices.Marshal]::PtrToStringAuto($binaryStringPointer)
                }

                $sensitiveValue += $passwordClearText

                $setupArgument += '="{0}"' -f $passwordClearText

                break
            }

            default
            {
                <#
                    When there is backslash followed by a double-quote then the backslash
                    is treated as an escape character for the double-quote. For arguments
                    that holds a path and the value references a root directory, e.g. 'E:\',
                    then the value must not be surrounded by double-quotes. Other paths
                    should be surrounded by double-quotes as they can contain spaces.
                    See issue https://github.com/dsccommunity/SqlServerDsc/issues/1254.
                #>
                if ($PSBoundParameters.$parameterName -match '^[a-zA-Z]:\\$')
                {
                    $setupArgument += '={0}' -f $PSBoundParameters.$parameterName
                }
                else
                {
                    $setupArgument += '="{0}"' -f $PSBoundParameters.$parameterName
                }
                break
            }
        }
    }

    $verboseSetupArgument = $setupArgument

    # Obfuscate sensitive values.
    foreach ($currentSensitiveValue in $sensitiveValue)
    {
        $escapedRegExString = [System.Text.RegularExpressions.Regex]::Escape($currentSensitiveValue)

        $verboseSetupArgument = $verboseSetupArgument -replace $escapedRegExString, '********'
    }

    # Clear sensitive values.
    $sensitiveValue = $null

    Write-Verbose -Message ($script:localizedData.Invoke_SetupAction_SetupArguments -f $verboseSetupArgument)

    $verboseDescriptionMessage = $script:localizedData.Invoke_SetupAction_ShouldProcessVerboseDescription -f $PSCmdlet.ParameterSetName
    $verboseWarningMessage = $script:localizedData.Invoke_SetupAction_ShouldProcessVerboseWarning -f $PSCmdlet.ParameterSetName
    $captionMessage = $script:localizedData.Invoke_SetupAction_ShouldProcessCaption

    if ($PSCmdlet.ShouldProcess($verboseDescriptionMessage, $verboseWarningMessage, $captionMessage))
    {
        $expandedMediaPath = [System.Environment]::ExpandEnvironmentVariables($MediaPath)

        $startProcessParameters = @{
            FilePath     = Join-Path -Path $expandedMediaPath -ChildPath 'setup.exe'
            ArgumentList = $setupArgument
            Timeout      = $Timeout
        }

        # Clear setupArgument to remove any sensitive values.
        $setupArgument = $null

        # Run setup executable.
        $processExitCode = Start-SqlSetupProcess @startProcessParameters

        $setupExitMessage = ($script:localizedData.SetupAction_SetupExitMessage -f $processExitCode)

        if ($processExitCode -eq 3010)
        {
            Write-Warning -Message (
                '{0} {1}' -f $setupExitMessage, $script:localizedData.SetupAction_SetupSuccessfulRebootRequired
            )
        }
        elseif ($processExitCode -ne 0)
        {
            $PSCmdlet.ThrowTerminatingError(
                [System.Management.Automation.ErrorRecord]::new(
                    ('{0} {1}' -f $setupExitMessage, $script:localizedData.Invoke_SetupAction_SetupFailed),
                    'ISA0001', # cspell: disable-line
                    [System.Management.Automation.ErrorCategory]::InvalidOperation,
                    $InstanceName
                )
            )
        }
        else
        {
            Write-Verbose -Message (
                '{0} {1}' -f $setupExitMessage, ($script:localizedData.SetupAction_SetupSuccessful)
            )
        }
    }
}
#EndRegion '.\Private\Invoke-SetupAction.ps1' 1740
#Region '.\Public\Add-SqlDscFileGroup.ps1' -1

<#
    .SYNOPSIS
        Adds one or more FileGroup objects to a Database object.

    .DESCRIPTION
        This command adds one or more FileGroup objects to a Database object's FileGroups
        collection. This is useful when you have created FileGroup objects using
        New-SqlDscFileGroup and want to associate them with a Database.

    .PARAMETER Database
        Specifies the Database object to which the FileGroups will be added.

    .PARAMETER FileGroup
        Specifies one or more FileGroup objects to add to the Database. This parameter
        accepts pipeline input.

    .PARAMETER PassThru
        Returns the FileGroup objects that were added to the Database.

    .PARAMETER Force
        Specifies that the FileGroup should be added without confirmation.

    .INPUTS
        Microsoft.SqlServer.Management.Smo.FileGroup

        FileGroup objects that will be added to the Database.

    .OUTPUTS
        None

        This cmdlet does not generate output by default.

    .OUTPUTS
        Microsoft.SqlServer.Management.Smo.FileGroup[]

        When the PassThru parameter is specified, returns the FileGroup objects that were added.

    .EXAMPLE
        Add-SqlDscFileGroup -Database $database -FileGroup $fileGroup

        Adds a single FileGroup to the Database.

    .EXAMPLE
        $fileGroups | Add-SqlDscFileGroup -Database $database -PassThru

        Adds multiple FileGroups to the Database via pipeline and returns the FileGroup objects.
#>
function Add-SqlDscFileGroup
{
    [System.Diagnostics.CodeAnalysis.SuppressMessageAttribute('UseSyntacticallyCorrectExamples', '', Justification = 'Because the rule does not yet support parsing the code when a parameter type is not available. The ScriptAnalyzer rule UseSyntacticallyCorrectExamples will always error in the editor due to https://github.com/indented-automation/Indented.ScriptAnalyzerRules/issues/8.')]
    [CmdletBinding(SupportsShouldProcess = $true, ConfirmImpact = 'Medium')]
    [OutputType([Microsoft.SqlServer.Management.Smo.FileGroup[]])]
    param
    (
        [Parameter(Mandatory = $true)]
        [Microsoft.SqlServer.Management.Smo.Database]
        $Database,

        [Parameter(Mandatory = $true, ValueFromPipeline = $true)]
        [Microsoft.SqlServer.Management.Smo.FileGroup[]]
        $FileGroup,

        [Parameter()]
        [System.Management.Automation.SwitchParameter]
        $PassThru,

        [Parameter()]
        [System.Management.Automation.SwitchParameter]
        $Force
    )

    process
    {
        if ($Force.IsPresent -and -not $Confirm)
        {
            $ConfirmPreference = 'None'
        }

        foreach ($fileGroupObject in $FileGroup)
        {
            $descriptionMessage = $script:localizedData.AddSqlDscFileGroup_Add_ShouldProcessDescription -f $fileGroupObject.Name, $Database.Name
            $confirmationMessage = $script:localizedData.AddSqlDscFileGroup_Add_ShouldProcessConfirmation -f $fileGroupObject.Name
            $captionMessage = $script:localizedData.AddSqlDscFileGroup_Add_ShouldProcessCaption

            if ($PSCmdlet.ShouldProcess($descriptionMessage, $confirmationMessage, $captionMessage))
            {
                $Database.FileGroups.Add($fileGroupObject)

                if ($PassThru.IsPresent)
                {
                    $fileGroupObject
                }
            }
        }
    }
}
#EndRegion '.\Public\Add-SqlDscFileGroup.ps1' 97
#Region '.\Public\Add-SqlDscNode.ps1' -1

<#
    .SYNOPSIS
        Add a SQL Server node to an Failover Cluster instance (FCI).

    .DESCRIPTION
        Add a SQL Server node to an Failover Cluster instance (FCI).

        See the link in the commands help for information on each parameter. The
        link points to SQL Server command line setup documentation.

    .PARAMETER AcceptLicensingTerms
        Required parameter to be able to run unattended install. By specifying this
        parameter you acknowledge the acceptance all license terms and notices for
        the specified features, the terms and notices that the Microsoft SQL Server
        setup executable normally ask for.

    .PARAMETER MediaPath
        Specifies the path where to find the SQL Server installation media. On this
        path the SQL Server setup executable must be found.

    .PARAMETER Timeout
        Specifies how long to wait for the setup process to finish. Default value
        is `7200` seconds (2 hours). If the setup process does not finish before
        this time, an exception will be thrown.

    .PARAMETER Force
        If specified the command will not ask for confirmation. Same as if Confirm:$false
        is used.

    .PARAMETER IAcknowledgeEntCalLimits
        See the notes section for more information.

    .PARAMETER InstanceName
        See the notes section for more information.

    .PARAMETER Enu
        See the notes section for more information.

    .PARAMETER UpdateEnabled
        See the notes section for more information.

    .PARAMETER UpdateSource
        See the notes section for more information.

    .PARAMETER PBEngSvcAccount
        See the notes section for more information.

    .PARAMETER PBEngSvcPassword
        See the notes section for more information.

    .PARAMETER PBEngSvcStartupType
        See the notes section for more information.

    .PARAMETER PBStartPortRange
        See the notes section for more information.

    .PARAMETER PBEndPortRange
        See the notes section for more information.

    .PARAMETER PBScaleOut
        See the notes section for more information.

    .PARAMETER ProductKey
        See the notes section for more information.

    .PARAMETER AgtSvcAccount
        See the notes section for more information.

    .PARAMETER AgtSvcPassword
        See the notes section for more information.

    .PARAMETER ASSvcAccount
        See the notes section for more information.

    .PARAMETER ASSvcPassword
        See the notes section for more information.

    .PARAMETER SqlSvcAccount
        See the notes section for more information.

    .PARAMETER SqlSvcPassword
        See the notes section for more information.

    .PARAMETER ISSvcAccount
        See the notes section for more information.

    .PARAMETER ISSvcPassword
        See the notes section for more information.

    .PARAMETER RsInstallMode
        See the notes section for more information.

    .PARAMETER RSSvcAccount
        See the notes section for more information.

    .PARAMETER RSSvcPassword
        See the notes section for more information.

    .PARAMETER FailoverClusterIPAddresses
        See the notes section for more information.

    .PARAMETER ConfirmIPDependencyChange
        See the notes section for more information.

    .PARAMETER ProductCoveredBySA
        See the notes section for more information.

    .LINK
        https://docs.microsoft.com/en-us/sql/database-engine/install-windows/install-sql-server-from-the-command-prompt

    .OUTPUTS
        None.

    .EXAMPLE
        Add-SqlDscNode -AcceptLicensingTerms -InstanceName 'MyInstance' -FailoverClusterIPAddresses 'IPv4;192.168.0.46;ClusterNetwork1;255.255.255.0' -MediaPath 'E:\'

        Adds the current node's SQL Server instance 'MyInstance' to the Failover Cluster instance.

    .NOTES
        The parameters are intentionally not described since it would take a lot
        of effort to keep them up to date. Instead there is a link that points to
        the SQL Server command line setup documentation which will stay relevant.
#>
function Add-SqlDscNode
{
    [System.Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSShouldProcess', '', Justification = 'Because ShouldProcess is used in Invoke-SetupAction')]
    [System.Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSShouldProcess', '', Justification = 'Because ShouldProcess is used in Invoke-SetupAction')]
    [CmdletBinding(SupportsShouldProcess = $true, ConfirmImpact = 'High')]
    [OutputType()]
    param
    (
        [Parameter(Mandatory = $true)]
        [System.Management.Automation.SwitchParameter]
        $AcceptLicensingTerms,

        [Parameter()]
        [System.Management.Automation.SwitchParameter]
        $IAcknowledgeEntCalLimits,

        [Parameter(Mandatory = $true)]
        [System.String]
        $MediaPath,

        [Parameter(Mandatory = $true)]
        [System.String]
        $InstanceName,

        [Parameter()]
        [System.Management.Automation.SwitchParameter]
        $Enu,

        [Parameter()]
        [System.Management.Automation.SwitchParameter]
        $UpdateEnabled,

        [Parameter()]
        [System.String]
        $UpdateSource,

        [Parameter()]
        [System.String]
        $PBEngSvcAccount,

        [Parameter()]
        [System.Security.SecureString]
        $PBEngSvcPassword,

        [Parameter()]
        [ValidateSet('Automatic', 'Disabled', 'Manual')]
        [System.String]
        $PBEngSvcStartupType,

        [Parameter()]
        [System.UInt16]
        $PBStartPortRange,

        [Parameter()]
        [System.UInt16]
        $PBEndPortRange,

        [Parameter()]
        [System.Management.Automation.SwitchParameter]
        $PBScaleOut,

        [Parameter()]
        [System.String]
        $ProductKey, # This is argument PID but $PID is reserved variable.

        [Parameter()]
        [System.String]
        $AgtSvcAccount,

        [Parameter()]
        [System.Security.SecureString]
        $AgtSvcPassword,

        [Parameter()]
        [System.String]
        $ASSvcAccount,

        [Parameter()]
        [System.Security.SecureString]
        $ASSvcPassword,

        [Parameter()]
        [System.String]
        $SqlSvcAccount,

        [Parameter()]
        [System.Security.SecureString]
        $SqlSvcPassword,

        [Parameter()]
        [System.String]
        $ISSvcAccount,

        [Parameter()]
        [System.Security.SecureString]
        $ISSvcPassword,

        [Parameter()]
        [ValidateSet('SharePointFilesOnlyMode', 'DefaultNativeMode', 'FilesOnlyMode')]
        [System.String]
        $RsInstallMode,

        [Parameter()]
        [System.String]
        $RSSvcAccount,

        [Parameter()]
        [System.Security.SecureString]
        $RSSvcPassword,

        [Parameter(Mandatory = $true)]
        [System.String[]]
        $FailoverClusterIPAddresses,

        [Parameter()]
        [System.Management.Automation.SwitchParameter]
        $ConfirmIPDependencyChange,

        [Parameter()]
        [System.Management.Automation.SwitchParameter]
        $ProductCoveredBySA,

        [Parameter()]
        [System.UInt32]
        $Timeout = 7200,

        [Parameter()]
        [System.Management.Automation.SwitchParameter]
        $Force
    )

    Invoke-SetupAction -AddNode @PSBoundParameters
}
#EndRegion '.\Public\Add-SqlDscNode.ps1' 257
#Region '.\Public\Add-SqlDscTraceFlag.ps1' -1

<#
    .SYNOPSIS
        Add trace flags to a Database Engine instance.

    .DESCRIPTION
        Add trace flags on a Database Engine instance, keeping any trace flags
        currently set.

    .PARAMETER ServiceObject
        Specifies the Service object on which to add the trace flags.

    .PARAMETER ServerName
        Specifies the server name where the instance exist.

    .PARAMETER InstanceName
       Specifies the instance name on which to add the trace flags.

    .PARAMETER TraceFlag
        Specifies the trace flags to add.

    .PARAMETER Force
        Specifies that the trace flag should be added without any confirmation.

    .EXAMPLE
        Add-SqlDscTraceFlag -TraceFlag 4199

        Adds the trace flag 4199 on the Database Engine default instance
        on the server where the command in run.

    .EXAMPLE
        $serviceObject = Get-SqlDscManagedComputerService -ServiceType 'DatabaseEngine'
        Add-SqlDscTraceFlag -ServiceObject $serviceObject -TraceFlag 4199

        Adds the trace flag 4199 on the Database Engine default instance
        on the server where the command in run.

    .EXAMPLE
        Add-SqlDscTraceFlag -InstanceName 'SQL2022' -TraceFlag 4199,3226

        Adds the trace flags 4199 and 3226 on the Database Engine instance
        'SQL2022' on the server where the command in run.

    .EXAMPLE
        $serviceObject = Get-SqlDscManagedComputerService -ServiceType 'DatabaseEngine' -InstanceName 'SQL2022'
        Add-SqlDscTraceFlag -ServiceObject $serviceObject -TraceFlag 4199,3226

        Adds the trace flags 4199 and 3226 on the Database Engine instance
        'SQL2022' on the server where the command in run.

    .OUTPUTS
        None.
#>
function Add-SqlDscTraceFlag
{
    [System.Diagnostics.CodeAnalysis.SuppressMessageAttribute('UseSyntacticallyCorrectExamples', '', Justification = 'Because the rule does not yet support parsing the code when a parameter type is not available. The ScriptAnalyzer rule UseSyntacticallyCorrectExamples will always error in the editor due to https://github.com/indented-automation/Indented.ScriptAnalyzerRules/issues/8.')]
    [OutputType()]
    [CmdletBinding(DefaultParameterSetName = 'ByServerName', SupportsShouldProcess = $true, ConfirmImpact = 'High')]
    param
    (
        [Parameter(ParameterSetName = 'ByServiceObject', Mandatory = $true, ValueFromPipeline = $true)]
        [Microsoft.SqlServer.Management.Smo.Wmi.Service]
        $ServiceObject,

        [Parameter(ParameterSetName = 'ByServerName')]
        [ValidateNotNullOrEmpty()]
        [System.String]
        $ServerName = (Get-ComputerName),

        [Parameter(ParameterSetName = 'ByServerName')]
        [ValidateNotNullOrEmpty()]
        [System.String]
        $InstanceName = 'MSSQLSERVER',

        [Parameter(Mandatory = $true)]
        [ValidateRange(1, [System.UInt32]::MaxValue)]
        [System.UInt32[]]
        $TraceFlag,

        [Parameter()]
        [System.Management.Automation.SwitchParameter]
        $Force
    )

    begin
    {
        if ($Force.IsPresent -and -not $Confirm)
        {
            $ConfirmPreference = 'None'
        }
    }

    process
    {
        if ($PSCmdlet.ParameterSetName -eq 'ByServiceObject')
        {
            $InstanceName = $ServiceObject.Name -replace '^MSSQL\$'
        }

        # Copy $PSBoundParameters to keep it intact.
        $getSqlDscTraceFlagParameters = Remove-CommonParameter -Hashtable $PSBoundParameters

        # Remove parameters that Get-SqlDscTraceFlag does not have/support.
        @('Force', 'TraceFlag') |
            ForEach-Object -Process {
                $getSqlDscTraceFlagParameters.Remove($_)
            }

        $originalErrorActionPreference = $ErrorActionPreference

        $ErrorActionPreference = 'Stop'

        $currentTraceFlags = Get-SqlDscTraceFlag @getSqlDscTraceFlagParameters -ErrorAction 'Stop'

        $ErrorActionPreference = $originalErrorActionPreference

        # Normalize current trace flags: sort uniquely.
        # Get-SqlDscTraceFlag already filters out nulls and zeros, and returns [UInt32[]].
        $normalizedCurrentTraceFlags = $currentTraceFlags | Sort-Object -Unique

        # Ensure $normalizedCurrentTraceFlags is an empty array if no trace flags exist.
        if ($null -eq $normalizedCurrentTraceFlags)
        {
            $normalizedCurrentTraceFlags = [System.UInt32[]] @()
        }

        # Normalize input trace flags: sort uniquely.
        # Parameter type [System.UInt32[]] with ValidateRange already ensures non-null values and valid range.
        $normalizedInputTraceFlags = $TraceFlag | Sort-Object -Unique

        # Combine normalized current and input trace flags to get the desired state
        $desiredTraceFlags = [System.UInt32[]] @(
            $normalizedCurrentTraceFlags
            $normalizedInputTraceFlags
        ) |
            Sort-Object -Unique

        # Compare normalized current and desired trace flags to determine if there's an effective change
        $compareResult = Compare-Object -ReferenceObject $normalizedCurrentTraceFlags -DifferenceObject $desiredTraceFlags

        if ($compareResult)
        {
            $descriptionMessage = $script:localizedData.TraceFlag_Add_ShouldProcessVerboseDescription -f $InstanceName, ($desiredTraceFlags -join ', ')
            $confirmationMessage = $script:localizedData.TraceFlag_Add_ShouldProcessVerboseWarning -f $InstanceName
            $captionMessage = $script:localizedData.TraceFlag_Add_ShouldProcessCaption

            if ($PSCmdlet.ShouldProcess($descriptionMessage, $confirmationMessage, $captionMessage))
            {
                # Copy $PSBoundParameters to keep it intact.
                $setSqlDscTraceFlagParameters = Remove-CommonParameter -Hashtable $PSBoundParameters

                $setSqlDscTraceFlagParameters.TraceFlag = $desiredTraceFlags

                $originalErrorActionPreference = $ErrorActionPreference

                $ErrorActionPreference = 'Stop'

                Set-SqlDscTraceFlag @setSqlDscTraceFlagParameters -ErrorAction 'Stop'

                $ErrorActionPreference = $originalErrorActionPreference
            }
        }
    }
}
#EndRegion '.\Public\Add-SqlDscTraceFlag.ps1' 164
#Region '.\Public\Assert-SqlDscAgentOperator.ps1' -1

<#
    .SYNOPSIS
        Asserts that a SQL Server Agent Operator exists and throws a terminating error if not found.

    .DESCRIPTION
        This command asserts that a SQL Server Agent Operator exists using the provided
        parameters. If the operator is not found, it throws a terminating error with a
        generic localized error message.

    .PARAMETER ServerObject
        Specifies the server object on which to check for the operator.

    .PARAMETER Name
        Specifies the name of the operator to check for.

    .INPUTS
        [Microsoft.SqlServer.Management.Smo.Server]

    .OUTPUTS
        None.

        This command does not return anything if the operator exists.

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine -InstanceName 'MyInstance'
        $serverObject | Assert-SqlDscAgentOperator -Name 'TestOperator'

        Asserts that the SQL Agent Operator 'TestOperator' exists, throws error if not found.

    .EXAMPLE
        Assert-SqlDscAgentOperator -ServerObject $serverObject -Name 'TestOperator'

        Asserts that the SQL Agent Operator 'TestOperator' exists, throws error if not found.
#>
function Assert-SqlDscAgentOperator
{
    [System.Diagnostics.CodeAnalysis.SuppressMessageAttribute('UseSyntacticallyCorrectExamples', '', Justification = 'Because the rule does not yet support parsing the code when a parameter type is not available. The ScriptAnalyzer rule UseSyntacticallyCorrectExamples will always error in the editor due to https://github.com/indented-automation/Indented.ScriptAnalyzerRules/issues/8.')]
    [CmdletBinding()]
    [OutputType()]
    param
    (
        [Parameter(Mandatory = $true, ValueFromPipeline = $true)]
        [Microsoft.SqlServer.Management.Smo.Server]
        $ServerObject,

        [Parameter(Mandatory = $true)]
        [System.String]
        $Name
    )

    process
    {
        $originalErrorActionPreference = $ErrorActionPreference
        $ErrorActionPreference = 'Stop'

        # This will throw a terminating error if the operator is not found
        $null = Get-AgentOperatorObject -ServerObject $ServerObject -Name $Name -ErrorAction 'Stop'

        $ErrorActionPreference = $originalErrorActionPreference

        # This command does not return anything if the operator exists
    }
}
#EndRegion '.\Public\Assert-SqlDscAgentOperator.ps1' 64
#Region '.\Public\Assert-SqlDscLogin.ps1' -1

<#
    .SYNOPSIS
        Assert that the specified SQL Server principal exists as a login.

    .DESCRIPTION
        This command asserts that the specified SQL Server principal exists as a
        login. If the principal does not exist as a login, a terminating error
        is thrown.

    .PARAMETER ServerObject
        Specifies current server connection object.

    .PARAMETER Name
        Specifies the name of the principal that needs to exist as a login.

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine -InstanceName 'MyInstance'
        $serverObject | Assert-SqlDscLogin -Name 'MyLogin'

        Asserts that the principal 'MyLogin' exists as a login.

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine -InstanceName 'MyInstance'
        Assert-SqlDscLogin -ServerObject $serverObject -Name 'MyLogin'

        Asserts that the principal 'MyLogin' exists as a login.

    .NOTES
        This command throws a terminating error if the specified SQL Server
        principal does not exist as a SQL server login.
#>
function Assert-SqlDscLogin
{
    [System.Diagnostics.CodeAnalysis.SuppressMessageAttribute('UseSyntacticallyCorrectExamples', '', Justification = 'Because the rule does not yet support parsing the code when a parameter type is not available. The ScriptAnalyzer rule UseSyntacticallyCorrectExamples will always error in the editor due to https://github.com/indented-automation/Indented.ScriptAnalyzerRules/issues/8.')]
    [CmdletBinding()]
    param
    (
        [Parameter(Mandatory = $true, ValueFromPipeline = $true)]
        [Microsoft.SqlServer.Management.Smo.Server]
        $ServerObject,

        [Parameter(Mandatory = $true)]
        [System.String]
        $Name
    )

    process
    {
        Write-Verbose -Message ($script:localizedData.Assert_Login_CheckingLogin -f $Name, $ServerObject.InstanceName)

        if (-not (Test-SqlDscIsLogin -ServerObject $ServerObject -Name $Name))
        {
            $missingLoginMessage = $script:localizedData.Assert_Login_LoginMissing -f $Name, $ServerObject.InstanceName

            $PSCmdlet.ThrowTerminatingError(
                [System.Management.Automation.ErrorRecord]::new(
                    $missingLoginMessage,
                    'ASDL0001', # cspell: disable-line
                    [System.Management.Automation.ErrorCategory]::ObjectNotFound,
                    $Name
                )
            )
        }

        Write-Debug -Message ($script:localizedData.Assert_Login_LoginExists -f $Name)
    }
}
#EndRegion '.\Public\Assert-SqlDscLogin.ps1' 68
#Region '.\Public\Complete-SqlDscFailoverCluster.ps1' -1

<#
    .SYNOPSIS
        Completes the SQL Server instance installation in the Failover Cluster
        instance.

    .DESCRIPTION
        Completes the SQL Server instance installation in the Failover Cluster
        instance that was prepared using `Install-SqlDscServer` with the parameter
        `-PrepareFailoverCluster`.

        See the link in the commands help for information on each parameter. The
        link points to SQL Server command line setup documentation.

    .PARAMETER MediaPath
        Specifies the path where to find the SQL Server installation media. On this
        path the SQL Server setup executable must be found.

    .PARAMETER Timeout
        Specifies how long to wait for the setup process to finish. Default value
        is `7200` seconds (2 hours). If the setup process does not finish before
        this time, an exception will be thrown.

    .PARAMETER Force
        If specified the command will not ask for confirmation. Same as if Confirm:$false
        is used.

    .PARAMETER InstanceName
        See the notes section for more information.

    .PARAMETER Enu
        See the notes section for more information.

    .PARAMETER ProductKey
        See the notes section for more information.

    .PARAMETER ASBackupDir
        See the notes section for more information.

    .PARAMETER ASCollation
        See the notes section for more information.

    .PARAMETER ASConfigDir
        See the notes section for more information.

    .PARAMETER ASDataDir
        See the notes section for more information.

    .PARAMETER ASLogDir
        See the notes section for more information.

    .PARAMETER ASTempDir
        See the notes section for more information.

    .PARAMETER ASServerMode
        See the notes section for more information.

    .PARAMETER ASSysAdminAccounts
        See the notes section for more information.

    .PARAMETER ASProviderMSOLAP
        See the notes section for more information.

    .PARAMETER InstallSqlDataDir
        See the notes section for more information.

    .PARAMETER SqlBackupDir
        See the notes section for more information.

    .PARAMETER SecurityMode
        See the notes section for more information.

    .PARAMETER SAPwd
        See the notes section for more information.

    .PARAMETER SqlCollation
        See the notes section for more information.

    .PARAMETER SqlSysAdminAccounts
        See the notes section for more information.

    .PARAMETER SqlTempDbDir
        See the notes section for more information.

    .PARAMETER SqlTempDbLogDir
        See the notes section for more information.

    .PARAMETER SqlTempDbFileCount
        See the notes section for more information.

    .PARAMETER SqlTempDbFileSize
        See the notes section for more information.

    .PARAMETER SqlTempDbFileGrowth
        See the notes section for more information.

    .PARAMETER SqlTempDbLogFileSize
        See the notes section for more information.

    .PARAMETER SqlTempDbLogFileGrowth
        See the notes section for more information.

    .PARAMETER SqlUserDbDir
        See the notes section for more information.

    .PARAMETER SqlUserDbLogDir
        See the notes section for more information.

    .PARAMETER RsInstallMode
        See the notes section for more information.

    .PARAMETER FailoverClusterGroup
        See the notes section for more information.

    .PARAMETER FailoverClusterDisks
        See the notes section for more information.

    .PARAMETER FailoverClusterNetworkName
        See the notes section for more information.

    .PARAMETER FailoverClusterIPAddresses
        See the notes section for more information.

    .PARAMETER ConfirmIPDependencyChange
        See the notes section for more information.

    .PARAMETER ProductCoveredBySA
        See the notes section for more information.

    .LINK
        https://docs.microsoft.com/en-us/sql/database-engine/install-windows/install-sql-server-from-the-command-prompt

    .OUTPUTS
        None.

    .EXAMPLE
        Complete-SqlDscFailoverCluster -InstanceName 'MyInstance' -InstallSqlDataDir 'D:\MSSQL\Data' -SqlSysAdminAccounts @('MyAdminAccount') -FailoverClusterNetworkName 'TestCluster01A' -FailoverClusterIPAddresses 'IPv4;192.168.0.46;ClusterNetwork1;255.255.255.0' -MediaPath 'E:\'

        Completes the installation of the SQL Server instance 'MyInstance' in the
        Failover Cluster instance.

    .NOTES
        The parameters are intentionally not described since it would take a lot
        of effort to keep them up to date. Instead there is a link that points to
        the SQL Server command line setup documentation which will stay relevant.
#>
function Complete-SqlDscFailoverCluster
{
    [System.Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSShouldProcess', '', Justification = 'Because ShouldProcess is used in Invoke-SetupAction')]
    [CmdletBinding(SupportsShouldProcess = $true, ConfirmImpact = 'High')]
    [OutputType()]
    param
    (
        [Parameter(Mandatory = $true)]
        [System.String]
        $MediaPath,

        [Parameter(Mandatory = $true)]
        [System.String]
        $InstanceName,

        [Parameter()]
        [System.Management.Automation.SwitchParameter]
        $Enu,

        [Parameter()]
        [System.String]
        $ProductKey, # This is argument PID but $PID is reserved variable.

        [Parameter()]
        [System.String]
        $ASBackupDir,

        [Parameter()]
        [System.String]
        $ASCollation,

        [Parameter()]
        [System.String]
        $ASConfigDir,

        [Parameter()]
        [System.String]
        $ASDataDir,

        [Parameter()]
        [System.String]
        $ASLogDir,

        [Parameter()]
        [System.String]
        $ASTempDir,

        [Parameter()]
        [ValidateSet('Multidimensional', 'PowerPivot', 'Tabular')]
        [System.String]
        $ASServerMode,

        [Parameter()]
        [System.String[]]
        $ASSysAdminAccounts,

        [Parameter()]
        [System.Management.Automation.SwitchParameter]
        $ASProviderMSOLAP,

        [Parameter(Mandatory = $true)]
        [System.String]
        $InstallSqlDataDir,

        [Parameter()]
        [System.String]
        $SqlBackupDir,

        [Parameter()]
        [ValidateSet('SQL')]
        [System.String]
        $SecurityMode,

        [Parameter()]
        [System.Security.SecureString]
        $SAPwd,

        [Parameter()]
        [System.String]
        $SqlCollation,

        [Parameter(Mandatory = $true)]
        [System.String[]]
        $SqlSysAdminAccounts,

        [Parameter()]
        [System.String]
        $SqlTempDbDir,

        [Parameter()]
        [System.String]
        $SqlTempDbLogDir,

        [Parameter()]
        [System.UInt16]
        $SqlTempDbFileCount,

        [Parameter()]
        [ValidateRange(4, 262144)]
        [System.UInt16]
        $SqlTempDbFileSize,

        [Parameter()]
        [ValidateRange(0, 1024)]
        [System.UInt16]
        $SqlTempDbFileGrowth,

        [Parameter()]
        [ValidateRange(4, 262144)]
        [System.UInt16]
        $SqlTempDbLogFileSize,

        [Parameter()]
        [ValidateRange(0, 1024)]
        [System.UInt16]
        $SqlTempDbLogFileGrowth,

        [Parameter()]
        [System.String]
        $SqlUserDbDir,

        [Parameter()]
        [System.String]
        $SqlUserDbLogDir,

        [Parameter()]
        [ValidateSet('SharePointFilesOnlyMode', 'DefaultNativeMode', 'FilesOnlyMode')]
        [System.String]
        $RsInstallMode,

        [Parameter()]
        [System.String]
        $FailoverClusterGroup,

        [Parameter()]
        [System.String[]]
        $FailoverClusterDisks,

        [Parameter(Mandatory = $true)]
        [System.String]
        $FailoverClusterNetworkName,

        [Parameter(Mandatory = $true)]
        [System.String[]]
        $FailoverClusterIPAddresses,

        [Parameter()]
        [System.Management.Automation.SwitchParameter]
        $ConfirmIPDependencyChange,

        [Parameter()]
        [System.Management.Automation.SwitchParameter]
        $ProductCoveredBySA,

        [Parameter()]
        [System.UInt32]
        $Timeout = 7200,

        [Parameter()]
        [System.Management.Automation.SwitchParameter]
        $Force
    )

    Invoke-SetupAction -CompleteFailoverCluster @PSBoundParameters
}
#EndRegion '.\Public\Complete-SqlDscFailoverCluster.ps1' 311
#Region '.\Public\Complete-SqlDscImage.ps1' -1

<#
    .SYNOPSIS
        Completes the image installation of an SQL Server instance.

    .DESCRIPTION
        Completes the image installation of an SQL Server instance that was prepared
        using `Install-SqlDscServer` with the parameter `-PrepareImage`.

        See the link in the commands help for information on each parameter. The
        link points to SQL Server command line setup documentation.

    .PARAMETER AcceptLicensingTerms
        Required parameter to be able to run unattended install. By specifying this
        parameter you acknowledge the acceptance all license terms and notices for
        the specified features, the terms and notices that the Microsoft SQL Server
        setup executable normally ask for.

    .PARAMETER MediaPath
        Specifies the path where to find the SQL Server installation media. On this
        path the SQL Server setup executable must be found.

    .PARAMETER Timeout
        Specifies how long to wait for the setup process to finish. Default value
        is `7200` seconds (2 hours). If the setup process does not finish before
        this time, an exception will be thrown.

    .PARAMETER Force
        If specified the command will not ask for confirmation. Same as if Confirm:$false
        is used.

    .PARAMETER InstanceName
        See the notes section for more information.

    .PARAMETER Enu
        See the notes section for more information.

    .PARAMETER InstanceId
        See the notes section for more information.

    .PARAMETER PBEngSvcAccount
        See the notes section for more information.

    .PARAMETER PBEngSvcPassword
        See the notes section for more information.

    .PARAMETER PBEngSvcStartupType
        See the notes section for more information.

    .PARAMETER PBStartPortRange
        See the notes section for more information.

    .PARAMETER PBEndPortRange
        See the notes section for more information.

    .PARAMETER PBScaleOut
        See the notes section for more information.

    .PARAMETER ProductKey
        See the notes section for more information.

    .PARAMETER AgtSvcAccount
        See the notes section for more information.

    .PARAMETER AgtSvcPassword
        See the notes section for more information.

    .PARAMETER AgtSvcStartupType
        See the notes section for more information.

    .PARAMETER BrowserSvcStartupType
        See the notes section for more information.

    .PARAMETER EnableRanU
        See the notes section for more information.

    .PARAMETER InstallSqlDataDir
        See the notes section for more information.

    .PARAMETER SqlBackupDir
        See the notes section for more information.

    .PARAMETER SecurityMode
        See the notes section for more information.

    .PARAMETER SAPwd
        See the notes section for more information.

    .PARAMETER SqlCollation
        See the notes section for more information.

    .PARAMETER SqlSvcAccount
        See the notes section for more information.

    .PARAMETER SqlSvcPassword
        See the notes section for more information.

    .PARAMETER SqlSvcStartupType
        See the notes section for more information.

    .PARAMETER SqlSysAdminAccounts
        See the notes section for more information.

    .PARAMETER SqlTempDbDir
        See the notes section for more information.

    .PARAMETER SqlTempDbLogDir
        See the notes section for more information.

    .PARAMETER SqlTempDbFileCount
        See the notes section for more information.

    .PARAMETER SqlTempDbFileSize
        See the notes section for more information.

    .PARAMETER SqlTempDbFileGrowth
        See the notes section for more information.

    .PARAMETER SqlTempDbLogFileSize
        See the notes section for more information.

    .PARAMETER SqlTempDbLogFileGrowth
        See the notes section for more information.

    .PARAMETER SqlUserDbDir
        See the notes section for more information.

    .PARAMETER SqlUserDbLogDir
        See the notes section for more information.

    .PARAMETER FileStreamLevel
        See the notes section for more information.

    .PARAMETER FileStreamShareName
        See the notes section for more information.

    .PARAMETER NpEnabled
        See the notes section for more information.

    .PARAMETER TcpEnabled
        See the notes section for more information.

    .PARAMETER RsInstallMode
        See the notes section for more information.

    .PARAMETER RSSvcAccount
        See the notes section for more information.

    .PARAMETER RSSvcPassword
        See the notes section for more information.

    .PARAMETER RSSvcStartupType
        See the notes section for more information.

    .PARAMETER ProductCoveredBySA
        See the notes section for more information.

    .LINK
        https://docs.microsoft.com/en-us/sql/database-engine/install-windows/install-sql-server-from-the-command-prompt

    .OUTPUTS
        None.

    .EXAMPLE
        Complete-SqlDscImage -AcceptLicensingTerms -MediaPath 'E:\' -InstanceId 'MSSQLSERVER' -SqlSvcAccount 'NT Service\MSSQLSERVER' -AgtSvcAccount 'NT Service\MSSQLSERVER'

        Completes the image installation of the SQL Server default instance that
        was prepared using `Install-SqlDscServer` with the parameter `-PrepareImage`.

    .NOTES
        The parameters are intentionally not described since it would take a lot
        of effort to keep them up to date. Instead there is a link that points to
        the SQL Server command line setup documentation which will stay relevant.
#>
function Complete-SqlDscImage
{
    [System.Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSShouldProcess', '', Justification = 'Because ShouldProcess is used in Invoke-SetupAction')]
    [CmdletBinding(SupportsShouldProcess = $true, ConfirmImpact = 'High')]
    [OutputType()]
    param
    (
        [Parameter(Mandatory = $true)]
        [System.Management.Automation.SwitchParameter]
        $AcceptLicensingTerms,

        [Parameter(Mandatory = $true)]
        [System.String]
        $MediaPath,

        [Parameter()]
        [System.String]
        $InstanceName,

        [Parameter()]
        [System.Management.Automation.SwitchParameter]
        $Enu,

        [Parameter()]
        [System.String]
        $InstanceId,

        [Parameter()]
        [System.String]
        $PBEngSvcAccount,

        [Parameter()]
        [System.Security.SecureString]
        $PBEngSvcPassword,

        [Parameter()]
        [ValidateSet('Automatic', 'Disabled', 'Manual')]
        [System.String]
        $PBEngSvcStartupType,

        [Parameter()]
        [System.UInt16]
        $PBStartPortRange,

        [Parameter()]
        [System.UInt16]
        $PBEndPortRange,

        [Parameter()]
        [System.Management.Automation.SwitchParameter]
        $PBScaleOut,

        [Parameter()]
        [System.String]
        $ProductKey, # This is argument PID but $PID is reserved variable.

        [Parameter()]
        [System.String]
        $AgtSvcAccount,

        [Parameter()]
        [System.Security.SecureString]
        $AgtSvcPassword,

        [Parameter()]
        [ValidateSet('Automatic', 'Disabled', 'Manual')]
        [System.String]
        $AgtSvcStartupType,

        [Parameter()]
        [ValidateSet('Automatic', 'Disabled', 'Manual')]
        [System.String]
        $BrowserSvcStartupType,

        [Parameter()]
        [System.Management.Automation.SwitchParameter]
        $EnableRanU,

        [Parameter()]
        [System.String]
        $InstallSqlDataDir,

        [Parameter()]
        [System.String]
        $SqlBackupDir,

        [Parameter()]
        [ValidateSet('SQL')]
        [System.String]
        $SecurityMode,

        [Parameter()]
        [System.Security.SecureString]
        $SAPwd,

        [Parameter()]
        [System.String]
        $SqlCollation,

        [Parameter()]
        [System.String]
        $SqlSvcAccount,

        [Parameter()]
        [System.Security.SecureString]
        $SqlSvcPassword,

        [Parameter()]
        [ValidateSet('Automatic', 'Disabled', 'Manual')]
        [System.String]
        $SqlSvcStartupType,

        [Parameter()]
        [System.String[]]
        $SqlSysAdminAccounts,

        [Parameter()]
        [System.String]
        $SqlTempDbDir,

        [Parameter()]
        [System.String]
        $SqlTempDbLogDir,

        [Parameter()]
        [System.UInt16]
        $SqlTempDbFileCount,

        [Parameter()]
        [ValidateRange(4, 262144)]
        [System.UInt16]
        $SqlTempDbFileSize,

        [Parameter()]
        [ValidateRange(0, 1024)]
        [System.UInt16]
        $SqlTempDbFileGrowth,

        [Parameter()]
        [ValidateRange(4, 262144)]
        [System.UInt16]
        $SqlTempDbLogFileSize,

        [Parameter()]
        [ValidateRange(0, 1024)]
        [System.UInt16]
        $SqlTempDbLogFileGrowth,

        [Parameter()]
        [System.String]
        $SqlUserDbDir,

        [Parameter()]
        [System.String]
        $SqlUserDbLogDir,

        [Parameter()]
        [ValidateRange(0, 3)]
        [System.UInt16]
        $FileStreamLevel,

        [Parameter()]
        [System.String]
        $FileStreamShareName,

        [Parameter()]
        [System.Management.Automation.SwitchParameter]
        $NpEnabled,

        [Parameter()]
        [System.Management.Automation.SwitchParameter]
        $TcpEnabled,

        [Parameter()]
        [ValidateSet('SharePointFilesOnlyMode', 'DefaultNativeMode', 'FilesOnlyMode')]
        [System.String]
        $RsInstallMode,

        [Parameter()]
        [System.String]
        $RSSvcAccount,

        [Parameter()]
        [System.Security.SecureString]
        $RSSvcPassword,

        [Parameter()]
        [ValidateSet('Automatic', 'Disabled', 'Manual')]
        [System.String]
        $RSSvcStartupType,

        [Parameter()]
        [System.Management.Automation.SwitchParameter]
        $ProductCoveredBySA,

        [Parameter()]
        [System.UInt32]
        $Timeout = 7200,

        [Parameter()]
        [System.Management.Automation.SwitchParameter]
        $Force
    )

    Invoke-SetupAction -CompleteImage @PSBoundParameters
}
#EndRegion '.\Public\Complete-SqlDscImage.ps1' 380
#Region '.\Public\Connect-SqlDscDatabaseEngine.ps1' -1

<#
    .SYNOPSIS
        Connect to a SQL Server Database Engine and return the server object.

    .DESCRIPTION
        This command connects to a  SQL Server Database Engine instance and returns
        the Server object.

    .PARAMETER ServerName
        String containing the host name of the SQL Server to connect to.
        Default value is the current computer name.

    .PARAMETER InstanceName
        String containing the SQL Server Database Engine instance to connect to.
        Default value is 'MSSQLSERVER'.

    .PARAMETER Credential
        The credentials to use to impersonate a user when connecting to the
        SQL Server Database Engine instance. If this parameter is left out, then
        the current user will be used to connect to the SQL Server Database Engine
        instance using Windows Integrated authentication.

    .PARAMETER LoginType
        Specifies which type of logon credential should be used. The valid types
        are 'WindowsUser' or 'SqlLogin'. Default value is 'WindowsUser'
        If set to 'WindowsUser' then the it will impersonate using the Windows
        login specified in the parameter Credential.
        If set to 'SqlLogin' then it will impersonate using the native SQL
        login specified in the parameter Credential.

    .PARAMETER StatementTimeout
        Set the query StatementTimeout in seconds. Default 600 seconds (10 minutes).

    .PARAMETER Encrypt
        Specifies if encryption should be used.

    .EXAMPLE
        Connect-SqlDscDatabaseEngine

        Connects to the default instance on the local server.

    .EXAMPLE
        Connect-SqlDscDatabaseEngine -InstanceName 'MyInstance'

        Connects to the instance 'MyInstance' on the local server.

    .EXAMPLE
        Connect-SqlDscDatabaseEngine -ServerName 'sql.company.local' -InstanceName 'MyInstance'

        Connects to the instance 'MyInstance' on the server 'sql.company.local'.

    .EXAMPLE
        Connect-SqlDscDatabaseEngine -Credential ([System.Management.Automation.PSCredential]::new('DOMAIN\SqlUser', (ConvertTo-SecureString -String 'MyP@ssw0rd1' -AsPlainText -Force)))

        Connects to the default instance on the local server impersonating the Windows user 'DOMAIN\SqlUser'.

    .EXAMPLE
        Connect-SqlDscDatabaseEngine -LoginType 'SqlLogin' -Credential ([System.Management.Automation.PSCredential]::new('sa', (ConvertTo-SecureString -String 'MyP@ssw0rd1' -AsPlainText -Force)))

        Connects to the default instance on the local server using the SQL login 'sa'.

    .OUTPUTS
        `[Microsoft.SqlServer.Management.Smo.Server]`
#>
function Connect-SqlDscDatabaseEngine
{
    [CmdletBinding(DefaultParameterSetName = 'SqlServer')]
    param
    (
        [Parameter(ParameterSetName = 'SqlServer')]
        [Parameter(ParameterSetName = 'SqlServerWithCredential')]
        [ValidateNotNull()]
        [System.String]
        $ServerName = (Get-ComputerName),

        [Parameter(ParameterSetName = 'SqlServer')]
        [Parameter(ParameterSetName = 'SqlServerWithCredential')]
        [ValidateNotNull()]
        [System.String]
        $InstanceName = 'MSSQLSERVER',

        [Parameter(ParameterSetName = 'SqlServerWithCredential', Mandatory = $true)]
        [ValidateNotNull()]
        [Alias('SetupCredential', 'DatabaseCredential')]
        [System.Management.Automation.PSCredential]
        $Credential,

        [Parameter(ParameterSetName = 'SqlServerWithCredential')]
        [ValidateSet('WindowsUser', 'SqlLogin')]
        [System.String]
        $LoginType = 'WindowsUser',

        [Parameter()]
        [ValidateNotNull()]
        [System.Int32]
        $StatementTimeout = 600,

        [Parameter()]
        [System.Management.Automation.SwitchParameter]
        $Encrypt
    )

    # Call the private function.
    return (Connect-Sql @PSBoundParameters)
}
#EndRegion '.\Public\Connect-SqlDscDatabaseEngine.ps1' 106
#Region '.\Public\ConvertFrom-SqlDscDatabasePermission.ps1' -1

<#
    .SYNOPSIS
        Converts one or more DatabasePermission objects into an object of the type
        Microsoft.SqlServer.Management.Smo.DatabasePermissionSet.

    .DESCRIPTION
        Converts one or more DatabasePermission objects into a single object of the type
        Microsoft.SqlServer.Management.Smo.DatabasePermissionSet.

    .PARAMETER Permission
        Specifies a DatabasePermission object.

    .EXAMPLE
        [DatabasePermission] @{
            State = 'Grant'
            Permission = 'Connect'
        } | ConvertFrom-SqlDscDatabasePermission

        Returns an object of `[Microsoft.SqlServer.Management.Smo.DatabasePermissionSet]`
        with all the permissions set to $true that was part of the `[DatabasePermission]`.

    .OUTPUTS
        [Microsoft.SqlServer.Management.Smo.DatabasePermissionSet]
#>
function ConvertFrom-SqlDscDatabasePermission
{
    [System.Diagnostics.CodeAnalysis.SuppressMessageAttribute('UseSyntacticallyCorrectExamples', '', Justification = 'Because the rule does not yet support parsing the code when the output type is not available. The ScriptAnalyzer rule UseSyntacticallyCorrectExamples will always error in the editor due to https://github.com/indented-automation/Indented.ScriptAnalyzerRules/issues/8.')]
    [CmdletBinding()]
    [OutputType([Microsoft.SqlServer.Management.Smo.DatabasePermissionSet])]
    param
    (
        [Parameter(Mandatory = $true, ValueFromPipeline = $true)]
        [DatabasePermission]
        $Permission
    )

    begin
    {
        $permissionSet = New-Object -TypeName 'Microsoft.SqlServer.Management.Smo.DatabasePermissionSet'
    }

    process
    {
        foreach ($permissionName in $Permission.Permission)
        {
            $permissionSet.$permissionName = $true
        }
    }

    end
    {
        return $permissionSet
    }
}
#EndRegion '.\Public\ConvertFrom-SqlDscDatabasePermission.ps1' 55
#Region '.\Public\ConvertFrom-SqlDscServerPermission.ps1' -1

<#
    .SYNOPSIS
        Converts a ServerPermission object into an object of the type
        Microsoft.SqlServer.Management.Smo.ServerPermissionSet.

    .DESCRIPTION
        Converts a ServerPermission object into an object of the type
        Microsoft.SqlServer.Management.Smo.ServerPermissionSet.

    .PARAMETER Permission
        Specifies a ServerPermission object.

    .EXAMPLE
        [ServerPermission] @{
            State = 'Grant'
            Permission = 'Connect'
        } | ConvertFrom-SqlDscServerPermission

        Returns an object of `[Microsoft.SqlServer.Management.Smo.ServerPermissionSet]`
        with all the permissions set to $true that was part of the `[ServerPermission]`.

    .OUTPUTS
        [Microsoft.SqlServer.Management.Smo.ServerPermissionSet]
#>
function ConvertFrom-SqlDscServerPermission
{
    [System.Diagnostics.CodeAnalysis.SuppressMessageAttribute('UseSyntacticallyCorrectExamples', '', Justification = 'Because the rule does not yet support parsing the code when the output type is not available. The ScriptAnalyzer rule UseSyntacticallyCorrectExamples will always error in the editor due to https://github.com/indented-automation/Indented.ScriptAnalyzerRules/issues/8.')]
    [CmdletBinding()]
    [OutputType([Microsoft.SqlServer.Management.Smo.ServerPermissionSet])]
    param
    (
        [Parameter(Mandatory = $true, ValueFromPipeline = $true)]
        [ServerPermission]
        $Permission
    )

    begin
    {
        $permissionSet = New-Object -TypeName 'Microsoft.SqlServer.Management.Smo.ServerPermissionSet'
    }

    process
    {
        foreach ($permissionName in $Permission.Permission)
        {
            $permissionSet.$permissionName = $true
        }
    }

    end
    {
        return $permissionSet
    }
}
#EndRegion '.\Public\ConvertFrom-SqlDscServerPermission.ps1' 55
#Region '.\Public\ConvertTo-SqlDscDatabasePermission.ps1' -1

<#
    .SYNOPSIS
        Converts a collection of Microsoft.SqlServer.Management.Smo.DatabasePermissionInfo
        objects into an array of DatabasePermission objects.

    .DESCRIPTION
        Converts a collection of Microsoft.SqlServer.Management.Smo.DatabasePermissionInfo
        objects into an array of DatabasePermission objects.

    .PARAMETER DatabasePermissionInfo
        Specifies a collection of Microsoft.SqlServer.Management.Smo.DatabasePermissionInfo
        objects.

    .EXAMPLE
        $serverInstance = Connect-SqlDscDatabaseEngine
        $databasePermissionInfo = Get-SqlDscDatabasePermission -ServerObject $serverInstance -DatabaseName 'MyDatabase' -Name 'MyPrincipal'
        ConvertTo-SqlDscDatabasePermission -DatabasePermissionInfo $databasePermissionInfo

        Get all permissions for the principal 'MyPrincipal' and converts the permissions
        into an array of `[DatabasePermission[]]`.

    .OUTPUTS
        [DatabasePermission[]]
#>
function ConvertTo-SqlDscDatabasePermission
{
    [System.Diagnostics.CodeAnalysis.SuppressMessageAttribute('UseSyntacticallyCorrectExamples', '', Justification = 'Because the rule does not yet support parsing the code when the output type is not available. The ScriptAnalyzer rule UseSyntacticallyCorrectExamples will always error in the editor due to https://github.com/indented-automation/Indented.ScriptAnalyzerRules/issues/8.')]
    [CmdletBinding()]
    [OutputType([DatabasePermission[]])]
    param
    (
        [Parameter(Mandatory = $true, ValueFromPipeline = $true)]
        [AllowEmptyCollection()]
        [Microsoft.SqlServer.Management.Smo.DatabasePermissionInfo[]]
        $DatabasePermissionInfo
    )

    begin
    {
        [DatabasePermission[]] $permissions = @()
    }

    process
    {
        $permissionState = foreach ($currentDatabasePermissionInfo in $DatabasePermissionInfo)
        {
            # Convert from the type PermissionState to String.
            [System.String] $currentDatabasePermissionInfo.PermissionState
        }

        $permissionState = $permissionState | Select-Object -Unique

        foreach ($currentPermissionState in $permissionState)
        {
            $filteredDatabasePermission = $DatabasePermissionInfo |
                Where-Object -FilterScript {
                    $_.PermissionState -eq $currentPermissionState
                }

            $databasePermissionStateExist = $permissions.Where({
                    $_.State -contains $currentPermissionState
                }) |
                Select-Object -First 1

            if ($databasePermissionStateExist)
            {
                $databasePermission = $databasePermissionStateExist
            }
            else
            {
                $databasePermission = [DatabasePermission] @{
                    State      = $currentPermissionState
                    Permission = [System.String[]] @()
                }
            }

            foreach ($currentPermission in $filteredDatabasePermission)
            {
                # Get the permission names that is set to $true
                $permissionProperty = $currentPermission.PermissionType |
                    Get-Member -MemberType 'Property' |
                    Select-Object -ExpandProperty 'Name' -Unique |
                    Where-Object -FilterScript {
                        $currentPermission.PermissionType.$_
                    }


                foreach ($currentPermissionProperty in $permissionProperty)
                {
                    $databasePermission.Permission += $currentPermissionProperty
                }
            }

            # Only add the object if it was created.
            if (-not $databasePermissionStateExist)
            {
                $permissions += $databasePermission
            }
        }
    }

    end
    {
        return $permissions
    }
}
#EndRegion '.\Public\ConvertTo-SqlDscDatabasePermission.ps1' 107
#Region '.\Public\ConvertTo-SqlDscDataFile.ps1' -1

<#
    .SYNOPSIS
        Converts a DatabaseFileSpec object to a SMO DataFile object.

    .DESCRIPTION
        This command takes a DatabaseFileSpec specification object and converts it
        to a SMO (SQL Server Management Objects) DataFile object. This is used
        internally when creating databases with custom file configurations.

    .PARAMETER FileGroupObject
        The SMO FileGroup object to which the DataFile will belong.

    .PARAMETER DataFileSpec
        The DatabaseFileSpec object containing the data file configuration.

    .INPUTS
        None

        This command does not accept pipeline input.

    .OUTPUTS
        Microsoft.SqlServer.Management.Smo.DataFile

        Returns a SMO DataFile object bound to the provided FileGroup.

    .EXAMPLE
        $fileSpec = New-SqlDscDataFile -Name 'TestDB_Data' -FileName 'C:\SQLData\TestDB.mdf' -AsSpec
        $fileGroup = [Microsoft.SqlServer.Management.Smo.FileGroup]::new($database, 'PRIMARY')
        $dataFile = ConvertTo-SqlDscDataFile -FileGroupObject $fileGroup -DataFileSpec $fileSpec

        Converts a DatabaseFileSpec to a SMO DataFile object.
#>
function ConvertTo-SqlDscDataFile
{
    [System.Diagnostics.CodeAnalysis.SuppressMessageAttribute('UseSyntacticallyCorrectExamples', '', Justification = 'Because the rule does not yet support parsing the code when a parameter type is not available. The ScriptAnalyzer rule UseSyntacticallyCorrectExamples will always error in the editor due to https://github.com/indented-automation/Indented.ScriptAnalyzerRules/issues/8.')]
    [CmdletBinding()]
    [OutputType([Microsoft.SqlServer.Management.Smo.DataFile])]
    param
    (
        [Parameter(Mandatory = $true)]
        [Microsoft.SqlServer.Management.Smo.FileGroup]
        $FileGroupObject,

        [Parameter(Mandatory = $true)]
        [DatabaseFileSpec]
        $DataFileSpec
    )

    # Create SMO DataFile object
    $smoDataFile = [Microsoft.SqlServer.Management.Smo.DataFile]::new($FileGroupObject, $DataFileSpec.Name)
    $smoDataFile.FileName = $DataFileSpec.FileName

    # Set optional data file properties
    if ($DataFileSpec.Size -gt 0)
    {
        $smoDataFile.Size = $DataFileSpec.Size
    }

    if ($DataFileSpec.MaxSize -gt 0)
    {
        $smoDataFile.MaxSize = $DataFileSpec.MaxSize
    }

    if ($DataFileSpec.Growth -gt 0)
    {
        $smoDataFile.Growth = $DataFileSpec.Growth
    }

    if ($DataFileSpec.GrowthType)
    {
        $smoDataFile.GrowthType = $DataFileSpec.GrowthType
    }

    if ($DataFileSpec.IsPrimaryFile)
    {
        $smoDataFile.IsPrimaryFile = $DataFileSpec.IsPrimaryFile
    }

    return $smoDataFile
}
#EndRegion '.\Public\ConvertTo-SqlDscDataFile.ps1' 81
#Region '.\Public\ConvertTo-SqlDscEditionName.ps1' -1

<#
    .SYNOPSIS
        Converts a SQL Server Reporting Services or Power BI Report Server edition
        ID to an edition name.

    .DESCRIPTION
        Converts a SQL Server Reporting Services or Power BI Report Server edition
        ID. The command returns a PSCustomObject containing the EditionId, Edition,
        and EditionName based on a predefined mapping table.

    .PARAMETER Id
        Specifies the edition ID that should be converted.

    .EXAMPLE
        ConvertTo-SqlDscEditionName -Id 2176971986

        Returns information about the edition ID 2176971986.

    .EXAMPLE
        ConvertTo-SqlDscEditionName -Id 2017617798

        Returns information about the edition ID 2017617798.

    .NOTES
        Author: SqlServerDsc
#>
function ConvertTo-SqlDscEditionName
{
    [CmdletBinding()]
    [OutputType([System.Management.Automation.PSCustomObject])]
    param
    (
        [Parameter(Mandatory = $true)]
        [System.UInt32]
        $Id
    )

    Write-Debug -Message ($script:localizedData.ConvertTo_EditionName_ConvertingEditionId -f $Id)

    $resultObject = [PSCustomObject] @{
        EditionId = $Id
        Edition = ''
        EditionName = ''
    }

    switch ($Id)
    {
        2176971986
        {
            $resultObject.Edition = 'Developer'
            $resultObject.EditionName = 'SQL Server Developer'
        }

        2017617798
        {
            $resultObject.Edition = 'Developer'
            $resultObject.EditionName = 'Power BI Report Server - Developer'
        }

        1369084056
        {
            $resultObject.Edition = 'Evaluation'
            $resultObject.EditionName = 'Power BI Report Server - Evaluation'
        }

        default
        {
            Write-Debug -Message ($script:localizedData.ConvertTo_EditionName_UnknownEditionId -f $Id)

            $resultObject.Edition = 'Unknown'
            $resultObject.EditionName = 'Unknown'
        }
    }

    return $resultObject
}
#EndRegion '.\Public\ConvertTo-SqlDscEditionName.ps1' 77
#Region '.\Public\ConvertTo-SqlDscFileGroup.ps1' -1

<#
    .SYNOPSIS
        Converts a DatabaseFileGroupSpec object to a SMO FileGroup object.

    .DESCRIPTION
        This command takes a DatabaseFileGroupSpec specification object and converts it
        to a SMO (SQL Server Management Objects) FileGroup object with all configured
        data files. This is used internally when creating databases with custom file
        group configurations.

    .PARAMETER DatabaseObject
        The SMO Database object to which the FileGroup will belong.

    .PARAMETER FileGroupSpec
        The DatabaseFileGroupSpec object containing the file group configuration.

    .OUTPUTS
        Microsoft.SqlServer.Management.Smo.FileGroup

    .EXAMPLE
        $fileSpec = New-SqlDscDataFile -Name 'TestDB_Data' -FileName 'C:\SQLData\TestDB.mdf' -AsSpec
        $fileGroupSpec = New-SqlDscFileGroup -Name 'PRIMARY' -Files @($fileSpec) -AsSpec
        $smoFileGroup = ConvertTo-SqlDscFileGroup -DatabaseObject $database -FileGroupSpec $fileGroupSpec

        Converts a DatabaseFileGroupSpec to a SMO FileGroup object with data files.
#>
function ConvertTo-SqlDscFileGroup
{
    [System.Diagnostics.CodeAnalysis.SuppressMessageAttribute('UseSyntacticallyCorrectExamples', '', Justification = 'Because the rule does not yet support parsing the code when a parameter type is not available. The ScriptAnalyzer rule UseSyntacticallyCorrectExamples will always error in the editor due to https://github.com/indented-automation/Indented.ScriptAnalyzerRules/issues/8.')]
    [CmdletBinding()]
    [OutputType([Microsoft.SqlServer.Management.Smo.FileGroup])]
    param
    (
        [Parameter(Mandatory = $true)]
        [Microsoft.SqlServer.Management.Smo.Database]
        $DatabaseObject,

        [Parameter(Mandatory = $true)]
        [DatabaseFileGroupSpec]
        $FileGroupSpec
    )

    # Create SMO FileGroup object
    $smoFileGroup = [Microsoft.SqlServer.Management.Smo.FileGroup]::new($DatabaseObject, $FileGroupSpec.Name)

    # Set file group properties
    if ($null -ne $FileGroupSpec.ReadOnly)
    {
        $smoFileGroup.ReadOnly = $FileGroupSpec.ReadOnly
    }

    if ($null -ne $FileGroupSpec.IsDefault)
    {
        $smoFileGroup.IsDefault = $FileGroupSpec.IsDefault
    }

    # Add data files to the file group
    if ($FileGroupSpec.Files -and $FileGroupSpec.Files.Count -gt 0)
    {
        foreach ($fileSpec in $FileGroupSpec.Files)
        {
            $smoDataFile = ConvertTo-SqlDscDataFile -FileGroupObject $smoFileGroup -DataFileSpec $fileSpec
            $smoFileGroup.Files.Add($smoDataFile)
        }
    }

    return $smoFileGroup
}
#EndRegion '.\Public\ConvertTo-SqlDscFileGroup.ps1' 69
#Region '.\Public\ConvertTo-SqlDscServerPermission.ps1' -1

<#
    .SYNOPSIS
        Converts a collection of Microsoft.SqlServer.Management.Smo.ServerPermissionInfo
        objects into an array of ServerPermission objects.

    .DESCRIPTION
        Converts a collection of Microsoft.SqlServer.Management.Smo.ServerPermissionInfo
        objects into an array of ServerPermission objects.

    .PARAMETER ServerPermissionInfo
        Specifies a collection of Microsoft.SqlServer.Management.Smo.ServerPermissionInfo
        objects.

    .EXAMPLE
        $serverInstance = Connect-SqlDscDatabaseEngine
        $serverPermissionInfo = Get-SqlDscServerPermission -ServerObject $serverInstance -Name 'MyPrincipal'
        ConvertTo-SqlDscServerPermission -ServerPermissionInfo $serverPermissionInfo

        Get all permissions for the principal 'MyPrincipal' and converts the permissions
        into an array of `[ServerPermission[]]`.

    .OUTPUTS
        [ServerPermission[]]
#>
function ConvertTo-SqlDscServerPermission
{
    [System.Diagnostics.CodeAnalysis.SuppressMessageAttribute('UseSyntacticallyCorrectExamples', '', Justification = 'Because the rule does not yet support parsing the code when the output type is not available. The ScriptAnalyzer rule UseSyntacticallyCorrectExamples will always error in the editor due to https://github.com/indented-automation/Indented.ScriptAnalyzerRules/issues/8.')]
    [CmdletBinding()]
    [OutputType([ServerPermission[]])]
    param
    (
        [Parameter(Mandatory = $true, ValueFromPipeline = $true)]
        [AllowEmptyCollection()]
        [Microsoft.SqlServer.Management.Smo.ServerPermissionInfo[]]
        $ServerPermissionInfo
    )

    begin
    {
        [ServerPermission[]] $permissions = @()
    }

    process
    {
        $permissionState = foreach ($currentServerPermissionInfo in $ServerPermissionInfo)
        {
            # Convert from the type PermissionState to String.
            [System.String] $currentServerPermissionInfo.PermissionState
        }

        $permissionState = $permissionState | Select-Object -Unique

        foreach ($currentPermissionState in $permissionState)
        {
            $filteredServerPermission = $ServerPermissionInfo |
                Where-Object -FilterScript {
                    $_.PermissionState -eq $currentPermissionState
                }

            $serverPermissionStateExist = $permissions.Where({
                    $_.State -contains $currentPermissionState
                }) |
                Select-Object -First 1

            if ($serverPermissionStateExist)
            {
                $serverPermission = $serverPermissionStateExist
            }
            else
            {
                $serverPermission = [ServerPermission] @{
                    State      = $currentPermissionState
                    Permission = [System.String[]] @()
                }
            }

            foreach ($currentPermission in $filteredServerPermission)
            {
                # Get the permission names that is set to $true
                $permissionProperty = $currentPermission.PermissionType |
                    Get-Member -MemberType 'Property' |
                    Select-Object -ExpandProperty 'Name' -Unique |
                    Where-Object -FilterScript {
                        $currentPermission.PermissionType.$_
                    }


                foreach ($currentPermissionProperty in $permissionProperty)
                {
                    $serverPermission.Permission += $currentPermissionProperty
                }
            }

            # Only add the object if it was created.
            if (-not $serverPermissionStateExist)
            {
                $permissions += $serverPermission
            }
        }
    }

    end
    {
        return $permissions
    }
}
#EndRegion '.\Public\ConvertTo-SqlDscServerPermission.ps1' 107
#Region '.\Public\Deny-SqlDscServerPermission.ps1' -1

<#
    .SYNOPSIS
        Denies server permissions to a principal on a SQL Server Database Engine instance.

    .DESCRIPTION
        This command denies server permissions to an existing principal on a SQL Server
        Database Engine instance. The principal can be specified as either a Login
        object (from Get-SqlDscLogin) or a ServerRole object (from Get-SqlDscRole).

    .PARAMETER Login
        Specifies the Login object for which the permissions are denied.
        This parameter accepts pipeline input.

    .PARAMETER ServerRole
        Specifies the ServerRole object for which the permissions are denied.
        This parameter accepts pipeline input.

    .PARAMETER Permission
        Specifies the permissions to be denied. Specify multiple permissions by
        providing an array of SqlServerPermission enum values.

    .PARAMETER Force
        Specifies that the permissions should be denied without any confirmation.

    .OUTPUTS
        None.

    .EXAMPLE
        $serverInstance = Connect-SqlDscDatabaseEngine
        $login = $serverInstance | Get-SqlDscLogin -Name 'MyLogin'

        Deny-SqlDscServerPermission -Login $login -Permission ConnectSql, ViewServerState

        Denies the specified permissions to the login 'MyLogin'.

    .EXAMPLE
        $serverInstance = Connect-SqlDscDatabaseEngine
        $role = $serverInstance | Get-SqlDscRole -Name 'MyRole'

        $role | Deny-SqlDscServerPermission -Permission AlterAnyDatabase -Force

        Denies the specified permissions to the role 'MyRole' without prompting for confirmation.

    .NOTES
        The Login or ServerRole object must come from the same SQL Server instance
        where the permissions will be denied. If specifying `-ErrorAction 'SilentlyContinue'`
        then the command will silently continue if any errors occur. If specifying
        `-ErrorAction 'Stop'` the command will throw an error on any failure.
#>
function Deny-SqlDscServerPermission
{
    [System.Diagnostics.CodeAnalysis.SuppressMessageAttribute('UseSyntacticallyCorrectExamples', '', Justification = 'Because the rule does not yet support parsing the code when a parameter type is not available. The ScriptAnalyzer rule UseSyntacticallyCorrectExamples will always error in the editor due to https://github.com/indented-automation/Indented.ScriptAnalyzerRules/issues/8.')]
    [System.Diagnostics.CodeAnalysis.SuppressMessageAttribute('AvoidThrowOutsideOfTry', '', Justification = 'Because the code throws based on an prior expression')]
    [CmdletBinding(SupportsShouldProcess = $true, ConfirmImpact = 'High')]
    [OutputType()]
    param
    (
        [Parameter(Mandatory = $true, ValueFromPipeline = $true, ParameterSetName = 'Login')]
        [Microsoft.SqlServer.Management.Smo.Login]
        $Login,

        [Parameter(Mandatory = $true, ValueFromPipeline = $true, ParameterSetName = 'ServerRole')]
        [Microsoft.SqlServer.Management.Smo.ServerRole]
        $ServerRole,

        [Parameter(Mandatory = $true)]
        [SqlServerPermission[]]
        $Permission,

        [Parameter()]
        [System.Management.Automation.SwitchParameter]
        $Force
    )

    process
    {
        if ($Force.IsPresent -and -not $Confirm)
        {
            $ConfirmPreference = 'None'
        }

        # Determine which principal object we're working with
        if ($PSCmdlet.ParameterSetName -eq 'Login')
        {
            $principalName = $Login.Name
            $serverObject = $Login.Parent
        }
        else
        {
            $principalName = $ServerRole.Name
            $serverObject = $ServerRole.Parent
        }

        $verboseDescriptionMessage = $script:localizedData.ServerPermission_Deny_ShouldProcessVerboseDescription -f $principalName, $serverObject.InstanceName, ($Permission -join ',')
        $verboseWarningMessage = $script:localizedData.ServerPermission_Deny_ShouldProcessVerboseWarning -f $principalName
        $captionMessage = $script:localizedData.ServerPermission_Deny_ShouldProcessCaption

        if ($PSCmdlet.ShouldProcess($verboseDescriptionMessage, $verboseWarningMessage, $captionMessage))
        {
            # Convert enum array to ServerPermissionSet object
            $permissionSet = [Microsoft.SqlServer.Management.Smo.ServerPermissionSet]::new()
            foreach ($permissionName in $Permission)
            {
                $permissionSet.$permissionName = $true
            }

            try
            {
                $serverObject.Deny($permissionSet, $principalName)
            }
            catch
            {
                $errorMessage = $script:localizedData.ServerPermission_Deny_FailedToDenyPermission -f $principalName, $serverObject.InstanceName, ($Permission -join ',')

                $exception = [System.InvalidOperationException]::new($errorMessage, $_.Exception)

                $PSCmdlet.ThrowTerminatingError(
                    [System.Management.Automation.ErrorRecord]::new(
                        $exception,
                        'DSDSP0001', # cSpell: disable-line
                        [System.Management.Automation.ErrorCategory]::InvalidOperation,
                        $principalName
                    )
                )
            }
        }
    }
}
#EndRegion '.\Public\Deny-SqlDscServerPermission.ps1' 129
#Region '.\Public\Disable-SqlDscAgentOperator.ps1' -1

<#
    .SYNOPSIS
        Disables a SQL Agent Operator.

    .DESCRIPTION
        This command disables a SQL Agent Operator on a SQL Server Database Engine instance.

    .PARAMETER ServerObject
        Specifies current server connection object.

    .PARAMETER OperatorObject
        Specifies a SQL Agent Operator object to disable.

    .PARAMETER Name
        Specifies the name of the SQL Agent Operator to be disabled.

    .PARAMETER Force
        Specifies that the operator should be disabled without any confirmation.

    .PARAMETER Refresh
        Specifies that the **ServerObject**'s operators should be refreshed before
        trying to disable the operator object. This is helpful when operators could have
        been modified outside of the **ServerObject**, for example through T-SQL.
        But on instances with a large amount of operators it might be better to make
        sure the **ServerObject** is recent enough, or pass in **OperatorObject**.

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine -InstanceName 'MyInstance'
        $operatorObject = $serverObject | Get-SqlDscAgentOperator -Name 'MyOperator'
        $operatorObject | Disable-SqlDscAgentOperator

        Disables the operator named **MyOperator**.

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine -InstanceName 'MyInstance'
        $serverObject | Disable-SqlDscAgentOperator -Name 'MyOperator'

        Disables the operator named **MyOperator**.

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine -InstanceName 'MyInstance'
        $serverObject | Disable-SqlDscAgentOperator -Name 'MyOperator' -Force

        Disables the operator without confirmation using **-Force**.

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine -InstanceName 'MyInstance'
        $serverObject | Disable-SqlDscAgentOperator -Name 'MyOperator' -Refresh

        Refreshes the server operators collection before disabling **MyOperator**.

    .INPUTS
        [Microsoft.SqlServer.Management.Smo.Server]

        Server object accepted from the pipeline (ServerObject parameter set).

    .INPUTS
        [Microsoft.SqlServer.Management.Smo.Agent.Operator]

        Operator object accepted from the pipeline (OperatorObject parameter set).

    .OUTPUTS
        None.
#>
function Disable-SqlDscAgentOperator
{
    [System.Diagnostics.CodeAnalysis.SuppressMessageAttribute('UseSyntacticallyCorrectExamples', '', Justification = 'Because the rule does not yet support parsing the code when a parameter type is not available. The ScriptAnalyzer rule UseSyntacticallyCorrectExamples will always error in the editor due to https://github.com/indented-automation/Indented.ScriptAnalyzerRules/issues/8.')]
    [OutputType()]
    [CmdletBinding(SupportsShouldProcess = $true, ConfirmImpact = 'High')]
    param
    (
        [Parameter(ParameterSetName = 'ServerObject', Mandatory = $true, ValueFromPipeline = $true)]
        [Microsoft.SqlServer.Management.Smo.Server]
        $ServerObject,

        [Parameter(ParameterSetName = 'OperatorObject', Mandatory = $true, ValueFromPipeline = $true)]
        [Microsoft.SqlServer.Management.Smo.Agent.Operator]
        $OperatorObject,

        [Parameter(ParameterSetName = 'ServerObject', Mandatory = $true)]
        [System.String]
        $Name,

        [Parameter()]
        [System.Management.Automation.SwitchParameter]
        $Force,

        [Parameter(ParameterSetName = 'ServerObject')]
        [System.Management.Automation.SwitchParameter]
        $Refresh
    )

    process
    {
        if ($Force.IsPresent -and -not $Confirm)
        {
            $ConfirmPreference = 'None'
        }

        if ($PSCmdlet.ParameterSetName -eq 'ServerObject')
        {
            $originalErrorActionPreference = $ErrorActionPreference
            $ErrorActionPreference = 'Stop'
            $OperatorObject = Get-AgentOperatorObject -ServerObject $ServerObject -Name $Name -Refresh:$Refresh -ErrorAction 'Stop'
            $ErrorActionPreference = $originalErrorActionPreference
        }

        $verboseDescriptionMessage = $script:localizedData.Disable_SqlDscAgentOperator_ShouldProcessVerboseDescription -f $OperatorObject.Name, $OperatorObject.Parent.Parent.InstanceName
        $verboseWarningMessage = $script:localizedData.Disable_SqlDscAgentOperator_ShouldProcessVerboseWarning -f $OperatorObject.Name
        $captionMessage = $script:localizedData.Disable_SqlDscAgentOperator_ShouldProcessCaption

        if ($PSCmdlet.ShouldProcess($verboseDescriptionMessage, $verboseWarningMessage, $captionMessage))
        {
            try
            {
                $OperatorObject.Enabled = $false
                $OperatorObject.Alter()
            }
            catch
            {
                $errorMessage = $script:localizedData.Disable_SqlDscAgentOperator_DisableFailed -f $OperatorObject.Name

                $PSCmdlet.ThrowTerminatingError(
                    [System.Management.Automation.ErrorRecord]::new(
                        [System.InvalidOperationException]::new($errorMessage, $_.Exception),
                        'DSAO0005', # Align with Disable_SqlDscAgentOperator_DisableFailed
                        [System.Management.Automation.ErrorCategory]::InvalidOperation,
                        $OperatorObject
                    )
                )
            }
        }
    }
}
#EndRegion '.\Public\Disable-SqlDscAgentOperator.ps1' 135
#Region '.\Public\Disable-SqlDscAudit.ps1' -1

<#
    .SYNOPSIS
        Disables a server audit.

    .DESCRIPTION
        This command disables a server audit in a SQL Server Database Engine instance.

    .PARAMETER ServerObject
        Specifies current server connection object.

    .PARAMETER AuditObject
        Specifies an audit object to disable.

    .PARAMETER Name
        Specifies the name of the server audit to be disabled.

    .PARAMETER Force
        Specifies that the audit should be disabled without any confirmation.

    .PARAMETER Refresh
        Specifies that the **ServerObject**'s audits should be refreshed before
        trying to disable the audit object. This is helpful when audits could have
        been modified outside of the **ServerObject**, for example through T-SQL.
        But on instances with a large amount of audits it might be better to make
        sure the **ServerObject** is recent enough, or pass in **AuditObject**.

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine -InstanceName 'MyInstance'
        $auditObject = $sqlServerObject | Get-SqlDscAudit -Name 'MyFileAudit'
        $auditObject | Disable-SqlDscAudit

        Disables the audit named **MyFileAudit**.

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine -InstanceName 'MyInstance'
        $sqlServerObject | Disable-SqlDscAudit -Name 'MyFileAudit'

        Disables the audit named **MyFileAudit**.

    .OUTPUTS
        None.
#>
function Disable-SqlDscAudit
{
    [System.Diagnostics.CodeAnalysis.SuppressMessageAttribute('UseSyntacticallyCorrectExamples', '', Justification = 'Because the rule does not yet support parsing the code when a parameter type is not available. The ScriptAnalyzer rule UseSyntacticallyCorrectExamples will always error in the editor due to https://github.com/indented-automation/Indented.ScriptAnalyzerRules/issues/8.')]
    [OutputType()]
    [CmdletBinding(SupportsShouldProcess = $true, ConfirmImpact = 'High')]
    param
    (
        [Parameter(ParameterSetName = 'ServerObject', Mandatory = $true, ValueFromPipeline = $true)]
        [Microsoft.SqlServer.Management.Smo.Server]
        $ServerObject,

        [Parameter(ParameterSetName = 'AuditObject', Mandatory = $true, ValueFromPipeline = $true)]
        [Microsoft.SqlServer.Management.Smo.Audit]
        $AuditObject,

        [Parameter(ParameterSetName = 'ServerObject', Mandatory = $true)]
        [System.String]
        $Name,

        [Parameter()]
        [System.Management.Automation.SwitchParameter]
        $Force,

        [Parameter(ParameterSetName = 'ServerObject')]
        [System.Management.Automation.SwitchParameter]
        $Refresh
    )

    process
    {
        if ($Force.IsPresent -and -not $Confirm)
        {
            $ConfirmPreference = 'None'
        }

        if ($PSCmdlet.ParameterSetName -eq 'ServerObject')
        {
            $getSqlDscAuditParameters = @{
                ServerObject = $ServerObject
                Name         = $Name
                Refresh      = $Refresh
                ErrorAction  = 'Stop'
            }

            # If this command does not find the audit it will throw an exception.
            $auditObjectArray = Get-SqlDscAudit @getSqlDscAuditParameters

            # Pick the only object in the array.
            $AuditObject = $auditObjectArray | Select-Object -First 1
        }

        $verboseDescriptionMessage = $script:localizedData.Audit_Disable_ShouldProcessVerboseDescription -f $AuditObject.Name, $AuditObject.Parent.InstanceName
        $verboseWarningMessage = $script:localizedData.Audit_Disable_ShouldProcessVerboseWarning -f $AuditObject.Name
        $captionMessage = $script:localizedData.Audit_Disable_ShouldProcessCaption

        if ($PSCmdlet.ShouldProcess($verboseDescriptionMessage, $verboseWarningMessage, $captionMessage))
        {
            $AuditObject.Disable()
        }
    }
}
#EndRegion '.\Public\Disable-SqlDscAudit.ps1' 104
#Region '.\Public\Disable-SqlDscDatabaseSnapshotIsolation.ps1' -1

<#
    .SYNOPSIS
        Disables snapshot isolation for a database in a SQL Server Database Engine instance.

    .DESCRIPTION
        This command disables snapshot isolation for a database in a SQL Server Database Engine
        instance. Disabling snapshot isolation removes row-versioning and snapshot isolation
        settings for the database.

        The command uses the SetSnapshotIsolation() method on the SMO Database object to disable
        row-versioning and snapshot isolation settings.

    .PARAMETER ServerObject
        Specifies current server connection object.

    .PARAMETER Name
        Specifies the name of the database to modify.

    .PARAMETER DatabaseObject
        Specifies the database object to modify (from Get-SqlDscDatabase).

    .PARAMETER Refresh
        Specifies that the **ServerObject**'s databases should be refreshed before
        trying to get the database object. This is helpful when databases could have been
        modified outside of the **ServerObject**, for example through T-SQL. But
        on instances with a large amount of databases it might be better to make
        sure the **ServerObject** is recent enough.

        This parameter is only used when setting snapshot isolation using **ServerObject** and
        **Name** parameters.

    .PARAMETER Force
        Specifies that snapshot isolation should be disabled without any confirmation.

    .PARAMETER PassThru
        Specifies that the database object should be returned after modification.

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine -InstanceName 'MyInstance'
        Disable-SqlDscDatabaseSnapshotIsolation -ServerObject $serverObject -Name 'MyDatabase'

        Disables snapshot isolation for the database named **MyDatabase**.

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine -InstanceName 'MyInstance'
        $databaseObject = $serverObject | Get-SqlDscDatabase -Name 'MyDatabase'
        Disable-SqlDscDatabaseSnapshotIsolation -DatabaseObject $databaseObject -Force

        Disables snapshot isolation for the database using a database object without prompting for confirmation.

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine -InstanceName 'MyInstance'
        Disable-SqlDscDatabaseSnapshotIsolation -ServerObject $serverObject -Name 'MyDatabase' -PassThru

        Disables snapshot isolation and returns the updated database object.

    .INPUTS
        Microsoft.SqlServer.Management.Smo.Database

        The database object to modify (from Get-SqlDscDatabase).

    .OUTPUTS
        None.

        By default, no output is returned.

    .OUTPUTS
        Microsoft.SqlServer.Management.Smo.Database

        When PassThru is specified, the updated database object is returned.
#>
function Disable-SqlDscDatabaseSnapshotIsolation
{
    [System.Diagnostics.CodeAnalysis.SuppressMessageAttribute('UseSyntacticallyCorrectExamples', '', Justification = 'Because the rule does not yet support parsing the code when a parameter type is not available. The ScriptAnalyzer rule UseSyntacticallyCorrectExamples will always error in the editor due to https://github.com/indented-automation/Indented.ScriptAnalyzerRules/issues.')]
    [OutputType()]
    [OutputType([Microsoft.SqlServer.Management.Smo.Database])]
    [CmdletBinding(DefaultParameterSetName = 'ServerObjectSet', SupportsShouldProcess = $true, ConfirmImpact = 'Medium')]
    param
    (
        [Parameter(ParameterSetName = 'ServerObjectSet', Mandatory = $true)]
        [Microsoft.SqlServer.Management.Smo.Server]
        $ServerObject,

        [Parameter(ParameterSetName = 'ServerObjectSet', Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [System.String]
        $Name,

        [Parameter(ParameterSetName = 'ServerObjectSet')]
        [System.Management.Automation.SwitchParameter]
        $Refresh,

        [Parameter(ParameterSetName = 'DatabaseObjectSet', Mandatory = $true, ValueFromPipeline = $true)]
        [Microsoft.SqlServer.Management.Smo.Database]
        $DatabaseObject,

        [Parameter()]
        [System.Management.Automation.SwitchParameter]
        $Force,

        [Parameter()]
        [System.Management.Automation.SwitchParameter]
        $PassThru
    )

    begin
    {
        if ($Force.IsPresent -and -not $Confirm)
        {
            $ConfirmPreference = 'None'
        }
    }

    process
    {
        # Get the database object based on the parameter set
        switch ($PSCmdlet.ParameterSetName)
        {
            'ServerObjectSet'
            {
                $previousErrorActionPreference = $ErrorActionPreference
                $ErrorActionPreference = 'Stop'

                $sqlDatabaseObject = $ServerObject |
                    Get-SqlDscDatabase -Name $Name -Refresh:$Refresh -ErrorAction 'Stop'

                $ErrorActionPreference = $previousErrorActionPreference
            }

            'DatabaseObjectSet'
            {
                $sqlDatabaseObject = $DatabaseObject
            }
        }

        $descriptionMessage = $script:localizedData.DatabaseSnapshotIsolation_Disable_ShouldProcessVerboseDescription -f $sqlDatabaseObject.Name, $sqlDatabaseObject.Parent.InstanceName
        $confirmationMessage = $script:localizedData.DatabaseSnapshotIsolation_Disable_ShouldProcessVerboseWarning -f $sqlDatabaseObject.Name
        $captionMessage = $script:localizedData.DatabaseSnapshotIsolation_Disable_ShouldProcessCaption

        if ($PSCmdlet.ShouldProcess($descriptionMessage, $confirmationMessage, $captionMessage))
        {
            # Check if snapshot isolation is already disabled (idempotence)
            if ($sqlDatabaseObject.SnapshotIsolationState -eq 'Disabled')
            {
                Write-Debug -Message ($script:localizedData.DatabaseSnapshotIsolation_AlreadyDisabled -f $sqlDatabaseObject.Name)
            }
            else
            {
                Write-Debug -Message ($script:localizedData.DatabaseSnapshotIsolation_Disabling -f $sqlDatabaseObject.Name)

                try
                {
                    $sqlDatabaseObject.SetSnapshotIsolation($false)
                }
                catch
                {
                    $errorMessage = $script:localizedData.DatabaseSnapshotIsolation_DisableFailed -f $sqlDatabaseObject.Name

                    $PSCmdlet.ThrowTerminatingError(
                        [System.Management.Automation.ErrorRecord]::new(
                            [System.InvalidOperationException]::new($errorMessage, $_.Exception),
                            'DSDSI0001', # cspell: disable-line
                            [System.Management.Automation.ErrorCategory]::InvalidOperation,
                            $sqlDatabaseObject
                        )
                    )
                }

                Write-Debug -Message ($script:localizedData.DatabaseSnapshotIsolation_Disabled -f $sqlDatabaseObject.Name)
            }

            <#
                Refresh the database object to get the updated SnapshotIsolationState property if:
                - PassThru is specified (user wants the updated object back)
                - Using DatabaseObject parameter set (user's object reference should be updated)

                Refresh even if no change was made to ensure the object is up to date.
            #>
            if ($PassThru.IsPresent -or $PSCmdlet.ParameterSetName -eq 'DatabaseObjectSet')
            {
                $sqlDatabaseObject.Refresh()
            }

            if ($PassThru.IsPresent)
            {
                return $sqlDatabaseObject
            }
        }
    }
}
#EndRegion '.\Public\Disable-SqlDscDatabaseSnapshotIsolation.ps1' 191
#Region '.\Public\Disable-SqlDscLogin.ps1' -1

<#
    .SYNOPSIS
        Disables a SQL Server login.

    .DESCRIPTION
        This command disables a SQL Server login in a SQL Server Database Engine instance.

    .PARAMETER ServerObject
        Specifies current server connection object.

    .PARAMETER LoginObject
        Specifies a login object to disable.

    .PARAMETER Name
        Specifies the name of the server login to be disabled.

    .PARAMETER Force
        Specifies that the login should be disabled without any confirmation.

    .PARAMETER Refresh
        Specifies that the **ServerObject**'s logins should be refreshed before
        trying to disable the login object. This is helpful when logins could have
        been modified outside of the **ServerObject**, for example through T-SQL.
        But on instances with a large amount of logins it might be better to make
        sure the **ServerObject** is recent enough, or pass in **LoginObject**.

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine -InstanceName 'MyInstance'
        $loginObject = $serverObject | Get-SqlDscLogin -Name 'MyLogin'
        $loginObject | Disable-SqlDscLogin

        Disables the login named **MyLogin**.

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine -InstanceName 'MyInstance'
        $serverObject | Disable-SqlDscLogin -Name 'MyLogin'

        Disables the login named **MyLogin**.

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine -InstanceName 'MyInstance'
        $serverObject | Disable-SqlDscLogin -Name 'MyLogin' -Force

        Disables the login without confirmation using **-Force**.

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine -InstanceName 'MyInstance'
        $serverObject | Disable-SqlDscLogin -Name 'MyLogin' -Refresh

        Refreshes the server logins collection before disabling **MyLogin**.
    .INPUTS
        [Microsoft.SqlServer.Management.Smo.Server]

        Server object accepted from the pipeline (ServerObject parameter set).

        [Microsoft.SqlServer.Management.Smo.Login]

        Login object accepted from the pipeline (LoginObject parameter set).

    .OUTPUTS
        None.
#>
function Disable-SqlDscLogin
{
    [System.Diagnostics.CodeAnalysis.SuppressMessageAttribute('UseSyntacticallyCorrectExamples', '', Justification = 'Because the rule does not yet support parsing the code when a parameter type is not available. The ScriptAnalyzer rule UseSyntacticallyCorrectExamples will always error in the editor due to https://github.com/indented-automation/Indented.ScriptAnalyzerRules/issues/8.')]
    [OutputType()]
    [CmdletBinding(SupportsShouldProcess = $true, ConfirmImpact = 'High')]
    param
    (
        [Parameter(ParameterSetName = 'ServerObject', Mandatory = $true, ValueFromPipeline = $true)]
        [Microsoft.SqlServer.Management.Smo.Server]
        $ServerObject,

        [Parameter(ParameterSetName = 'LoginObject', Mandatory = $true, ValueFromPipeline = $true)]
        [Microsoft.SqlServer.Management.Smo.Login]
        $LoginObject,

        [Parameter(ParameterSetName = 'ServerObject', Mandatory = $true)]
        [System.String]
        $Name,

        [Parameter()]
        [System.Management.Automation.SwitchParameter]
        $Force,

        [Parameter(ParameterSetName = 'ServerObject')]
        [System.Management.Automation.SwitchParameter]
        $Refresh
    )

    process
    {
        if ($Force.IsPresent -and -not $Confirm)
        {
            $ConfirmPreference = 'None'
        }

        if ($PSCmdlet.ParameterSetName -eq 'ServerObject')
        {
            $getSqlDscLoginParameters = @{
                ServerObject = $ServerObject
                Name         = $Name
                Refresh      = $Refresh
                ErrorAction  = 'Stop'
            }

            # If this command does not find the login it will throw an exception.
            $LoginObject = Get-SqlDscLogin @getSqlDscLoginParameters
        }

        $verboseDescriptionMessage = $script:localizedData.Login_Disable_ShouldProcessVerboseDescription -f $LoginObject.Name, $LoginObject.Parent.InstanceName
        $verboseWarningMessage = $script:localizedData.Login_Disable_ShouldProcessVerboseWarning -f $LoginObject.Name
        $captionMessage = $script:localizedData.Login_Disable_ShouldProcessCaption

        if ($PSCmdlet.ShouldProcess($verboseDescriptionMessage, $verboseWarningMessage, $captionMessage))
        {
            $LoginObject.Disable()
        }
    }
}
#EndRegion '.\Public\Disable-SqlDscLogin.ps1' 121
#Region '.\Public\Disconnect-SqlDscDatabaseEngine.ps1' -1

<#
    .SYNOPSIS
        Disconnect from a SQL Server Database Engine instance.

    .DESCRIPTION
        Disconnect from a SQL Server Database Engine instance.

    .PARAMETER ServerObject
        Specifies a current server connection object.

    .PARAMETER Force
        Specifies that there is no confirmation before disconnect.

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine
        Disconnect-SqlDscDatabaseEngine -ServerObject $serverObject

        Connects and then disconnects from the default instance on the local server.

    .EXAMPLE
        Connect-SqlDscDatabaseEngine | Disconnect-SqlDscDatabaseEngine

        Connects and then disconnects from the default instance on the local server.

    .OUTPUTS
        None.
#>
function Disconnect-SqlDscDatabaseEngine
{
    [System.Diagnostics.CodeAnalysis.SuppressMessageAttribute('UseSyntacticallyCorrectExamples', '', Justification = 'Because the rule does not yet support parsing the code when a parameter type is not available. The ScriptAnalyzer rule UseSyntacticallyCorrectExamples will always error in the editor due to https://github.com/indented-automation/Indented.ScriptAnalyzerRules/issues/8.')]
    [OutputType([System.Data.DataSet])]
    [CmdletBinding(SupportsShouldProcess = $true, ConfirmImpact = 'Medium')]
    param
    (
        [Parameter(Mandatory = $true, ValueFromPipeline = $true)]
        [Microsoft.SqlServer.Management.Smo.Server]
        $ServerObject,

        [Parameter()]
        [System.Management.Automation.SwitchParameter]
        $Force
    )

    begin
    {
        if ($Force.IsPresent -and -not $Confirm)
        {
            $ConfirmPreference = 'None'
        }
    }

    process
    {
        $verboseDescriptionMessage = $script:localizedData.DatabaseEngine_Disconnect_ShouldProcessVerboseDescription -f $ServerObject.InstanceName
        $verboseWarningMessage = $script:localizedData.DatabaseEngine_Disconnect_ShouldProcessVerboseWarning -f $ServerObject.InstanceName
        $captionMessage = $script:localizedData.DatabaseEngine_Disconnect_ShouldProcessCaption

        if ($PSCmdlet.ShouldProcess($verboseDescriptionMessage, $verboseWarningMessage, $captionMessage))
        {
            $ServerObject.ConnectionContext.Disconnect()
        }
    }
}
#EndRegion '.\Public\Disconnect-SqlDscDatabaseEngine.ps1' 64
#Region '.\Public\Enable-SqlDscAgentOperator.ps1' -1

<#
    .SYNOPSIS
        Enables a SQL Agent Operator.

    .DESCRIPTION
        This command enables a SQL Agent Operator on a SQL Server Database Engine instance.

    .PARAMETER ServerObject
        Specifies current server connection object.

    .PARAMETER OperatorObject
        Specifies a SQL Agent Operator object to enable.

    .PARAMETER Name
        Specifies the name of the SQL Agent Operator to be enabled.

    .PARAMETER Force
        Specifies that the operator should be enabled without any confirmation.

    .PARAMETER Refresh
        Specifies that the **ServerObject**'s operators should be refreshed before
        trying to enable the operator object. This is helpful when operators could have
        been modified outside of the **ServerObject**, for example through T-SQL.
        But on instances with a large amount of operators it might be better to make
        sure the **ServerObject** is recent enough, or pass in **OperatorObject**.

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine -InstanceName 'MyInstance'
        $operatorObject = $serverObject | Get-SqlDscAgentOperator -Name 'MyOperator'
        $operatorObject | Enable-SqlDscAgentOperator

        Enables the operator named **MyOperator**.

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine -InstanceName 'MyInstance'
        $serverObject | Enable-SqlDscAgentOperator -Name 'MyOperator'

        Enables the operator named **MyOperator**.

    .INPUTS
        Microsoft.SqlServer.Management.Smo.Server

        When using the ServerObject parameter set, a Server object can be piped in.

    .INPUTS
        Microsoft.SqlServer.Management.Smo.Agent.Operator

        When using the OperatorObject parameter set, an Operator object can be piped in.

    .OUTPUTS
        None.
#>
function Enable-SqlDscAgentOperator
{
    [System.Diagnostics.CodeAnalysis.SuppressMessageAttribute('UseSyntacticallyCorrectExamples', '', Justification = 'Because the rule does not yet support parsing the code when a parameter type is not available. The ScriptAnalyzer rule UseSyntacticallyCorrectExamples will always error in the editor due to https://github.com/indented-automation/Indented.ScriptAnalyzerRules/issues/8.')]
    [OutputType()]
    [CmdletBinding(SupportsShouldProcess = $true, ConfirmImpact = 'High')]
    param
    (
        [Parameter(ParameterSetName = 'ServerObject', Mandatory = $true, ValueFromPipeline = $true)]
        [Microsoft.SqlServer.Management.Smo.Server]
        $ServerObject,

        [Parameter(ParameterSetName = 'OperatorObject', Mandatory = $true, ValueFromPipeline = $true)]
        [Microsoft.SqlServer.Management.Smo.Agent.Operator]
        $OperatorObject,

        [Parameter(ParameterSetName = 'ServerObject', Mandatory = $true)]
        [System.String]
        $Name,

        [Parameter()]
        [System.Management.Automation.SwitchParameter]
        $Force,

        [Parameter(ParameterSetName = 'ServerObject')]
        [System.Management.Automation.SwitchParameter]
        $Refresh
    )

    process
    {
        if ($Force.IsPresent -and -not $Confirm)
        {
            $ConfirmPreference = 'None'
        }

        if ($PSCmdlet.ParameterSetName -eq 'ServerObject')
        {
            $originalErrorActionPreference = $ErrorActionPreference
            $ErrorActionPreference = 'Stop'
            $OperatorObject = Get-AgentOperatorObject -ServerObject $ServerObject -Name $Name -Refresh:$Refresh -ErrorAction 'Stop'
            $ErrorActionPreference = $originalErrorActionPreference
        }

        $verboseDescriptionMessage = $script:localizedData.Enable_SqlDscAgentOperator_ShouldProcessVerboseDescription -f $OperatorObject.Name, $OperatorObject.Parent.Parent.InstanceName
        $verboseWarningMessage = $script:localizedData.Enable_SqlDscAgentOperator_ShouldProcessVerboseWarning -f $OperatorObject.Name
        $captionMessage = $script:localizedData.Enable_SqlDscAgentOperator_ShouldProcessCaption

        if ($PSCmdlet.ShouldProcess($verboseDescriptionMessage, $verboseWarningMessage, $captionMessage))
        {
            try
            {
                $OperatorObject.Enabled = $true
                $OperatorObject.Alter()
            }
            catch
            {
                $errorMessage = $script:localizedData.Enable_SqlDscAgentOperator_EnableFailed -f $OperatorObject.Name

                $PSCmdlet.ThrowTerminatingError(
                    [System.Management.Automation.ErrorRecord]::new(
                        [System.InvalidOperationException]::new($errorMessage, $_.Exception),
                        'ESAO0001', # cspell: disable-line
                        [System.Management.Automation.ErrorCategory]::InvalidOperation,
                        $OperatorObject
                    )
                )
            }
        }
    }
}
#EndRegion '.\Public\Enable-SqlDscAgentOperator.ps1' 123
#Region '.\Public\Enable-SqlDscAudit.ps1' -1

<#
    .SYNOPSIS
        Enables a server audit.

    .DESCRIPTION
        This command enables a server audit in a SQL Server Database Engine instance.

    .PARAMETER ServerObject
        Specifies current server connection object.

    .PARAMETER AuditObject
        Specifies an audit object to enable.

    .PARAMETER Name
        Specifies the name of the server audit to be enabled.

    .PARAMETER Force
        Specifies that the audit should be enabled without any confirmation.

    .PARAMETER Refresh
        Specifies that the **ServerObject**'s audits should be refreshed before
        trying to enable the audit object. This is helpful when audits could have
        been modified outside of the **ServerObject**, for example through T-SQL.
        But on instances with a large amount of audits it might be better to make
        sure the **ServerObject** is recent enough, or pass in **AuditObject**.

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine -InstanceName 'MyInstance'
        $auditObject = $sqlServerObject | Get-SqlDscAudit -Name 'MyFileAudit'
        $auditObject | Enable-SqlDscAudit

        Enables the audit named **MyFileAudit**.

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine -InstanceName 'MyInstance'
        $sqlServerObject | Enable-SqlDscAudit -Name 'MyFileAudit'

        Enables the audit named **MyFileAudit**.

    .OUTPUTS
        None.
#>
function Enable-SqlDscAudit
{
    [System.Diagnostics.CodeAnalysis.SuppressMessageAttribute('UseSyntacticallyCorrectExamples', '', Justification = 'Because the rule does not yet support parsing the code when a parameter type is not available. The ScriptAnalyzer rule UseSyntacticallyCorrectExamples will always error in the editor due to https://github.com/indented-automation/Indented.ScriptAnalyzerRules/issues/8.')]
    [OutputType()]
    [CmdletBinding(SupportsShouldProcess = $true, ConfirmImpact = 'High')]
    param
    (
        [Parameter(ParameterSetName = 'ServerObject', Mandatory = $true, ValueFromPipeline = $true)]
        [Microsoft.SqlServer.Management.Smo.Server]
        $ServerObject,

        [Parameter(ParameterSetName = 'AuditObject', Mandatory = $true, ValueFromPipeline = $true)]
        [Microsoft.SqlServer.Management.Smo.Audit]
        $AuditObject,

        [Parameter(ParameterSetName = 'ServerObject', Mandatory = $true)]
        [System.String]
        $Name,

        [Parameter()]
        [System.Management.Automation.SwitchParameter]
        $Force,

        [Parameter(ParameterSetName = 'ServerObject')]
        [System.Management.Automation.SwitchParameter]
        $Refresh
    )

    process
    {
        if ($Force.IsPresent -and -not $Confirm)
        {
            $ConfirmPreference = 'None'
        }

        if ($PSCmdlet.ParameterSetName -eq 'ServerObject')
        {
            $getSqlDscAuditParameters = @{
                ServerObject = $ServerObject
                Name         = $Name
                Refresh      = $Refresh
                ErrorAction  = 'Stop'
            }

            # If this command does not find the audit it will throw an exception.
            $auditObjectArray = Get-SqlDscAudit @getSqlDscAuditParameters

            # Pick the only object in the array.
            $AuditObject = $auditObjectArray | Select-Object -First 1
        }

        $verboseDescriptionMessage = $script:localizedData.Audit_Enable_ShouldProcessVerboseDescription -f $AuditObject.Name, $AuditObject.Parent.InstanceName
        $verboseWarningMessage = $script:localizedData.Audit_Enable_ShouldProcessVerboseWarning -f $AuditObject.Name
        $captionMessage = $script:localizedData.Audit_Enable_ShouldProcessCaption

        if ($PSCmdlet.ShouldProcess($verboseDescriptionMessage, $verboseWarningMessage, $captionMessage))
        {
            $AuditObject.Enable()
        }
    }
}
#EndRegion '.\Public\Enable-SqlDscAudit.ps1' 104
#Region '.\Public\Enable-SqlDscDatabaseSnapshotIsolation.ps1' -1

<#
    .SYNOPSIS
        Enables snapshot isolation for a database in a SQL Server Database Engine instance.

    .DESCRIPTION
        This command enables snapshot isolation for a database in a SQL Server Database Engine
        instance. Enabling snapshot isolation may require additional tempdb space and can affect
        transaction behavior.

        The command uses the SetSnapshotIsolation() method on the SMO Database object to enable
        row-versioning and snapshot isolation settings to optimize concurrency and consistency.

    .PARAMETER ServerObject
        Specifies current server connection object.

    .PARAMETER Name
        Specifies the name of the database to modify.

    .PARAMETER DatabaseObject
        Specifies the database object to modify (from Get-SqlDscDatabase).

    .PARAMETER Refresh
        Specifies that the **ServerObject**'s databases should be refreshed before
        trying to get the database object. This is helpful when databases could have been
        modified outside of the **ServerObject**, for example through T-SQL. But
        on instances with a large amount of databases it might be better to make
        sure the **ServerObject** is recent enough.

        This parameter is only used when setting snapshot isolation using **ServerObject** and
        **Name** parameters.

    .PARAMETER Force
        Specifies that snapshot isolation should be enabled without any confirmation.

    .PARAMETER PassThru
        Specifies that the database object should be returned after modification.

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine -InstanceName 'MyInstance'
        Enable-SqlDscDatabaseSnapshotIsolation -ServerObject $serverObject -Name 'MyDatabase'

        Enables snapshot isolation for the database named **MyDatabase**.

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine -InstanceName 'MyInstance'
        $databaseObject = $serverObject | Get-SqlDscDatabase -Name 'MyDatabase'
        Enable-SqlDscDatabaseSnapshotIsolation -DatabaseObject $databaseObject -Force

        Enables snapshot isolation for the database using a database object without prompting for confirmation.

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine -InstanceName 'MyInstance'
        Enable-SqlDscDatabaseSnapshotIsolation -ServerObject $serverObject -Name 'MyDatabase' -PassThru

        Enables snapshot isolation and returns the updated database object.

    .INPUTS
        Microsoft.SqlServer.Management.Smo.Database

        The database object to modify (from Get-SqlDscDatabase).

    .OUTPUTS
        None.

        By default, no output is returned.

    .OUTPUTS
        Microsoft.SqlServer.Management.Smo.Database

        When PassThru is specified, the updated database object is returned.
#>
function Enable-SqlDscDatabaseSnapshotIsolation
{
    [System.Diagnostics.CodeAnalysis.SuppressMessageAttribute('UseSyntacticallyCorrectExamples', '', Justification = 'Because the rule does not yet support parsing the code when a parameter type is not available. The ScriptAnalyzer rule UseSyntacticallyCorrectExamples will always error in the editor due to https://github.com/indented-automation/Indented.ScriptAnalyzerRules/issues.')]
    [OutputType()]
    [OutputType([Microsoft.SqlServer.Management.Smo.Database])]
    [CmdletBinding(DefaultParameterSetName = 'ServerObjectSet', SupportsShouldProcess = $true, ConfirmImpact = 'Medium')]
    param
    (
        [Parameter(ParameterSetName = 'ServerObjectSet', Mandatory = $true)]
        [Microsoft.SqlServer.Management.Smo.Server]
        $ServerObject,

        [Parameter(ParameterSetName = 'ServerObjectSet', Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [System.String]
        $Name,

        [Parameter(ParameterSetName = 'ServerObjectSet')]
        [System.Management.Automation.SwitchParameter]
        $Refresh,

        [Parameter(ParameterSetName = 'DatabaseObjectSet', Mandatory = $true, ValueFromPipeline = $true)]
        [Microsoft.SqlServer.Management.Smo.Database]
        $DatabaseObject,

        [Parameter()]
        [System.Management.Automation.SwitchParameter]
        $Force,

        [Parameter()]
        [System.Management.Automation.SwitchParameter]
        $PassThru
    )

    begin
    {
        if ($Force.IsPresent -and -not $Confirm)
        {
            $ConfirmPreference = 'None'
        }
    }

    process
    {
        # Get the database object based on the parameter set
        switch ($PSCmdlet.ParameterSetName)
        {
            'ServerObjectSet'
            {
                $previousErrorActionPreference = $ErrorActionPreference
                $ErrorActionPreference = 'Stop'

                $sqlDatabaseObject = $ServerObject |
                    Get-SqlDscDatabase -Name $Name -Refresh:$Refresh -ErrorAction 'Stop'

                $ErrorActionPreference = $previousErrorActionPreference
            }

            'DatabaseObjectSet'
            {
                $sqlDatabaseObject = $DatabaseObject
            }
        }

        $descriptionMessage = $script:localizedData.DatabaseSnapshotIsolation_Enable_ShouldProcessVerboseDescription -f $sqlDatabaseObject.Name, $sqlDatabaseObject.Parent.InstanceName
        $confirmationMessage = $script:localizedData.DatabaseSnapshotIsolation_Enable_ShouldProcessVerboseWarning -f $sqlDatabaseObject.Name
        $captionMessage = $script:localizedData.DatabaseSnapshotIsolation_Enable_ShouldProcessCaption

        if ($PSCmdlet.ShouldProcess($descriptionMessage, $confirmationMessage, $captionMessage))
        {
            # Check if snapshot isolation is already enabled (idempotence)
            if ($sqlDatabaseObject.SnapshotIsolationState -eq 'Enabled')
            {
                Write-Debug -Message ($script:localizedData.DatabaseSnapshotIsolation_AlreadyEnabled -f $sqlDatabaseObject.Name)
            }
            else
            {
                Write-Debug -Message ($script:localizedData.DatabaseSnapshotIsolation_Enabling -f $sqlDatabaseObject.Name)

                try
                {
                    $sqlDatabaseObject.SetSnapshotIsolation($true)
                }
                catch
                {
                    $errorMessage = $script:localizedData.DatabaseSnapshotIsolation_EnableFailed -f $sqlDatabaseObject.Name

                    $PSCmdlet.ThrowTerminatingError(
                        [System.Management.Automation.ErrorRecord]::new(
                            [System.InvalidOperationException]::new($errorMessage, $_.Exception),
                            'ESDSI0001', # cspell: disable-line
                            [System.Management.Automation.ErrorCategory]::InvalidOperation,
                            $sqlDatabaseObject
                        )
                    )
                }

                Write-Debug -Message ($script:localizedData.DatabaseSnapshotIsolation_Enabled -f $sqlDatabaseObject.Name)
            }

            <#
                Refresh the database object to get the updated SnapshotIsolationState property if:
                - PassThru is specified (user wants the updated object back)
                - Using DatabaseObject parameter set (user's object reference should be updated)

                Refresh even if no change was made to ensure the object is up to date.
            #>
            if ($PassThru.IsPresent -or $PSCmdlet.ParameterSetName -eq 'DatabaseObjectSet')
            {
                $sqlDatabaseObject.Refresh()
            }

            if ($PassThru.IsPresent)
            {
                return $sqlDatabaseObject
            }
        }
    }
}
#EndRegion '.\Public\Enable-SqlDscDatabaseSnapshotIsolation.ps1' 191
#Region '.\Public\Enable-SqlDscLogin.ps1' -1

<#
    .SYNOPSIS
        Enables a SQL Server login.

    .DESCRIPTION
        This command enables a SQL Server login in a SQL Server Database Engine instance.

    .PARAMETER ServerObject
        Specifies current server connection object.

    .PARAMETER LoginObject
        Specifies a login object to enable.

    .PARAMETER Name
        Specifies the name of the server login to be enabled.

    .PARAMETER Force
        Specifies that the login should be enabled without any confirmation.

    .PARAMETER Refresh
        Specifies that the **ServerObject**'s logins should be refreshed before
        trying to enable the login object. This is helpful when logins could have
        been modified outside of the **ServerObject**, for example through T-SQL.
        But on instances with a large amount of logins it might be better to make
        sure the **ServerObject** is recent enough, or pass in **LoginObject**.

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine -InstanceName 'MyInstance'
        $loginObject = $serverObject | Get-SqlDscLogin -Name 'MyLogin'
        $loginObject | Enable-SqlDscLogin

        Enables the login named **MyLogin**.

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine -InstanceName 'MyInstance'
        $serverObject | Enable-SqlDscLogin -Name 'MyLogin'

        Enables the login named **MyLogin**.

    .INPUTS
        Microsoft.SqlServer.Management.Smo.Server
            When using the ServerObject parameter set, a Server object can be piped in.

        Microsoft.SqlServer.Management.Smo.Login
            When using the LoginObject parameter set, a Login object can be piped in.

    .OUTPUTS
        None.
#>
function Enable-SqlDscLogin
{
    [System.Diagnostics.CodeAnalysis.SuppressMessageAttribute('UseSyntacticallyCorrectExamples', '', Justification = 'Because the rule does not yet support parsing the code when a parameter type is not available. The ScriptAnalyzer rule UseSyntacticallyCorrectExamples will always error in the editor due to https://github.com/indented-automation/Indented.ScriptAnalyzerRules/issues/8.')]
    [OutputType()]
    [CmdletBinding(SupportsShouldProcess = $true, ConfirmImpact = 'High')]
    param
    (
        [Parameter(ParameterSetName = 'ServerObject', Mandatory = $true, ValueFromPipeline = $true)]
        [Microsoft.SqlServer.Management.Smo.Server]
        $ServerObject,

        [Parameter(ParameterSetName = 'LoginObject', Mandatory = $true, ValueFromPipeline = $true)]
        [Microsoft.SqlServer.Management.Smo.Login]
        $LoginObject,

        [Parameter(ParameterSetName = 'ServerObject', Mandatory = $true)]
        [System.String]
        $Name,

        [Parameter()]
        [System.Management.Automation.SwitchParameter]
        $Force,

        [Parameter(ParameterSetName = 'ServerObject')]
        [System.Management.Automation.SwitchParameter]
        $Refresh
    )

    process
    {
        if ($Force.IsPresent -and -not $Confirm)
        {
            $ConfirmPreference = 'None'
        }

        if ($PSCmdlet.ParameterSetName -eq 'ServerObject')
        {
            $getSqlDscLoginParameters = @{
                ServerObject = $ServerObject
                Name         = $Name
                Refresh      = $Refresh
                ErrorAction  = 'Stop'
            }

            # If this command does not find the login it will throw an exception.
            $LoginObject = Get-SqlDscLogin @getSqlDscLoginParameters
        }

        $verboseDescriptionMessage = $script:localizedData.Login_Enable_ShouldProcessVerboseDescription -f $LoginObject.Name, $LoginObject.Parent.InstanceName
        $verboseWarningMessage = $script:localizedData.Login_Enable_ShouldProcessVerboseWarning -f $LoginObject.Name
        $captionMessage = $script:localizedData.Login_Enable_ShouldProcessCaption

        if ($PSCmdlet.ShouldProcess($verboseDescriptionMessage, $verboseWarningMessage, $captionMessage))
        {
            $LoginObject.Enable()
        }
    }
}
#EndRegion '.\Public\Enable-SqlDscLogin.ps1' 108
#Region '.\Public\Get-SqlDscAgentAlert.ps1' -1

<#
    .SYNOPSIS
        Returns SQL Agent Alert information.

    .DESCRIPTION
        Returns SQL Agent Alert information from a SQL Server Database Engine instance.

    .PARAMETER ServerObject
        Specifies current server connection object.

    .PARAMETER Name
        Specifies the name of the SQL Agent Alert to retrieve. If not specified,
        all alerts are returned.

    .INPUTS
        Microsoft.SqlServer.Management.Smo.Server

        SQL Server Database Engine instance object.

    .OUTPUTS
        Microsoft.SqlServer.Management.Smo.Agent.Alert

        When using the ByName parameter set, returns a single SQL Agent Alert object.

    .OUTPUTS
        Microsoft.SqlServer.Management.Smo.Agent.Alert[]

        When using the All parameter set, returns an array of SQL Agent Alert objects.

    .OUTPUTS
        None
        Returns nothing when no alerts are found for the specified criteria.
    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine
        Get-SqlDscAgentAlert -ServerObject $serverObject

        Returns all SQL Agent Alerts from the server.

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine
        Get-SqlDscAgentAlert -ServerObject $serverObject -Name 'MyAlert'

        Returns the SQL Agent Alert named 'MyAlert'.

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine
        $serverObject | Get-SqlDscAgentAlert -Name 'MyAlert'

        Returns the SQL Agent Alert named 'MyAlert' using pipeline input.
#>
function Get-SqlDscAgentAlert
{
    [System.Diagnostics.CodeAnalysis.SuppressMessageAttribute('UseSyntacticallyCorrectExamples', '', Justification = 'Because the rule does not yet support parsing the code when a parameter type is not available. The ScriptAnalyzer rule UseSyntacticallyCorrectExamples will always error in the editor due to https://github.com/indented-automation/Indented.ScriptAnalyzerRules/issues/8.')]
    [CmdletBinding(DefaultParameterSetName = 'All')]
    [OutputType([Microsoft.SqlServer.Management.Smo.Agent.Alert], ParameterSetName = 'ByName')]
    [OutputType([Microsoft.SqlServer.Management.Smo.Agent.Alert[]], ParameterSetName = 'All')]
    param
    (
        [Parameter(Mandatory = $true, ValueFromPipeline = $true, ParameterSetName = 'ByName')]
        [Parameter(Mandatory = $true, ValueFromPipeline = $true, ParameterSetName = 'All')]
        [Microsoft.SqlServer.Management.Smo.Server]
        $ServerObject,

        [Parameter(Mandatory = $true, ParameterSetName = 'ByName')]
        [ValidateNotNullOrEmpty()]
        [System.String]
        $Name
    )

    # cSpell: ignore GSAA
    process
    {
        switch ($PSCmdlet.ParameterSetName)
        {
            'ByName'
            {
                return Get-AgentAlertObject -ServerObject $ServerObject -Name $Name
            }

            'All'
            {
                Write-Verbose -Message ($script:localizedData.Get_SqlDscAgentAlert_GettingAlerts -f $ServerObject.InstanceName)

                $alertCollection = $ServerObject.JobServer.Alerts

                Write-Verbose -Message ($script:localizedData.Get_SqlDscAgentAlert_ReturningAllAlerts -f $alertCollection.Count)

                return [Microsoft.SqlServer.Management.Smo.Agent.Alert[]] $alertCollection
            }
        }
    }
}
#EndRegion '.\Public\Get-SqlDscAgentAlert.ps1' 93
#Region '.\Public\Get-SqlDscAgentOperator.ps1' -1

<#
    .SYNOPSIS
        Returns SQL Agent Operator information.

    .DESCRIPTION
        Returns SQL Agent Operator information from a SQL Server Database Engine instance.

    .PARAMETER ServerObject
        Specifies current server connection object.

    .PARAMETER Name
        Specifies the name of the SQL Agent Operator to retrieve. If not specified,
        all operators are returned.

    .INPUTS
        Microsoft.SqlServer.Management.Smo.Server

        SQL Server Database Engine instance object.

    .OUTPUTS
        Microsoft.SqlServer.Management.Smo.Agent.Operator

        When using the ByName parameter set, returns a single SQL Agent Operator object.

    .OUTPUTS
        Microsoft.SqlServer.Management.Smo.Agent.Operator[]

        When using the All parameter set, returns an array of SQL Agent Operator objects.

    .OUTPUTS
        None
        Returns nothing when no operators are found for the specified criteria.
    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine
        Get-SqlDscAgentOperator -ServerObject $serverObject

        Returns all SQL Agent Operators from the server.

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine
        Get-SqlDscAgentOperator -ServerObject $serverObject -Name 'MyOperator'

        Returns the SQL Agent Operator named 'MyOperator'.

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine
        $serverObject | Get-SqlDscAgentOperator -Name 'MyOperator'

        Returns the SQL Agent Operator named 'MyOperator' using pipeline input.
#>
function Get-SqlDscAgentOperator
{
    [System.Diagnostics.CodeAnalysis.SuppressMessageAttribute('UseSyntacticallyCorrectExamples', '', Justification = 'Because the rule does not yet support parsing the code when a parameter type is not available. The ScriptAnalyzer rule UseSyntacticallyCorrectExamples will always error in the editor due to https://github.com/indented-automation/Indented.ScriptAnalyzerRules/issues/8.')]
    [CmdletBinding(DefaultParameterSetName = 'All')]
    [OutputType([Microsoft.SqlServer.Management.Smo.Agent.Operator], ParameterSetName = 'ByName')]
    [OutputType([Microsoft.SqlServer.Management.Smo.Agent.Operator[]], ParameterSetName = 'All')]
    param
    (
        [Parameter(Mandatory = $true, ValueFromPipeline = $true, ParameterSetName = 'ByName')]
        [Parameter(Mandatory = $true, ValueFromPipeline = $true, ParameterSetName = 'All')]
        [Microsoft.SqlServer.Management.Smo.Server]
        $ServerObject,

        [Parameter(Mandatory = $true, ParameterSetName = 'ByName')]
        [ValidateNotNullOrEmpty()]
        [System.String]
        $Name
    )

    # cSpell: ignore GSAO
    process
    {
        switch ($PSCmdlet.ParameterSetName)
        {
            'ByName'
            {
                Write-Verbose -Message ($script:localizedData.Get_SqlDscAgentOperator_GettingOperator -f $Name)

                $operatorObject = Get-AgentOperatorObject -ServerObject $ServerObject -Name $Name -ErrorAction 'SilentlyContinue'

                return $operatorObject
            }

            'All'
            {
                Write-Verbose -Message ($script:localizedData.Get_SqlDscAgentOperator_GettingOperators -f $ServerObject.InstanceName)

                $operatorCollection = $ServerObject.JobServer.Operators

                Write-Verbose -Message ($script:localizedData.Get_SqlDscAgentOperator_ReturningAllOperators -f $operatorCollection.Count)

                return [Microsoft.SqlServer.Management.Smo.Agent.Operator[]] $operatorCollection
            }
        }
    }
}
#EndRegion '.\Public\Get-SqlDscAgentOperator.ps1' 97
#Region '.\Public\Get-SqlDscAudit.ps1' -1

<#
    .SYNOPSIS
        Get server audit.

    .DESCRIPTION
        This command gets a server audit from a SQL Server Database Engine instance.

    .PARAMETER ServerObject
        Specifies current server connection object.

    .PARAMETER Name
        Specifies the name of the server audit to get.

    .PARAMETER Refresh
        Specifies that the **ServerObject**'s audits should be refreshed before
        trying get the audit object. This is helpful when audits could have been
        modified outside of the **ServerObject**, for example through T-SQL. But
        on instances with a large amount of audits it might be better to make
        sure the **ServerObject** is recent enough, or pass in **AuditObject**.

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine -InstanceName 'MyInstance'
        $sqlServerObject | Get-SqlDscAudit -Name 'MyFileAudit'

        Get the audit named **MyFileAudit**.

    .OUTPUTS
        `[Microsoft.SqlServer.Management.Smo.Audit[]]`
        Array of SMO Audit objects from the target SQL Server instance.
#>
function Get-SqlDscAudit
{
    [System.Diagnostics.CodeAnalysis.SuppressMessageAttribute('UseSyntacticallyCorrectExamples', '', Justification = 'Because the rule does not yet support parsing the code when a parameter type is not available. The ScriptAnalyzer rule UseSyntacticallyCorrectExamples will always error in the editor due to https://github.com/indented-automation/Indented.ScriptAnalyzerRules/issues/8.')]
    [OutputType([Microsoft.SqlServer.Management.Smo.Audit[]])]
    [CmdletBinding()]
    param
    (
        [Parameter(Mandatory = $true, ValueFromPipeline = $true)]
        [Microsoft.SqlServer.Management.Smo.Server]
        $ServerObject,

        [Parameter()]
        [System.String]
        $Name,

        [Parameter()]
        [System.Management.Automation.SwitchParameter]
        $Refresh
    )

    process
    {
        if ($Refresh.IsPresent)
        {
            # Make sure the audits are up-to-date to get any newly created audits.
            $ServerObject.Audits.Refresh()
        }

        $auditObject = @()

        if ($PSBoundParameters.ContainsKey('Name'))
        {
            $auditObject = $ServerObject.Audits[$Name]

            if (-not $auditObject)
            {
                $missingAuditMessage = $script:localizedData.Audit_Missing -f $Name

                $writeErrorParameters = @{
                    Message      = $missingAuditMessage
                    Category     = 'InvalidOperation'
                    ErrorId      = 'GSDA0001' # cspell: disable-line
                    TargetObject = $Name
                }

                Write-Error @writeErrorParameters
            }
        }
        else
        {
            $auditObject = $ServerObject.Audits
        }

        return [Microsoft.SqlServer.Management.Smo.Audit[]] $auditObject
    }
}
#EndRegion '.\Public\Get-SqlDscAudit.ps1' 87
#Region '.\Public\Get-SqlDscCompatibilityLevel.ps1' -1

<#
    .SYNOPSIS
        Gets the supported database compatibility levels for a SQL Server instance or version.

    .DESCRIPTION
        This command returns the supported database compatibility levels for a SQL Server
        Database Engine instance or a specific SQL Server version.

        The compatibility levels are determined based on the SQL Server version, following
        the official Microsoft documentation for supported compatibility level ranges.

    .PARAMETER ServerObject
        Specifies the SQL Server connection object to get supported compatibility levels for.

    .PARAMETER Version
        Specifies the SQL Server version to get supported compatibility levels for.
        Only the major version number is used for determining compatibility levels.

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine -InstanceName 'MyInstance'
        Get-SqlDscCompatibilityLevel -ServerObject $serverObject

        Returns all supported compatibility levels for the connected SQL Server instance.

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine -InstanceName 'MyInstance'
        $serverObject | Get-SqlDscCompatibilityLevel

        Returns all supported compatibility levels using pipeline input.

    .EXAMPLE
        Get-SqlDscCompatibilityLevel -Version '16.0.1000.6'

        Returns all supported compatibility levels for SQL Server 2022 (version 16).

    .INPUTS
        Microsoft.SqlServer.Management.Smo.Server

        The server object to get supported compatibility levels for.

    .OUTPUTS
        System.String[]

        Returns an array of supported compatibility level names (e.g., 'Version160', 'Version150').
#>
function Get-SqlDscCompatibilityLevel
{
    [System.Diagnostics.CodeAnalysis.SuppressMessageAttribute('UseSyntacticallyCorrectExamples', '', Justification = 'Because the rule does not yet support parsing the code when a parameter type is not available. The ScriptAnalyzer rule UseSyntacticallyCorrectExamples will always error in the editor due to https://github.com/indented-automation/Indented.ScriptAnalyzerRules/issues/8.')]
    [CmdletBinding(DefaultParameterSetName = 'ServerObject')]
    [OutputType([System.String[]])]
    param
    (
        [Parameter(ParameterSetName = 'ServerObject', Mandatory = $true, ValueFromPipeline = $true)]
        [Microsoft.SqlServer.Management.Smo.Server]
        $ServerObject,

        [Parameter(ParameterSetName = 'Version', Mandatory = $true)]
        [System.Version]
        $Version
    )

    process
    {
        # Get the major version based on parameter set
        $majorVersion = if ($PSCmdlet.ParameterSetName -eq 'ServerObject')
        {
            Write-Verbose -Message ($script:localizedData.GetCompatibilityLevel_GettingForInstance -f $ServerObject.InstanceName, $ServerObject.VersionMajor)
            $ServerObject.VersionMajor
        }
        else
        {
            Write-Verbose -Message ($script:localizedData.GetCompatibilityLevel_GettingForVersion -f $Version, $Version.Major)
            $Version.Major
        }

        # Get all available compatibility levels from the enum
        $allCompatibilityLevels = [System.Enum]::GetNames([Microsoft.SqlServer.Management.Smo.CompatibilityLevel])

        <#
            Determine minimum supported compatibility level based on SQL Server version
            Reference: https://learn.microsoft.com/en-us/sql/t-sql/statements/alter-database-transact-sql-compatibility-level
        #>
        $minimumCompatLevel = switch ($majorVersion)
        {
            { $_ -ge 12 }
            {
                100 # SQL 2014 (v12) and later support minimum compat level 100
            }

            11
            {
                90 # SQL 2012 (v11) supports minimum compat level 90
            }

            { $_ -le 10 }
            {
                80 # SQL 2008 R2 (v10.5) and earlier support minimum compat level 80
            }
        }

        <#
            Filter compatibility levels that are supported by this SQL Server version
            CompatibilityLevel enum values are named like "Version80", "Version90", etc.
            SQL Server supports compatibility levels from the minimum up to (version * 10)
        #>
        $supportedCompatibilityLevels = $allCompatibilityLevels | Where-Object -FilterScript {
            if ($_ -match 'Version(\d+)')
            {
                $compatLevelVersion = [System.Int32] $Matches[1]
                ($compatLevelVersion -ge $minimumCompatLevel) -and ($compatLevelVersion -le ($majorVersion * 10))
            }
            else
            {
                $false
            }
        }

        <#
            Warn if SQL Server version is newer than what SMO library supports
            Check if the expected maximum compatibility level is missing from the supported list
        #>
        $expectedMaxCompatLevel = "Version$($majorVersion * 10)"
        if ($expectedMaxCompatLevel -notin $supportedCompatibilityLevels -and $supportedCompatibilityLevels.Count -gt 0)
        {
            # Get the actual maximum from the last element (they're in ascending order)
            $lastCompatLevel = $supportedCompatibilityLevels[-1]
            if ($lastCompatLevel -match 'Version(\d+)')
            {
                $maxCompatLevelInEnum = [System.Int32] $Matches[1]
                Write-Warning -Message ($script:localizedData.GetCompatibilityLevel_SmoTooOld -f $majorVersion, $maxCompatLevelInEnum, ($majorVersion * 10))
            }
        }

        Write-Debug -Message ($script:localizedData.GetCompatibilityLevel_Found -f $supportedCompatibilityLevels.Count, $majorVersion)

        return $supportedCompatibilityLevels
    }
}
#EndRegion '.\Public\Get-SqlDscCompatibilityLevel.ps1' 139
#Region '.\Public\Get-SqlDscConfigurationOption.ps1' -1

<#
    .SYNOPSIS
        Get server configuration option metadata or raw SMO objects.

    .DESCRIPTION
        This command gets configuration options from a SQL Server Database Engine instance.
        By default, it returns user-friendly metadata objects with current values, ranges,
        and dynamic properties. Use the -Raw switch to get the original SMO ConfigProperty objects.

    .PARAMETER ServerObject
        Specifies current server connection object.

    .PARAMETER Name
        Specifies the name of the configuration option to get. Supports wildcards.
        If not specified, all configuration options are returned.

    .PARAMETER Raw
        Specifies that the original SMO ConfigProperty objects should be returned
        instead of the enhanced metadata objects.

    .PARAMETER Refresh
        Specifies that the **ServerObject**'s configuration property should be
        refreshed before trying get the available configuration options. This is
        helpful when run values or configuration values have been modified outside
        of the specified **ServerObject**.

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine -InstanceName 'MyInstance'
        $serverObject | Get-SqlDscConfigurationOption

        Get metadata for all available configuration options.

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine -InstanceName 'MyInstance'
        $serverObject | Get-SqlDscConfigurationOption -Name '*threshold*'

        Get metadata for configuration options that contain the word "threshold".

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine -InstanceName 'MyInstance'
        $serverObject | Get-SqlDscConfigurationOption -Name "Agent XPs"

        Get metadata for the specific "Agent XPs" configuration option.

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine -InstanceName 'MyInstance'
        $serverObject | Get-SqlDscConfigurationOption -Raw

        Get all configuration options as raw SMO ConfigProperty objects.

    .INPUTS
        Microsoft.SqlServer.Management.Smo.Server
        SQL Server Management Objects (SMO) Server object representing a SQL Server instance.

    .OUTPUTS
        PSCustomObject[]
        Returns user-friendly metadata objects with configuration option details (default behavior).

        Microsoft.SqlServer.Management.Smo.ConfigProperty[]
        Returns raw SMO ConfigProperty objects when using the -Raw parameter.
#>
function Get-SqlDscConfigurationOption
{
    [System.Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSReviewUnusedParameter', '', Justification = 'Because we pass parameters in the argument completer that are not yet used.')]
    [System.Diagnostics.CodeAnalysis.SuppressMessageAttribute('UseSyntacticallyCorrectExamples', '', Justification = 'Because the rule does not yet support parsing the code when a parameter type is not available. The ScriptAnalyzer rule UseSyntacticallyCorrectExamples will always error in the editor due to https://github.com/indented-automation/Indented.ScriptAnalyzerRules/issues/8.')]
    [OutputType([PSCustomObject[]], ParameterSetName = 'Metadata')]
    [OutputType([Microsoft.SqlServer.Management.Smo.ConfigProperty[]], ParameterSetName = 'Raw')]
    [CmdletBinding(DefaultParameterSetName = 'Metadata')]
    param
    (
        [Parameter(Mandatory = $true, ValueFromPipeline = $true)]
        [Microsoft.SqlServer.Management.Smo.Server]
        $ServerObject,

        [Parameter()]
        [ArgumentCompleter({
                param
                (
                    [Parameter()]
                    $commandName,

                    [Parameter()]
                    $parameterName,

                    [Parameter()]
                    $wordToComplete,

                    [Parameter()]
                    $commandAst,

                    [Parameter()]
                    $fakeBoundParameters
                )

                # Get ServerObject from bound parameters only
                $serverObject = $null

                if ($FakeBoundParameters.ContainsKey('ServerObject'))
                {
                    $serverObject = $FakeBoundParameters['ServerObject']
                }

                if ($serverObject -and $serverObject -is [Microsoft.SqlServer.Management.Smo.Server])
                {
                    try
                    {
                        $options = $serverObject.Configuration.Properties | Where-Object {
                            $_.DisplayName -like "*$WordToComplete*"
                        } | Sort-Object DisplayName

                        foreach ($option in $options)
                        {
                            $tooltip = "Current: $($option.ConfigValue), Run: $($option.RunValue), Range: $($option.Minimum)-$($option.Maximum)"
                            [System.Management.Automation.CompletionResult]::new(
                                "'$($option.DisplayName)'",
                                $option.DisplayName,
                                'ParameterValue',
                                $tooltip
                            )
                        }
                    }
                    catch
                    {
                        # Return empty if there's an error accessing the server
                        @()
                    }
                }
                else
                {
                    # Return empty array if no server object available
                    @()
                }
            })]
        [System.String]
        $Name,

        [Parameter(ParameterSetName = 'Raw')]
        [System.Management.Automation.SwitchParameter]
        $Raw,

        [Parameter()]
        [System.Management.Automation.SwitchParameter]
        $Refresh
    )

    process
    {
        if ($Refresh.IsPresent)
        {
            # Make sure the configuration option values are up-to-date.
            $ServerObject.Configuration.Refresh()
        }

        if ($PSBoundParameters.ContainsKey('Name'))
        {
            $configurationOptions = $ServerObject.Configuration.Properties |
                Where-Object -FilterScript {
                    $_.DisplayName -like $Name
                }

            if (-not $configurationOptions)
            {
                $missingConfigurationOptionMessage = $script:localizedData.ConfigurationOption_Get_Missing -f $Name

                $writeErrorParameters = @{
                    Message      = $missingConfigurationOptionMessage
                    Category     = 'InvalidOperation'
                    ErrorId      = 'GSDCO0001' # cspell: disable-line
                    TargetObject = $Name
                }

                Write-Error @writeErrorParameters
                return
            }
        }
        else
        {
            $configurationOptions = $ServerObject.Configuration.Properties.ForEach({ $_ })
        }

        # Sort the options by DisplayName
        $sortedOptions = $configurationOptions | Sort-Object -Property 'DisplayName'

        if ($Raw.IsPresent)
        {
            # Return raw SMO ConfigProperty objects
            return [Microsoft.SqlServer.Management.Smo.ConfigProperty[]] $sortedOptions
        }
        else
        {
            # Return enhanced metadata objects
            $metadataObjects = foreach ($option in $sortedOptions)
            {
                $metadata = [PSCustomObject]@{
                    Name        = $option.DisplayName
                    RunValue    = $option.RunValue
                    ConfigValue = $option.ConfigValue
                    Minimum     = $option.Minimum
                    Maximum     = $option.Maximum
                    IsDynamic   = $option.IsDynamic
                }

                # Add custom type name for formatting
                $metadata.PSTypeNames.Insert(0, 'SqlDsc.ConfigurationOption')
                $metadata
            }

            return $metadataObjects
        }
    }
}
#EndRegion '.\Public\Get-SqlDscConfigurationOption.ps1' 212
#Region '.\Public\Get-SqlDscDatabase.ps1' -1

<#
    .SYNOPSIS
        Get databases from a SQL Server Database Engine instance.

    .DESCRIPTION
        This command gets one or more databases from a SQL Server Database Engine instance.
        If no name is specified, all databases are returned.

    .PARAMETER ServerObject
        Specifies current server connection object.

    .PARAMETER Name
        Specifies the name of the database to get. If not specified, all
        databases are returned.

    .PARAMETER Refresh
        Specifies that the **ServerObject**'s databases should be refreshed before
        trying to get the database object. This is helpful when databases could have been
        modified outside of the **ServerObject**, for example through T-SQL. But
        on instances with a large amount of databases it might be better to make
        sure the **ServerObject** is recent enough.

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine -InstanceName 'MyInstance'
        $serverObject | Get-SqlDscDatabase

        Get all databases from the instance.

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine -InstanceName 'MyInstance'
        $serverObject | Get-SqlDscDatabase -Name 'MyDatabase'

        Get the database named **MyDatabase**.

    .OUTPUTS
        `[Microsoft.SqlServer.Management.Smo.Database[]]`
#>
function Get-SqlDscDatabase
{
    [System.Diagnostics.CodeAnalysis.SuppressMessageAttribute('UseSyntacticallyCorrectExamples', '', Justification = 'Because the rule does not yet support parsing the code when a parameter type is not available. The ScriptAnalyzer rule UseSyntacticallyCorrectExamples will always error in the editor due to https://github.com/indented-automation/Indented.ScriptAnalyzerRules/issues/8.')]
    [OutputType([Microsoft.SqlServer.Management.Smo.Database[]])]
    [CmdletBinding()]
    param
    (
        [Parameter(Mandatory = $true, ValueFromPipeline = $true)]
        [Microsoft.SqlServer.Management.Smo.Server]
        $ServerObject,

        [Parameter()]
        [System.String]
        $Name,

        [Parameter()]
        [System.Management.Automation.SwitchParameter]
        $Refresh
    )

    process
    {
        if ($Refresh.IsPresent)
        {
            # Refresh the server object's databases collection
            $ServerObject.Databases.Refresh()
        }

        Write-Verbose -Message ($script:localizedData.Database_Get -f $ServerObject.InstanceName)

        $databaseObject = @()

        if ($PSBoundParameters.ContainsKey('Name'))
        {
            $databaseObject = $ServerObject.Databases[$Name]

            if (-not $databaseObject)
            {
                Write-Verbose -Message ($script:localizedData.Database_NotFound -f $Name)

                $missingDatabaseMessage = $script:localizedData.Database_NotFound -f $Name

                $writeErrorParameters = @{
                    Message      = $missingDatabaseMessage
                    Category     = 'ObjectNotFound'
                    ErrorId      = 'GSDD0001' # cspell: disable-line
                    TargetObject = $Name
                }

                Write-Error @writeErrorParameters
            }
            else
            {
                if ($Refresh.IsPresent)
                {
                    # Refresh the database object
                    $databaseObject.Refresh()
                }

                Write-Verbose -Message ($script:localizedData.Database_Found -f $Name)
            }
        }
        else
        {
            Write-Verbose -Message ($script:localizedData.Database_GetAll)

            $databaseObject = $ServerObject.Databases
        }

        return [Microsoft.SqlServer.Management.Smo.Database[]] $databaseObject
    }
}
#EndRegion '.\Public\Get-SqlDscDatabase.ps1' 110
#Region '.\Public\Get-SqlDscDatabasePermission.ps1' -1

<#
    .SYNOPSIS
        Returns the current permissions for the database principal.

    .DESCRIPTION
        Returns the current permissions for the database principal.

    .PARAMETER ServerObject
        Specifies current server connection object.

    .PARAMETER DatabaseName
        Specifies the database name.

    .PARAMETER Name
        Specifies the name of the database principal for which the permissions are
        returned.

    .PARAMETER Refresh
        Specifies that the database's principal collections (Users, Roles, and
        ApplicationRoles) should be refreshed before testing if the principal exists.
        This is helpful when principals could have been modified outside of the
        **ServerObject**, for example through T-SQL. But on databases with a large
        amount of principals it might be better to make sure the **ServerObject**
        is recent enough.

    .OUTPUTS
        [Microsoft.SqlServer.Management.Smo.DatabasePermissionInfo[]]

    .EXAMPLE
        $serverInstance = Connect-SqlDscDatabaseEngine
        Get-SqlDscDatabasePermission -ServerObject $serverInstance -DatabaseName 'MyDatabase' -Name 'MyPrincipal'

        Get the permissions for the principal 'MyPrincipal'.

    .EXAMPLE
        $serverInstance = Connect-SqlDscDatabaseEngine
        Get-SqlDscDatabasePermission -ServerObject $serverInstance -DatabaseName 'MyDatabase' -Name 'MyPrincipal' -Refresh

        Get the permissions for the principal 'MyPrincipal'. The database's principal
        collections are refreshed before testing if the principal exists.

    .NOTES
        This command excludes fixed roles like _db_datareader_ by default, and will
        always return `$null` if a fixed role is specified as **Name**.

        If specifying `-ErrorAction 'SilentlyContinue'` then the command will silently
        ignore if the database (parameter **DatabaseName**) is not present or the
        database principal is not present. In such case the command will return `$null`.
        If specifying `-ErrorAction 'Stop'` the command will throw an error if the
        database or database principal is missing.
#>
function Get-SqlDscDatabasePermission
{
    [System.Diagnostics.CodeAnalysis.SuppressMessageAttribute('UseSyntacticallyCorrectExamples', '', Justification = 'Because the rule does not yet support parsing the code when a parameter type is not available. The ScriptAnalyzer rule UseSyntacticallyCorrectExamples will always error in the editor due to https://github.com/indented-automation/Indented.ScriptAnalyzerRules/issues/8.')]
    [System.Diagnostics.CodeAnalysis.SuppressMessageAttribute('AvoidThrowOutsideOfTry', '', Justification = 'Because the code throws based on an prior expression')]
    [CmdletBinding()]
    [OutputType([Microsoft.SqlServer.Management.Smo.DatabasePermissionInfo[]])]
    param
    (
        [Parameter(Mandatory = $true, ValueFromPipeline = $true)]
        [Microsoft.SqlServer.Management.Smo.Server]
        $ServerObject,

        [Parameter(Mandatory = $true)]
        [System.String]
        $DatabaseName,

        [Parameter(Mandatory = $true)]
        [System.String]
        $Name,

        [Parameter()]
        [System.Management.Automation.SwitchParameter]
        $Refresh
    )

    # cSpell: ignore GSDDP
    process
    {
        $getSqlDscDatabasePermissionResult = $null

        $sqlDatabaseObject = $null

        if ($ServerObject.Databases)
        {
            $sqlDatabaseObject = $ServerObject.Databases[$DatabaseName]
        }

        if ($sqlDatabaseObject)
        {
            $testSqlDscIsDatabasePrincipalParameters = @{
                ServerObject      = $ServerObject
                DatabaseName      = $DatabaseName
                Name              = $Name
                ExcludeFixedRoles = $true
            }

            if ($Refresh.IsPresent)
            {
                $testSqlDscIsDatabasePrincipalParameters.Refresh = $true
            }

            $isDatabasePrincipal = Test-SqlDscIsDatabasePrincipal @testSqlDscIsDatabasePrincipalParameters

            if ($isDatabasePrincipal)
            {
                $getSqlDscDatabasePermissionResult = $sqlDatabaseObject.EnumDatabasePermissions($Name)
            }
            else
            {
                $missingPrincipalMessage = $script:localizedData.DatabasePermission_MissingPrincipal -f $Name, $DatabaseName

                Write-Error -Message $missingPrincipalMessage -Category 'InvalidOperation' -ErrorId 'GSDDP0001' -TargetObject $Name
            }
        }
        else
        {
            $missingDatabaseMessage = $script:localizedData.DatabasePermission_MissingDatabase -f $DatabaseName

            Write-Error -Message $missingDatabaseMessage -Category 'InvalidOperation' -ErrorId 'GSDDP0002' -TargetObject $DatabaseName
        }

        return [Microsoft.SqlServer.Management.Smo.DatabasePermissionInfo[]] $getSqlDscDatabasePermissionResult
    }
}
#EndRegion '.\Public\Get-SqlDscDatabasePermission.ps1' 126
#Region '.\Public\Get-SqlDscInstalledInstance.ps1' -1

<#
    .SYNOPSIS
        Returns the installed instances on the current node.

    .DESCRIPTION
        Returns the installed instances on the current node.

    .PARAMETER InstanceName
       Specifies the instance name to return instances for.

    .PARAMETER ServiceType
        Specifies the service type to filter instances by. Valid values are
        'DatabaseEngine', 'AnalysisServices', and 'ReportingServices'.

    .OUTPUTS
        `[System.Object[]]`

    .EXAMPLE
        Get-SqlDscInstalledInstance

        Returns all installed instances.
#>
function Get-SqlDscInstalledInstance
{
    [CmdletBinding()]
    [OutputType([System.Object[]])]
    param
    (
        [Parameter()]
        [System.String]
        $InstanceName,

        [Parameter()]
        [ValidateSet('DatabaseEngine', 'AnalysisServices', 'ReportingServices')]
        [System.String[]]
        $ServiceType
    )

    if ($PSBoundParameters.ContainsKey('InstanceName'))
    {
        $InstanceName = $InstanceName.ToUpper()
    }

    $instances = @()

    $installedServiceType = Get-ChildItem -Path 'HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\Instance Names' -ErrorAction 'SilentlyContinue'

    foreach ($currentServiceType in $installedServiceType)
    {
        $serviceTypeName = switch ($currentServiceType.PSChildName)
        {
            'OLAP'
            {
                'AnalysisServices'

                break
            }

            'SQL'
            {
                'DatabaseEngine'

                break
            }

           'RS'
            {
                'ReportingServices'

                break
            }
        }

        if ($PSBoundParameters.ContainsKey('ServiceType') -and $serviceTypeName -notin $ServiceType)
        {
            continue
        }

        $instanceNames = $currentServiceType.GetValueNames()

        foreach ($currentInstanceName in $instanceNames)
        {
            if ($PSBoundParameters.ContainsKey('InstanceName') -and $currentInstanceName -ne $InstanceName)
            {
                continue
            }

            $foundInstance = [PSCustomObject] @{
                ServiceType = $serviceTypeName
                InstanceName = $currentInstanceName
                InstanceId = $currentServiceType.GetValue($currentInstanceName)
            }

            $instances += $foundInstance
        }
    }

    return $instances
}
#EndRegion '.\Public\Get-SqlDscInstalledInstance.ps1' 100
#Region '.\Public\Get-SqlDscLogin.ps1' -1

<#
    .SYNOPSIS
        Gets SQL Server logins.

    .DESCRIPTION
        Retrieves login objects from a SQL Server Database Engine instance. Specify -Name
        to return a specific login, or omit -Name to return all logins. Use -Refresh to
        refresh the login collection before retrieval.

    .PARAMETER ServerObject
            Specifies the current server connection object.
    .PARAMETER Name
        Specifies the name of the server login to get.

    .PARAMETER Refresh
        Specifies that the **ServerObject** logins should be refreshed before
        trying to get the login object. This is helpful when logins might have
        been modified outside of the **ServerObject**, for example through T-SQL.
        On instances with a large number of logins, consider ensuring the
        **ServerObject** is recent enough.

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine -InstanceName 'MyInstance'
        $serverObject | Get-SqlDscLogin -Name 'MyLogin'

        Get the login named **MyLogin**.

    .OUTPUTS
        `[Microsoft.SqlServer.Management.Smo.Login]`

        Returns a single Login object when the Name parameter is specified and a
        match is found.

    .OUTPUTS
        `[Microsoft.SqlServer.Management.Smo.Login[]]`

        Returns an array of Login objects when the Name parameter is not specified
        (returns all logins) or when multiple matches are found.
#>
function Get-SqlDscLogin
{
    [System.Diagnostics.CodeAnalysis.SuppressMessageAttribute('UseSyntacticallyCorrectExamples', '', Justification = 'Because the rule does not yet support parsing the code when a parameter type is not available. The ScriptAnalyzer rule UseSyntacticallyCorrectExamples will always error in the editor due to https://github.com/indented-automation/Indented.ScriptAnalyzerRules/issues/8.')]
    [OutputType([Microsoft.SqlServer.Management.Smo.Login[]])]
    [CmdletBinding()]
    param
    (
        [Parameter(Mandatory = $true, ValueFromPipeline = $true)]
        [Microsoft.SqlServer.Management.Smo.Server]
        $ServerObject,

        [Parameter()]
        [System.String]
        $Name,

        [Parameter()]
        [System.Management.Automation.SwitchParameter]
        $Refresh
    )

    process
    {
        if ($Refresh.IsPresent)
        {
            Write-Verbose -Message ($script:localizedData.Login_Get_RefreshingLogins -f $ServerObject.InstanceName)

            # Make sure the logins are up-to-date to get any newly created logins.
            $ServerObject.Logins.Refresh()
        }

        $loginObject = @()

        if ($PSBoundParameters.ContainsKey('Name'))
        {
            Write-Verbose -Message ($script:localizedData.Login_Get_RetrievingByName -f $Name, $ServerObject.InstanceName)

            $loginObject = $ServerObject.Logins[$Name]

            if (-not $loginObject)
            {
                $missingLoginMessage = $script:localizedData.Login_Get_Missing -f $Name

                $writeErrorParameters = @{
                    Message      = $missingLoginMessage
                    Category     = 'ObjectNotFound'
                    ErrorId      = 'GSDL0001' # cspell: disable-line
                    TargetObject = $Name
                }

                Write-Error @writeErrorParameters
            }
        }
        else
        {
            Write-Verbose -Message ($script:localizedData.Login_Get_ReturningAllLogins -f $ServerObject.InstanceName)

            $loginObject = $ServerObject.Logins
        }

        return [Microsoft.SqlServer.Management.Smo.Login[]] $loginObject
    }
}
#EndRegion '.\Public\Get-SqlDscLogin.ps1' 102
#Region '.\Public\Get-SqlDscManagedComputer.ps1' -1

<#
    .SYNOPSIS
        Returns the managed computer object.

    .DESCRIPTION
        Returns the managed computer object, by default for the node the command
        is run on.

    .PARAMETER ServerName
       Specifies the server name for which to return the managed computer object.

    .EXAMPLE
        Get-SqlDscManagedComputer

        Returns the managed computer object for the current node.

    .EXAMPLE
        Get-SqlDscManagedComputer -ServerName 'MyServer'

        Returns the managed computer object for the server 'MyServer'.

    .OUTPUTS
        `[Microsoft.SqlServer.Management.Smo.Wmi.ManagedComputer]`
#>
function Get-SqlDscManagedComputer
{
    [System.Diagnostics.CodeAnalysis.SuppressMessageAttribute('UseSyntacticallyCorrectExamples', '', Justification = 'Because the rule does not yet support parsing the code when the output type is not available. The ScriptAnalyzer rule UseSyntacticallyCorrectExamples will always error in the editor due to https://github.com/indented-automation/Indented.ScriptAnalyzerRules/issues/8.')]    [OutputType([Microsoft.SqlServer.Management.Smo.Wmi.ManagedComputer])]
    [CmdletBinding()]
    param
    (
        [Parameter()]
        [System.String]
        $ServerName = (Get-ComputerName)
    )

    Write-Verbose -Message (
        $script:localizedData.ManagedComputer_GetState -f $ServerName
    )

    $managedComputerObject = New-Object -TypeName 'Microsoft.SqlServer.Management.Smo.Wmi.ManagedComputer' -ArgumentList $ServerName

    return $managedComputerObject
}
#EndRegion '.\Public\Get-SqlDscManagedComputer.ps1' 44
#Region '.\Public\Get-SqlDscManagedComputerInstance.ps1' -1

<#
    .SYNOPSIS
        Returns managed computer server instance information.

    .DESCRIPTION
        Returns managed computer server instance information for a SQL Server instance
        using SMO (SQL Server Management Objects). The command can retrieve a specific
        instance or all instances on a managed computer.

    .PARAMETER ServerName
        Specifies the name of the server where the SQL Server instance is running.
        Defaults to the local computer name.

    .PARAMETER InstanceName
        Specifies the name of the SQL Server instance to retrieve.
        If not specified, all instances are returned.

    .PARAMETER ManagedComputerObject
        Specifies a managed computer object from which to retrieve server instances.
        This parameter accepts pipeline input from Get-SqlDscManagedComputer.

    .EXAMPLE
        Get-SqlDscManagedComputerInstance -InstanceName 'MSSQLSERVER'

        Returns the default SQL Server instance information from the local computer.

    .EXAMPLE
        Get-SqlDscManagedComputerInstance -ServerName 'MyServer' -InstanceName 'MyInstance'

        Returns the MyInstance SQL Server instance information from the MyServer computer.

    .EXAMPLE
        Get-SqlDscManagedComputerInstance -ServerName 'MyServer'

        Returns all SQL Server instances information from the MyServer computer.

    .EXAMPLE
        Get-SqlDscManagedComputer -ServerName 'MyServer' | Get-SqlDscManagedComputerInstance -InstanceName 'MyInstance'

        Uses pipeline input to retrieve a specific instance from a managed computer object.

    .INPUTS
        Microsoft.SqlServer.Management.Smo.Wmi.ManagedComputer

        A managed computer object can be piped to this command.

    .OUTPUTS
        Microsoft.SqlServer.Management.Smo.Wmi.ServerInstance

        Returns server instance objects from SMO (SQL Server Management Objects).

    .NOTES
        This command uses SMO (SQL Server Management Objects) to retrieve server
        instance information from the specified managed computer.
#>
function Get-SqlDscManagedComputerInstance
{
    [System.Diagnostics.CodeAnalysis.SuppressMessageAttribute('UseSyntacticallyCorrectExamples', '', Justification = 'Because the rule does not yet support parsing the code when a parameter type is not available. The ScriptAnalyzer rule UseSyntacticallyCorrectExamples will always error in the editor due to https://github.com/indented-automation/Indented.ScriptAnalyzerRules/issues/8.')]
    [CmdletBinding(DefaultParameterSetName = 'ByServerName')]
    [OutputType([Microsoft.SqlServer.Management.Smo.Wmi.ServerInstance])]
    param
    (
        [Parameter(ParameterSetName = 'ByServerName')]
        [ValidateNotNullOrEmpty()]
        [System.String]
        $ServerName = (Get-ComputerName),

        [Parameter(ParameterSetName = 'ByServerName')]
        [Parameter(ParameterSetName = 'ByManagedComputerObject')]
        [ValidateNotNullOrEmpty()]
        [System.String]
        $InstanceName,

        [Parameter(Mandatory = $true, ValueFromPipeline = $true, ParameterSetName = 'ByManagedComputerObject')]
        [Microsoft.SqlServer.Management.Smo.Wmi.ManagedComputer]
        $ManagedComputerObject
    )

    process
    {
        if ($PSCmdlet.ParameterSetName -eq 'ByServerName')
        {
            Write-Verbose -Message (
                $script:localizedData.ManagedComputerInstance_GetFromServer -f $ServerName
            )

            $ManagedComputerObject = Get-SqlDscManagedComputer -ServerName $ServerName
        }
        else
        {
            Write-Verbose -Message (
                $script:localizedData.ManagedComputerInstance_GetFromObject
            )
        }

        if ($PSBoundParameters.ContainsKey('InstanceName'))
        {
            Write-Verbose -Message (
                $script:localizedData.ManagedComputerInstance_GetSpecificInstance -f $InstanceName
            )

            $serverInstance = $ManagedComputerObject.ServerInstances[$InstanceName]

            if (-not $serverInstance)
            {
                $errorMessage = $script:localizedData.ManagedComputerInstance_InstanceNotFound -f $InstanceName, $ManagedComputerObject.Name
                $errorRecord = [System.Management.Automation.ErrorRecord]::new(
                    [System.InvalidOperationException]::new($errorMessage),
                    'SqlServerInstanceNotFound',
                    [System.Management.Automation.ErrorCategory]::ObjectNotFound,
                    $InstanceName
                )
                $PSCmdlet.ThrowTerminatingError($errorRecord)
            }

            return $serverInstance
        }
        else
        {
            Write-Verbose -Message (
                $script:localizedData.ManagedComputerInstance_GetAllInstances
            )

            return $ManagedComputerObject.ServerInstances
        }
    }
}
#EndRegion '.\Public\Get-SqlDscManagedComputerInstance.ps1' 128
#Region '.\Public\Get-SqlDscManagedComputerService.ps1' -1

<#
    .SYNOPSIS
        Returns one or more managed computer service objects.

    .DESCRIPTION
        Returns one or more managed computer service objects, by default for the
        node the command is run on.

    .PARAMETER ManagedComputerObject
        Specifies the Managed Computer object to return the services from.

    .PARAMETER ServerName
       Specifies the server name to return the services from.

    .PARAMETER InstanceName
       Specifies the instance name to return the services for, this will exclude
       any service that does not have the instance name in the service name.

    .PARAMETER ServiceType
       Specifies one or more service types to return the services for.

    .EXAMPLE
        Get-SqlDscManagedComputer | Get-SqlDscManagedComputerService

        Returns all the managed computer service objects for the current node.

    .EXAMPLE
        Get-SqlDscManagedComputerService

        Returns all the managed computer service objects for the current node.

    .EXAMPLE
        Get-SqlDscManagedComputerService -ServerName 'MyServer'

        Returns all the managed computer service objects for the server 'MyServer'.

    .EXAMPLE
        Get-SqlDscManagedComputerService -ServiceType 'DatabaseEngine','AnalysisServices'

        Returns all the managed computer service objects for service types
        'DatabaseEngine' and 'AnalysisServices'.

    .EXAMPLE
        Get-SqlDscManagedComputerService -InstanceName 'SQL2022'

        Returns all the managed computer service objects for instance SQL2022.

    .OUTPUTS
        `[Microsoft.SqlServer.Management.Smo.Wmi.Service[]]`
#>
function Get-SqlDscManagedComputerService
{
    [System.Diagnostics.CodeAnalysis.SuppressMessageAttribute('UseSyntacticallyCorrectExamples', '', Justification = 'Because the rule does not yet support parsing the code when the output type is not available. The ScriptAnalyzer rule UseSyntacticallyCorrectExamples will always error in the editor due to https://github.com/indented-automation/Indented.ScriptAnalyzerRules/issues/8.')]    [OutputType([Microsoft.SqlServer.Management.Smo.Wmi.ManagedComputer])]
    [OutputType([Microsoft.SqlServer.Management.Smo.Wmi.Service[]])]
    [CmdletBinding(DefaultParameterSetName = 'ByServerName')]
    param
    (
        [Parameter(ParameterSetName = 'ByServerObject', Mandatory = $true, ValueFromPipeline = $true)]
        [Microsoft.SqlServer.Management.Smo.Wmi.ManagedComputer]
        $ManagedComputerObject,

        [Parameter(ParameterSetName = 'ByServerName')]
        [ValidateNotNullOrEmpty()]
        [System.String]
        $ServerName = (Get-ComputerName),

        [Parameter()]
        [System.String[]]
        $InstanceName,

        [Parameter()]
        [ValidateSet('DatabaseEngine', 'SQLServerAgent', 'Search', 'IntegrationServices', 'AnalysisServices', 'ReportingServices', 'SQLServerBrowser', 'NotificationServices')]
        [System.String[]]
        $ServiceType
    )

    begin
    {
        if ($PSCmdlet.ParameterSetName -eq 'ByServerName')
        {
            $ManagedComputerObject = Get-SqlDscManagedComputer -ServerName $ServerName
        }

        Write-Verbose -Message (
            $script:localizedData.ManagedComputerService_GetState -f $ServerName
        )

        $serviceObject = $null
    }

    process
    {
        if ($ManagedComputerObject)
        {
            if ($serviceObject)
            {
                $serviceObject += $ManagedComputerObject.Services
            }
            else
            {
                $serviceObject = $ManagedComputerObject.Services
            }
        }
    }

    end
    {
        if ($serviceObject)
        {
            if ($PSBoundParameters.ContainsKey('ServiceType'))
            {
                $managedServiceType = $ServiceType |
                    ConvertTo-ManagedServiceType

                $serviceObject = $serviceObject |
                    Where-Object -FilterScript {
                        $_.Type -in $managedServiceType
                    }
            }

            if ($PSBoundParameters.ContainsKey('InstanceName'))
            {
                $serviceObject = $serviceObject |
                    Where-Object -FilterScript {
                        $_.Name -match ('\${0}$' -f $InstanceName)
                    }
            }
        }

        return $serviceObject
    }
}
#EndRegion '.\Public\Get-SqlDscManagedComputerService.ps1' 133
#Region '.\Public\Get-SqlDscPreferredModule.ps1' -1

<#
    .SYNOPSIS
        Get the first available (preferred) module that is installed.

    .DESCRIPTION
        Get the first available (preferred) module that is installed.

        If the environment variable `SMODefaultModuleName` is set to a module name
        that name will be used as the preferred module name instead of the default
        module 'SqlServer'.

        If the envrionment variable `SMODefaultModuleVersion` is set, then that
        specific version of the preferred module will be searched for.

    .PARAMETER Name
        Specifies the list of the (preferred) modules to search for, in order.
        Defaults to 'SqlServer' and then 'SQLPS'.

    .PARAMETER Refresh
        Specifies if the session environment variable PSModulePath should be refreshed
        with the paths from other environment variable targets (Machine and User).

    .EXAMPLE
        Get-SqlDscPreferredModule

        Returns the SqlServer PSModuleInfo object if it is installed, otherwise it
        will return SQLPS PSModuleInfo object if is is installed. If neither is
        installed `$null` is returned.

    .EXAMPLE
        Get-SqlDscPreferredModule -Refresh

        Updates the session environment variable PSModulePath and then returns the
        SqlServer PSModuleInfo object if it is installed, otherwise it will return SQLPS
        PSModuleInfo object if is is installed. If neither is installed `$null` is
        returned.

    .EXAMPLE
        Get-SqlDscPreferredModule -Name @('MyModule', 'SQLPS')

        Returns the MyModule PSModuleInfo object if it is installed, otherwise it will
        return SQLPS PSModuleInfo object if is is installed. If neither is installed
        `$null` is returned.

    .NOTES

#>
function Get-SqlDscPreferredModule
{
    [OutputType([PSModuleInfo])]
    [CmdletBinding()]
    param
    (
        [Parameter()]
        [System.String[]]
        $Name,

        [Parameter()]
        [System.Management.Automation.SwitchParameter]
        $Refresh
    )

    if (-not $PSBoundParameters.ContainsKey('Name'))
    {
        if ($env:SMODefaultModuleName)
        {
            $Name = @($env:SMODefaultModuleName, 'SQLPS')
        }
        else
        {
            $Name = @('SqlServer', 'SQLPS')
        }
    }

    if ($Refresh.IsPresent)
    {
        # Only run on Windows that has Machine state.
        if (-not ($IsLinux -or $IsMacOS))
        {
            <#
                After installing SQL Server the current PowerShell session doesn't know
                about the new path that was added for the SQLPS module. This reloads
                PowerShell session environment variable PSModulePath to make sure it
                contains all paths.
            #>

            $modulePath = Get-PSModulePath -FromTarget 'Session', 'User', 'Machine'

            Set-PSModulePath -Path $modulePath
        }
    }

    $availableModule = $null

    $availableModules = Get-Module -Name $Name -ListAvailable |
        ForEach-Object -Process {
            @{
                PSModuleInfo      = $_
                CalculatedVersion = $_ | Get-SMOModuleCalculatedVersion
            }
        }

    foreach ($preferredModuleName in $Name)
    {
        $preferredModules = $availableModules |
            Where-Object -FilterScript { $_.PSModuleInfo.Name -eq $preferredModuleName }

        if ($preferredModules)
        {
            if ($env:SMODefaultModuleVersion)
            {
                # Get the version specified in $env:SMODefaultModuleVersion if available
                $availableModule = $preferredModules |
                    Where-Object -FilterScript { $_.CalculatedVersion -eq $env:SMODefaultModuleVersion } |
                    Select-Object -First 1
            }
            else
            {
                # Get the latest version if available
                $availableModule = $preferredModules |
                    Sort-Object -Property { ($_.CalculatedVersion -replace '-.+$') -as [System.Version] }, { $_.CalculatedVersion } -Descending |
                    Select-Object -First 1
            }

            Write-Verbose -Message ($script:localizedData.PreferredModule_ModuleVersionFound -f $availableModule.PSModuleInfo.Name, $availableModule.CalculatedVersion)

            break
        }
    }

    if (-not $availableModule)
    {
        $errorMessage = $null

        if ($env:SMODefaultModuleVersion)
        {
            $errorMessage = $script:localizedData.PreferredModule_ModuleVersionNotFound -f $env:SMODefaultModuleVersion
        }
        else
        {
            $errorMessage = $script:localizedData.PreferredModule_ModuleNotFound
        }

        # cSpell: disable-next
        Write-Error -Message $errorMessage -Category 'ObjectNotFound' -ErrorId 'GSDPM0001' -TargetObject ($Name -join ', ')
    }

    return $availableModule.PSModuleInfo
}
#EndRegion '.\Public\Get-SqlDscPreferredModule.ps1' 150
#Region '.\Public\Get-SqlDscRole.ps1' -1

<#
    .SYNOPSIS
        Get server roles from a SQL Server Database Engine instance.

    .DESCRIPTION
        This command gets one or more server roles from a SQL Server Database Engine instance.
        If no name is specified, all server roles are returned.

    .PARAMETER ServerObject
        Specifies current server connection object.

    .PARAMETER Name
        Specifies the name of the server role to get. If not specified, all
        server roles are returned.

    .PARAMETER Refresh
        Specifies that the **ServerObject**'s roles should be refreshed before
        trying to get the role object. This is helpful when roles could have been
        modified outside of the **ServerObject**, for example through T-SQL. But
        on instances with a large amount of roles it might be better to make
        sure the **ServerObject** is recent enough.

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine -InstanceName 'MyInstance'
        $serverObject | Get-SqlDscRole

        Get all server roles from the instance.

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine -InstanceName 'MyInstance'
        $serverObject | Get-SqlDscRole -Name 'MyCustomRole'

        Get the server role named **MyCustomRole**.

    .OUTPUTS
        `[Microsoft.SqlServer.Management.Smo.ServerRole[]]`
#>
function Get-SqlDscRole
{
    [System.Diagnostics.CodeAnalysis.SuppressMessageAttribute('UseSyntacticallyCorrectExamples', '', Justification = 'Because the rule does not yet support parsing the code when a parameter type is not available. The ScriptAnalyzer rule UseSyntacticallyCorrectExamples will always error in the editor due to https://github.com/indented-automation/Indented.ScriptAnalyzerRules/issues/8.')]
    [OutputType([Microsoft.SqlServer.Management.Smo.ServerRole[]])]
    [CmdletBinding()]
    param
    (
        [Parameter(Mandatory = $true, ValueFromPipeline = $true)]
        [Microsoft.SqlServer.Management.Smo.Server]
        $ServerObject,

        [Parameter()]
        [System.String]
        $Name,

        [Parameter()]
        [System.Management.Automation.SwitchParameter]
        $Refresh
    )

    process
    {
        if ($Refresh.IsPresent)
        {
            # Refresh the server object's roles collection
            $ServerObject.Roles.Refresh()
        }

        Write-Verbose -Message ($script:localizedData.Role_Get -f $ServerObject.InstanceName)

        $roleObject = @()

        if ($PSBoundParameters.ContainsKey('Name'))
        {
            $roleObject = $ServerObject.Roles[$Name]

            if (-not $roleObject)
            {
                Write-Verbose -Message ($script:localizedData.Get_SqlDscRole_NotFound -f $Name)

                $missingRoleMessage = $script:localizedData.Get_SqlDscRole_NotFound -f $Name

                $writeErrorParameters = @{
                    Message      = $missingRoleMessage
                    Category     = 'ObjectNotFound'
                    ErrorId      = 'GSDR0001' # cspell: disable-line
                    TargetObject = $Name
                }

                Write-Error @writeErrorParameters

                return
            }
            else
            {
                Write-Verbose -Message ($script:localizedData.Role_Found -f $Name)
            }
        }
        else
        {
            Write-Verbose -Message ($script:localizedData.Role_GetAll)

            $roleObject = $ServerObject.Roles
        }

        return [Microsoft.SqlServer.Management.Smo.ServerRole[]] $roleObject
    }
}
#EndRegion '.\Public\Get-SqlDscRole.ps1' 106
#Region '.\Public\Get-SqlDscRSSetupConfiguration.ps1' -1

<#
    .SYNOPSIS
        Gets the SQL Server Reporting Services or Power BI Report Server setup
        configuration from the Registry.

    .DESCRIPTION
        Gets the SQL Server Reporting Services and Power BI Report Server setup
        configuration information from the Registry. This includes information like
        instance name, installation folder, service name, error dump directory,
        customer feedback settings, error reporting settings, virtual root, configuration
        file path, and various version information of the installed Reporting Services
        instance.

        When no InstanceName is specified, it returns configuration information for all
        installed Reporting Services instances.

    .PARAMETER InstanceName
        Specifies the instance name to return configuration information for.
        If not specified, configuration information for all Reporting Services
        and Power BI Report Server instances will be returned.

    .EXAMPLE
        Get-SqlDscRSSetupConfiguration

        Returns configuration information about all SQL Server Reporting Services
        and Power BI Report Server instances.

    .EXAMPLE
        Get-SqlDscRSSetupConfiguration -InstanceName 'SSRS'

        Returns configuration information about the SQL Server Reporting Services
        instance 'SSRS'.

    .EXAMPLE
        Get-SqlDscRSSetupConfiguration -InstanceName 'PBIRS'

        Returns configuration information about the Power BI Report Server
        instance 'PBIRS'.

    .OUTPUTS
        Returns a PSCustomObject with the following properties:
        - InstanceName: The name of the Reporting Services instance.
        - InstallFolder: The installation folder path.
        - ServiceName: The name of the service.
        - ErrorDumpDirectory: The path to the error dump directory.
        - CustomerFeedback: Whether customer feedback is enabled.
        - EnableErrorReporting: Whether error reporting is enabled.
        - ProductVersion: The product version from registry.
        - CurrentVersion: The current version from registry.
        - VirtualRootServer: The virtual root server value.
        - ConfigFilePath: The path to the report server configuration file.
        - EditionID: The edition ID of the Reporting Services instance.
        - EditionName: The edition name of the Reporting Services instance.
        - IsSharePointIntegrated: Whether the instance is SharePoint integrated.
          MSReportServer_Instance.
        - InstanceId: The instance ID of the Reporting Services instance.
#>
function Get-SqlDscRSSetupConfiguration
{
    # cSpell: ignore PBIRS
    [CmdletBinding()]
    [OutputType([PSCustomObject[]])]
    param
    (
        [Parameter()]
        [System.String]
        $InstanceName
    )

    $reportingServicesInstances = @()

    # Get all Reporting Services instances or filter by specified instance name
    $getInstalledInstanceParams = @{
        ServiceType = 'ReportingServices'
    }

    if ($PSBoundParameters.ContainsKey('InstanceName'))
    {
        Write-Verbose -Message ($script:localizedData.Get_SqlDscRSSetupConfiguration_GetSpecificInstance -f $InstanceName)

        $getInstalledInstanceParams.InstanceName = $InstanceName
    }
    else
    {
        Write-Verbose -Message $script:localizedData.Get_SqlDscRSSetupConfiguration_GetAllInstances
    }

    $instances = Get-SqlDscInstalledInstance @getInstalledInstanceParams

    foreach ($instance in $instances)
    {
        Write-Verbose -Message ($script:localizedData.Get_SqlDscRSSetupConfiguration_ProcessingInstance -f $instance.InstanceName)

        $returnObject = [PSCustomObject]@{
            InstanceName           = $instance.InstanceName
            InstallFolder          = $null
            ServiceName            = $null
            ErrorDumpDirectory     = $null
            CurrentVersion         = $null
            CustomerFeedback       = $null
            EnableErrorReporting   = $null
            ProductVersion         = $null
            VirtualRootServer      = $null
            ConfigFilePath         = $null
            EditionID              = $null
            EditionName            = $null
            IsSharePointIntegrated = $null
            InstanceId             = $instance.InstanceId
        }

        Write-Verbose -Message ($script:localizedData.Get_SqlDscRSSetupConfiguration_FoundInstance -f $instance.InstanceName)

        $getRegistryPropertyValueParameters = @{
            ErrorAction = 'SilentlyContinue'
        }

        # Get values from SSRS\Setup registry key
        $getRegistryPropertyValueParameters.Path = 'HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\{0}\Setup' -f $returnObject.InstanceId

        # InstallRootDirectory
        $getRegistryPropertyValueParameters.Name = 'InstallRootDirectory'
        $returnObject.InstallFolder = Get-RegistryPropertyValue @getRegistryPropertyValueParameters
        # Fallback to SQLPath if InstallRootDirectory is not found. This is the case for SQL 2016 and earlier.
        if ($null -eq $returnObject.InstallFolder)
        {
            $getRegistryPropertyValueParameters.Name = 'SQLPath'
            $returnObject.InstallFolder = Get-RegistryPropertyValue @getRegistryPropertyValueParameters
            if (($null -ne $returnObject.InstallFolder) -and ($returnObject.InstallFolder -notmatch '^[A-Za-z]:\\?$'))
            {
                $returnObject.InstallFolder = $returnObject.InstallFolder.TrimEnd('\')
            }
        }

        # ServiceName
        $getRegistryPropertyValueParameters.Name = 'ServiceName'
        $returnObject.ServiceName = Get-RegistryPropertyValue @getRegistryPropertyValueParameters

        # RSVirtualRootServer
        $getRegistryPropertyValueParameters.Name = 'RSVirtualRootServer'
        $returnObject.VirtualRootServer = Get-RegistryPropertyValue @getRegistryPropertyValueParameters

        # RsConfigFilePath
        $getRegistryPropertyValueParameters.Name = 'RsConfigFilePath'
        $returnObject.ConfigFilePath = Get-RegistryPropertyValue @getRegistryPropertyValueParameters

        # Get values from SSRS\CPE registry key
        $getRegistryPropertyValueParameters.Path = 'HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\{0}\CPE' -f $returnObject.InstanceId

        # ErrorDumpDir
        $getRegistryPropertyValueParameters.Name = 'ErrorDumpDir'
        $returnObject.ErrorDumpDirectory = Get-RegistryPropertyValue @getRegistryPropertyValueParameters

        # CustomerFeedback
        $getRegistryPropertyValueParameters.Name = 'CustomerFeedback'
        $returnObject.CustomerFeedback = Get-RegistryPropertyValue @getRegistryPropertyValueParameters

        # EnableErrorReporting
        $getRegistryPropertyValueParameters.Name = 'EnableErrorReporting'
        $returnObject.EnableErrorReporting = Get-RegistryPropertyValue @getRegistryPropertyValueParameters

        # Get values from SSRS\MSSQLServer\CurrentVersion registry key
        $getRegistryPropertyValueParameters.Path = 'HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\{0}\MSSQLServer\CurrentVersion' -f $returnObject.InstanceId

        # CurrentVersion from registry
        $getRegistryPropertyValueParameters.Name = 'CurrentVersion'
        $returnObject.CurrentVersion = Get-RegistryPropertyValue @getRegistryPropertyValueParameters

        # ProductVersion
        $getRegistryPropertyValueParameters.Name = 'ProductVersion'
        $returnObject.ProductVersion = Get-RegistryPropertyValue @getRegistryPropertyValueParameters

        if (-not [System.String]::IsNullOrEmpty($returnObject.CurrentVersion))
        {
            $reportServerCurrentVersion = [System.Version] $returnObject.CurrentVersion

            # Get values from MSReportServer_Instance
            $getCimInstanceParameters = @{
                Filter = "InstanceId='{0}'" -f $returnObject.InstanceId
                Namespace = 'root\Microsoft\SqlServer\ReportServer\RS_{0}\v{1}' -f $instance.InstanceName, $reportServerCurrentVersion.Major
                ClassName = 'MSReportServer_Instance'
                ErrorAction = 'SilentlyContinue'
            }
            $msReportServerInstance = Get-CimInstance @getCimInstanceParameters
            if ($msReportServerInstance)
            {
                $returnObject.EditionID = $msReportServerInstance.EditionID
                $returnObject.EditionName = $msReportServerInstance.EditionName
                $returnObject.IsSharePointIntegrated = $msReportServerInstance.IsSharePointIntegrated
                $returnObject.InstanceId = $msReportServerInstance.InstanceId
            }
        }

        $reportingServicesInstances += $returnObject
    }

    if ($reportingServicesInstances.Count -eq 0)
    {
        if ($PSBoundParameters.ContainsKey('InstanceName'))
        {
            Write-Verbose -Message ($script:localizedData.Get_SqlDscRSSetupConfiguration_InstanceNotFound -f $InstanceName)
        }
        else
        {
            Write-Verbose -Message $script:localizedData.Get_SqlDscRSSetupConfiguration_NoInstancesFound
        }
    }

    return $reportingServicesInstances
}
#EndRegion '.\Public\Get-SqlDscRSSetupConfiguration.ps1' 210
#Region '.\Public\Get-SqlDscServerPermission.ps1' -1

<#
    .SYNOPSIS
        Returns the current permissions for a SQL Server login or server role.

    .DESCRIPTION
        Returns the current permissions for a SQL Server login or server role.
        The command can retrieve permissions for both user-defined and built-in
        server principals including SQL Server logins and server roles.

        The command supports two modes of operation:
        1. By name: Specify ServerObject, Name, and optionally PrincipalType
        2. By object: Pass Login or ServerRole objects via pipeline

    .PARAMETER ServerObject
        Specifies current server connection object. This parameter is used in the
        default parameter set for backward compatibility.

    .PARAMETER Name
        Specifies the name of the SQL Server login or server role for which
        the permissions are returned. This parameter is used in the default
        parameter set for backward compatibility.

    .PARAMETER PrincipalType
        Specifies the type(s) of principal to check. Valid values are 'Login'
        and 'Role'. If not specified, both login and role checks will be performed.
        If specified, only the specified type(s) will be checked. This parameter
        is used in the default parameter set for backward compatibility.

    .PARAMETER Login
        Specifies the Login object for which the permissions are returned.
        This parameter accepts pipeline input.

    .PARAMETER ServerRole
        Specifies the ServerRole object for which the permissions are returned.
        This parameter accepts pipeline input.

    .OUTPUTS
        [Microsoft.SqlServer.Management.Smo.ServerPermissionInfo[]]

    .EXAMPLE
        $serverInstance = Connect-SqlDscDatabaseEngine
        Get-SqlDscServerPermission -ServerObject $serverInstance -Name 'MyPrincipal'

        Get the permissions for the principal 'MyPrincipal'.

    .EXAMPLE
        $serverInstance = Connect-SqlDscDatabaseEngine
        Get-SqlDscServerPermission -ServerObject $serverInstance -Name 'sysadmin'

        Get the permissions for the server role 'sysadmin'.

    .EXAMPLE
        $serverInstance = Connect-SqlDscDatabaseEngine
        Get-SqlDscServerPermission -ServerObject $serverInstance -Name 'MyLogin' -PrincipalType 'Login'

        Get the permissions for the login 'MyLogin', only checking if it exists as a login.

    .EXAMPLE
        $serverInstance = Connect-SqlDscDatabaseEngine
        Get-SqlDscServerPermission -ServerObject $serverInstance -Name 'MyRole' -PrincipalType 'Role'

        Get the permissions for the server role 'MyRole', only checking if it exists as a role.

    .EXAMPLE
        $serverInstance = Connect-SqlDscDatabaseEngine
        $login = $serverInstance | Get-SqlDscLogin -Name 'MyLogin'

        Get-SqlDscServerPermission -Login $login

        Get the permissions for the login 'MyLogin' using a Login object.

    .EXAMPLE
        $serverInstance = Connect-SqlDscDatabaseEngine
        $role = $serverInstance | Get-SqlDscRole -Name 'MyRole'

        $role | Get-SqlDscServerPermission

        Get the permissions for the server role 'MyRole' using a ServerRole object from the pipeline.

    .EXAMPLE
        $serverInstance = Connect-SqlDscDatabaseEngine

        $serverInstance | Get-SqlDscLogin | Get-SqlDscServerPermission

        Get the permissions for all logins from the pipeline.

    .NOTES
        If specifying `-ErrorAction 'SilentlyContinue'` then the command will silently
        ignore if the principal (parameter **Name**) is not present. In such case the
        command will return `$null`. If specifying `-ErrorAction 'Stop'` the command
        will throw an error if the principal is missing.

        The Login or ServerRole object must come from the same SQL Server instance
        where the permissions will be retrieved.
#>
function Get-SqlDscServerPermission
{
    [System.Diagnostics.CodeAnalysis.SuppressMessageAttribute('UseSyntacticallyCorrectExamples', '', Justification = 'Because the rule does not yet support parsing the code when a parameter type is not available. The ScriptAnalyzer rule UseSyntacticallyCorrectExamples will always error in the editor due to https://github.com/indented-automation/Indented.ScriptAnalyzerRules/issues/8.')]
    [System.Diagnostics.CodeAnalysis.SuppressMessageAttribute('AvoidThrowOutsideOfTry', '', Justification = 'Because the code throws based on an prior expression')]
    [CmdletBinding(DefaultParameterSetName = 'ByName')]
    [OutputType([Microsoft.SqlServer.Management.Smo.ServerPermissionInfo[]])]
    param
    (
        [Parameter(Mandatory = $true, ValueFromPipeline = $true, ParameterSetName = 'ByName')]
        [Microsoft.SqlServer.Management.Smo.Server]
        $ServerObject,

        [Parameter(Mandatory = $true, ParameterSetName = 'ByName')]
        [System.String]
        $Name,

        [Parameter(ParameterSetName = 'ByName')]
        [ValidateSet('Login', 'Role')]
        [System.String[]]
        $PrincipalType,

        [Parameter(Mandatory = $true, ValueFromPipeline = $true, ParameterSetName = 'Login')]
        [Microsoft.SqlServer.Management.Smo.Login]
        $Login,

        [Parameter(Mandatory = $true, ValueFromPipeline = $true, ParameterSetName = 'ServerRole')]
        [Microsoft.SqlServer.Management.Smo.ServerRole]
        $ServerRole
    )

    # cSpell: ignore GSDSP
    process
    {
        $getSqlDscServerPermissionResult = $null

        # Determine which parameter set we're using and set up variables accordingly
        if ($PSCmdlet.ParameterSetName -eq 'Login')
        {
            $principalName = $Login.Name
            $serverObject = $Login.Parent
            $isLogin = $true
            $isRole = $false
        }
        elseif ($PSCmdlet.ParameterSetName -eq 'ServerRole')
        {
            $principalName = $ServerRole.Name
            $serverObject = $ServerRole.Parent
            $isLogin = $false
            $isRole = $true
        }
        else
        {
            # ByName parameter set (default for backward compatibility)
            $principalName = $Name
            $serverObject = $ServerObject

            $testSqlDscIsPrincipalParameters = @{
                ServerObject = $serverObject
                Name         = $principalName
            }

            # Determine which checks to perform based on PrincipalType parameter
            $checkLogin = $true
            $checkRole = $true

            if ($PSBoundParameters.ContainsKey('PrincipalType'))
            {
                $checkLogin = $PrincipalType -contains 'Login'
                $checkRole = $PrincipalType -contains 'Role'
            }

            # Perform the appropriate checks
            $isLogin = if ($checkLogin)
            {
                Test-SqlDscIsLogin @testSqlDscIsPrincipalParameters
            }
            else
            {
                $false
            }

            $isRole = if ($checkRole)
            {
                Test-SqlDscIsRole @testSqlDscIsPrincipalParameters
            }
            else
            {
                $false
            }
        }

        if ($isLogin -or $isRole)
        {
            $getSqlDscServerPermissionResult = $serverObject.EnumServerPermissions($principalName)
        }
        else
        {
            $missingPrincipalMessage = $script:localizedData.ServerPermission_MissingPrincipal -f $principalName, $serverObject.InstanceName

            Write-Error -Message $missingPrincipalMessage -Category 'InvalidOperation' -ErrorId 'GSDSP0001' -TargetObject $principalName
        }

        return [Microsoft.SqlServer.Management.Smo.ServerPermissionInfo[]] $getSqlDscServerPermissionResult
    }
}
#EndRegion '.\Public\Get-SqlDscServerPermission.ps1' 201
#Region '.\Public\Get-SqlDscServerProtocol.ps1' -1

<#
    .SYNOPSIS
        Returns server protocol information for a SQL Server instance.

    .DESCRIPTION
        Returns server protocol information for a SQL Server instance using
        SMO (SQL Server Management Objects). The command supports getting
        information for TcpIp, NamedPipes, and SharedMemory protocols.
        If no protocol is specified, all protocols are returned.

    .PARAMETER ServerName
        Specifies the name of the server where the SQL Server instance is running.
        Defaults to the local computer name.

    .PARAMETER InstanceName
        Specifies the name of the SQL Server instance for which to return protocol
        information.

    .PARAMETER ProtocolName
        Specifies the name of the network protocol to return information for.
        Valid values are 'TcpIp', 'NamedPipes', and 'SharedMemory'.
        If not specified, all protocols are returned.

    .PARAMETER ManagedComputerObject
        Specifies a managed computer object from which to retrieve server protocol
        information. This parameter accepts pipeline input from Get-SqlDscManagedComputer.

    .PARAMETER ManagedComputerInstanceObject
        Specifies a managed computer instance object from which to retrieve server
        protocol information. This parameter accepts pipeline input from
        Get-SqlDscManagedComputerInstance.

    .EXAMPLE
        Get-SqlDscServerProtocol -InstanceName 'MSSQLSERVER' -ProtocolName 'TcpIp'

        Returns TcpIp protocol information for the default SQL Server instance
        on the local computer.

    .EXAMPLE
        Get-SqlDscServerProtocol -ServerName 'MyServer' -InstanceName 'MyInstance' -ProtocolName 'NamedPipes'

        Returns NamedPipes protocol information for the MyInstance SQL Server
        instance on the MyServer computer.

    .EXAMPLE
        Get-SqlDscServerProtocol -InstanceName 'MSSQLSERVER'

        Returns all protocol information for the default SQL Server instance
        on the local computer.

    .EXAMPLE
        Get-SqlDscManagedComputer -ServerName 'MyServer' | Get-SqlDscServerProtocol -InstanceName 'MyInstance'

        Uses pipeline input from Get-SqlDscManagedComputer to retrieve all protocols
        for the specified instance.

    .EXAMPLE
        Get-SqlDscManagedComputerInstance -InstanceName 'MyInstance' | Get-SqlDscServerProtocol -ProtocolName 'TcpIp'

        Uses pipeline input from Get-SqlDscManagedComputerInstance to retrieve TcpIp
        protocol information.

    .INPUTS
        Microsoft.SqlServer.Management.Smo.Wmi.ManagedComputer

        A managed computer object can be piped to this command.

        Microsoft.SqlServer.Management.Smo.Wmi.ServerInstance

        A server instance object can be piped to this command.

    .OUTPUTS
        Microsoft.SqlServer.Management.Smo.Wmi.ServerProtocol

        Returns server protocol objects from SMO (SQL Server Management Objects).
#>
function Get-SqlDscServerProtocol
{
    [System.Diagnostics.CodeAnalysis.SuppressMessageAttribute('UseSyntacticallyCorrectExamples', '', Justification = 'Because the rule does not yet support parsing the code when a parameter type is not available. The ScriptAnalyzer rule UseSyntacticallyCorrectExamples will always error in the editor due to https://github.com/indented-automation/Indented.ScriptAnalyzerRules/issues/8.')]
    [CmdletBinding(DefaultParameterSetName = 'ByServerName')]
    [OutputType([Microsoft.SqlServer.Management.Smo.Wmi.ServerProtocol])]
    param
    (
        [Parameter(ParameterSetName = 'ByServerName')]
        [ValidateNotNullOrEmpty()]
        [System.String]
        $ServerName,

        [Parameter(Mandatory = $true, ParameterSetName = 'ByServerName')]
        [Parameter(Mandatory = $true, ParameterSetName = 'ByManagedComputerObject')]
        [ValidateNotNullOrEmpty()]
        [System.String]
        $InstanceName,

        [Parameter(ParameterSetName = 'ByServerName')]
        [Parameter(ParameterSetName = 'ByManagedComputerObject')]
        [Parameter(ParameterSetName = 'ByManagedComputerInstanceObject')]
        [ValidateSet('TcpIp', 'NamedPipes', 'SharedMemory')]
        [System.String]
        $ProtocolName,

        [Parameter(Mandatory = $true, ValueFromPipeline = $true, ParameterSetName = 'ByManagedComputerObject')]
        [Microsoft.SqlServer.Management.Smo.Wmi.ManagedComputer]
        $ManagedComputerObject,

        [Parameter(Mandatory = $true, ValueFromPipeline = $true, ParameterSetName = 'ByManagedComputerInstanceObject')]
        [Microsoft.SqlServer.Management.Smo.Wmi.ServerInstance]
        $ManagedComputerInstanceObject
    )

    process
    {
        $previousErrorActionPreference = $ErrorActionPreference
        $ErrorActionPreference = 'Stop'

        # Set default value for ServerName if not provided
        if (-not $PSBoundParameters.ContainsKey('ServerName'))
        {
            $ServerName = Get-ComputerName -ErrorAction 'Stop'
        }

        if ($PSBoundParameters.ContainsKey('ProtocolName'))
        {
            Write-Verbose -Message (
                $script:localizedData.ServerProtocol_GetState -f $ProtocolName, $InstanceName, $ServerName
            )
        }
        else
        {
            Write-Verbose -Message (
                $script:localizedData.ServerProtocol_GetAllProtocols -f $InstanceName, $ServerName
            )
        }

        switch ($PSCmdlet.ParameterSetName)
        {
            'ByServerName'
            {
                $serverInstance = Get-SqlDscManagedComputerInstance -ServerName $ServerName -InstanceName $InstanceName -ErrorAction 'Stop'
            }

            'ByManagedComputerObject'
            {
                $serverInstance = $ManagedComputerObject | Get-SqlDscManagedComputerInstance -InstanceName $InstanceName -ErrorAction 'Stop'
            }

            'ByManagedComputerInstanceObject'
            {
                $serverInstance = $ManagedComputerInstanceObject
            }
        }

        if ($PSBoundParameters.ContainsKey('ProtocolName'))
        {
            # Get specific protocol
            $protocolMapping = Get-SqlDscServerProtocolName -ProtocolName $ProtocolName -ErrorAction 'Stop'

            $serverProtocolObject = $serverInstance.ServerProtocols[$protocolMapping.ShortName]

            $ErrorActionPreference = $previousErrorActionPreference

            if (-not $serverProtocolObject)
            {
                $errorMessage = $script:localizedData.ServerProtocol_ProtocolNotFound -f $protocolMapping.DisplayName, $InstanceName, $serverInstance.Parent.Name
                $errorRecord = [System.Management.Automation.ErrorRecord]::new(
                    [System.InvalidOperationException]::new($errorMessage),
                    'SqlServerProtocolNotFound',
                    [System.Management.Automation.ErrorCategory]::ObjectNotFound,
                    $ProtocolName
                )
                $PSCmdlet.ThrowTerminatingError($errorRecord)
            }

            return $serverProtocolObject
        }
        else
        {
            # Get all protocols
            $allProtocolMappings = Get-SqlDscServerProtocolName -All -ErrorAction 'Stop'
            $allServerProtocols = @()

            foreach ($protocolMapping in $allProtocolMappings)
            {
                $serverProtocolObject = $serverInstance.ServerProtocols[$protocolMapping.ShortName]

                if ($serverProtocolObject)
                {
                    $allServerProtocols += $serverProtocolObject
                }
            }

            $ErrorActionPreference = $previousErrorActionPreference

            if ($allServerProtocols.Count -eq 0)
            {
                return $null
            }

            return $allServerProtocols
        }
    }
}
#EndRegion '.\Public\Get-SqlDscServerProtocol.ps1' 203
#Region '.\Public\Get-SqlDscServerProtocolName.ps1' -1

<#
    .SYNOPSIS
        Returns SQL Server protocol name mappings.

    .DESCRIPTION
        Returns SQL Server protocol name mappings including the protocol name,
        display name, and short name. This command provides standardized
        protocol naming across different SQL Server management interfaces.

    .PARAMETER ProtocolName
        Specifies the protocol name using the ServerProtocols enumeration.
        Valid values are 'TcpIp', 'NamedPipes', and 'SharedMemory'.

    .PARAMETER DisplayName
        Specifies the protocol display name as shown in SQL Server Configuration Manager.
        Valid values are 'TCP/IP', 'Named Pipes', and 'Shared Memory'.

    .PARAMETER ShortName
        Specifies the short protocol name as used by SMO.
        Valid values are 'Tcp', 'Np', and 'Sm'.

    .PARAMETER All
        Returns all available protocol name mappings.

    .EXAMPLE
        Get-SqlDscServerProtocolName -ProtocolName 'TcpIp'

        Returns the protocol name mapping for TCP/IP protocol.

    .EXAMPLE
        Get-SqlDscServerProtocolName -DisplayName 'Named Pipes'

        Returns the protocol name mapping for Named Pipes protocol using its display name.

    .EXAMPLE
        Get-SqlDscServerProtocolName -ShortName 'Sm'

        Returns the protocol name mapping for Shared Memory protocol using its short name.

    .EXAMPLE
        Get-SqlDscServerProtocolName -All

        Returns all available protocol name mappings.

    .INPUTS
        None

    .OUTPUTS
        System.Management.Automation.PSCustomObject

        Returns a PSCustomObject with the properties Name, DisplayName, and ShortName.

    .NOTES
        This command replaces the deprecated Get-ProtocolNameProperties function.
#>
function Get-SqlDscServerProtocolName
{
    [CmdletBinding(DefaultParameterSetName = 'All')]
    [OutputType([System.Management.Automation.PSCustomObject])]
    param
    (
        [Parameter(Mandatory = $true, ParameterSetName = 'ByProtocolName')]
        [ValidateSet('TcpIp', 'NamedPipes', 'SharedMemory')]
        [System.String]
        $ProtocolName,

        [Parameter(Mandatory = $true, ParameterSetName = 'ByDisplayName')]
        [ValidateSet('TCP/IP', 'Named Pipes', 'Shared Memory')]
        [System.String]
        $DisplayName,

        [Parameter(Mandatory = $true, ParameterSetName = 'ByShortName')]
        [ValidateSet('Tcp', 'Np', 'Sm')]
        [System.String]
        $ShortName,

        [Parameter(ParameterSetName = 'All')]
        [System.Management.Automation.SwitchParameter]
        $All
    )

    Write-Verbose -Message (
        $script:localizedData.ServerProtocolName_GetProtocolMappings
    )

    # Define all protocol mappings
    $protocolMappings = @(
        [PSCustomObject]@{
            Name = 'TcpIp'
            DisplayName = 'TCP/IP'
            ShortName = 'Tcp'
        },
        [PSCustomObject]@{
            Name = 'NamedPipes'
            DisplayName = 'Named Pipes'
            ShortName = 'Np'
        },
        [PSCustomObject]@{
            Name = 'SharedMemory'
            DisplayName = 'Shared Memory'
            ShortName = 'Sm'
        }
    )

    # Check if All parameter is present or if no parameters specified (default case)
    if ($All.IsPresent -or $PSCmdlet.ParameterSetName -eq 'All')
    {
        $result = $protocolMappings
    }
    else
    {
        switch ($PSCmdlet.ParameterSetName)
        {
            'ByProtocolName'
            {
                $result = $protocolMappings | Where-Object -FilterScript { $_.Name -eq $ProtocolName }
                break
            }

            'ByDisplayName'
            {
                $result = $protocolMappings | Where-Object -FilterScript { $_.DisplayName -eq $DisplayName }
                break
            }

            'ByShortName'
            {
                $result = $protocolMappings | Where-Object -FilterScript { $_.ShortName -eq $ShortName }
                break
            }
        }
    }

    return $result
}
#EndRegion '.\Public\Get-SqlDscServerProtocolName.ps1' 136
#Region '.\Public\Get-SqlDscSetupLog.ps1' -1

<#
    .SYNOPSIS
        Get SQL Server setup bootstrap log.

    .DESCRIPTION
        This command retrieves the SQL Server setup bootstrap log (Summary.txt)
        from the most recent setup operation. The log is typically located in
        the Setup Bootstrap\Log directory under the SQL Server installation path.

        This command is useful for diagnosing SQL Server setup failures or
        understanding what occurred during the installation, upgrade, or rebuild
        operations.

    .PARAMETER Path
        Specifies the root SQL Server installation path to search for the setup log
        file. Defaults to 'C:\Program Files\Microsoft SQL Server'.

    .EXAMPLE
        Get-SqlDscSetupLog

        Retrieves the most recent SQL Server setup log from the default location.

    .EXAMPLE
        Get-SqlDscSetupLog -Path 'D:\SQLServer'

        Retrieves the most recent SQL Server setup log from a custom installation path.

    .EXAMPLE
        Get-SqlDscSetupLog -Verbose | Select-String -Pattern 'Error'

        Retrieves the setup log and filters for lines containing 'Error'.

    .INPUTS
        None. This command does not accept pipeline input.

    .OUTPUTS
        `[System.String[]]`

        Returns the content of the setup log file, or null if no log file is found.
#>
function Get-SqlDscSetupLog
{
    [CmdletBinding()]
    [OutputType([System.String[]])]
    param
    (
        [Parameter()]
        [System.String]
        $Path = 'C:\Program Files\Microsoft SQL Server'
    )

    $setupLogFileName = 'Summary.txt'

    Write-Verbose -Message ($script:localizedData.Get_SqlDscSetupLog_SearchingForFile -f $setupLogFileName, $Path)

    # Check if the path exists before attempting to search for files
    if (-not (Test-Path -Path $Path -PathType 'Container'))
    {
        $writeErrorParameters = @{
            Message      = $script:localizedData.Get_SqlDscSetupLog_PathNotFound -f $Path
            Category     = 'ObjectNotFound'
            ErrorId      = 'GSDSL0006'
            TargetObject = $Path
        }

        Write-Error @writeErrorParameters

        return $null
    }

    <#
        Find the most recent Summary.txt file from Setup Bootstrap\Log directories.
        Summary.txt is the standard SQL Server setup diagnostic log that records the outcome
        of installation, upgrade, or rebuild operations. Both the 'Summary.txt' filename and
        'Setup Bootstrap\Log' directory pattern are hardcoded as they are fixed SQL Server
        structures and should not be user-configurable. The -Path parameter allows users to
        specify the root search path for cases where SQL Server is installed in non-standard locations.
    #>
    $summaryFile = Get-ChildItem -Path $Path -Filter $setupLogFileName -Recurse -ErrorAction 'SilentlyContinue' |
        Where-Object -FilterScript { $_.FullName -match '\\Setup Bootstrap\\Log\\' } |
        Sort-Object -Property 'LastWriteTime' -Descending |
        Select-Object -First 1

    $output = @()

    if ($summaryFile)
    {
        Write-Verbose -Message ($script:localizedData.Get_SqlDscSetupLog_FileFound -f $summaryFile.FullName)

        $output += $script:localizedData.Get_SqlDscSetupLog_Header -f $setupLogFileName, $summaryFile.FullName
        $output += Get-Content -Path $summaryFile.FullName
        $output += $script:localizedData.Get_SqlDscSetupLog_Footer -f $setupLogFileName

        return $output
    }
    else
    {
        Write-Verbose -Message ($script:localizedData.Get_SqlDscSetupLog_FileNotFound -f $setupLogFileName)

        return $null
    }
}
#EndRegion '.\Public\Get-SqlDscSetupLog.ps1' 103
#Region '.\Public\Get-SqlDscStartupParameter.ps1' -1

<#
    .SYNOPSIS
        Get current startup parameters on a Database Engine instance.

    .DESCRIPTION
        Get current startup parameters on a Database Engine instance.

    .PARAMETER ServiceObject
        Specifies the Service object to return the startup parameters from.

    .PARAMETER ServerName
        Specifies the server name to return the startup parameters from.

    .PARAMETER InstanceName
        Specifies the instance name to return the startup parameters for.

    .INPUTS
        Microsoft.SqlServer.Management.Smo.Wmi.Service

        A service object representing the Database Engine service.

    .OUTPUTS
        StartupParameters

        Returns a StartupParameters object containing the startup parameters
        for the specified Database Engine instance.

    .EXAMPLE
        Get-SqlDscStartupParameter

        Get the startup parameters from the Database Engine default instance on
        the server where the command in run.

    .EXAMPLE
        $serviceObject = Get-SqlDscManagedComputerService -ServiceType 'DatabaseEngine'
        Get-SqlDscStartupParameter -ServiceObject $serviceObject

        Get the startup parameters from the Database Engine default instance on
        the server where the command in run.

    .EXAMPLE
        Get-SqlDscStartupParameter -InstanceName 'SQL2022'

        Get the startup parameters from the Database Engine instance 'SQL2022' on
        the server where the command in run.

    .EXAMPLE
        $serviceObject = Get-SqlDscManagedComputerService -ServiceType 'DatabaseEngine' -InstanceName 'SQL2022'
        Get-SqlDscStartupParameter -ServiceObject $serviceObject

        Get the startup parameters from the Database Engine instance 'SQL2022' on
        the server where the command in run.
#>
function Get-SqlDscStartupParameter
{
    [System.Diagnostics.CodeAnalysis.SuppressMessageAttribute('UseSyntacticallyCorrectExamples', '', Justification = 'Because the rule does not yet support parsing the code when a parameter type is not available. The ScriptAnalyzer rule UseSyntacticallyCorrectExamples will always error in the editor due to https://github.com/indented-automation/Indented.ScriptAnalyzerRules/issues/8.')]
    [OutputType([StartupParameters])]
    [CmdletBinding(DefaultParameterSetName = 'ByServerName')]
    param
    (
        [Parameter(ParameterSetName = 'ByServiceObject', Mandatory = $true, ValueFromPipeline = $true)]
        [Microsoft.SqlServer.Management.Smo.Wmi.Service]
        $ServiceObject,

        [Parameter(ParameterSetName = 'ByServerName')]
        [ValidateNotNullOrEmpty()]
        [System.String]
        $ServerName = (Get-ComputerName),

        [Parameter(ParameterSetName = 'ByServerName')]
        [ValidateNotNullOrEmpty()]
        [System.String]
        $InstanceName = 'MSSQLSERVER'
    )

    begin
    {
        $originalErrorActionPreference = $ErrorActionPreference

        $ErrorActionPreference = 'Stop'

        Assert-ElevatedUser -ErrorAction 'Stop'

        $ErrorActionPreference = $originalErrorActionPreference
    }

    process
    {
        if ($PSCmdlet.ParameterSetName -eq 'ByServiceObject')
        {
            $ServiceObject | Assert-ManagedServiceType -ServiceType 'DatabaseEngine'
        }

        if ($PSCmdlet.ParameterSetName -eq 'ByServerName')
        {
            $getSqlDscManagedComputerServiceParameters = @{
                ServerName   = $ServerName
                InstanceName = $InstanceName
                ServiceType  = 'DatabaseEngine'
            }

            $ServiceObject = Get-SqlDscManagedComputerService @getSqlDscManagedComputerServiceParameters

            if (-not $ServiceObject)
            {
                $writeErrorParameters = @{
                    Message      = $script:localizedData.StartupParameter_Get_FailedToFindServiceObject
                    Category     = 'InvalidOperation'
                    ErrorId      = 'GSDSP0001' # CSpell: disable-line
                    TargetObject = $ServiceObject
                }

                Write-Error @writeErrorParameters
            }
        }

        Write-Verbose -Message (
            $script:localizedData.StartupParameter_Get_ReturnStartupParameters -f $InstanceName, $ServerName
        )

        $startupParameters = $null

        if ($ServiceObject.StartupParameters)
        {
            $startupParameters = [StartupParameters]::Parse($ServiceObject.StartupParameters)
        }
        else
        {
            Write-Debug -Message ($script:localizedData.StartupParameter_Get_FailedToFindStartupParameters -f $MyInvocation.MyCommand)
        }

        return $startupParameters
    }
}
#EndRegion '.\Public\Get-SqlDscStartupParameter.ps1' 135
#Region '.\Public\Get-SqlDscTraceFlag.ps1' -1

<#
    .SYNOPSIS
        Get current trace flags on a Database Engine instance.

    .DESCRIPTION
        Get current trace flags on a Database Engine instance.

    .PARAMETER ServiceObject
        Specifies the Service object to return the trace flags from.

    .PARAMETER ServerName
       Specifies the server name to return the trace flags from.

    .PARAMETER InstanceName
       Specifies the instance name to return the trace flags for.

    .EXAMPLE
        Get-SqlDscTraceFlag

        Get all the trace flags from the Database Engine default instance on the
        server where the command in run.

    .EXAMPLE
        $serviceObject = Get-SqlDscManagedComputerService -ServiceType 'DatabaseEngine'
        Get-SqlDscTraceFlag -ServiceObject $serviceObject

        Get all the trace flags from the Database Engine default instance on the
        server where the command in run.

    .EXAMPLE
        Get-SqlDscTraceFlag -InstanceName 'SQL2022'

        Get all the trace flags from the Database Engine instance 'SQL2022' on the
        server where the command in run.

    .EXAMPLE
        $serviceObject = Get-SqlDscManagedComputerService -ServiceType 'DatabaseEngine' -InstanceName 'SQL2022'
        Get-SqlDscTraceFlag -ServiceObject $serviceObject

        Get all the trace flags from the Database Engine instance 'SQL2022' on the
        server where the command in run.

    .OUTPUTS
        `[System.UInt32[]]`
#>
function Get-SqlDscTraceFlag
{
    [System.Diagnostics.CodeAnalysis.SuppressMessageAttribute('UseSyntacticallyCorrectExamples', '', Justification = 'Because the rule does not yet support parsing the code when a parameter type is not available. The ScriptAnalyzer rule UseSyntacticallyCorrectExamples will always error in the editor due to https://github.com/indented-automation/Indented.ScriptAnalyzerRules/issues/8.')]
    [OutputType([System.UInt32[]])]
    [CmdletBinding(DefaultParameterSetName = 'ByServerName')]
    param
    (
        [Parameter(ParameterSetName = 'ByServiceObject', Mandatory = $true)]
        [Microsoft.SqlServer.Management.Smo.Wmi.Service]
        $ServiceObject,

        [Parameter(ParameterSetName = 'ByServerName')]
        [ValidateNotNullOrEmpty()]
        [System.String]
        $ServerName = (Get-ComputerName),

        [Parameter(ParameterSetName = 'ByServerName')]
        [ValidateNotNullOrEmpty()]
        [System.String]
        $InstanceName = 'MSSQLSERVER'
    )

    Write-Verbose -Message (
        $script:localizedData.TraceFlag_Get_ReturnTraceFlags -f $InstanceName, $ServerName
    )

    $startupParameter = Get-SqlDscStartupParameter @PSBoundParameters

    $traceFlags = [System.UInt32[]] @()

    if ($startupParameter -and $startupParameter.TraceFlag)
    {
        # Filter out null and zero values (nulls get converted to 0 in UInt32 arrays).
        # Valid trace flags start at 1.
        $traceFlags = $startupParameter.TraceFlag |
            Where-Object -FilterScript { $_ -ne 0 }
    }

    Write-Debug -Message (
        $script:localizedData.TraceFlag_Get_DebugReturningTraceFlags -f $MyInvocation.MyCommand, ($traceFlags -join ', ')
    )

    return [System.UInt32[]] $traceFlags
}
#EndRegion '.\Public\Get-SqlDscTraceFlag.ps1' 90
#Region '.\Public\Grant-SqlDscServerPermission.ps1' -1

<#
    .SYNOPSIS
        Grants server permissions to a principal on a SQL Server Database Engine instance.

    .DESCRIPTION
        This command grants server permissions to an existing principal on a SQL Server
        Database Engine instance. The principal can be specified as either a Login
        object (from Get-SqlDscLogin) or a ServerRole object (from Get-SqlDscRole).

    .PARAMETER Login
        Specifies the Login object for which the permissions are granted.
        This parameter accepts pipeline input.

    .PARAMETER ServerRole
        Specifies the ServerRole object for which the permissions are granted.
        This parameter accepts pipeline input.

    .PARAMETER Permission
        Specifies the permissions to be granted. Specify multiple permissions by
        providing an array of SqlServerPermission enum values.

    .PARAMETER WithGrant
        Specifies that the principal should also be granted the right to grant
        other principals the same permission.

    .PARAMETER Force
        Specifies that the permissions should be granted without any confirmation.

    .OUTPUTS
        None.

    .EXAMPLE
        $serverInstance = Connect-SqlDscDatabaseEngine
        $login = $serverInstance | Get-SqlDscLogin -Name 'MyLogin'

        Grant-SqlDscServerPermission -Login $login -Permission ConnectSql, ViewServerState

        Grants the specified permissions to the login 'MyLogin'.

    .EXAMPLE
        $serverInstance = Connect-SqlDscDatabaseEngine
        $role = $serverInstance | Get-SqlDscRole -Name 'MyRole'

        $role | Grant-SqlDscServerPermission -Permission AlterAnyDatabase -WithGrant -Force

        Grants the specified permissions with grant option to the role 'MyRole' without prompting for confirmation.

    .EXAMPLE
        $serverInstance = Connect-SqlDscDatabaseEngine

        $serverInstance | Get-SqlDscLogin | Grant-SqlDscServerPermission -Permission ConnectSql

        Grants ConnectSql permission to all logins from the pipeline.

    .NOTES
        The Login or ServerRole object must come from the same SQL Server instance
        where the permissions will be granted. If specifying `-ErrorAction 'SilentlyContinue'`
        then the command will silently continue if any errors occur. If specifying
        `-ErrorAction 'Stop'` the command will throw an error on any failure.
#>
function Grant-SqlDscServerPermission
{
    [System.Diagnostics.CodeAnalysis.SuppressMessageAttribute('UseSyntacticallyCorrectExamples', '', Justification = 'Because the rule does not yet support parsing the code when a parameter type is not available. The ScriptAnalyzer rule UseSyntacticallyCorrectExamples will always error in the editor due to https://github.com/indented-automation/Indented.ScriptAnalyzerRules/issues/8.')]
    [System.Diagnostics.CodeAnalysis.SuppressMessageAttribute('AvoidThrowOutsideOfTry', '', Justification = 'Because the code throws based on an prior expression')]
    [CmdletBinding(SupportsShouldProcess = $true, ConfirmImpact = 'High')]
    [OutputType()]
    param
    (
        [Parameter(Mandatory = $true, ValueFromPipeline = $true, ParameterSetName = 'Login')]
        [Microsoft.SqlServer.Management.Smo.Login]
        $Login,

        [Parameter(Mandatory = $true, ValueFromPipeline = $true, ParameterSetName = 'ServerRole')]
        [Microsoft.SqlServer.Management.Smo.ServerRole]
        $ServerRole,

        [Parameter(Mandatory = $true)]
        [SqlServerPermission[]]
        $Permission,

        [Parameter()]
        [System.Management.Automation.SwitchParameter]
        $WithGrant,

        [Parameter()]
        [System.Management.Automation.SwitchParameter]
        $Force
    )

    process
    {
        if ($Force.IsPresent -and -not $Confirm)
        {
            $ConfirmPreference = 'None'
        }

        # Determine which principal object we're working with
        if ($PSCmdlet.ParameterSetName -eq 'Login')
        {
            $principalName = $Login.Name
            $serverObject = $Login.Parent
        }
        else
        {
            $principalName = $ServerRole.Name
            $serverObject = $ServerRole.Parent
        }

        $verboseDescriptionMessage = $script:localizedData.ServerPermission_Grant_ShouldProcessVerboseDescription -f $principalName, $serverObject.InstanceName, ($Permission -join ',')
        $verboseWarningMessage = $script:localizedData.ServerPermission_Grant_ShouldProcessVerboseWarning -f $principalName
        $captionMessage = $script:localizedData.ServerPermission_Grant_ShouldProcessCaption

        if ($PSCmdlet.ShouldProcess($verboseDescriptionMessage, $verboseWarningMessage, $captionMessage))
        {
            # Convert enum array to ServerPermissionSet object
            $permissionSet = [Microsoft.SqlServer.Management.Smo.ServerPermissionSet]::new()
            foreach ($permissionName in $Permission)
            {
                $permissionSet.$permissionName = $true
            }

            try
            {
                if ($WithGrant.IsPresent)
                {
                    $serverObject.Grant($permissionSet, $principalName, $true)
                }
                else
                {
                    $serverObject.Grant($permissionSet, $principalName)
                }
            }
            catch
            {
                $errorMessage = $script:localizedData.ServerPermission_Grant_FailedToGrantPermission -f $principalName, $serverObject.InstanceName, ($Permission -join ', ')

                $exception = [System.InvalidOperationException]::new($errorMessage, $_.Exception)

                $PSCmdlet.ThrowTerminatingError(
                    [System.Management.Automation.ErrorRecord]::new(
                        $exception,
                        'GSDSP0001', # cSpell: disable-line
                        [System.Management.Automation.ErrorCategory]::InvalidOperation,
                        $principalName
                    )
                )
            }
        }
    }
}
#EndRegion '.\Public\Grant-SqlDscServerPermission.ps1' 151
#Region '.\Public\Import-SqlDscPreferredModule.ps1' -1

<#
    .SYNOPSIS
        Imports a (preferred) module in a standardized way.

    .DESCRIPTION
        Imports a (preferred) module in a standardized way. If the parameter `Name`
        is not specified the command will imports the default module SqlServer
        if it exist, otherwise SQLPS.

        If the environment variable `SMODefaultModuleName` is set to a module name
        that name will be used as the preferred module name instead of the default
        module 'SqlServer'.

        The module is always imported globally.

    .PARAMETER Name
        Specifies the name of a preferred module.

    .PARAMETER Force
        Forces the removal of the previous module, to load the same or newer version
        fresh. This is meant to make sure the newest version is used, with the latest
        assemblies.

    .EXAMPLE
        Import-SqlDscPreferredModule

        Imports the default preferred module (SqlServer) if it exist, otherwise
        it will try to import the module SQLPS.

    .EXAMPLE
        Import-SqlDscPreferredModule -Force

        Will forcibly import the default preferred module if it exist, otherwise
        it will try to import the module SQLPS. Prior to importing it will remove
        an already loaded module.

    .EXAMPLE
        Import-SqlDscPreferredModule -Name 'OtherSqlModule'

        Imports the specified preferred module OtherSqlModule if it exist, otherwise
        it will try to import the module SQLPS.
#>
function Import-SqlDscPreferredModule
{
    [CmdletBinding()]
    param
    (
        [Parameter()]
        [Alias('PreferredModule')]
        [ValidateNotNullOrEmpty()]
        [System.String]
        $Name,

        [Parameter()]
        [System.Management.Automation.SwitchParameter]
        $Force
    )

    $getSqlDscPreferredModuleParameters = @{
        Refresh = $true
    }

    if ($PSBoundParameters.ContainsKey('Name'))
    {
        $getSqlDscPreferredModuleParameters.Name = @($Name, 'SQLPS')
    }

    if ($PSBoundParameters.ContainsKey('Force'))
    {
        $getSqlDscPreferredModuleParameters.Refresh = $true
    }

    $availableModule = $null

    $originalErrorActionPreference = $ErrorActionPreference

    $ErrorActionPreference = 'Stop'

    try
    {
        $availableModule = Get-SqlDscPreferredModule @getSqlDscPreferredModuleParameters -ErrorAction 'Stop'
    }
    catch
    {
        $PSCmdlet.ThrowTerminatingError(
            [System.Management.Automation.ErrorRecord]::new(
                ($script:localizedData.PreferredModule_FailedFinding),
                'ISDPM0001', # cspell: disable-line
                [System.Management.Automation.ErrorCategory]::ObjectNotFound,
                'PreferredModule'
            )
        )
    }
    finally
    {
        $ErrorActionPreference = $originalErrorActionPreference
    }

    if ($Force.IsPresent -and -not $Confirm)
    {
        Write-Verbose -Message $script:localizedData.PreferredModule_ForceRemoval

        $removeModule = @()

        if ($PSBoundParameters.ContainsKey('Name'))
        {
            $removeModule += Get-Module -Name $Name
        }

        # Available module could be
        if ($availableModule)
        {
            $removeModule += $availableModule
        }

        if ($removeModule -contains 'SQLPS')
        {
            $removeModule += Get-Module -Name 'SQLASCmdlets' # cSpell: disable-line
        }

        Remove-Module -ModuleInfo $removeModule -Force -ErrorAction 'SilentlyContinue'
    }
    else
    {
        <#
            Check if the preferred module is already loaded into the session.
        #>
        $loadedModule = Get-Module -Name $availableModule.Name | Select-Object -First 1

        if ($loadedModule)
        {
            Write-Verbose -Message ($script:localizedData.PreferredModule_AlreadyImported -f $loadedModule.Name)

            return
        }
    }

    try
    {
        Write-Debug -Message ($script:localizedData.PreferredModule_PushingLocation)

        Push-Location

        $originalErrorActionPreference = $ErrorActionPreference

        $ErrorActionPreference = 'Stop'

        <#
            SQLPS has unapproved verbs, disable checking to ignore Warnings.
            Suppressing verbose so all cmdlet is not listed.
        #>
        $importedModule = Import-Module -ModuleInfo $availableModule -DisableNameChecking -Verbose:$false -Force:$Force -Global -PassThru -ErrorAction 'Stop'

        $ErrorActionPreference = $originalErrorActionPreference

        <#
            SQLPS returns two entries, one with module type 'Script' and another with module type 'Manifest'.
            Only return the object with module type 'Manifest'.
            SqlServer only returns one object (of module type 'Script'), so no need to do anything for SqlServer module.
        #>
        if ($availableModule.Name -eq 'SQLPS')
        {
            $importedModule = $importedModule | Where-Object -Property 'ModuleType' -EQ -Value 'Manifest'
        }

        Write-Verbose -Message ($script:localizedData.PreferredModule_ImportedModule -f $importedModule.Name, $importedModule.Version, $importedModule.Path)
    }
    finally
    {
        Write-Debug -Message ($script:localizedData.PreferredModule_PoppingLocation)

        Pop-Location
    }
}
#EndRegion '.\Public\Import-SqlDscPreferredModule.ps1' 175
#Region '.\Public\Initialize-SqlDscRebuildDatabase.ps1' -1

<#
    .SYNOPSIS
        Rebuilds the system databases for an SQL Server instance.

    .DESCRIPTION
        Rebuilds the system databases for an SQL Server instance.

        See the link in the commands help for information on each parameter. The
        link points to SQL Server command line setup documentation.

    .PARAMETER MediaPath
        Specifies the path where to find the SQL Server installation media. On this
        path the SQL Server setup executable must be found.

    .PARAMETER Timeout
        Specifies how long to wait for the setup process to finish. Default value
        is `7200` seconds (2 hours). If the setup process does not finish before
        this time, an exception will be thrown.

    .PARAMETER Force
        If specified the command will not ask for confirmation. Same as if Confirm:$false
        is used.

    .PARAMETER InstanceName
        See the notes section for more information.

    .PARAMETER SAPwd
        See the notes section for more information.

    .PARAMETER SqlCollation
        See the notes section for more information.

    .PARAMETER SqlSysAdminAccounts
        See the notes section for more information.

    .PARAMETER SqlTempDbDir
        See the notes section for more information.

    .PARAMETER SqlTempDbLogDir
        See the notes section for more information.

    .PARAMETER SqlTempDbFileCount
        See the notes section for more information.

    .PARAMETER SqlTempDbFileSize
        See the notes section for more information.

    .PARAMETER SqlTempDbFileGrowth
        See the notes section for more information.

    .PARAMETER SqlTempDbLogFileSize
        See the notes section for more information.

    .PARAMETER SqlTempDbLogFileGrowth
        See the notes section for more information.

    .LINK
        https://docs.microsoft.com/en-us/sql/database-engine/install-windows/install-sql-server-from-the-command-prompt

    .OUTPUTS
        None.

    .EXAMPLE
        Initialize-SqlDscRebuildDatabase -InstanceName 'MyInstance' -SqlSysAdminAccounts @('MyAdminAccount') -MediaPath 'E:\'

        Rebuilds the database of the instance 'MyInstance'.

    .NOTES
        The parameters are intentionally not described since it would take a lot
        of effort to keep them up to date. Instead there is a link that points to
        the SQL Server command line setup documentation which will stay relevant.

        For RebuildDatabase the parameter SAPwd must be set if the instance was
        installed with SecurityMode = 'SQL'.
#>
function Initialize-SqlDscRebuildDatabase
{
    [System.Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSShouldProcess', '', Justification = 'Because ShouldProcess is used in Invoke-SetupAction')]
    [CmdletBinding(SupportsShouldProcess = $true, ConfirmImpact = 'High')]
    [OutputType()]
    param
    (
        [Parameter(Mandatory = $true)]
        [System.String]
        $MediaPath,

        [Parameter(Mandatory = $true)]
        [System.String]
        $InstanceName,

        [Parameter()]
        [System.Security.SecureString]
        $SAPwd,

        [Parameter()]
        [System.String]
        $SqlCollation,

        [Parameter(Mandatory = $true)]
        [System.String[]]
        $SqlSysAdminAccounts,

        [Parameter()]
        [System.String]
        $SqlTempDbDir,

        [Parameter()]
        [System.String]
        $SqlTempDbLogDir,

        [Parameter()]
        [System.UInt16]
        $SqlTempDbFileCount,

        [Parameter()]
        [ValidateRange(4, 262144)]
        [System.UInt16]
        $SqlTempDbFileSize,

        [Parameter()]
        [ValidateRange(0, 1024)]
        [System.UInt16]
        $SqlTempDbFileGrowth,

        [Parameter()]
        [ValidateRange(4, 262144)]
        [System.UInt16]
        $SqlTempDbLogFileSize,

        [Parameter()]
        [ValidateRange(0, 1024)]
        [System.UInt16]
        $SqlTempDbLogFileGrowth,

        [Parameter()]
        [System.UInt32]
        $Timeout = 7200,

        [Parameter()]
        [System.Management.Automation.SwitchParameter]
        $Force
    )

    Invoke-SetupAction -RebuildDatabase @PSBoundParameters
}
#EndRegion '.\Public\Initialize-SqlDscRebuildDatabase.ps1' 146
#Region '.\Public\Install-SqlDscBIReportServer.ps1' -1

<#
    .SYNOPSIS
        Installs SQL Server Power BI Report Server.

    .DESCRIPTION
        Installs SQL Server Power BI Report Server using the provided setup executable.

    .PARAMETER AcceptLicensingTerms
        Specifies that the acceptance of all license terms and notices for the
        specified features is required to be able to run unattended install. By specifying this
        parameter you acknowledge the acceptance of all license terms and notices for
        the specified features, the terms and notices that the setup executable
        normally asks for.

    .PARAMETER MediaPath
        Specifies the path where to find the SQL Server installation media. On this
        path the SQL Server setup executable must be found.

    .PARAMETER ProductKey
        Specifies the product key to use for the installation, e.g. '12345-12345-12345-12345-12345'.
        This parameter is mutually exclusive with the parameter Edition.

    .PARAMETER EditionUpgrade
        Specifies whether to upgrade the edition of the installed product. Requires that either the
        ProductKey or the Edition parameter is also assigned. By default no edition
        upgrade is performed.

    .PARAMETER Edition
        Specifies a free custom edition to use for the installation. This parameter
        is mutually exclusive with the parameter ProductKey.

    .PARAMETER LogPath
        Specifies the file path where to write the log files, e.g. 'C:\Logs\Install.log'.
        By default log files are created under %TEMP%.

    .PARAMETER InstallFolder
        Specifies the folder where to install the product, e.g. 'C:\Program Files\Power BI Report Server'.
        By default the product is installed under the default installation folder.

        Reporting Services: %ProgramFiles%\Microsoft SQL Server Reporting Services
        PI Report Server: %ProgramFiles%\Microsoft Power BI Report Server

    .PARAMETER SuppressRestart
        Specifies whether to suppress the restart of the computer after the installation is finished.
        By default the computer is restarted after the installation is finished.

    .PARAMETER Timeout
        Specifies how long to wait for the setup process to finish. Default value
        is `7200` seconds (2 hours). If the setup process does not finish before
        this time, an exception will be thrown.

    .PARAMETER Force
        Specifies whether the command will not ask for confirmation. Same as if Confirm:$false
        is used.

    .PARAMETER PassThru
        Specifies whether the command will return the setup process exit code.

    .OUTPUTS
        When PassThru is specified the function will return the setup process exit
        code as System.Int32. Otherwise, the function does not generate any output.

    .EXAMPLE
        Install-SqlDscBIReportServer -AcceptLicensingTerms -MediaPath 'E:\PowerBIReportServer.exe'

        Installs Power BI Report Server with default settings.

    .EXAMPLE
        Install-SqlDscBIReportServer -AcceptLicensingTerms -MediaPath 'E:\PowerBIReportServer.exe' -ProductKey '12345-12345-12345-12345-12345'

        Installs Power BI Report Server using a product key.

    .EXAMPLE
        Install-SqlDscBIReportServer -AcceptLicensingTerms -MediaPath 'E:\PowerBIReportServer.exe' -Edition 'Evaluation' -InstallFolder 'C:\Program Files\Power BI Report Server'

        Installs Power BI Report Server in evaluation edition to a custom folder.

    .EXAMPLE
        Install-SqlDscBIReportServer -AcceptLicensingTerms -MediaPath 'E:\PowerBIReportServer.exe' -ProductKey '12345-12345-12345-12345-12345' -EditionUpgrade -LogPath 'C:\Logs\PowerBIReportServer_Install.log'

        Installs Power BI Report Server and upgrades the edition using a product key. Also specifies a custom log path.

    .EXAMPLE
        $exitCode = Install-SqlDscBIReportServer -AcceptLicensingTerms -MediaPath 'E:\PowerBIReportServer.exe' -PassThru

        Installs Power BI Report Server with default settings and returns the setup exit code.
#>
function Install-SqlDscBIReportServer
{
    [System.Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSShouldProcess', '', Justification = 'Because ShouldProcess is used in Invoke-SetupAction')]
    [CmdletBinding(SupportsShouldProcess = $true, ConfirmImpact = 'High')]
    [OutputType([System.Int32])]
    param
    (
        [Parameter(Mandatory = $true)]
        [System.Management.Automation.SwitchParameter]
        $AcceptLicensingTerms,

        [Parameter(Mandatory = $true)]
        [System.String]
        $MediaPath,

        [Parameter()]
        [System.String]
        $ProductKey,

        [Parameter()]
        [System.Management.Automation.SwitchParameter]
        $EditionUpgrade,

        [Parameter()]
        [ValidateSet('Developer', 'Evaluation', 'ExpressAdvanced')]
        [System.String]
        $Edition,

        [Parameter()]
        [System.String]
        $LogPath,

        [Parameter()]
        [System.String]
        $InstallFolder,

        [Parameter()]
        [System.Management.Automation.SwitchParameter]
        $SuppressRestart,

        [Parameter()]
        [System.UInt32]
        $Timeout = 7200,

        [Parameter()]
        [System.Management.Automation.SwitchParameter]
        $Force,

        [Parameter()]
        [System.Management.Automation.SwitchParameter]
        $PassThru
    )

    $exitCode = Invoke-ReportServerSetupAction -Install @PSBoundParameters

    if ($PassThru.IsPresent)
    {
        return $exitCode
    }
}
#EndRegion '.\Public\Install-SqlDscBIReportServer.ps1' 148
#Region '.\Public\Install-SqlDscReportingService.ps1' -1

<#
    .SYNOPSIS
        Installs SQL Server Reporting Services or Power BI Report Server.

    .DESCRIPTION
        Installs SQL Server Reporting Services or Power BI Report Server using
        the provided setup executable.

    .PARAMETER AcceptLicensingTerms
        Required parameter to be able to run unattended install. By specifying this
        parameter you acknowledge the acceptance of all license terms and notices for
        the specified features, the terms and notices that the setup executable
        normally asks for.

    .PARAMETER MediaPath
        Specifies the path where to find the SQL Server installation media. On this
        path the SQL Server setup executable must be found.

    .PARAMETER ProductKey
        Specifies the product key to use for the installation, e.g. '12345-12345-12345-12345-12345'.
        This parameter is mutually exclusive with the parameter Edition.

    .PARAMETER EditionUpgrade
        Upgrades the edition of the installed product. Requires that either the
        ProductKey or the Edition parameter is also assigned. By default no edition
        upgrade is performed.

    .PARAMETER Edition
        Specifies a free custom edition to use for the installation. This parameter
        is mutually exclusive with the parameter ProductKey.

    .PARAMETER LogPath
        Specifies the file path where to write the log files, e.g. 'C:\Logs\Install.log'.
        By default log files are created under %TEMP%.

    .PARAMETER InstallFolder
        Specifies the folder where to install the product, e.g. 'C:\Program Files\SSRS'.
        By default the product is installed under the default installation folder.

        Reporting Services: %ProgramFiles%\Microsoft SQL Server Reporting Services
        PI Report Server: %ProgramFiles%\Microsoft Power BI Report Server

    .PARAMETER SuppressRestart
        Suppresses the restart of the computer after the installation is finished.
        By default the computer is restarted after the installation is finished.

    .PARAMETER Timeout
        Specifies how long to wait for the setup process to finish. Default value
        is `7200` seconds (2 hours). If the setup process does not finish before
        this time, an exception will be thrown.

    .PARAMETER Force
        If specified the command will not ask for confirmation. Same as if Confirm:$false
        is used.

    .PARAMETER PassThru
        If specified the command will return the setup process exit code.

    .OUTPUTS
        When PassThru is specified the function will return the setup process exit
        code as System.Int32. Otherwise, the function does not generate any output.

    .EXAMPLE
        Install-SqlDscReportingService -AcceptLicensingTerms -MediaPath 'E:\SQLServerReportingServices.exe'

        Installs SQL Server Reporting Services with default settings.

    .EXAMPLE
        Install-SqlDscReportingService -AcceptLicensingTerms -MediaPath 'E:\SQLServerReportingServices.exe' -ProductKey '12345-12345-12345-12345-12345'

        Installs SQL Server Reporting Services using a product key.

    .EXAMPLE
        Install-SqlDscReportingService -AcceptLicensingTerms -MediaPath 'E:\PowerBIReportServer.exe' -Edition 'Evaluation' -InstallFolder 'C:\Program Files\Power BI Report Server'

        Installs Power BI Report Server in evaluation edition to a custom folder.

    .EXAMPLE
        Install-SqlDscReportingService -AcceptLicensingTerms -MediaPath 'E:\SQLServerReportingServices.exe' -ProductKey '12345-12345-12345-12345-12345' -EditionUpgrade -LogPath 'C:\Logs\SSRS_Install.log'

        Installs SQL Server Reporting Services and upgrades the edition using a
        product key. Also specifies a custom log path.

    .EXAMPLE
        $exitCode = Install-SqlDscReportingService -AcceptLicensingTerms -MediaPath 'E:\SQLServerReportingServices.exe' -PassThru

        Installs SQL Server Reporting Services with default settings and returns the setup exit code.
#>
function Install-SqlDscReportingService
{
    [System.Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSShouldProcess', '', Justification = 'Because ShouldProcess is used in Invoke-SetupAction')]
    [CmdletBinding(SupportsShouldProcess = $true, ConfirmImpact = 'High')]
    [OutputType([System.Int32])]
    param
    (
        [Parameter(Mandatory = $true)]
        [System.Management.Automation.SwitchParameter]
        $AcceptLicensingTerms,

        [Parameter(Mandatory = $true)]
        [System.String]
        $MediaPath,

        [Parameter()]
        [System.String]
        $ProductKey,

        [Parameter()]
        [System.Management.Automation.SwitchParameter]
        $EditionUpgrade,

        [Parameter()]
        [ValidateSet('Developer', 'Evaluation', 'ExpressAdvanced')]
        [System.String]
        $Edition,

        [Parameter()]
        [System.String]
        $LogPath,

        [Parameter()]
        [System.String]
        $InstallFolder,

        [Parameter()]
        [System.Management.Automation.SwitchParameter]
        $SuppressRestart,

        [Parameter()]
        [System.UInt32]
        $Timeout = 7200,

        [Parameter()]
        [System.Management.Automation.SwitchParameter]
        $Force,

        [Parameter()]
        [System.Management.Automation.SwitchParameter]
        $PassThru
    )

    $exitCode = Invoke-ReportServerSetupAction -Install @PSBoundParameters

    if ($PassThru.IsPresent)
    {
        return $exitCode
    }
}
#EndRegion '.\Public\Install-SqlDscReportingService.ps1' 149
#Region '.\Public\Install-SqlDscServer.ps1' -1

<#
    .SYNOPSIS
        Executes an setup action using Microsoft SQL Server setup executable.

    .DESCRIPTION
        Executes an setup action using Microsoft SQL Server setup executable.

        See the link in the commands help for information on each parameter. The
        link points to SQL Server command line setup documentation.

    .PARAMETER Install
        Specifies the setup action Install.

    .PARAMETER Uninstall
        Specifies the setup action Uninstall.

    .PARAMETER PrepareImage
        Specifies the setup action PrepareImage.

    .PARAMETER Upgrade
        Specifies the setup action Upgrade.

    .PARAMETER EditionUpgrade
        Specifies the setup action EditionUpgrade.

    .PARAMETER InstallFailoverCluster
        Specifies the setup action InstallFailoverCluster.

    .PARAMETER PrepareFailoverCluster
        Specifies the setup action PrepareFailoverCluster.

    .PARAMETER ConfigurationFile
        Specifies an configuration file to use during SQL Server setup. This
        parameter cannot be used together with any of the setup actions, but instead
        it is expected that the configuration file specifies what setup action to
        run.

    .PARAMETER AcceptLicensingTerms
        Required parameter to be able to run unattended install. By specifying this
        parameter you acknowledge the acceptance all license terms and notices for
        the specified features, the terms and notices that the Microsoft SQL Server
        setup executable normally ask for.

    .PARAMETER MediaPath
        Specifies the path where to find the SQL Server installation media. On this
        path the SQL Server setup executable must be found.

    .PARAMETER Timeout
        Specifies how long to wait for the setup process to finish. Default value
        is `7200` seconds (2 hours). If the setup process does not finish before
        this time, an exception will be thrown.

    .PARAMETER Force
        If specified the command will not ask for confirmation. Same as if Confirm:$false
        is used.

    .PARAMETER SuppressPrivacyStatementNotice
        See the notes section for more information.

    .PARAMETER IAcknowledgeEntCalLimits
        See the notes section for more information.

    .PARAMETER InstanceName
        See the notes section for more information.

    .PARAMETER Enu
        See the notes section for more information.

    .PARAMETER UpdateEnabled
        See the notes section for more information.

    .PARAMETER UpdateSource
        See the notes section for more information.

    .PARAMETER Features
        See the notes section for more information.

    .PARAMETER Role
        See the notes section for more information.

    .PARAMETER InstallSharedDir
        See the notes section for more information.

    .PARAMETER InstallSharedWowDir
        See the notes section for more information.

    .PARAMETER InstanceDir
        See the notes section for more information.

    .PARAMETER InstanceId
        See the notes section for more information.

    .PARAMETER PBEngSvcAccount
        See the notes section for more information.

    .PARAMETER PBEngSvcPassword
        See the notes section for more information.

    .PARAMETER PBEngSvcStartupType
        See the notes section for more information.

    .PARAMETER PBDMSSvcAccount
        See the notes section for more information.

    .PARAMETER PBDMSSvcPassword
        See the notes section for more information.

    .PARAMETER PBDMSSvcStartupType
        See the notes section for more information.

    .PARAMETER PBStartPortRange
        See the notes section for more information.

    .PARAMETER PBEndPortRange
        See the notes section for more information.

    .PARAMETER PBScaleOut
        See the notes section for more information.

    .PARAMETER ProductKey
        See the notes section for more information.

    .PARAMETER AgtSvcAccount
        See the notes section for more information.

    .PARAMETER AgtSvcPassword
        See the notes section for more information.

    .PARAMETER AgtSvcStartupType
        See the notes section for more information.

    .PARAMETER ASBackupDir
        See the notes section for more information.

    .PARAMETER ASCollation
        See the notes section for more information.

    .PARAMETER ASConfigDir
        See the notes section for more information.

    .PARAMETER ASDataDir
        See the notes section for more information.

    .PARAMETER ASLogDir
        See the notes section for more information.

    .PARAMETER ASTempDir
        See the notes section for more information.

    .PARAMETER ASServerMode
        See the notes section for more information.

    .PARAMETER ASSvcAccount
        See the notes section for more information.

    .PARAMETER ASSvcPassword
        See the notes section for more information.

    .PARAMETER ASSvcStartupType
        See the notes section for more information.

    .PARAMETER ASSysAdminAccounts
        See the notes section for more information.

    .PARAMETER ASProviderMSOLAP
        See the notes section for more information.

    .PARAMETER FarmAccount
        See the notes section for more information.

    .PARAMETER FarmPassword
        See the notes section for more information.

    .PARAMETER Passphrase
        See the notes section for more information.

    .PARAMETER FarmAdminiPort
        See the notes section for more information.

    .PARAMETER BrowserSvcStartupType
        See the notes section for more information.

    .PARAMETER FTUpgradeOption
        See the notes section for more information.

    .PARAMETER EnableRanU
        See the notes section for more information.

    .PARAMETER InstallSqlDataDir
        See the notes section for more information.

    .PARAMETER SqlBackupDir
        See the notes section for more information.

    .PARAMETER SecurityMode
        See the notes section for more information.

    .PARAMETER SAPwd
        See the notes section for more information.

    .PARAMETER SqlCollation
        See the notes section for more information.

    .PARAMETER AddCurrentUserAsSqlAdmin
        See the notes section for more information.

    .PARAMETER SqlSvcAccount
        See the notes section for more information.

    .PARAMETER SqlSvcPassword
        See the notes section for more information.

    .PARAMETER SqlSvcStartupType
        See the notes section for more information.

    .PARAMETER SqlSysAdminAccounts
        See the notes section for more information.

    .PARAMETER SqlTempDbDir
        See the notes section for more information.

    .PARAMETER SqlTempDbLogDir
        See the notes section for more information.

    .PARAMETER SqlTempDbFileCount
        See the notes section for more information.

    .PARAMETER SqlTempDbFileSize
        See the notes section for more information.

    .PARAMETER SqlTempDbFileGrowth
        See the notes section for more information.

    .PARAMETER SqlTempDbLogFileSize
        See the notes section for more information.

    .PARAMETER SqlTempDbLogFileGrowth
        See the notes section for more information.

    .PARAMETER SqlUserDbDir
        See the notes section for more information.

    .PARAMETER SqlSvcInstantFileInit
        See the notes section for more information.

    .PARAMETER SqlUserDbLogDir
        See the notes section for more information.

    .PARAMETER SqlMaxDop
        See the notes section for more information.

    .PARAMETER UseSqlRecommendedMemoryLimits
        See the notes section for more information.

    .PARAMETER SqlMinMemory
        See the notes section for more information.

    .PARAMETER SqlMaxMemory
        See the notes section for more information.

    .PARAMETER FileStreamLevel
        See the notes section for more information.

    .PARAMETER FileStreamShareName
        See the notes section for more information.

    .PARAMETER ISSvcAccount
        See the notes section for more information.

    .PARAMETER ISSvcPassword
        See the notes section for more information.

    .PARAMETER ISSvcStartupType
        See the notes section for more information.

    .PARAMETER AllowUpgradeForSSRSSharePointMode
        See the notes section for more information.

    .PARAMETER NpEnabled
        See the notes section for more information.

    .PARAMETER TcpEnabled
        See the notes section for more information.

    .PARAMETER RsInstallMode
        See the notes section for more information.

    .PARAMETER RSSvcAccount
        See the notes section for more information.

    .PARAMETER RSSvcPassword
        See the notes section for more information.

    .PARAMETER RSSvcStartupType
        See the notes section for more information.

    .PARAMETER MPYCacheDirectory
        See the notes section for more information.

    .PARAMETER MRCacheDirectory
        See the notes section for more information.

    .PARAMETER SqlInstJava
        See the notes section for more information.

    .PARAMETER SqlJavaDir
        See the notes section for more information.

    .PARAMETER FailoverClusterGroup
        See the notes section for more information.

    .PARAMETER FailoverClusterDisks
        See the notes section for more information.

    .PARAMETER FailoverClusterNetworkName
        See the notes section for more information.

    .PARAMETER FailoverClusterIPAddresses
        See the notes section for more information.

    .PARAMETER FailoverClusterRollOwnership
        See the notes section for more information.

    .PARAMETER AzureSubscriptionId
        See the notes section for more information.

    .PARAMETER AzureResourceGroup
        See the notes section for more information.

    .PARAMETER AzureRegion
        See the notes section for more information.

    .PARAMETER AzureTenantId
        See the notes section for more information.

    .PARAMETER AzureServicePrincipal
        See the notes section for more information.

    .PARAMETER AzureServicePrincipalSecret
        See the notes section for more information.

    .PARAMETER AzureArcProxy
        See the notes section for more information.

    .PARAMETER SkipRules
        See the notes section for more information.

    .PARAMETER ProductCoveredBySA
        See the notes section for more information.

    .LINK
        https://docs.microsoft.com/en-us/sql/database-engine/install-windows/install-sql-server-from-the-command-prompt

    .OUTPUTS
        None.

    .EXAMPLE
        Install-SqlDscServer -Install -AcceptLicensingTerms -InstanceName 'MyInstance' -Features 'SQLENGINE' -SqlSysAdminAccounts @('MyAdminAccount') -MediaPath 'E:\'

        Installs the database engine for the named instance MyInstance.

    .EXAMPLE
        Install-SqlDscServer -Install -AcceptLicensingTerms -InstanceName 'MyInstance' -Features 'SQLENGINE','ARC' -SqlSysAdminAccounts @('MyAdminAccount') -MediaPath 'E:\' -AzureSubscriptionId 'MySubscriptionId' -AzureResourceGroup 'MyRG' -AzureRegion 'West-US' -AzureTenantId 'MyTenantId' -AzureServicePrincipal 'MyPrincipalName' -AzureServicePrincipalSecret ('MySecret' | ConvertTo-SecureString -AsPlainText -Force)

        Installs the database engine for the named instance MyInstance and onboard the server to Azure Arc.

    .EXAMPLE
        Install-SqlDscServer -Install -AcceptLicensingTerms -MediaPath 'E:\' -AzureSubscriptionId 'MySubscriptionId' -AzureResourceGroup 'MyRG' -AzureRegion 'West-US' -AzureTenantId 'MyTenantId' -AzureServicePrincipal 'MyPrincipalName' -AzureServicePrincipalSecret ('MySecret' | ConvertTo-SecureString -AsPlainText -Force)

        Installs the Azure Arc Agent on the server.

    .EXAMPLE
        Install-SqlDscServer -ConfigurationFile 'MySqlConfig.ini' -MediaPath 'E:\'

        Installs SQL Server using the configuration file 'MySqlConfig.ini'.

    .EXAMPLE
        Install-SqlDscServer -PrepareImage -AcceptLicensingTerms -Features 'SQLENGINE' -InstanceId 'MyInstance' -MediaPath 'E:\'

        Prepares the server for using the database engine for an instance named 'MyInstance'.

    .EXAMPLE
        Install-SqlDscServer -Upgrade -AcceptLicensingTerms -InstanceName 'MyInstance' -MediaPath 'E:\'

        Upgrades the instance 'MyInstance' with the SQL Server version that is provided by the media path.

    .EXAMPLE
        Install-SqlDscServer -EditionUpgrade -AcceptLicensingTerms -ProductKey 'NewEditionProductKey' -InstanceName 'MyInstance' -MediaPath 'E:\'

        Upgrades the instance 'MyInstance' with the SQL Server edition that is provided by the media path.

    .EXAMPLE
        Install-SqlDscServer -InstallFailoverCluster -AcceptLicensingTerms -InstanceName 'MyInstance' -Features 'SQLENGINE' -InstallSqlDataDir 'D:\MSSQL\Data' -SqlSysAdminAccounts @('MyAdminAccount') -FailoverClusterNetworkName 'TestCluster01A' -FailoverClusterIPAddresses 'IPv4;192.168.0.46;ClusterNetwork1;255.255.255.0' -MediaPath 'E:\'

        Installs the database engine in a failover cluster with the instance name 'MyInstance'.

    .EXAMPLE
        Install-SqlDscServer -PrepareFailoverCluster -AcceptLicensingTerms -InstanceName 'MyInstance' -Features 'SQLENGINE' -MediaPath 'E:\'

        Prepares to installs the database engine in a failover cluster with the instance name 'MyInstance'.

    .NOTES
        The parameters are intentionally not described since it would take a lot
        of effort to keep them up to date. Instead there is a link that points to
        the SQL Server command line setup documentation which will stay relevant.
#>
function Install-SqlDscServer
{
    # cSpell: ignore PBDMS Admini AZUREEXTENSION
    [System.Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSShouldProcess', '', Justification = 'Because ShouldProcess is used in Invoke-SetupAction')]
    [CmdletBinding(SupportsShouldProcess = $true, ConfirmImpact = 'High')]
    [OutputType()]
    param
    (
        [Parameter(ParameterSetName = 'Install', Mandatory = $true)]
        [Parameter(ParameterSetName = 'InstallRole', Mandatory = $true)]
        [Parameter(ParameterSetName = 'InstallAzureArcAgent', Mandatory = $true)]
        [System.Management.Automation.SwitchParameter]
        $Install,

        [Parameter(ParameterSetName = 'PrepareImage', Mandatory = $true)]
        [System.Management.Automation.SwitchParameter]
        $PrepareImage,

        [Parameter(ParameterSetName = 'Upgrade', Mandatory = $true)]
        [System.Management.Automation.SwitchParameter]
        $Upgrade,

        [Parameter(ParameterSetName = 'EditionUpgrade', Mandatory = $true)]
        [System.Management.Automation.SwitchParameter]
        $EditionUpgrade,

        [Parameter(ParameterSetName = 'InstallFailoverCluster', Mandatory = $true)]
        [System.Management.Automation.SwitchParameter]
        $InstallFailoverCluster,

        [Parameter(ParameterSetName = 'PrepareFailoverCluster', Mandatory = $true)]
        [System.Management.Automation.SwitchParameter]
        $PrepareFailoverCluster,

        [Parameter(ParameterSetName = 'UsingConfigurationFile', Mandatory = $true)]
        [System.String]
        $ConfigurationFile,

        [Parameter(ParameterSetName = 'Install', Mandatory = $true)]
        [Parameter(ParameterSetName = 'InstallRole', Mandatory = $true)]
        [Parameter(ParameterSetName = 'InstallAzureArcAgent', Mandatory = $true)]
        [Parameter(ParameterSetName = 'PrepareImage', Mandatory = $true)]
        [Parameter(ParameterSetName = 'Upgrade', Mandatory = $true)]
        [Parameter(ParameterSetName = 'EditionUpgrade', Mandatory = $true)]
        [Parameter(ParameterSetName = 'InstallFailoverCluster', Mandatory = $true)]
        [Parameter(ParameterSetName = 'PrepareFailoverCluster', Mandatory = $true)]
        [System.Management.Automation.SwitchParameter]
        $AcceptLicensingTerms,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [System.Management.Automation.SwitchParameter]
        $SuppressPrivacyStatementNotice,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [Parameter(ParameterSetName = 'PrepareImage')]
        [Parameter(ParameterSetName = 'InstallFailoverCluster')]
        [Parameter(ParameterSetName = 'PrepareFailoverCluster')]
        [System.Management.Automation.SwitchParameter]
        $IAcknowledgeEntCalLimits,

        [Parameter(Mandatory = $true)]
        [System.String]
        $MediaPath,

        [Parameter(ParameterSetName = 'Install', Mandatory = $true)]
        [Parameter(ParameterSetName = 'Upgrade', Mandatory = $true)]
        [Parameter(ParameterSetName = 'EditionUpgrade', Mandatory = $true)]
        [Parameter(ParameterSetName = 'InstallFailoverCluster', Mandatory = $true)]
        [Parameter(ParameterSetName = 'PrepareFailoverCluster', Mandatory = $true)]
        [Parameter(ParameterSetName = 'InstallRole')]
        [System.String]
        $InstanceName,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [Parameter(ParameterSetName = 'PrepareImage')]
        [Parameter(ParameterSetName = 'Upgrade')]
        [Parameter(ParameterSetName = 'InstallFailoverCluster')]
        [Parameter(ParameterSetName = 'PrepareFailoverCluster')]
        [System.Management.Automation.SwitchParameter]
        $Enu,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [Parameter(ParameterSetName = 'PrepareImage')]
        [Parameter(ParameterSetName = 'Upgrade')]
        [Parameter(ParameterSetName = 'InstallFailoverCluster')]
        [Parameter(ParameterSetName = 'PrepareFailoverCluster')]
        [System.Management.Automation.SwitchParameter]
        $UpdateEnabled,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [Parameter(ParameterSetName = 'PrepareImage')]
        [Parameter(ParameterSetName = 'Upgrade')]
        [Parameter(ParameterSetName = 'InstallFailoverCluster')]
        [Parameter(ParameterSetName = 'PrepareFailoverCluster')]
        [System.String]
        $UpdateSource,

        [Parameter(ParameterSetName = 'Install', Mandatory = $true)]
        [Parameter(ParameterSetName = 'PrepareImage', Mandatory = $true)]
        [Parameter(ParameterSetName = 'InstallFailoverCluster', Mandatory = $true)]
        [Parameter(ParameterSetName = 'PrepareFailoverCluster', Mandatory = $true)]
        [Parameter(ParameterSetName = 'InstallRole')]
        [ValidateSet(
            'SQL',
            'SQLEngine', # Part of parent feature SQL
            'Replication', # Part of parent feature SQL
            'FullText', # Part of parent feature SQL
            'DQ', # Part of parent feature SQL
            'PolyBase', # Part of parent feature SQL
            'PolyBaseCore', # Part of parent feature SQL
            'PolyBaseJava', # Part of parent feature SQL
            'AdvancedAnalytics', # Part of parent feature SQL
            'SQL_INST_MR', # Part of parent feature SQL
            'SQL_INST_MPY', # Part of parent feature SQL
            'SQL_INST_JAVA', # Part of parent feature SQL
            'AS',
            'RS',
            'RS_SHP',
            'RS_SHPWFE', # cspell: disable-line
            'DQC',
            'IS',
            'IS_Master', # Part of parent feature IS
            'IS_Worker', # Part of parent feature IS
            'MDS',
            'SQL_SHARED_MPY',
            'SQL_SHARED_MR',
            'Tools',
            'BC', # Part of parent feature Tools
            'Conn', # Part of parent feature Tools
            'DREPLAY_CTLR', # Part of parent feature Tools (cspell: disable-line)
            'DREPLAY_CLT', # Part of parent feature Tools (cspell: disable-line)
            'SNAC_SDK', # Part of parent feature Tools (cspell: disable-line)
            'SDK', # Part of parent feature Tools
            'LocalDB', # Part of parent feature Tools
            'AZUREEXTENSION'
        )]
        [System.String[]]
        $Features,

        [Parameter(ParameterSetName = 'InstallRole', Mandatory = $true)]
        [ValidateSet(
            'ALLFeatures_WithDefaults',
            'SPI_AS_NewFarm',
            'SPI_AS_ExistingFarm'
        )]
        [System.String]
        $Role,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [Parameter(ParameterSetName = 'PrepareImage')]
        [Parameter(ParameterSetName = 'InstallFailoverCluster')]
        [Parameter(ParameterSetName = 'PrepareFailoverCluster')]
        [System.String]
        $InstallSharedDir,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [Parameter(ParameterSetName = 'PrepareImage')]
        [Parameter(ParameterSetName = 'InstallFailoverCluster')]
        [Parameter(ParameterSetName = 'PrepareFailoverCluster')]
        [System.String]
        $InstallSharedWowDir,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [Parameter(ParameterSetName = 'PrepareImage')]
        [Parameter(ParameterSetName = 'Upgrade')]
        [Parameter(ParameterSetName = 'InstallFailoverCluster')]
        [Parameter(ParameterSetName = 'PrepareFailoverCluster')]
        [System.String]
        $InstanceDir,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [Parameter(ParameterSetName = 'PrepareImage')]
        [Parameter(ParameterSetName = 'Upgrade')]
        [Parameter(ParameterSetName = 'InstallFailoverCluster')]
        [Parameter(ParameterSetName = 'PrepareFailoverCluster')]
        [System.String]
        $InstanceId,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [Parameter(ParameterSetName = 'PrepareImage')]
        [Parameter(ParameterSetName = 'InstallFailoverCluster')]
        [Parameter(ParameterSetName = 'PrepareFailoverCluster')]
        [System.String]
        $PBEngSvcAccount,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [Parameter(ParameterSetName = 'PrepareImage')]
        [Parameter(ParameterSetName = 'InstallFailoverCluster')]
        [Parameter(ParameterSetName = 'PrepareFailoverCluster')]
        [System.Security.SecureString]
        $PBEngSvcPassword,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [Parameter(ParameterSetName = 'PrepareImage')]
        [Parameter(ParameterSetName = 'InstallFailoverCluster')]
        [Parameter(ParameterSetName = 'PrepareFailoverCluster')]
        [ValidateSet('Automatic', 'Disabled', 'Manual')]
        [System.String]
        $PBEngSvcStartupType,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [System.String]
        $PBDMSSvcAccount, # cspell: disable-line

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [System.Security.SecureString]
        $PBDMSSvcPassword, # cspell: disable-line

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [ValidateSet('Automatic', 'Disabled', 'Manual')]
        [System.String]
        $PBDMSSvcStartupType, # cspell: disable-line

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [Parameter(ParameterSetName = 'PrepareImage')]
        [Parameter(ParameterSetName = 'InstallFailoverCluster')]
        [Parameter(ParameterSetName = 'PrepareFailoverCluster')]
        [System.UInt16]
        $PBStartPortRange,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [Parameter(ParameterSetName = 'PrepareImage')]
        [Parameter(ParameterSetName = 'InstallFailoverCluster')]
        [Parameter(ParameterSetName = 'PrepareFailoverCluster')]
        [System.UInt16]
        $PBEndPortRange,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [Parameter(ParameterSetName = 'PrepareImage')]
        [Parameter(ParameterSetName = 'InstallFailoverCluster')]
        [Parameter(ParameterSetName = 'PrepareFailoverCluster')]
        [System.Management.Automation.SwitchParameter]
        $PBScaleOut,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [Parameter(ParameterSetName = 'Upgrade')]
        [Parameter(ParameterSetName = 'InstallFailoverCluster')]
        [Parameter(ParameterSetName = 'PrepareFailoverCluster')]
        [Parameter(ParameterSetName = 'EditionUpgrade', Mandatory = $true)]
        [System.String]
        $ProductKey, # This is argument PID but $PID is reserved variable.

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [Parameter(ParameterSetName = 'InstallFailoverCluster')]
        [Parameter(ParameterSetName = 'PrepareFailoverCluster')]
        [System.String]
        $AgtSvcAccount,

        [Parameter(ParameterSetName = 'UsingConfigurationFile')]
        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [Parameter(ParameterSetName = 'InstallFailoverCluster')]
        [Parameter(ParameterSetName = 'PrepareFailoverCluster')]
        [System.Security.SecureString]
        $AgtSvcPassword,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [ValidateSet('Automatic', 'Disabled', 'Manual')]
        [System.String]
        $AgtSvcStartupType,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [Parameter(ParameterSetName = 'InstallFailoverCluster')]
        [System.String]
        $ASBackupDir,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [Parameter(ParameterSetName = 'InstallFailoverCluster')]
        [System.String]
        $ASCollation,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [Parameter(ParameterSetName = 'InstallFailoverCluster')]
        [System.String]
        $ASConfigDir,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [Parameter(ParameterSetName = 'InstallFailoverCluster')]
        [System.String]
        $ASDataDir,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [Parameter(ParameterSetName = 'InstallFailoverCluster')]
        [System.String]
        $ASLogDir,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [Parameter(ParameterSetName = 'InstallFailoverCluster')]
        [System.String]
        $ASTempDir,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [Parameter(ParameterSetName = 'InstallFailoverCluster')]
        [ValidateSet('Multidimensional', 'PowerPivot', 'Tabular')]
        [System.String]
        $ASServerMode,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [Parameter(ParameterSetName = 'InstallFailoverCluster')]
        [Parameter(ParameterSetName = 'PrepareFailoverCluster')]
        [System.String]
        $ASSvcAccount,

        [Parameter(ParameterSetName = 'UsingConfigurationFile')]
        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [Parameter(ParameterSetName = 'InstallFailoverCluster')]
        [Parameter(ParameterSetName = 'PrepareFailoverCluster')]
        [System.Security.SecureString]
        $ASSvcPassword,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [Parameter(ParameterSetName = 'InstallFailoverCluster')]
        [ValidateSet('Automatic', 'Disabled', 'Manual')]
        [System.String]
        $ASSvcStartupType,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [Parameter(ParameterSetName = 'InstallFailoverCluster')]
        [System.String[]]
        $ASSysAdminAccounts,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [Parameter(ParameterSetName = 'InstallFailoverCluster')]
        [System.Management.Automation.SwitchParameter]
        $ASProviderMSOLAP,

        [Parameter(ParameterSetName = 'InstallRole')]
        [System.String]
        $FarmAccount,

        [Parameter(ParameterSetName = 'InstallRole')]
        [System.Security.SecureString]
        $FarmPassword,

        [Parameter(ParameterSetName = 'InstallRole')]
        [System.Security.SecureString]
        $Passphrase,

        [Parameter(ParameterSetName = 'InstallRole')]
        [ValidateRange(0, 65536)]
        [System.UInt16]
        $FarmAdminiPort, # cspell: disable-line

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [Parameter(ParameterSetName = 'Upgrade')]
        [ValidateSet('Automatic', 'Disabled', 'Manual')]
        [System.String]
        $BrowserSvcStartupType,

        [Parameter(ParameterSetName = 'Upgrade')]
        [ValidateSet('Rebuild', 'Reset', 'Import')]
        [System.String]
        $FTUpgradeOption,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [System.Management.Automation.SwitchParameter]
        $EnableRanU,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [Parameter(ParameterSetName = 'InstallFailoverCluster', Mandatory = $true)]
        [System.String]
        $InstallSqlDataDir,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [Parameter(ParameterSetName = 'InstallFailoverCluster')]
        [System.String]
        $SqlBackupDir,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [Parameter(ParameterSetName = 'InstallFailoverCluster')]
        [ValidateSet('SQL')]
        [System.String]
        $SecurityMode,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [Parameter(ParameterSetName = 'InstallFailoverCluster')]
        [System.Security.SecureString]
        $SAPwd,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [Parameter(ParameterSetName = 'InstallFailoverCluster')]
        [System.String]
        $SqlCollation,

        [Parameter(ParameterSetName = 'InstallRole')]
        [System.Management.Automation.SwitchParameter]
        $AddCurrentUserAsSqlAdmin,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [Parameter(ParameterSetName = 'InstallFailoverCluster')]
        [Parameter(ParameterSetName = 'PrepareFailoverCluster')]
        [System.String]
        $SqlSvcAccount,

        [Parameter(ParameterSetName = 'UsingConfigurationFile')]
        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [Parameter(ParameterSetName = 'InstallFailoverCluster')]
        [Parameter(ParameterSetName = 'PrepareFailoverCluster')]
        [System.Security.SecureString]
        $SqlSvcPassword,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [Parameter(ParameterSetName = 'InstallFailoverCluster')]
        [ValidateSet('Automatic', 'Disabled', 'Manual')]
        [System.String]
        $SqlSvcStartupType,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallFailoverCluster', Mandatory = $true)]
        [Parameter(ParameterSetName = 'InstallRole')]
        [System.String[]]
        $SqlSysAdminAccounts,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [Parameter(ParameterSetName = 'InstallFailoverCluster')]
        [System.String]
        $SqlTempDbDir,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [Parameter(ParameterSetName = 'InstallFailoverCluster')]
        [System.String]
        $SqlTempDbLogDir,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [Parameter(ParameterSetName = 'InstallFailoverCluster')]
        [System.UInt16]
        $SqlTempDbFileCount,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [Parameter(ParameterSetName = 'InstallFailoverCluster')]
        [ValidateRange(4, 262144)]
        [System.UInt16]
        $SqlTempDbFileSize,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [Parameter(ParameterSetName = 'InstallFailoverCluster')]
        [ValidateRange(0, 1024)]
        [System.UInt16]
        $SqlTempDbFileGrowth,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [Parameter(ParameterSetName = 'InstallFailoverCluster')]
        [ValidateRange(4, 262144)]
        [System.UInt16]
        $SqlTempDbLogFileSize,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [Parameter(ParameterSetName = 'InstallFailoverCluster')]
        [ValidateRange(0, 1024)]
        [System.UInt16]
        $SqlTempDbLogFileGrowth,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [Parameter(ParameterSetName = 'InstallFailoverCluster')]
        [System.String]
        $SqlUserDbDir,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [System.Management.Automation.SwitchParameter]
        $SqlSvcInstantFileInit,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [Parameter(ParameterSetName = 'InstallFailoverCluster')]
        [System.String]
        $SqlUserDbLogDir,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [ValidateRange(0, 32767)]
        [System.UInt16]
        $SqlMaxDop,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [System.Management.Automation.SwitchParameter]
        $UseSqlRecommendedMemoryLimits,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [ValidateRange(0, 2147483647)]
        [System.UInt32]
        $SqlMinMemory,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [ValidateRange(0, 2147483647)]
        [System.UInt32]
        $SqlMaxMemory,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [Parameter(ParameterSetName = 'InstallFailoverCluster')]
        [Parameter(ParameterSetName = 'PrepareFailoverCluster')]
        [ValidateRange(0, 3)]
        [System.UInt16]
        $FileStreamLevel,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [Parameter(ParameterSetName = 'InstallFailoverCluster')]
        [Parameter(ParameterSetName = 'PrepareFailoverCluster')]
        [System.String]
        $FileStreamShareName,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [Parameter(ParameterSetName = 'Upgrade')]
        [Parameter(ParameterSetName = 'InstallFailoverCluster')]
        [Parameter(ParameterSetName = 'PrepareFailoverCluster')]
        [System.String]
        $ISSvcAccount,

        [Parameter(ParameterSetName = 'UsingConfigurationFile')]
        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [Parameter(ParameterSetName = 'Upgrade')]
        [Parameter(ParameterSetName = 'InstallFailoverCluster')]
        [Parameter(ParameterSetName = 'PrepareFailoverCluster')]
        [System.Security.SecureString]
        $ISSvcPassword,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [Parameter(ParameterSetName = 'Upgrade')]
        [Parameter(ParameterSetName = 'InstallFailoverCluster')]
        [Parameter(ParameterSetName = 'PrepareFailoverCluster')]
        [ValidateSet('Automatic', 'Disabled', 'Manual')]
        [System.String]
        $ISSvcStartupType,

        [Parameter(ParameterSetName = 'Upgrade')]
        [System.Management.Automation.SwitchParameter]
        $AllowUpgradeForSSRSSharePointMode,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [System.Management.Automation.SwitchParameter]
        $NpEnabled,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [System.Management.Automation.SwitchParameter]
        $TcpEnabled,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [Parameter(ParameterSetName = 'InstallFailoverCluster')]
        [Parameter(ParameterSetName = 'PrepareFailoverCluster')]
        [ValidateSet('SharePointFilesOnlyMode', 'DefaultNativeMode', 'FilesOnlyMode')]
        [System.String]
        $RsInstallMode,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [Parameter(ParameterSetName = 'InstallFailoverCluster')]
        [Parameter(ParameterSetName = 'PrepareFailoverCluster')]
        [System.String]
        $RSSvcAccount,

        [Parameter(ParameterSetName = 'UsingConfigurationFile')]
        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [Parameter(ParameterSetName = 'InstallFailoverCluster')]
        [Parameter(ParameterSetName = 'PrepareFailoverCluster')]
        [System.Security.SecureString]
        $RSSvcPassword,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [Parameter(ParameterSetName = 'InstallFailoverCluster')]
        [Parameter(ParameterSetName = 'PrepareFailoverCluster')]
        [ValidateSet('Automatic', 'Disabled', 'Manual')]
        [System.String]
        $RSSvcStartupType,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [System.String]
        $MPYCacheDirectory,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [System.String]
        $MRCacheDirectory,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [System.Management.Automation.SwitchParameter]
        $SqlInstJava,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [System.String]
        $SqlJavaDir,

        [Parameter(ParameterSetName = 'InstallFailoverCluster')]
        [System.String]
        $FailoverClusterGroup,

        [Parameter(ParameterSetName = 'InstallFailoverCluster')]
        [System.String[]]
        $FailoverClusterDisks,

        [Parameter(ParameterSetName = 'InstallFailoverCluster', Mandatory = $true)]
        [System.String]
        $FailoverClusterNetworkName,

        [Parameter(ParameterSetName = 'InstallFailoverCluster', Mandatory = $true)]
        [System.String[]]
        $FailoverClusterIPAddresses,

        [Parameter(ParameterSetName = 'Upgrade')]
        [ValidateRange(0, 2)]
        [System.UInt16]
        $FailoverClusterRollOwnership,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [Parameter(ParameterSetName = 'InstallAzureArcAgent', Mandatory = $true)]
        [System.String]
        $AzureSubscriptionId,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [Parameter(ParameterSetName = 'InstallAzureArcAgent', Mandatory = $true)]
        [System.String]
        $AzureResourceGroup,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [Parameter(ParameterSetName = 'InstallAzureArcAgent', Mandatory = $true)]
        [System.String]
        $AzureRegion,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [Parameter(ParameterSetName = 'InstallAzureArcAgent', Mandatory = $true)]
        [System.String]
        $AzureTenantId,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [Parameter(ParameterSetName = 'InstallAzureArcAgent', Mandatory = $true)]
        [System.String]
        $AzureServicePrincipal,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [Parameter(ParameterSetName = 'InstallAzureArcAgent', Mandatory = $true)]
        [System.Security.SecureString]
        $AzureServicePrincipalSecret,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [Parameter(ParameterSetName = 'InstallAzureArcAgent')]
        [System.String]
        $AzureArcProxy,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [Parameter(ParameterSetName = 'InstallFailoverCluster')]
        [Parameter(ParameterSetName = 'EditionUpgrade')]
        [System.String[]]
        $SkipRules,

        [Parameter(ParameterSetName = 'Install')]
        [Parameter(ParameterSetName = 'InstallRole')]
        [Parameter(ParameterSetName = 'Upgrade')]
        [Parameter(ParameterSetName = 'InstallFailoverCluster')]
        [Parameter(ParameterSetName = 'PrepareFailoverCluster')]
        [Parameter(ParameterSetName = 'EditionUpgrade')]
        [System.Management.Automation.SwitchParameter]
        $ProductCoveredBySA,

        [Parameter()]
        [System.UInt32]
        $Timeout = 7200,

        [Parameter()]
        [System.Management.Automation.SwitchParameter]
        $Force
    )

    Invoke-SetupAction @PSBoundParameters
}
#EndRegion '.\Public\Install-SqlDscServer.ps1' 1145
#Region '.\Public\Invoke-SqlDscQuery.ps1' -1

<#
    .SYNOPSIS
        Executes a query on the specified database.

    .DESCRIPTION
        Executes a query on the specified database.

    .PARAMETER ServerObject
        Specifies current server connection object.

    .PARAMETER ServerName
        Specifies the server name where the instance exists.

    .PARAMETER InstanceName
       Specifies the instance name on which to execute the T-SQL query.

    .PARAMETER Credential
        Specifies the credentials to use to impersonate a user when connecting.
        If this is not provided then the current user will be used to connect
        to the SQL Server Database Engine instance.

    .PARAMETER LoginType
        Specifies which type of credentials are specified. The valid types are
        Integrated, WindowsUser, and SqlLogin. If WindowsUser or SqlLogin are
        specified then the Credential needs to be specified as well. Defaults
        to `Integrated`.

    .PARAMETER DatabaseName
        Specifies the name of the database to execute the T-SQL query in.

    .PARAMETER Query
        Specifies the query string to execute.

    .PARAMETER PassThru
        Specifies whether the command should return any result the query might return.

    .PARAMETER StatementTimeout
        Specifies the query StatementTimeout in seconds. Default 600 seconds (10 minutes).

    .PARAMETER RedactText
        Specifies one or more text strings to redact from the query when verbose messages
        are written to the console. Strings will be escaped so they will not
        be interpreted as regular expressions (RegEx).

    .PARAMETER Encrypt
        Specifies whether encryption should be used.

    .PARAMETER Force
        Specifies that the query should be executed without any confirmation.

    .OUTPUTS
        `[System.Data.DataSet]` when passing parameter **PassThru**, otherwise
        outputs none.

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine
        Invoke-SqlDscQuery -ServerObject $serverObject -DatabaseName 'master' `
            -Query 'SELECT name FROM sys.databases' -PassThru

        Connects to the default instance and then runs a query to return all the
        database names in the instance.

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine
        $serverObject | Invoke-SqlDscQuery -DatabaseName 'master' `
            -Query 'RESTORE DATABASE [NorthWinds] WITH RECOVERY'

        Connects to the default instance and then runs the query to restore the
        database NorthWinds.

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine
        Invoke-SqlDscQuery -ServerObject $serverObject -DatabaseName 'master' `
            -Query "select * from MyTable where password = 'PlaceholderPa\ssw0rd1' and password = 'placeholder secret passphrase'" `
            -RedactText @('PlaceholderPa\sSw0rd1','Placeholder Secret PassPhrase') `
            -PassThru -Verbose

        Shows how to redact sensitive information in the query when the query string
        is output as verbose information when the parameter Verbose is used. For it
        to work the sensitiv information must be known and passed into the parameter
        RedactText. If any single character is wrong the sensitiv information will
        not be redacted. The redaction is case-insensitive.

    .EXAMPLE
        Invoke-SqlDscQuery -ServerName Server1 -InstanceName MSSQLSERVER -DatabaseName 'master' `
            -Query 'SELECT name FROM sys.databases' -PassThru

        Connects to the default instance and then runs a query to return all the
        database names in the instance.
#>
function Invoke-SqlDscQuery
{
    [System.Diagnostics.CodeAnalysis.SuppressMessageAttribute('UseSyntacticallyCorrectExamples', '', Justification = 'Because the rule does not yet support parsing the code when a parameter type is not available. The ScriptAnalyzer rule UseSyntacticallyCorrectExamples will always error in the editor due to https://github.com/indented-automation/Indented.ScriptAnalyzerRules/issues/8.')]
    [OutputType([System.Data.DataSet])]
    [CmdletBinding(DefaultParameterSetName = 'ByServerName', SupportsShouldProcess = $true, ConfirmImpact = 'High')]
    param
    (
        [Parameter(ParameterSetName = 'ByServerObject', Mandatory = $true, ValueFromPipeline = $true)]
        [Microsoft.SqlServer.Management.Smo.Server]
        $ServerObject,

        [Parameter(ParameterSetName = 'ByServerName')]
        [ValidateNotNullOrEmpty()]
        [System.String]
        $ServerName = (Get-ComputerName),

        [Parameter(ParameterSetName = 'ByServerName')]
        [System.String]
        $InstanceName = 'MSSQLSERVER',

        [Parameter(ParameterSetName = 'ByServerName')]
        [Alias('SetupCredential')]
        [Alias('DatabaseCredential')]
        [System.Management.Automation.PSCredential]
        $Credential,

        [Parameter(ParameterSetName = 'ByServerName')]
        [ValidateSet('Integrated', 'WindowsUser', 'SqlLogin')]
        [System.String]
        $LoginType = 'Integrated',

        [Parameter(ParameterSetName = 'ByServerName')]
        [System.Management.Automation.SwitchParameter]
        $Encrypt,

        [Parameter(Mandatory = $true)]
        [System.String]
        $DatabaseName,

        [Parameter(Mandatory = $true)]
        [System.String]
        $Query,

        [Parameter()]
        [Alias('WithResults')]
        [Switch]
        $PassThru,

        [Parameter()]
        [ValidateNotNull()]
        [System.Int32]
        $StatementTimeout = 600,

        [Parameter()]
        [ValidateNotNullOrEmpty()]
        [System.String[]]
        $RedactText,

        [Parameter()]
        [System.Management.Automation.SwitchParameter]
        $Force
    )

    begin
    {
        if ($Force.IsPresent -and -not $Confirm)
        {
            $ConfirmPreference = 'None'
        }

        if ($PSCmdlet.ParameterSetName -eq 'ByServerName')
        {
            $connectSqlDscDatabaseEngineParameters = @{
                ServerName       = $ServerName
                InstanceName     = $InstanceName
                StatementTimeout = $StatementTimeout
                ErrorAction      = 'Stop'
                Verbose          = $VerbosePreference
            }

            if ($Encrypt.IsPresent)
            {
                $connectSqlDscDatabaseEngineParameters.Encrypt = $true
            }

            if ($LoginType -ne 'Integrated')
            {
                $connectSqlDscDatabaseEngineParameters['LoginType'] = $LoginType
            }

            if ($PSBoundParameters.ContainsKey('Credential'))
            {
                $connectSqlDscDatabaseEngineParameters.Credential = $Credential
            }

            $ServerObject = Connect-SqlDscDatabaseEngine @connectSqlDscDatabaseEngineParameters
        }

        if ($PSCmdlet.ParameterSetName -eq 'ByServerObject')
        {
            $InstanceName = $ServerObject.InstanceName
        }

        $redactedQuery = $Query

        if ($PSBoundParameters.ContainsKey('RedactText'))
        {
            $redactedQuery = ConvertTo-RedactedText -Text $Query -RedactPhrase $RedactText
        }
    }

    process
    {
        $result = $null

        $verboseDescriptionMessage = $script:localizedData.Query_Invoke_ShouldProcessVerboseDescription -f $InstanceName
        $verboseWarningMessage = $script:localizedData.Query_Invoke_ShouldProcessVerboseWarning -f $InstanceName
        $captionMessage = $script:localizedData.Query_Invoke_ShouldProcessCaption

        if ($PSCmdlet.ShouldProcess($verboseDescriptionMessage, $verboseWarningMessage, $captionMessage))
        {
            $previousStatementTimeout = $null

            if ($PSCmdlet.ParameterSetName -eq 'ByServerObject')
            {
                if ($PSBoundParameters.ContainsKey('StatementTimeout'))
                {
                    # Make sure we can return the StatementTimeout before exiting.
                    $previousStatementTimeout = $ServerObject.ConnectionContext.StatementTimeout

                    $ServerObject.ConnectionContext.StatementTimeout = $StatementTimeout
                }
            }

            try
            {
                if ($PassThru)
                {
                    Write-Verbose -Message (
                        $script:localizedData.Query_Invoke_ExecuteQueryWithResults -f $redactedQuery
                    )

                    $result = $ServerObject.Databases[$DatabaseName].ExecuteWithResults($Query)

                    return $result
                }
                else
                {
                    Write-Verbose -Message (
                        $script:localizedData.Query_Invoke_ExecuteNonQuery -f $redactedQuery
                    )

                    $null = $ServerObject.Databases[$DatabaseName].ExecuteNonQuery($Query)
                }
            }
            catch
            {
                $writeErrorParameters = @{
                    Message      = $_.Exception.ToString()
                    Category     = 'InvalidOperation'
                    ErrorId      = 'ISDQ0001' # cSpell: disable-line
                    TargetObject = $DatabaseName
                }

                Write-Error @writeErrorParameters
            }
            finally
            {
                if ($previousStatementTimeout)
                {
                    $ServerObject.ConnectionContext.StatementTimeout = $previousStatementTimeout
                }
            }
        }
    }

    end
    {
        if ($PSCmdlet.ParameterSetName -eq 'ByServerName')
        {
            $ServerObject | Disconnect-SqlDscDatabaseEngine -Force -Verbose:$VerbosePreference
        }
    }
}
#EndRegion '.\Public\Invoke-SqlDscQuery.ps1' 275
#Region '.\Public\New-SqlDscAgentAlert.ps1' -1

<#
    .SYNOPSIS
        Creates a new SQL Agent Alert.

    .DESCRIPTION
        This command creates a new SQL Agent Alert on a SQL Server Database Engine instance.

    .PARAMETER ServerObject
        Specifies current server connection object.

    .PARAMETER Name
        Specifies the name of the SQL Agent Alert to create.

    .PARAMETER Severity
        Specifies the severity level for the SQL Agent Alert. Valid range is 0 to 25.
        Cannot be used together with MessageId.

    .PARAMETER MessageId
        Specifies the message ID for the SQL Agent Alert. Valid range is 0 to 2147483647.
        Cannot be used together with Severity.

    .PARAMETER PassThru
        If specified, the created alert object will be returned.

    .PARAMETER Force
        Forces the action without prompting for confirmation.

    .INPUTS
        Microsoft.SqlServer.Management.Smo.Server

        SQL Server Database Engine instance object.

    .OUTPUTS
        `[Microsoft.SqlServer.Management.Smo.Agent.Alert]` if passing parameter **PassThru**,
         otherwise none.

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine -InstanceName 'MyInstance'
        New-SqlDscAgentAlert -ServerObject $serverObject -Name 'MyAlert' -Severity 16

        Creates a new SQL Agent Alert named 'MyAlert' with severity level 16.

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine -InstanceName 'MyInstance'
        $serverObject | New-SqlDscAgentAlert -Name 'MyAlert' -MessageId 50001

        Creates a new SQL Agent Alert named 'MyAlert' for message ID 50001 using pipeline input.

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine -InstanceName 'MyInstance'
        $alertObject = $serverObject | New-SqlDscAgentAlert -Name 'MyAlert' -Severity 16 -PassThru

        Creates a new SQL Agent Alert and returns the created object.

    .NOTES
        Either -Severity or -MessageId must be specified (mutually exclusive).
#>
function New-SqlDscAgentAlert
{
    [System.Diagnostics.CodeAnalysis.SuppressMessageAttribute('UseSyntacticallyCorrectExamples', '', Justification = 'Because the rule does not yet support parsing the code when a parameter type is not available. The ScriptAnalyzer rule UseSyntacticallyCorrectExamples will always error in the editor due to https://github.com/indented-automation/Indented.ScriptAnalyzerRules/issues/8.')]
    [CmdletBinding(SupportsShouldProcess = $true, ConfirmImpact = 'Medium')]
    [OutputType([Microsoft.SqlServer.Management.Smo.Agent.Alert])]
    param
    (
        [Parameter(Mandatory = $true, ValueFromPipeline = $true)]
        [Microsoft.SqlServer.Management.Smo.Server]
        $ServerObject,

        [Parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [System.String]
        $Name,

        [Parameter()]
        [ValidateRange(0, 25)]
        [System.Int32]
        $Severity,

        [Parameter()]
        [ValidateRange(0, 2147483647)]
        [System.Int32]
        $MessageId,

        [Parameter()]
        [System.Management.Automation.SwitchParameter]
        $PassThru,

        [Parameter()]
        [System.Management.Automation.SwitchParameter]
        $Force
    )

    begin
    {
        if ($Force.IsPresent -and -not $Confirm)
        {
            $ConfirmPreference = 'None'
        }
    }

    # cSpell: ignore NSAA
    process
    {
        # Validate that both Severity and MessageId are not specified
        Assert-BoundParameter -BoundParameterList $PSBoundParameters -MutuallyExclusiveList1 @('Severity') -MutuallyExclusiveList2 @('MessageId')

        # Check if alert already exists
        $alertExists = Test-SqlDscIsAgentAlert -ServerObject $ServerObject -Name $Name

        if ($alertExists)
        {
            $errorMessage = $script:localizedData.New_SqlDscAgentAlert_AlertAlreadyExists -f $Name

            $PSCmdlet.ThrowTerminatingError(
                [System.Management.Automation.ErrorRecord]::new(
                    [System.InvalidOperationException]::new($errorMessage),
                    'NSAA0001', # cspell: disable-line
                    [System.Management.Automation.ErrorCategory]::ResourceExists,
                    $Name
                )
            )
        }

        $verboseDescriptionMessage = $script:localizedData.New_SqlDscAgentAlert_CreateShouldProcessVerboseDescription -f $Name, $ServerObject.InstanceName
        $verboseWarningMessage = $script:localizedData.New_SqlDscAgentAlert_CreateShouldProcessVerboseWarning -f $Name
        $captionMessage = $script:localizedData.New_SqlDscAgentAlert_CreateShouldProcessCaption

        if ($PSCmdlet.ShouldProcess($verboseDescriptionMessage, $verboseWarningMessage, $captionMessage))
        {
            try
            {
                Write-Verbose -Message ($script:localizedData.New_SqlDscAgentAlert_CreatingAlert -f $Name)

                # Create the new alert SMO object
                $newAlertObject = [Microsoft.SqlServer.Management.Smo.Agent.Alert]::new($ServerObject.JobServer, $Name)

                if ($PSBoundParameters.ContainsKey('Severity'))
                {
                    Write-Verbose -Message ($script:localizedData.New_SqlDscAgentAlert_SettingSeverity -f $Severity, $Name)
                    $newAlertObject.Severity = $Severity
                }

                if ($PSBoundParameters.ContainsKey('MessageId'))
                {
                    Write-Verbose -Message ($script:localizedData.New_SqlDscAgentAlert_SettingMessageId -f $MessageId, $Name)
                    $newAlertObject.MessageId = $MessageId
                }

                $newAlertObject.Create()

                Write-Verbose -Message ($script:localizedData.New_SqlDscAgentAlert_AlertCreated -f $Name)

                if ($PassThru.IsPresent)
                {
                    return $newAlertObject
                }
            }
            catch
            {
                $errorMessage = $script:localizedData.New_SqlDscAgentAlert_CreateFailed -f $Name

                $PSCmdlet.ThrowTerminatingError(
                    [System.Management.Automation.ErrorRecord]::new(
                        [System.InvalidOperationException]::new($errorMessage, $_.Exception),
                        'NSAA0002', # cspell: disable-line
                        [System.Management.Automation.ErrorCategory]::InvalidOperation,
                        $Name
                    )
                )
            }
        }
    }
}
#EndRegion '.\Public\New-SqlDscAgentAlert.ps1' 174
#Region '.\Public\New-SqlDscAgentOperator.ps1' -1

<#
    .SYNOPSIS
        Creates a new SQL Agent Operator.

    .DESCRIPTION
        This command creates a new SQL Agent Operator on a SQL Server Database Engine instance.

    .PARAMETER ServerObject
        Specifies current server connection object.

    .PARAMETER Name
        Specifies the name of the SQL Agent Operator to create.

    .PARAMETER EmailAddress
        Specifies the email address for the SQL Agent Operator.

    .PARAMETER CategoryName
        Specifies the category name for the SQL Agent Operator.

    .PARAMETER NetSendAddress
        Specifies the net send address for the SQL Agent Operator.

    .PARAMETER PagerAddress
        Specifies the pager address for the SQL Agent Operator.

    .PARAMETER PagerDays
        Specifies the days when pager notifications are active for the SQL Agent Operator.

    .PARAMETER SaturdayPagerEndTime
        Specifies the Saturday pager end time for the SQL Agent Operator.

    .PARAMETER SaturdayPagerStartTime
        Specifies the Saturday pager start time for the SQL Agent Operator.

    .PARAMETER SundayPagerEndTime
        Specifies the Sunday pager end time for the SQL Agent Operator.

    .PARAMETER SundayPagerStartTime
        Specifies the Sunday pager start time for the SQL Agent Operator.

    .PARAMETER WeekdayPagerEndTime
        Specifies the weekday pager end time for the SQL Agent Operator.

    .PARAMETER WeekdayPagerStartTime
        Specifies the weekday pager start time for the SQL Agent Operator.

    .PARAMETER PassThru
        Specifies whether the created operator object will be returned.

    .PARAMETER Force
        Specifies that the operator should be created without any confirmation.

    .PARAMETER Refresh
        Specifies that the **ServerObject**'s operators should be refreshed before
        testing if the operator already exists. This is helpful when operators could have
        been modified outside of the **ServerObject**, for example through T-SQL.
        But on instances with a large amount of operators it might be better to make
        sure the **ServerObject** is recent enough.

    .INPUTS
        Microsoft.SqlServer.Management.Smo.Server

        SQL Server Database Engine instance object.

    .OUTPUTS
        `[Microsoft.SqlServer.Management.Smo.Agent.Operator]` if passing parameter **PassThru**,
         otherwise none.

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine -InstanceName 'MyInstance'
        New-SqlDscAgentOperator -ServerObject $serverObject -Name 'MyOperator' -EmailAddress 'admin@example.com'

        Creates a new SQL Agent Operator named 'MyOperator' with an email address.

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine -InstanceName 'MyInstance'
        $serverObject | New-SqlDscAgentOperator -Name 'MyOperator' -EmailAddress 'admin@contoso.com'

        Creates a new SQL Agent Operator named 'MyOperator' with an email address using pipeline input.

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine -InstanceName 'MyInstance'
        $operatorObject = $serverObject | New-SqlDscAgentOperator -Name 'MyOperator' -EmailAddress 'admin@example.com' -PassThru

        Creates a new SQL Agent Operator with an email address and returns the created object.

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine -InstanceName 'MyInstance'
        $serverObject | New-SqlDscAgentOperator -Name 'MyOperator' -EmailAddress 'admin@contoso.com' -Refresh

        Creates a new SQL Agent Operator, refreshing the operators collection before checking if it already exists.
#>
function New-SqlDscAgentOperator
{
    [System.Diagnostics.CodeAnalysis.SuppressMessageAttribute('UseSyntacticallyCorrectExamples', '', Justification = 'Because the rule does not yet support parsing the code when a parameter type is not available. The ScriptAnalyzer rule UseSyntacticallyCorrectExamples will always error in the editor due to https://github.com/indented-automation/Indented.ScriptAnalyzerRules/issues/8.')]
    [CmdletBinding(SupportsShouldProcess = $true, ConfirmImpact = 'Medium')]
    [OutputType([Microsoft.SqlServer.Management.Smo.Agent.Operator])]
    param
    (
        [Parameter(Mandatory = $true, ValueFromPipeline = $true)]
        [Microsoft.SqlServer.Management.Smo.Server]
        $ServerObject,

        [Parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [System.String]
        $Name,

        [Parameter()]
        [System.String]
        $EmailAddress,

        [Parameter()]
        [System.String]
        $CategoryName,

        [Parameter()]
        [System.String]
        $NetSendAddress,

        [Parameter()]
        [System.String]
        $PagerAddress,

        [Parameter()]
        [Microsoft.SqlServer.Management.Smo.Agent.WeekDays]
        $PagerDays,

        [Parameter()]
        [System.TimeSpan]
        $SaturdayPagerEndTime,

        [Parameter()]
        [System.TimeSpan]
        $SaturdayPagerStartTime,

        [Parameter()]
        [System.TimeSpan]
        $SundayPagerEndTime,

        [Parameter()]
        [System.TimeSpan]
        $SundayPagerStartTime,

        [Parameter()]
        [System.TimeSpan]
        $WeekdayPagerEndTime,

        [Parameter()]
        [System.TimeSpan]
        $WeekdayPagerStartTime,

        [Parameter()]
        [System.Management.Automation.SwitchParameter]
        $PassThru,

        [Parameter()]
        [System.Management.Automation.SwitchParameter]
        $Force,

        [Parameter()]
        [System.Management.Automation.SwitchParameter]
        $Refresh
    )

    begin
    {
        # Dynamically get settable properties by filtering out common parameters and control parameters
        $settableProperties = Get-CommandParameter -Command $MyInvocation.MyCommand -Exclude @('ServerObject', 'Name', 'PassThru', 'Force', 'Refresh')

        Assert-BoundParameter -BoundParameterList $PSBoundParameters -AtLeastOneList $settableProperties
    }

    # cSpell: ignore NSAO
    process
    {
        if ($Force.IsPresent -and -not $Confirm)
        {
            $ConfirmPreference = 'None'
        }

        # Check if operator already exists
        if (Test-SqlDscIsAgentOperator -ServerObject $ServerObject -Name $Name -Refresh:$Refresh)
        {
            $errorMessage = $script:localizedData.New_SqlDscAgentOperator_OperatorAlreadyExists -f $Name

            $PSCmdlet.ThrowTerminatingError(
                [System.Management.Automation.ErrorRecord]::new(
                    [System.InvalidOperationException]::new($errorMessage),
                    'NSAO0001', # cspell: disable-line
                    [System.Management.Automation.ErrorCategory]::ResourceExists,
                    $Name
                )
            )
        }

        $verboseDescriptionMessage = $script:localizedData.New_SqlDscAgentOperator_CreateShouldProcessVerboseDescription -f $Name, $ServerObject.InstanceName
        $verboseWarningMessage = $script:localizedData.New_SqlDscAgentOperator_CreateShouldProcessVerboseWarning -f $Name
        $captionMessage = $script:localizedData.New_SqlDscAgentOperator_CreateShouldProcessCaption

        if ($PSCmdlet.ShouldProcess($verboseDescriptionMessage, $verboseWarningMessage, $captionMessage))
        {
            try
            {
                # Create the new operator SMO object
                $newOperatorObject = [Microsoft.SqlServer.Management.Smo.Agent.Operator]::new($ServerObject.JobServer, $Name)

                if ($PSBoundParameters.ContainsKey('EmailAddress'))
                {
                    $newOperatorObject.EmailAddress = $EmailAddress
                }

                if ($PSBoundParameters.ContainsKey('CategoryName'))
                {
                    $newOperatorObject.CategoryName = $CategoryName
                }

                if ($PSBoundParameters.ContainsKey('NetSendAddress'))
                {
                    $newOperatorObject.NetSendAddress = $NetSendAddress
                }

                if ($PSBoundParameters.ContainsKey('PagerAddress'))
                {
                    $newOperatorObject.PagerAddress = $PagerAddress
                }

                if ($PSBoundParameters.ContainsKey('PagerDays'))
                {
                    $newOperatorObject.PagerDays = $PagerDays
                }

                if ($PSBoundParameters.ContainsKey('SaturdayPagerEndTime'))
                {
                    $newOperatorObject.SaturdayPagerEndTime = $SaturdayPagerEndTime
                }

                if ($PSBoundParameters.ContainsKey('SaturdayPagerStartTime'))
                {
                    $newOperatorObject.SaturdayPagerStartTime = $SaturdayPagerStartTime
                }

                if ($PSBoundParameters.ContainsKey('SundayPagerEndTime'))
                {
                    $newOperatorObject.SundayPagerEndTime = $SundayPagerEndTime
                }

                if ($PSBoundParameters.ContainsKey('SundayPagerStartTime'))
                {
                    $newOperatorObject.SundayPagerStartTime = $SundayPagerStartTime
                }

                if ($PSBoundParameters.ContainsKey('WeekdayPagerEndTime'))
                {
                    $newOperatorObject.WeekdayPagerEndTime = $WeekdayPagerEndTime
                }

                if ($PSBoundParameters.ContainsKey('WeekdayPagerStartTime'))
                {
                    $newOperatorObject.WeekdayPagerStartTime = $WeekdayPagerStartTime
                }

                $newOperatorObject.Create()

                if ($PassThru.IsPresent)
                {
                    return $newOperatorObject
                }
            }
            catch
            {
                $errorMessage = $script:localizedData.New_SqlDscAgentOperator_CreateFailed -f $Name

                $PSCmdlet.ThrowTerminatingError(
                    [System.Management.Automation.ErrorRecord]::new(
                        [System.InvalidOperationException]::new($errorMessage, $_.Exception),
                        'NSAO0004', # cspell: disable-line
                        [System.Management.Automation.ErrorCategory]::InvalidOperation,
                        $Name
                    )
                )
            }
        }
    }
}
#EndRegion '.\Public\New-SqlDscAgentOperator.ps1' 286
#Region '.\Public\New-SqlDscAudit.ps1' -1

<#
    .SYNOPSIS
        Creates a server audit.

    .DESCRIPTION
        This command creates a server audit on a SQL Server Database Engine instance.

    .PARAMETER ServerObject
        Specifies current server connection object.

    .PARAMETER Name
        Specifies the name of the server audit to be added.

    .PARAMETER AuditFilter
        Specifies the filter that should be used on the audit. See [predicate expression](https://docs.microsoft.com/en-us/sql/t-sql/statements/create-server-audit-transact-sql)
        how to write the syntax for the filter.

    .PARAMETER OnFailure
        Specifies what should happen when writing events to the store fails.
        This can be 'Continue', 'FailOperation', or 'Shutdown'.

    .PARAMETER QueueDelay
        Specifies the maximum delay before a event is written to the store.
        When set to low this could impact server performance.
        When set to high events could be missing when a server crashes.

    .PARAMETER AuditGuid
        Specifies the GUID found in the mirrored database. To support scenarios such
        as database mirroring an audit needs a specific GUID.

    .PARAMETER Force
        Specifies that the audit should be created without any confirmation.

    .PARAMETER Refresh
        Specifies that the **ServerObject**'s audits should be refreshed before
        creating the audit object. This is helpful when audits could have been
        modified outside of the **ServerObject**, for example through T-SQL. But
        on instances with a large amount of audits it might be better to make
        sure the ServerObject is recent enough.

    .PARAMETER LogType
        Specifies the log location where the audit should write to.
        This can be SecurityLog or ApplicationLog.

    .PARAMETER Path
        Specifies the location where te log files wil be placed.

    .PARAMETER ReserveDiskSpace
        Specifies if the needed file space should be reserved. To use this parameter
        the parameters **MaximumFiles** and **MaximumFileSize** must also be used.

    .PARAMETER MaximumFiles
        Specifies the number of files on disk.

    .PARAMETER MaximumFileSize
        Specifies the maximum file size in units by parameter MaximumFileSizeUnit.

    .PARAMETER MaximumFileSizeUnit
        Specifies the unit that is used for the file size. This can be set to `Megabyte`,
        `Gigabyte`, or `Terabyte`.

    .PARAMETER MaximumRolloverFiles
        Specifies the amount of files on disk before SQL Server starts reusing
        the files. If not specified then it is set to unlimited.

    .PARAMETER PassThru
        If specified the created audit object will be returned.

    .OUTPUTS
        `[Microsoft.SqlServer.Management.Smo.Audit]` is passing parameter **PassThru**,
         otherwise none.

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine -InstanceName 'MyInstance'
        $sqlServerObject | New-SqlDscAudit -Name 'MyFileAudit' -Path 'E:\auditFolder'

        Create a new file audit named **MyFileAudit**.

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine -InstanceName 'MyInstance'
        $sqlServerObject | New-SqlDscAudit -Name 'MyAppLogAudit' -LogType 'ApplicationLog'

        Create a new application log audit named **MyAppLogAudit**.

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine -InstanceName 'MyInstance'
        $sqlServerObject | New-SqlDscAudit -Name 'MyFileAudit' -Path 'E:\auditFolder' -PassThru

        Create a new file audit named **MyFileAudit** and returns the Audit object.

    .NOTES
        This command has the confirm impact level set to medium since an audit is
        created but by default is is not enabled.

        See the SQL Server documentation for more information for the possible
        parameter values to pass to this command: https://docs.microsoft.com/en-us/sql/t-sql/statements/create-server-audit-transact-sql
#>
function New-SqlDscAudit
{
    [System.Diagnostics.CodeAnalysis.SuppressMessageAttribute('UseSyntacticallyCorrectExamples', '', Justification = 'Because the rule does not yet support parsing the code when a parameter type is not available. The ScriptAnalyzer rule UseSyntacticallyCorrectExamples will always error in the editor due to https://github.com/indented-automation/Indented.ScriptAnalyzerRules/issues/8.')]
    [OutputType([Microsoft.SqlServer.Management.Smo.Audit])]
    [CmdletBinding(SupportsShouldProcess = $true, ConfirmImpact = 'Medium')]
    param
    (
        [Parameter(ParameterSetName = 'Log', Mandatory = $true, ValueFromPipeline = $true)]
        [Parameter(ParameterSetName = 'File', Mandatory = $true, ValueFromPipeline = $true)]
        [Parameter(ParameterSetName = 'FileWithSize', Mandatory = $true, ValueFromPipeline = $true)]
        [Parameter(ParameterSetName = 'FileWithMaxFiles', Mandatory = $true, ValueFromPipeline = $true)]
        [Parameter(ParameterSetName = 'FileWithMaxRolloverFiles', Mandatory = $true, ValueFromPipeline = $true)]
        [Parameter(ParameterSetName = 'FileWithSizeAndMaxFiles', Mandatory = $true, ValueFromPipeline = $true)]
        [Parameter(ParameterSetName = 'FileWithSizeAndMaxRolloverFiles', Mandatory = $true, ValueFromPipeline = $true)]
        [Microsoft.SqlServer.Management.Smo.Server]
        $ServerObject,

        [Parameter(Mandatory = $true)]
        [System.String]
        $Name,

        [Parameter()]
        [System.String]
        $AuditFilter,

        [Parameter()]
        [ValidateSet('Continue', 'FailOperation', 'Shutdown')]
        [System.String]
        $OnFailure,

        [Parameter()]
        [ValidateRange(1000, 2147483647)]
        [System.UInt32]
        $QueueDelay,

        [Parameter()]
        [ValidatePattern('^[0-9a-fA-F]{8}-(?:[0-9a-fA-F]{4}-){3}[0-9a-fA-F]{12}$')]
        [System.String]
        $AuditGuid,

        [Parameter()]
        [System.Management.Automation.SwitchParameter]
        $Force,

        [Parameter()]
        [System.Management.Automation.SwitchParameter]
        $Refresh,

        [Parameter()]
        [System.Management.Automation.SwitchParameter]
        $PassThru,

        [Parameter(ParameterSetName = 'Log', Mandatory = $true)]
        [ValidateSet('SecurityLog', 'ApplicationLog')]
        [System.String]
        $LogType,

        [Parameter(ParameterSetName = 'File', Mandatory = $true)]
        [Parameter(ParameterSetName = 'FileWithSize', Mandatory = $true)]
        [Parameter(ParameterSetName = 'FileWithMaxFiles', Mandatory = $true)]
        [Parameter(ParameterSetName = 'FileWithMaxRolloverFiles', Mandatory = $true)]
        [Parameter(ParameterSetName = 'FileWithSizeAndMaxFiles', Mandatory = $true)]
        [Parameter(ParameterSetName = 'FileWithSizeAndMaxRolloverFiles', Mandatory = $true)]
        [ValidateScript({
                if (-not (Test-Path -Path $_))
                {
                    throw ($script:localizedData.Audit_PathParameterValueInvalid -f $_)
                }

                return $true
            })]
        [System.String]
        $Path,

        [Parameter(ParameterSetName = 'FileWithSize', Mandatory = $true)]
        [Parameter(ParameterSetName = 'FileWithSizeAndMaxFiles', Mandatory = $true)]
        [Parameter(ParameterSetName = 'FileWithSizeAndMaxRolloverFiles', Mandatory = $true)]
        [ValidateRange(2, 2147483647)]
        [System.UInt32]
        $MaximumFileSize,

        [Parameter(ParameterSetName = 'FileWithSize', Mandatory = $true)]
        [Parameter(ParameterSetName = 'FileWithSizeAndMaxFiles', Mandatory = $true)]
        [Parameter(ParameterSetName = 'FileWithSizeAndMaxRolloverFiles', Mandatory = $true)]
        [ValidateSet('Megabyte', 'Gigabyte', 'Terabyte')]
        [System.String]
        $MaximumFileSizeUnit,

        [Parameter(ParameterSetName = 'FileWithSizeAndMaxFiles', Mandatory = $true)]
        [Parameter(ParameterSetName = 'FileWithMaxFiles', Mandatory = $true)]
        [System.UInt32]
        $MaximumFiles,

        [Parameter(ParameterSetName = 'FileWithSizeAndMaxFiles')]
        [System.Management.Automation.SwitchParameter]
        $ReserveDiskSpace,

        [Parameter(ParameterSetName = 'FileWithSizeAndMaxRolloverFiles', Mandatory = $true)]
        [Parameter(ParameterSetName = 'FileWithMaxRolloverFiles', Mandatory = $true)]
        [ValidateRange(0, 2147483647)]
        [System.UInt32]
        $MaximumRolloverFiles
    )

    process
    {
        if ($Force.IsPresent -and -not $Confirm)
        {
            $ConfirmPreference = 'None'
        }

        $getSqlDscAuditParameters = @{
            ServerObject = $ServerObject
            Name         = $Name
            Refresh      = $Refresh
            ErrorAction  = 'SilentlyContinue'
        }

        $auditObject = Get-SqlDscAudit @getSqlDscAuditParameters

        if ($auditObject.Count -gt 0)
        {
            $auditAlreadyPresentMessage = $script:localizedData.Audit_AlreadyPresent -f $Name

            $PSCmdlet.ThrowTerminatingError(
                [System.Management.Automation.ErrorRecord]::new(
                    $auditAlreadyPresentMessage,
                    'NSDA0001', # cspell: disable-line
                    [System.Management.Automation.ErrorCategory]::InvalidOperation,
                    $DatabaseName
                )
            )
        }

        $auditObject = New-Object -TypeName 'Microsoft.SqlServer.Management.Smo.Audit' -ArgumentList @($ServerObject, $Name)

        $queryType = switch ($PSCmdlet.ParameterSetName)
        {
            'Log'
            {
                $LogType
            }

            default
            {
                'File'
            }
        }

        $auditObject.DestinationType = $queryType

        if ($PSCmdlet.ParameterSetName -match 'File')
        {
            $auditObject.FilePath = $Path

            if ($PSCmdlet.ParameterSetName -match 'FileWithSize')
            {
                $convertedMaximumFileSizeUnit = (
                    @{
                        Megabyte = 'MB'
                        Gigabyte = 'GB'
                        Terabyte = 'TB'
                    }
                ).$MaximumFileSizeUnit

                $auditObject.MaximumFileSize = $MaximumFileSize
                $auditObject.MaximumFileSizeUnit = $convertedMaximumFileSizeUnit
            }

            if ($PSCmdlet.ParameterSetName -in @('FileWithMaxFiles', 'FileWithSizeAndMaxFiles'))
            {
                $auditObject.MaximumFiles = $MaximumFiles

                if ($PSBoundParameters.ContainsKey('ReserveDiskSpace'))
                {
                    $auditObject.ReserveDiskSpace = $ReserveDiskSpace.IsPresent
                }
            }

            if ($PSCmdlet.ParameterSetName -in @('FileWithMaxRolloverFiles', 'FileWithSizeAndMaxRolloverFiles'))
            {
                $auditObject.MaximumRolloverFiles = $MaximumRolloverFiles
            }
        }

        if ($PSBoundParameters.ContainsKey('OnFailure'))
        {
            $auditObject.OnFailure = $OnFailure
        }

        if ($PSBoundParameters.ContainsKey('QueueDelay'))
        {
            $auditObject.QueueDelay = $QueueDelay
        }

        if ($PSBoundParameters.ContainsKey('AuditGuid'))
        {
            $auditObject.Guid = $AuditGuid
        }

        if ($PSBoundParameters.ContainsKey('AuditFilter'))
        {
            $auditObject.Filter = $AuditFilter
        }

        $verboseDescriptionMessage = $script:localizedData.Audit_Add_ShouldProcessVerboseDescription -f $Name, $ServerObject.InstanceName
        $verboseWarningMessage = $script:localizedData.Audit_Add_ShouldProcessVerboseWarning -f $Name
        $captionMessage = $script:localizedData.Audit_Add_ShouldProcessCaption

        if ($PSCmdlet.ShouldProcess($verboseDescriptionMessage, $verboseWarningMessage, $captionMessage))
        {
            $auditObject.Create()

            if ($PassThru.IsPresent)
            {
                return $auditObject
            }
        }
    }
}
#EndRegion '.\Public\New-SqlDscAudit.ps1' 318
#Region '.\Public\New-SqlDscDatabase.ps1' -1

<#
    .SYNOPSIS
        Creates a new database in a SQL Server Database Engine instance.

    .DESCRIPTION
        This command creates a new database in a SQL Server Database Engine instance.
        It supports creating both regular databases and database snapshots.

    .PARAMETER ServerObject
        Specifies current server connection object.

    .PARAMETER Name
        Specifies the name of the database to be created.

    .PARAMETER Collation
        The name of the SQL collation to use for the new database.
        Default value is server collation.

    .PARAMETER CatalogCollation
        Specifies the collation type for the system catalog. Valid values are
        DATABASE_DEFAULT and SQL_Latin1_General_CP1_CI_AS. This property can
        only be set during database creation and cannot be modified afterward.
        This parameter requires SQL Server 2019 (version 15) or later.

    .PARAMETER CompatibilityLevel
        The version of the SQL compatibility level to use for the new database.
        Default value is server version.

    .PARAMETER RecoveryModel
        The recovery model to be used for the new database.
        Default value is Full.

    .PARAMETER OwnerName
        Specifies the name of the login that should be the owner of the database.

    .PARAMETER IsLedger
        Specifies whether to create a ledger database. Ledger databases provide
        tamper-evidence capabilities and are immutable once created. This parameter
        can only be set during database creation - ledger status cannot be changed
        after the database is created. This parameter requires SQL Server 2022
        (version 16) or later, or Azure SQL Database.

    .PARAMETER DatabaseSnapshotBaseName
        Specifies the name of the source database from which to create a snapshot.
        When this parameter is specified, a database snapshot will be created instead
        of a regular database. The snapshot name is specified in the Name parameter.

    .PARAMETER FileGroup
        Specifies an array of DatabaseFileGroupSpec objects that define the file groups
        and data files for the database. Each DatabaseFileGroupSpec contains the file group
        name and an array of DatabaseFileSpec objects for the data files.

        This parameter allows you to specify custom file and filegroup configurations
        before the database is created, avoiding the SMO limitation where DataFile objects
        require an existing database context.

        For database snapshots, the FileName in each DatabaseFileSpec must point to sparse
        file locations. For regular databases, this allows full control over PRIMARY and
        secondary file group configurations.

    .PARAMETER Force
        Specifies that the database should be created without any confirmation.

    .PARAMETER Refresh
        Specifies that the **ServerObject**'s databases should be refreshed before
        creating the database object. This is helpful when databases could have been
        modified outside of the **ServerObject**, for example through T-SQL. But
        on instances with a large amount of databases it might be better to make
        sure the **ServerObject** is recent enough.

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine -InstanceName 'MyInstance'
        $serverObject | New-SqlDscDatabase -Name 'MyDatabase'

        Creates a new database named **MyDatabase**.

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine -InstanceName 'MyInstance'
        $serverObject | New-SqlDscDatabase -Name 'MyDatabase' -Collation 'SQL_Latin1_General_Pref_CP850_CI_AS' -RecoveryModel 'Simple' -Force

        Creates a new database named **MyDatabase** with the specified collation and recovery model
        without prompting for confirmation.

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine -InstanceName 'MyInstance'
        $serverObject | New-SqlDscDatabase -Name 'MyDatabaseSnapshot' -DatabaseSnapshotBaseName 'MyDatabase' -Force

        Creates a database snapshot named **MyDatabaseSnapshot** from the source database **MyDatabase**
        without prompting for confirmation.

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine -InstanceName 'MyInstance'

        $primaryFile = New-SqlDscDataFile -Name 'MyDatabase_Primary' -FileName 'D:\SQLData\MyDatabase.mdf' -Size 102400 -Growth 10240 -GrowthType 'KB' -IsPrimaryFile -AsSpec
        $primaryFileGroup = New-SqlDscFileGroup -Name 'PRIMARY' -Files @($primaryFile) -IsDefault $true -AsSpec

        $secondaryFile = New-SqlDscDataFile -Name 'MyDatabase_Secondary' -FileName 'E:\SQLData\MyDatabase.ndf' -Size 204800 -AsSpec
        $secondaryFileGroup = New-SqlDscFileGroup -Name 'SECONDARY' -Files @($secondaryFile) -AsSpec

        $serverObject | New-SqlDscDatabase -Name 'MyDatabase' -FileGroup @($primaryFileGroup, $secondaryFileGroup) -Force

        Creates a new database named **MyDatabase** with custom PRIMARY and SECONDARY file groups
        using specification objects created with the -AsSpec parameter. All properties are set
        directly via parameters without prompting for confirmation.

    .OUTPUTS
        `[Microsoft.SqlServer.Management.Smo.Database]`
#>
function New-SqlDscDatabase
{
    [System.Diagnostics.CodeAnalysis.SuppressMessageAttribute('UseSyntacticallyCorrectExamples', '', Justification = 'Because the rule does not yet support parsing the code when a parameter type is not available. The ScriptAnalyzer rule UseSyntacticallyCorrectExamples will always error in the editor due to https://github.com/indented-automation/Indented.ScriptAnalyzerRules/issues/8.')]
    [OutputType([Microsoft.SqlServer.Management.Smo.Database])]
    [CmdletBinding(SupportsShouldProcess = $true, ConfirmImpact = 'Medium', DefaultParameterSetName = 'Database')]
    param
    (
        [Parameter(Mandatory = $true, ValueFromPipeline = $true)]
        [Microsoft.SqlServer.Management.Smo.Server]
        $ServerObject,

        [Parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [System.String]
        $Name,

        [Parameter(ParameterSetName = 'Database')]
        [ValidateNotNullOrEmpty()]
        [System.String]
        $Collation,

        [Parameter(ParameterSetName = 'Database')]
        [Microsoft.SqlServer.Management.Smo.CatalogCollationType]
        $CatalogCollation,

        [Parameter(ParameterSetName = 'Database')]
        [ValidateSet('Version80', 'Version90', 'Version100', 'Version110', 'Version120', 'Version130', 'Version140', 'Version150', 'Version160')]
        [System.String]
        $CompatibilityLevel,

        [Parameter(ParameterSetName = 'Database')]
        [ValidateSet('Simple', 'Full', 'BulkLogged')]
        [System.String]
        $RecoveryModel,

        [Parameter(ParameterSetName = 'Database')]
        [System.String]
        $OwnerName,

        [Parameter(ParameterSetName = 'Database')]
        [System.Boolean]
        $IsLedger,

        [Parameter(Mandatory = $true, ParameterSetName = 'Snapshot')]
        [ValidateNotNullOrEmpty()]
        [System.String]
        $DatabaseSnapshotBaseName,

        [Parameter()]
        [DatabaseFileGroupSpec[]]
        $FileGroup,

        [Parameter()]
        [System.Management.Automation.SwitchParameter]
        $Force,

        [Parameter()]
        [System.Management.Automation.SwitchParameter]
        $Refresh
    )

    begin
    {
        if ($Force.IsPresent -and -not $Confirm)
        {
            $ConfirmPreference = 'None'
        }
    }

    process
    {
        if ($Refresh.IsPresent)
        {
            # Refresh the server object's databases collection
            $ServerObject.Databases.Refresh()
        }

        Write-Verbose -Message ($script:localizedData.Database_Create -f $Name, $ServerObject.InstanceName)

        # Check if the database already exists
        if ($ServerObject.Databases[$Name])
        {
            $errorMessage = $script:localizedData.Database_AlreadyExists -f $Name, $ServerObject.InstanceName

            $PSCmdlet.ThrowTerminatingError(
                [System.Management.Automation.ErrorRecord]::new(
                    [System.InvalidOperationException]::new($errorMessage),
                    'NSD0001', # cspell: disable-line
                    [System.Management.Automation.ErrorCategory]::ResourceExists,
                    $Name
                )
            )
        }

        # Validate compatibility level if specified
        if ($PSBoundParameters.ContainsKey('CompatibilityLevel'))
        {
            $supportedCompatibilityLevels = @{
                8  = @('Version80')
                9  = @('Version80', 'Version90')
                10 = @('Version80', 'Version90', 'Version100')
                11 = @('Version90', 'Version100', 'Version110')
                12 = @('Version100', 'Version110', 'Version120')
                13 = @('Version100', 'Version110', 'Version120', 'Version130')
                14 = @('Version100', 'Version110', 'Version120', 'Version130', 'Version140')
                15 = @('Version100', 'Version110', 'Version120', 'Version130', 'Version140', 'Version150')
                16 = @('Version100', 'Version110', 'Version120', 'Version130', 'Version140', 'Version150', 'Version160')
            }

            if ($CompatibilityLevel -notin $supportedCompatibilityLevels.$($ServerObject.VersionMajor))
            {
                $errorMessage = $script:localizedData.Database_InvalidCompatibilityLevel -f $CompatibilityLevel, $ServerObject.InstanceName

                $PSCmdlet.ThrowTerminatingError(
                    [System.Management.Automation.ErrorRecord]::new(
                        [System.ArgumentException]::new($errorMessage),
                        'NSD0003', # cspell: disable-line
                        [System.Management.Automation.ErrorCategory]::InvalidArgument,
                        $CompatibilityLevel
                    )
                )
            }
        }

        # Validate collation if specified
        if ($PSBoundParameters.ContainsKey('Collation'))
        {
            if ($Collation -notin $ServerObject.EnumCollations().Name)
            {
                $errorMessage = $script:localizedData.Database_InvalidCollation -f $Collation, $ServerObject.InstanceName

                $PSCmdlet.ThrowTerminatingError(
                    [System.Management.Automation.ErrorRecord]::new(
                        [System.ArgumentException]::new($errorMessage),
                        'NSD0004', # cspell: disable-line
                        [System.Management.Automation.ErrorCategory]::InvalidArgument,
                        $Collation
                    )
                )
            }
        }

        # Validate CatalogCollation if specified (requires SQL Server 2019+)
        if ($PSBoundParameters.ContainsKey('CatalogCollation'))
        {
            if ($ServerObject.VersionMajor -lt 15)
            {
                $errorMessage = $script:localizedData.Database_CatalogCollationNotSupported -f $ServerObject.InstanceName, $ServerObject.VersionMajor

                $PSCmdlet.ThrowTerminatingError(
                    [System.Management.Automation.ErrorRecord]::new(
                        [System.InvalidOperationException]::new($errorMessage),
                        'NSD0005', # cspell: disable-line
                        [System.Management.Automation.ErrorCategory]::InvalidOperation,
                        $CatalogCollation
                    )
                )
            }
        }

        # Validate IsLedger if specified (requires SQL Server 2022+)
        if ($PSBoundParameters.ContainsKey('IsLedger'))
        {
            if ($ServerObject.VersionMajor -lt 16)
            {
                $errorMessage = $script:localizedData.Database_IsLedgerNotSupported -f $ServerObject.InstanceName, $ServerObject.VersionMajor

                $PSCmdlet.ThrowTerminatingError(
                    [System.Management.Automation.ErrorRecord]::new(
                        [System.InvalidOperationException]::new($errorMessage),
                        'NSD0007', # cspell: disable-line
                        [System.Management.Automation.ErrorCategory]::InvalidOperation,
                        $IsLedger
                    )
                )
            }
        }

        # Validate source database exists when creating a snapshot
        if ($PSCmdlet.ParameterSetName -eq 'Snapshot')
        {
            if (-not $ServerObject.Databases[$DatabaseSnapshotBaseName])
            {
                $errorMessage = $script:localizedData.Database_SnapshotSourceDatabaseNotFound -f $DatabaseSnapshotBaseName, $ServerObject.InstanceName

                $PSCmdlet.ThrowTerminatingError(
                    [System.Management.Automation.ErrorRecord]::new(
                        [System.InvalidOperationException]::new($errorMessage),
                        'NSD0006', # cspell: disable-line
                        [System.Management.Automation.ErrorCategory]::ObjectNotFound,
                        $DatabaseSnapshotBaseName
                    )
                )
            }
        }

        $verboseDescriptionMessage = $script:localizedData.Database_Create_ShouldProcessVerboseDescription -f $Name, $ServerObject.InstanceName
        $verboseWarningMessage = $script:localizedData.Database_Create_ShouldProcessVerboseWarning -f $Name
        $captionMessage = $script:localizedData.Database_Create_ShouldProcessCaption

        if ($PSCmdlet.ShouldProcess($verboseDescriptionMessage, $verboseWarningMessage, $captionMessage))
        {
            try
            {
                $sqlDatabaseObjectToCreate = New-Object -TypeName 'Microsoft.SqlServer.Management.Smo.Database' -ArgumentList $ServerObject, $Name

                # Handle database snapshot creation
                if ($PSCmdlet.ParameterSetName -eq 'Snapshot')
                {
                    Write-Verbose -Message ($script:localizedData.Database_CreatingSnapshot -f $Name, $DatabaseSnapshotBaseName)

                    $sqlDatabaseObjectToCreate.DatabaseSnapshotBaseName = $DatabaseSnapshotBaseName
                }
                else
                {
                    # Handle regular database creation
                    if ($PSBoundParameters.ContainsKey('RecoveryModel'))
                    {
                        $sqlDatabaseObjectToCreate.RecoveryModel = $RecoveryModel
                    }

                    if ($PSBoundParameters.ContainsKey('Collation'))
                    {
                        $sqlDatabaseObjectToCreate.Collation = $Collation
                    }

                    if ($PSBoundParameters.ContainsKey('CatalogCollation'))
                    {
                        $sqlDatabaseObjectToCreate.CatalogCollation = $CatalogCollation
                    }

                    if ($PSBoundParameters.ContainsKey('CompatibilityLevel'))
                    {
                        $sqlDatabaseObjectToCreate.CompatibilityLevel = $CompatibilityLevel
                    }

                    if ($PSBoundParameters.ContainsKey('IsLedger'))
                    {
                        $sqlDatabaseObjectToCreate.IsLedger = $IsLedger
                    }
                }

                # Add FileGroups if provided (applies to both regular databases and snapshots)
                if ($PSBoundParameters.ContainsKey('FileGroup'))
                {
                    foreach ($fileGroupSpec in $FileGroup)
                    {
                        # Create FileGroup using New-SqlDscFileGroup with spec object
                        $smoFileGroup = New-SqlDscFileGroup -Database $sqlDatabaseObjectToCreate -FileGroupSpec $fileGroupSpec -Force

                        # Add the file group to the database
                        Add-SqlDscFileGroup -Database $sqlDatabaseObjectToCreate -FileGroup $smoFileGroup -Force
                    }
                }

                Write-Verbose -Message ($script:localizedData.Database_Creating -f $Name)

                $sqlDatabaseObjectToCreate.Create()

                <#
                    This must be run after the object is created because
                    the owner property is read-only and the method cannot
                    be call until the object has been created.
                    This only applies to regular databases, not snapshots.
                #>
                if ($PSCmdlet.ParameterSetName -eq 'Database' -and $PSBoundParameters.ContainsKey('OwnerName'))
                {
                    $sqlDatabaseObjectToCreate.SetOwner($OwnerName)
                }

                Write-Verbose -Message ($script:localizedData.Database_Created -f $Name)

                return $sqlDatabaseObjectToCreate
            }
            catch
            {
                $errorMessage = $script:localizedData.Database_CreateFailed -f $Name, $ServerObject.InstanceName

                $PSCmdlet.ThrowTerminatingError(
                    [System.Management.Automation.ErrorRecord]::new(
                        [System.InvalidOperationException]::new($errorMessage, $_.Exception),
                        'NSD0002', # cspell: disable-line
                        [System.Management.Automation.ErrorCategory]::InvalidOperation,
                        $Name
                    )
                )
            }
        }
    }
}
#EndRegion '.\Public\New-SqlDscDatabase.ps1' 399
#Region '.\Public\New-SqlDscDatabaseSnapshot.ps1' -1

<#
    .SYNOPSIS
        Creates a new database snapshot in a SQL Server Database Engine instance.

    .DESCRIPTION
        This command creates a new database snapshot in a SQL Server Database Engine
        instance using SMO. It provides an automated and DSC-friendly approach to
        snapshot management by leveraging the existing `New-SqlDscDatabase` command
        for the actual creation.

    .PARAMETER ServerObject
        Specifies the current server connection object. This parameter is used in the
        ServerObject parameter set.

    .PARAMETER Name
        Specifies the name of the database snapshot to be created.

    .PARAMETER DatabaseName
        Specifies the name of the source database from which to create a snapshot.
        This parameter is used in the ServerObject parameter set.

    .PARAMETER DatabaseObject
        Specifies the source database object to snapshot. This parameter can be
        provided via pipeline and is used in the DatabaseObject parameter set.

    .PARAMETER FileGroup
        Specifies an array of DatabaseFileGroupSpec objects that define the file groups
        and data files for the database snapshot. Each DatabaseFileGroupSpec contains the
        file group name and an array of DatabaseFileSpec objects for the sparse files.
        When not specified, the cmdlet automatically generates DatabaseFileGroupSpec
        and DatabaseFileSpec entries based on the source database's file structure,
        resulting in sparse files being created in the default data directory with
        automatically generated names.

    .PARAMETER Force
        Specifies that the snapshot should be created without any confirmation.

    .PARAMETER Refresh
        Specifies that the **ServerObject**'s databases should be refreshed before
        creating the snapshot. This is helpful when databases could have been
        modified outside of the **ServerObject**, for example through T-SQL. But
        on instances with a large amount of databases it might be better to make
        sure the **ServerObject** is recent enough.

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine -InstanceName 'MyInstance'
        $serverObject | New-SqlDscDatabaseSnapshot -Name 'MyDatabase_Snapshot' -DatabaseName 'MyDatabase'

        Creates a new database snapshot named **MyDatabase_Snapshot** from the source
        database **MyDatabase**.

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine -InstanceName 'MyInstance'
        $databaseObject = $serverObject | Get-SqlDscDatabase -Name 'MyDatabase'
        $databaseObject | New-SqlDscDatabaseSnapshot -Name 'MyDatabase_Snapshot' -Force

        Creates a new database snapshot named **MyDatabase_Snapshot** from the database
        object **MyDatabase** without prompting for confirmation.

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine -InstanceName 'MyInstance'
        $serverObject | New-SqlDscDatabaseSnapshot -Name 'MyDB_Snap' -DatabaseName 'MyDatabase' -Force

        Creates a new database snapshot named **MyDB_Snap** from the source database
        **MyDatabase** without prompting for confirmation.

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine -InstanceName 'MyInstance'
        $sourceDb = $serverObject.Databases['MyDatabase']

        $dataFile = New-SqlDscDataFile -Name 'MyDatabase_Data' -FileName 'C:\Snapshots\MyDatabase_Data.ss' -AsSpec
        $fileGroup = New-SqlDscFileGroup -Name 'PRIMARY' -Files @($dataFile) -AsSpec

        $serverObject | New-SqlDscDatabaseSnapshot -Name 'MyDB_Snap' -DatabaseName 'MyDatabase' -FileGroup @($fileGroup) -Force

        Creates a new database snapshot named **MyDB_Snap** from the source database
        **MyDatabase** with a specified sparse file location without prompting for confirmation.

    .INPUTS
        `[Microsoft.SqlServer.Management.Smo.Server]`

        Specifies the SQL Server connection object to create the snapshot in.

    .INPUTS
        `[Microsoft.SqlServer.Management.Smo.Database]`

        Specifies the source database object to create a snapshot from.

    .OUTPUTS
        `[Microsoft.SqlServer.Management.Smo.Database]`

        Returns the newly created database snapshot object.

    .NOTES
        This command is for snapshot creation only and does not support modification
        of existing snapshots.

        Database snapshots are only supported in certain SQL Server editions (Enterprise,
        Developer, and Evaluation editions). The command will validate edition support
        before attempting to create the snapshot.
#>
function New-SqlDscDatabaseSnapshot
{
    [System.Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSShouldProcess', '', Justification = 'Because ShouldProcess is used in New-SqlDscDatabase')]
    [System.Diagnostics.CodeAnalysis.SuppressMessageAttribute('UseSyntacticallyCorrectExamples', '', Justification = 'Because the rule does not yet support parsing the code when a parameter type is not available. The ScriptAnalyzer rule UseSyntacticallyCorrectExamples will always error in the editor due to https://github.com/indented-automation/Indented.ScriptAnalyzerRules/issues/8.')]
    [OutputType([Microsoft.SqlServer.Management.Smo.Database])]
    [CmdletBinding(SupportsShouldProcess = $true, ConfirmImpact = 'Medium')]
    param
    (
        [Parameter(ParameterSetName = 'ServerObject', Mandatory = $true, ValueFromPipeline = $true)]
        [Microsoft.SqlServer.Management.Smo.Server]
        $ServerObject,

        [Parameter(ParameterSetName = 'DatabaseObject', Mandatory = $true, ValueFromPipeline = $true)]
        [Microsoft.SqlServer.Management.Smo.Database]
        $DatabaseObject,

        [Parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [System.String]
        $Name,

        [Parameter(ParameterSetName = 'ServerObject', Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [System.String]
        $DatabaseName,

        [Parameter()]
        [DatabaseFileGroupSpec[]]
        $FileGroup,

        [Parameter()]
        [System.Management.Automation.SwitchParameter]
        $Force,

        [Parameter(ParameterSetName = 'ServerObject')]
        [System.Management.Automation.SwitchParameter]
        $Refresh
    )

    begin
    {
        if ($Force.IsPresent -and -not $Confirm)
        {
            $ConfirmPreference = 'None'
        }
    }

    process
    {
        # Determine the server object and source database name based on parameter set
        if ($PSCmdlet.ParameterSetName -eq 'DatabaseObject')
        {
            $ServerObject = $DatabaseObject.Parent
            $DatabaseName = $DatabaseObject.Name
        }

        # Validate SQL Server edition supports snapshots
        $supportedEditions = @('Enterprise', 'Developer', 'EnterpriseCore', 'EnterpriseOrDeveloper')

        if ($ServerObject.EngineEdition -notin @('Enterprise', 'EnterpriseEvaluation'))
        {
            # Check edition name for older servers or evaluation
            $editionName = $ServerObject.Edition

            $isSupported = $false

            foreach ($supportedEdition in $supportedEditions)
            {
                if ($editionName -like "*$supportedEdition*")
                {
                    $isSupported = $true
                    break
                }
            }

            # Also check for Evaluation edition
            if ($editionName -like '*Evaluation*')
            {
                $isSupported = $true
            }

            if (-not $isSupported)
            {
                $errorMessage = $script:localizedData.DatabaseSnapshot_EditionNotSupported -f $ServerObject.InstanceName, $editionName

                $PSCmdlet.ThrowTerminatingError(
                    [System.Management.Automation.ErrorRecord]::new(
                        [System.InvalidOperationException]::new($errorMessage),
                        'NSDS0001', # cspell: disable-line
                        [System.Management.Automation.ErrorCategory]::InvalidOperation,
                        $ServerObject
                    )
                )
            }
        }

        Write-Verbose -Message ($script:localizedData.DatabaseSnapshot_Create -f $Name, $DatabaseName, $ServerObject.InstanceName)

        # If FileGroup is not specified, automatically create file groups based on source database
        if (-not $PSBoundParameters.ContainsKey('FileGroup'))
        {
            # Get the source database object
            $getSqlDscDatabaseParameters = @{
                ServerObject = $ServerObject
                Name = $DatabaseName
                ErrorAction = 'Stop'
            }

            if ($PSCmdlet.ParameterSetName -eq 'ServerObject' -and $Refresh.IsPresent)
            {
                $getSqlDscDatabaseParameters['Refresh'] = $true
            }

            $sourceDatabase = Get-SqlDscDatabase @getSqlDscDatabaseParameters

            # Get the default data directory for sparse files
            $defaultDataDirectory = $ServerObject.Settings.DefaultFile

            if (-not $defaultDataDirectory)
            {
                $defaultDataDirectory = $ServerObject.Information.MasterDBPath
            }

            # Create file group specifications for all file groups in the source database
            $generatedFileGroups = [System.Collections.Generic.List[DatabaseFileGroupSpec]]::new()

            foreach ($sourceFileGroup in $sourceDatabase.FileGroups)
            {
                $fileSpecs = [System.Collections.Generic.List[DatabaseFileSpec]]::new()

                foreach ($sourceFile in $sourceFileGroup.Files)
                {
                    # Use the same physical filename as the source file, but with .ss extension
                    $sourceFileName = [System.IO.Path]::GetFileNameWithoutExtension($sourceFile.FileName)
                    $sparseFileName = '{0}.ss' -f $sourceFileName
                    $sparseFilePath = Join-Path -Path $defaultDataDirectory -ChildPath $sparseFileName

                    # Create a file spec using the same logical name as the source database file
                    $fileSpecs.Add((New-SqlDscDataFile -Name $sourceFile.Name -FileName $sparseFilePath -AsSpec))
                }

                # Create file group spec
                $generatedFileGroups.Add((New-SqlDscFileGroup -Name $sourceFileGroup.Name -Files $fileSpecs.ToArray() -AsSpec))
            }

            $FileGroup = $generatedFileGroups.ToArray()
        }

        # Create the snapshot using New-SqlDscDatabase
        $newSqlDscDatabaseParameters = @{
            ServerObject = $ServerObject
            Name = $Name
            DatabaseSnapshotBaseName = $DatabaseName
            FileGroup = $FileGroup
            Force = $Force
            WhatIf = $WhatIfPreference
        }

        if ($PSCmdlet.ParameterSetName -eq 'ServerObject' -and $Refresh.IsPresent)
        {
            $newSqlDscDatabaseParameters['Refresh'] = $true
        }

        $snapshotDatabaseObject = New-SqlDscDatabase @newSqlDscDatabaseParameters

        return $snapshotDatabaseObject
    }
}
#EndRegion '.\Public\New-SqlDscDatabaseSnapshot.ps1' 270
#Region '.\Public\New-SqlDscDataFile.ps1' -1

<#
    .SYNOPSIS
        Creates a new DataFile object for a SQL Server FileGroup and adds it to the FileGroup.

    .DESCRIPTION
        This command creates a new DataFile object and automatically adds it to the specified
        FileGroup's Files collection. The DataFile object represents a physical database file
        (.mdf, .ndf, or .ss for snapshots).

    .PARAMETER FileGroup
        Specifies the FileGroup object to which this DataFile will belong. The DataFile
        will be automatically added to this FileGroup's Files collection.

    .PARAMETER Name
        Specifies the logical name of the DataFile.

    .PARAMETER FileName
        Specifies the physical path and filename for the DataFile. For database snapshots,
        this should point to a sparse file location (typically with an .ss extension).
        For regular databases, this should be the data file path (typically with .mdf
        or .ndf extension).

    .PARAMETER DataFileSpec
        Specifies a DatabaseFileSpec object that defines the data file configuration
        including name, file path, size, growth, and other properties.

    .PARAMETER AsSpec
        Returns a DatabaseFileSpec object instead of a SMO DataFile object.
        This specification object can be used with New-SqlDscFileGroup -AsSpec
        or passed directly to New-SqlDscDatabase to define data files before
        the database is created.

        When this parameter is used, the command always returns a DatabaseFileSpec
        object, regardless of the PassThru parameter, and the FileGroup parameter
        is not available.

    .PARAMETER Size
        Specifies the initial size of the data file in kilobytes. Only valid when
        used with the -AsSpec parameter to create a DatabaseFileSpec object.

    .PARAMETER MaxSize
        Specifies the maximum size to which the data file can grow, in kilobytes.
        Only valid when used with the -AsSpec parameter to create a DatabaseFileSpec
        object.

    .PARAMETER Growth
        Specifies the amount by which the data file grows when it requires more space.
        The value is interpreted according to the GrowthType parameter (kilobytes or
        percentage). Only valid when used with the -AsSpec parameter to create a
        DatabaseFileSpec object.

    .PARAMETER GrowthType
        Specifies the type of growth for the data file. Valid values are 'KB', 'MB',
        or 'Percent'. Only valid when used with the -AsSpec parameter to create a
        DatabaseFileSpec object.

    .PARAMETER IsPrimaryFile
        Specifies that this data file is the primary file in the PRIMARY filegroup.
        Only valid when used with the -AsSpec parameter to create a DatabaseFileSpec
        object.

    .PARAMETER PassThru
        Returns the DataFile object that was created and added to the FileGroup.
        Only available when using the Standard or FromSpec parameter sets. When
        using the AsSpec parameter set, a DatabaseFileSpec object is always returned.

    .PARAMETER Force
        Specifies that the DataFile object should be created without prompting for
        confirmation. By default, the command prompts for confirmation when the FileGroup
        parameter is provided.

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine -InstanceName 'MyInstance'
        $database = $serverObject.Databases['MyDatabase']
        $fileGroup = New-SqlDscFileGroup -Database $database -Name 'PRIMARY'
        New-SqlDscDataFile -FileGroup $fileGroup -Name 'MyDatabase_Data' -FileName 'C:\Data\MyDatabase_Data.mdf' -Force

        Creates a new DataFile for a regular database with a FileGroup and adds it to the FileGroup.

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine -InstanceName 'MyInstance'
        $database = $serverObject.Databases['MyDatabase']
        $fileGroup = New-SqlDscFileGroup -Database $database -Name 'PRIMARY'
        $dataFile = New-SqlDscDataFile -FileGroup $fileGroup -Name 'MySnapshot_Data' -FileName 'C:\Snapshots\MySnapshot_Data.ss' -PassThru -Force

        Creates a new sparse file for a database snapshot and returns the DataFile object.

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine -InstanceName 'MyInstance'
        $database = $serverObject.Databases['MyDatabase']
        $fileGroup = $database.FileGroups['PRIMARY']
        $dataFile = New-SqlDscDataFile -FileGroup $fileGroup -Name 'AdditionalData' -FileName 'C:\Data\AdditionalData.ndf' -PassThru -Force

        Creates an additional DataFile and returns it for further processing.

    .EXAMPLE
        $dataFileSpec = New-SqlDscDataFile -Name 'MyDB_Primary' -FileName 'D:\SQLData\MyDB.mdf' -AsSpec

        Creates a DatabaseFileSpec object that can be used with New-SqlDscFileGroup -AsSpec
        or passed to New-SqlDscDatabase.

    .EXAMPLE
        $dataFileSpec = New-SqlDscDataFile -Name 'MyDB_Primary' -FileName 'D:\SQLData\MyDB.mdf' -Size 102400 -MaxSize 5242880 -Growth 10240 -GrowthType 'KB' -IsPrimaryFile -AsSpec

        Creates a DatabaseFileSpec object with all properties set directly via parameters.

    .INPUTS
        None

        This cmdlet does not accept input from the pipeline.

    .OUTPUTS
        None

        This cmdlet does not generate output by default when using Standard or FromSpec parameter sets without PassThru.

    .OUTPUTS
        Microsoft.SqlServer.Management.Smo.DataFile

        When using the Standard or FromSpec parameter sets with the PassThru parameter.

    .OUTPUTS
        DatabaseFileSpec

        When using the AsSpec parameter to create a specification object.
#>
function New-SqlDscDataFile
{
    [System.Diagnostics.CodeAnalysis.SuppressMessageAttribute('UseSyntacticallyCorrectExamples', '', Justification = 'Because the rule does not yet support parsing the code when a parameter type is not available. The ScriptAnalyzer rule UseSyntacticallyCorrectExamples will always error in the editor due to https://github.com/indented-automation/Indented.ScriptAnalyzerRules/issues/8.')]
    [CmdletBinding(DefaultParameterSetName = 'Standard', SupportsShouldProcess = $true, ConfirmImpact = 'High')]
    [OutputType([Microsoft.SqlServer.Management.Smo.DataFile])]
    [OutputType([DatabaseFileSpec])]
    param
    (
        [Parameter(Mandatory = $true, ParameterSetName = 'Standard')]
        [Parameter(Mandatory = $true, ParameterSetName = 'FromSpec')]
        [Microsoft.SqlServer.Management.Smo.FileGroup]
        $FileGroup,

        [Parameter(Mandatory = $true, ParameterSetName = 'Standard')]
        [Parameter(Mandatory = $true, ParameterSetName = 'AsSpec')]
        [ValidateNotNullOrEmpty()]
        [System.String]
        $Name,

        [Parameter(Mandatory = $true, ParameterSetName = 'Standard')]
        [Parameter(Mandatory = $true, ParameterSetName = 'AsSpec')]
        [ValidateNotNullOrEmpty()]
        [System.String]
        $FileName,

        [Parameter(Mandatory = $true, ParameterSetName = 'FromSpec')]
        [ValidateNotNull()]
        [DatabaseFileSpec]
        $DataFileSpec,

        [Parameter(Mandatory = $true, ParameterSetName = 'AsSpec')]
        [System.Management.Automation.SwitchParameter]
        $AsSpec,

        [Parameter(ParameterSetName = 'AsSpec')]
        [System.Nullable[System.Double]]
        $Size,

        [Parameter(ParameterSetName = 'AsSpec')]
        [System.Nullable[System.Double]]
        $MaxSize,

        [Parameter(ParameterSetName = 'AsSpec')]
        [System.Nullable[System.Double]]
        $Growth,

        [Parameter(ParameterSetName = 'AsSpec')]
        [ValidateSet('KB', 'MB', 'Percent')]
        [System.String]
        $GrowthType,

        [Parameter(ParameterSetName = 'AsSpec')]
        [System.Management.Automation.SwitchParameter]
        $IsPrimaryFile,

        [Parameter(ParameterSetName = 'Standard')]
        [Parameter(ParameterSetName = 'FromSpec')]
        [System.Management.Automation.SwitchParameter]
        $PassThru,

        [Parameter(ParameterSetName = 'Standard')]
        [Parameter(ParameterSetName = 'FromSpec')]
        [System.Management.Automation.SwitchParameter]
        $Force
    )

    if ($Force.IsPresent -and -not $Confirm)
    {
        $ConfirmPreference = 'None'
    }

    if ($PSCmdlet.ParameterSetName -eq 'AsSpec')
    {
        $fileSpec = [DatabaseFileSpec]::new($Name, $FileName)

        if ($PSBoundParameters.ContainsKey('Size'))
        {
            $fileSpec.Size = $Size
        }

        if ($PSBoundParameters.ContainsKey('MaxSize'))
        {
            $fileSpec.MaxSize = $MaxSize
        }

        if ($PSBoundParameters.ContainsKey('Growth'))
        {
            $fileSpec.Growth = $Growth
        }

        if ($PSBoundParameters.ContainsKey('GrowthType'))
        {
            $fileSpec.GrowthType = $GrowthType
        }

        if ($IsPrimaryFile.IsPresent)
        {
            $fileSpec.IsPrimaryFile = $true
        }

        return $fileSpec
    }

    # Validate that primary files can only be in the PRIMARY filegroup
    if ($PSCmdlet.ParameterSetName -in @('FromSpec'))
    {
        $isPrimary = $null -ne $DataFileSpec -and $DataFileSpec.IsPrimaryFile

        if ($isPrimary -and $FileGroup.Name -ne 'PRIMARY')
        {
            $PSCmdlet.ThrowTerminatingError(
                [System.Management.Automation.ErrorRecord]::new(
                    ($script:localizedData.DataFile_PrimaryFileMustBeInPrimaryFileGroup),
                    'NSDDF0003',
                    [System.Management.Automation.ErrorCategory]::InvalidArgument,
                    $FileGroup
                )
            )
        }
    }

    # Determine the data file name based on parameter set
    $dataFileName = if ($PSCmdlet.ParameterSetName -eq 'FromSpec')
    {
        $DataFileSpec.Name
    }
    else
    {
        $Name
    }

    $descriptionMessage = $script:localizedData.DataFile_Create_ShouldProcessDescription -f $dataFileName, $FileGroup.Name
    $confirmationMessage = $script:localizedData.DataFile_Create_ShouldProcessConfirmation -f $dataFileName
    $captionMessage = $script:localizedData.DataFile_Create_ShouldProcessCaption

    if ($PSCmdlet.ShouldProcess($descriptionMessage, $confirmationMessage, $captionMessage))
    {
        if ($PSCmdlet.ParameterSetName -eq 'FromSpec')
        {
            # Convert the spec object to SMO DataFile
            $dataFileObject = ConvertTo-SqlDscDataFile -FileGroupObject $FileGroup -DataFileSpec $DataFileSpec
        }
        else
        {
            $dataFileObject = [Microsoft.SqlServer.Management.Smo.DataFile]::new($FileGroup, $Name, $FileName)
        }

        $FileGroup.Files.Add($dataFileObject)

        if ($PassThru.IsPresent)
        {
            return $dataFileObject
        }
    }
}
#EndRegion '.\Public\New-SqlDscDataFile.ps1' 282
#Region '.\Public\New-SqlDscFileGroup.ps1' -1

<#
    .SYNOPSIS
        Creates a new FileGroup object for a SQL Server database.

    .DESCRIPTION
        This command creates a new FileGroup object that can be used when creating
        or modifying SQL Server databases. The FileGroup object can contain DataFile
        objects. The FileGroup can be created with or without an associated Database,
        allowing it to be added to a Database later using Add-SqlDscFileGroup.

    .PARAMETER Database
        Specifies the Database object to which this FileGroup will belong. This parameter
        is optional. If not specified, a standalone FileGroup is created that can be
        added to a Database later.

    .PARAMETER Name
        Specifies the name of the FileGroup to create.

    .PARAMETER FileGroupSpec
        Specifies a DatabaseFileGroupSpec object that defines the file group configuration
        including name, properties, and data files.

    .PARAMETER AsSpec
        Returns a DatabaseFileGroupSpec object instead of a SMO FileGroup object.
        This specification object can be passed to New-SqlDscDatabase to define
        file groups before the database is created.

    .PARAMETER Files
        Specifies an array of DatabaseFileSpec objects to include in the file group.
        Only valid when using -AsSpec.

    .PARAMETER ReadOnly
        Specifies whether the file group should be read-only. Only valid when using -AsSpec.

    .PARAMETER IsDefault
        Specifies whether this file group should be the default file group. Only valid when using -AsSpec.

    .PARAMETER Force
        Specifies that the FileGroup object should be created without prompting for
        confirmation. By default, the command prompts for confirmation when the Database
        parameter is provided.

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine -InstanceName 'MyInstance'
        $database = $serverObject.Databases['MyDatabase']
        $fileGroup = New-SqlDscFileGroup -Database $database -Name 'MyFileGroup'

        Creates a new FileGroup named 'MyFileGroup' for the specified database.

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine -InstanceName 'MyInstance'
        $database = $serverObject.Databases['MyDatabase']
        $fileGroup = New-SqlDscFileGroup -Database $database -Name 'PRIMARY'

        Creates a new PRIMARY FileGroup for the specified database.

    .EXAMPLE
        $fileGroup = New-SqlDscFileGroup -Name 'MyFileGroup'
        # Later add to database
        Add-SqlDscFileGroup -Database $database -FileGroup $fileGroup

        Creates a standalone FileGroup that can be added to a Database later.

    .EXAMPLE
        $fileGroupSpec = New-SqlDscFileGroup -Name 'PRIMARY' -AsSpec

        Creates a DatabaseFileGroupSpec object that can be passed to New-SqlDscDatabase.

    .EXAMPLE
        $primaryFile = New-SqlDscDataFile -Name 'MyDB_Primary' -FileName 'D:\SQLData\MyDB.mdf' -Size 102400 -IsPrimaryFile -AsSpec
        $fileGroupSpec = New-SqlDscFileGroup -Name 'PRIMARY' -Files @($primaryFile) -IsDefault $true -AsSpec

        Creates a DatabaseFileGroupSpec object with files and properties set directly via parameters.

    .INPUTS
        None

        This cmdlet does not accept input from the pipeline.

    .OUTPUTS
        Microsoft.SqlServer.Management.Smo.FileGroup

        When creating a FileGroup with or without an associated Database (not using -AsSpec).

    .OUTPUTS
        DatabaseFileGroupSpec

        When using the -AsSpec parameter to create a specification object.
#>
function New-SqlDscFileGroup
{
    [System.Diagnostics.CodeAnalysis.SuppressMessageAttribute('UseSyntacticallyCorrectExamples', '', Justification = 'Because the rule does not yet support parsing the code when a parameter type is not available. The ScriptAnalyzer rule UseSyntacticallyCorrectExamples will always error in the editor due to https://github.com/indented-automation/Indented.ScriptAnalyzerRules/issues/8.')]
    [CmdletBinding(DefaultParameterSetName = 'Standalone', SupportsShouldProcess = $true, ConfirmImpact = 'High')]
    [OutputType([Microsoft.SqlServer.Management.Smo.FileGroup])]
    [OutputType([DatabaseFileGroupSpec])]
    param
    (
        [Parameter(Mandatory = $true, ParameterSetName = 'WithDatabase')]
        [Parameter(Mandatory = $true, ParameterSetName = 'WithDatabaseFromSpec')]
        [Microsoft.SqlServer.Management.Smo.Database]
        $Database,

        [Parameter(Mandatory = $true, ParameterSetName = 'WithDatabase')]
        [Parameter(Mandatory = $true, ParameterSetName = 'Standalone')]
        [Parameter(Mandatory = $true, ParameterSetName = 'AsSpec')]
        [ValidateNotNullOrEmpty()]
        [System.String]
        $Name,

        [Parameter(Mandatory = $true, ParameterSetName = 'WithDatabaseFromSpec')]
        [DatabaseFileGroupSpec]
        $FileGroupSpec,

        [Parameter(Mandatory = $true, ParameterSetName = 'AsSpec')]
        [System.Management.Automation.SwitchParameter]
        $AsSpec,

        [Parameter(ParameterSetName = 'AsSpec')]
        [DatabaseFileSpec[]]
        $Files,

        [Parameter(ParameterSetName = 'AsSpec')]
        [System.Management.Automation.SwitchParameter]
        $ReadOnly,

        [Parameter(ParameterSetName = 'AsSpec')]
        [System.Management.Automation.SwitchParameter]
        $IsDefault,

        [Parameter(ParameterSetName = 'WithDatabase')]
        [Parameter(ParameterSetName = 'WithDatabaseFromSpec')]
        [System.Management.Automation.SwitchParameter]
        $Force
    )

    if ($Force.IsPresent -and -not $Confirm)
    {
        $ConfirmPreference = 'None'
    }

    $fileGroupObject = $null

    if ($PSCmdlet.ParameterSetName -in @('WithDatabase', 'WithDatabaseFromSpec'))
    {
        if (-not $Database.Parent)
        {
            $errorMessage = $script:localizedData.FileGroup_DatabaseMissingServerObject

            $PSCmdlet.ThrowTerminatingError(
                [System.Management.Automation.ErrorRecord]::new(
                    $errorMessage,
                    'NSDFG0003',
                    [System.Management.Automation.ErrorCategory]::InvalidArgument,
                    $Database
                )
            )
        }

        $serverObject = $Database.Parent

        # Determine the file group name based on parameter set
        $fileGroupName = if ($PSCmdlet.ParameterSetName -eq 'WithDatabaseFromSpec')
        {
            $FileGroupSpec.Name
        }
        else
        {
            $Name
        }

        $descriptionMessage = $script:localizedData.FileGroup_Create_ShouldProcessDescription -f $fileGroupName, $Database.Name, $serverObject.InstanceName
        $confirmationMessage = $script:localizedData.FileGroup_Create_ShouldProcessConfirmation -f $fileGroupName
        $captionMessage = $script:localizedData.FileGroup_Create_ShouldProcessCaption

        if ($PSCmdlet.ShouldProcess($descriptionMessage, $confirmationMessage, $captionMessage))
        {
            if ($PSCmdlet.ParameterSetName -eq 'WithDatabaseFromSpec')
            {
                # Convert the spec object to SMO FileGroup
                $fileGroupObject = ConvertTo-SqlDscFileGroup -DatabaseObject $Database -FileGroupSpec $FileGroupSpec
            }
            else
            {
                $fileGroupObject = [Microsoft.SqlServer.Management.Smo.FileGroup]::new($Database, $Name)
            }
        }
    }
    else
    {
        if ($AsSpec.IsPresent)
        {
            $fileGroupObject = [DatabaseFileGroupSpec]::new($Name)

            if ($PSBoundParameters.ContainsKey('Files'))
            {
                $fileGroupObject.Files = $Files
            }

            if ($ReadOnly.IsPresent)
            {
                $fileGroupObject.ReadOnly = $true
            }

            if ($IsDefault.IsPresent)
            {
                $fileGroupObject.IsDefault = $true
            }
        }
        else
        {
            $fileGroupObject = [Microsoft.SqlServer.Management.Smo.FileGroup]::new()

            $fileGroupObject.Name = $Name
        }
    }

    return $fileGroupObject
}
#EndRegion '.\Public\New-SqlDscFileGroup.ps1' 219
#Region '.\Public\New-SqlDscLogin.ps1' -1

<#
    .SYNOPSIS
        Creates a new login on a SQL Server Database Engine instance.

    .DESCRIPTION
        This command creates a new login on a SQL Server Database Engine instance.
        The login can be a SQL Server login, a Windows login (user or group),
        a certificate-based login, or an asymmetric key-based login.
    .PARAMETER ServerObject
        Specifies current server connection object.

    .PARAMETER Name
        Specifies the name of the login to be created.

    .PARAMETER SqlLogin
        Specifies that a SQL Server login should be created.

    .PARAMETER WindowsUser
        Specifies that a Windows user login should be created.

    .PARAMETER WindowsGroup
        Specifies that a Windows group login should be created.

    .PARAMETER Certificate
        Specifies that a certificate-based login should be created.

    .PARAMETER AsymmetricKey
        Specifies that an asymmetric key-based login should be created.

    .PARAMETER SecurePassword
        Specifies the password as a SecureString for SQL Server logins. This
        parameter is required when creating a SQL Server login.

    .PARAMETER CertificateName
        Specifies the certificate name when creating a certificate-based login.

    .PARAMETER AsymmetricKeyName
        Specifies the asymmetric key name when creating an asymmetric key-based login.

    .PARAMETER DefaultDatabase
        Specifies the default database for the login. If not specified,
        'master' will be used as the default database.

    .PARAMETER DefaultLanguage
        Specifies the default language for the login.

    .PARAMETER PasswordExpirationEnabled
        Specifies whether password expiration is enabled for SQL Server logins.
        Only applies when creating a SQL Server login.

    .PARAMETER PasswordPolicyEnforced
        Specifies whether password policy is enforced for SQL Server logins.
        Only applies when creating a SQL Server login.

    .PARAMETER MustChangePassword
        Specifies whether the user must change the password on next login.
        Only applies when creating a SQL Server login.

    .PARAMETER IsHashed
        Specifies whether the provided password is already hashed.
        Only applies when creating a SQL Server login.

    .PARAMETER Disabled
        Specifies whether the login should be created in a disabled state.

    .PARAMETER Force
        Specifies that the login should be created without any confirmation.

    .PARAMETER PassThru
        If specified, the created login object will be returned.

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine -InstanceName 'MyInstance'
        $securePassword = ConvertTo-SecureString -String 'MyPassword123!' -AsPlainText -Force
        $serverObject | New-SqlDscLogin -Name 'MyLogin' -SqlLogin -SecurePassword $securePassword

        Creates a new SQL Server login named 'MyLogin' with the specified password.

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine -InstanceName 'MyInstance'
        $securePassword = ConvertTo-SecureString -String 'MyPassword123!' -AsPlainText -Force
        $serverObject | New-SqlDscLogin -Name 'MyLogin' -SqlLogin -SecurePassword $securePassword -MustChangePassword

        Creates a new SQL Server login named 'MyLogin' with a SecureString password that must be changed on first login.

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine -InstanceName 'MyInstance'
        $serverObject | New-SqlDscLogin -Name 'DOMAIN\MyUser' -WindowsUser

        Creates a new Windows user login for 'DOMAIN\MyUser'.

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine -InstanceName 'MyInstance'
        $serverObject | New-SqlDscLogin -Name 'DOMAIN\MyGroup' -WindowsGroup

        Creates a new Windows group login for 'DOMAIN\MyGroup'.

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine -InstanceName 'MyInstance'
        $serverObject | New-SqlDscLogin -Name 'MyCertLogin' -Certificate -CertificateName 'MyCertificate'

        Creates a new certificate-based login using the specified certificate.

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine -InstanceName 'MyInstance'
        $hashedPassword = ConvertTo-SecureString -String '0x020012345678...' -AsPlainText -Force
        $serverObject | New-SqlDscLogin -Name 'MyHashedLogin' -SqlLogin -SecurePassword $hashedPassword -IsHashed

        Creates a new SQL Server login with a pre-hashed password. Note that password
        policy options (PasswordExpirationEnabled, PasswordPolicyEnforced, MustChangePassword)
        cannot be used with hashed passwords.

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine -InstanceName 'MyInstance'
        $securePassword = ConvertTo-SecureString -String 'MyPassword123!' -AsPlainText -Force
        $loginObject = $serverObject | New-SqlDscLogin -Name 'MyLogin' -SqlLogin -SecurePassword $securePassword -PassThru

        Creates a new SQL Server login and returns the Login object.

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine -InstanceName 'MyInstance'
        $serverObject | New-SqlDscLogin -Name 'MyAsymmetricKeyLogin' -AsymmetricKey -AsymmetricKeyName 'MyAsymmetricKey'

        Creates a new asymmetric key-based login using the specified asymmetric key.

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine -InstanceName 'MyInstance'
        $serverObject | New-SqlDscLogin -Name 'MyAsymmetricKeyLogin' -AsymmetricKey -AsymmetricKeyName 'MyAsymmetricKey' -PassThru

        Creates a new asymmetric key-based login and returns the Login object.

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine -InstanceName 'MyInstance'
        $securePassword = ConvertTo-SecureString -String 'NewPassword123!' -AsPlainText -Force
        $serverObject | New-SqlDscLogin -Name 'ExistingLogin' -SqlLogin -SecurePassword $securePassword -Force

        Creates a SQL Server login named 'ExistingLogin' without confirmation prompts.
        Note: If the login already exists, the command throws a terminating error.

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine -InstanceName 'MyInstance'
        $securePassword = ConvertTo-SecureString -String 'MyPassword123!' -AsPlainText -Force
        $serverObject | New-SqlDscLogin -Name 'DisabledLogin' -SqlLogin -SecurePassword $securePassword -Disabled

        Creates a new SQL Server login in a disabled state.

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine -InstanceName 'MyInstance'
        $serverObject | New-SqlDscLogin -Name 'DOMAIN\DisabledUser' -WindowsUser -Disabled -PassThru

        Creates a new disabled Windows user login and returns the Login object.

    .OUTPUTS
        `[Microsoft.SqlServer.Management.Smo.Login]` when passing parameter **PassThru**,
         otherwise none.

    .INPUTS
        `[Microsoft.SqlServer.Management.Smo.Server]` Accepted from the pipeline. This cmdlet accepts a SMO Server
        object (for example, the output of `Connect-SqlDscDatabaseEngine`) via the pipeline.

    .NOTES
        This command has the confirm impact level set to medium since a login is
        created but by default it does not have any special permissions.
#>
function New-SqlDscLogin
{
    [System.Diagnostics.CodeAnalysis.SuppressMessageAttribute('UseSyntacticallyCorrectExamples', '', Justification = 'Because the rule does not yet support parsing the code when a parameter type is not available. The ScriptAnalyzer rule UseSyntacticallyCorrectExamples will always error in the editor due to https://github.com/indented-automation/Indented.ScriptAnalyzerRules/issues/8.')]
    [OutputType([Microsoft.SqlServer.Management.Smo.Login])]
    [CmdletBinding(SupportsShouldProcess = $true, ConfirmImpact = 'Medium', DefaultParameterSetName = 'WindowsUser')]
    param
    (
        [Parameter(ParameterSetName = 'WindowsUser', Mandatory = $true, ValueFromPipeline = $true)]
        [Parameter(ParameterSetName = 'WindowsGroup', Mandatory = $true, ValueFromPipeline = $true)]
        [Parameter(ParameterSetName = 'SqlLogin', Mandatory = $true, ValueFromPipeline = $true)]
        [Parameter(ParameterSetName = 'SqlLoginHashed', Mandatory = $true, ValueFromPipeline = $true)]
        [Parameter(ParameterSetName = 'Certificate', Mandatory = $true, ValueFromPipeline = $true)]
        [Parameter(ParameterSetName = 'AsymmetricKey', Mandatory = $true, ValueFromPipeline = $true)]
        [Microsoft.SqlServer.Management.Smo.Server]
        $ServerObject,

        [Parameter(Mandatory = $true)]
        [System.String]
        $Name,

        [Parameter(ParameterSetName = 'SqlLogin', Mandatory = $true)]
        [Parameter(ParameterSetName = 'SqlLoginHashed', Mandatory = $true)]
        [System.Management.Automation.SwitchParameter]
        $SqlLogin,

        [Parameter(ParameterSetName = 'WindowsUser', Mandatory = $true)]
        [System.Management.Automation.SwitchParameter]
        $WindowsUser,

        [Parameter(ParameterSetName = 'WindowsGroup', Mandatory = $true)]
        [System.Management.Automation.SwitchParameter]
        $WindowsGroup,

        [Parameter(ParameterSetName = 'Certificate', Mandatory = $true)]
        [System.Management.Automation.SwitchParameter]
        $Certificate,

        [Parameter(ParameterSetName = 'AsymmetricKey', Mandatory = $true)]
        [System.Management.Automation.SwitchParameter]
        $AsymmetricKey,

        [Parameter(ParameterSetName = 'SqlLogin', Mandatory = $true)]
        [Parameter(ParameterSetName = 'SqlLoginHashed', Mandatory = $true)]
        [System.Security.SecureString]
        $SecurePassword,

        [Parameter(ParameterSetName = 'Certificate', Mandatory = $true)]
        [System.String]
        $CertificateName,

        [Parameter(ParameterSetName = 'AsymmetricKey', Mandatory = $true)]
        [System.String]
        $AsymmetricKeyName,

        [Parameter()]
        [System.String]
        $DefaultDatabase = 'master',

        [Parameter()]
        [System.String]
        $DefaultLanguage,

        [Parameter(ParameterSetName = 'SqlLogin')]
        [System.Management.Automation.SwitchParameter]
        $PasswordExpirationEnabled,

        [Parameter(ParameterSetName = 'SqlLogin')]
        [System.Management.Automation.SwitchParameter]
        $PasswordPolicyEnforced,

        [Parameter(ParameterSetName = 'SqlLogin')]
        [System.Management.Automation.SwitchParameter]
        $MustChangePassword,

        [Parameter(ParameterSetName = 'SqlLoginHashed', Mandatory = $true)]
        [System.Management.Automation.SwitchParameter]
        $IsHashed,

        [Parameter()]
        [System.Management.Automation.SwitchParameter]
        $Disabled,

        [Parameter()]
        [System.Management.Automation.SwitchParameter]
        $Force,

        [Parameter()]
        [System.Management.Automation.SwitchParameter]
        $PassThru
    )

    process
    {
        if ($Force.IsPresent -and -not $Confirm)
        {
            $ConfirmPreference = 'None'
        }

        # Determine login type from parameter set
        $loginType = $PSCmdlet.ParameterSetName

        # Check if login already exists
        if (Test-SqlDscIsLogin -ServerObject $ServerObject -Name $Name)
        {
            $errorMessage = $script:localizedData.Login_Add_LoginAlreadyExists -f $Name, $ServerObject.InstanceName

            $PSCmdlet.ThrowTerminatingError(
                [System.Management.Automation.ErrorRecord]::new(
                    $errorMessage,
                    'NSDL0001', # cspell: disable-line
                    [System.Management.Automation.ErrorCategory]::ResourceExists,
                    $Name
                )
            )
        }

        $verboseDescriptionMessage = $script:localizedData.Login_Add_ShouldProcessVerboseDescription -f $Name, $loginType, $ServerObject.InstanceName
        $verboseWarningMessage = $script:localizedData.Login_Add_ShouldProcessVerboseWarning -f $Name
        $captionMessage = $script:localizedData.Login_Add_ShouldProcessCaption

        if ($PSCmdlet.ShouldProcess($verboseDescriptionMessage, $verboseWarningMessage, $captionMessage))
        {
            # Create the login object
            $loginObject = [Microsoft.SqlServer.Management.Smo.Login]::new($ServerObject, $Name)

            # Set login type
            switch ($loginType)
            {
                { $_ -in 'SqlLogin', 'SqlLoginHashed' }
                {
                    $loginObject.LoginType = [Microsoft.SqlServer.Management.Smo.LoginType]::SqlLogin
                }

                'WindowsUser'
                {
                    $loginObject.LoginType = [Microsoft.SqlServer.Management.Smo.LoginType]::WindowsUser
                }

                'WindowsGroup'
                {
                    $loginObject.LoginType = [Microsoft.SqlServer.Management.Smo.LoginType]::WindowsGroup
                }

                'Certificate'
                {
                    $loginObject.LoginType = [Microsoft.SqlServer.Management.Smo.LoginType]::Certificate
                    $loginObject.Certificate = $CertificateName
                }

                'AsymmetricKey'
                {
                    $loginObject.LoginType = [Microsoft.SqlServer.Management.Smo.LoginType]::AsymmetricKey
                    $loginObject.AsymmetricKey = $AsymmetricKeyName
                }
            }

            # Set default database
            $loginObject.DefaultDatabase = $DefaultDatabase

            # Set default language if specified
            if ($PSBoundParameters.ContainsKey('DefaultLanguage'))
            {
                $loginObject.Language = $DefaultLanguage
            }

            # Set SQL Server login specific properties
            if ($loginType -in 'SqlLogin', 'SqlLoginHashed')
            {
                # Prepare login creation options
                $loginCreateOptions = [Microsoft.SqlServer.Management.Smo.LoginCreateOptions]::None

                if ($loginType -eq 'SqlLogin')
                {
                    # Regular SQL login - can use password policy options
                    $loginObject.PasswordExpirationEnabled = $PasswordExpirationEnabled.IsPresent
                    $loginObject.PasswordPolicyEnforced = $PasswordPolicyEnforced.IsPresent

                    if ($MustChangePassword.IsPresent)
                    {
                        $loginCreateOptions = $loginCreateOptions -bor [Microsoft.SqlServer.Management.Smo.LoginCreateOptions]::MustChange
                    }
                }
                elseif ($loginType -eq 'SqlLoginHashed')
                {
                    # Hashed SQL login - cannot use password policy options
                    $loginCreateOptions = $loginCreateOptions -bor [Microsoft.SqlServer.Management.Smo.LoginCreateOptions]::IsHashed
                }

                # Create the login with password
                $loginObject.Create($SecurePassword, $loginCreateOptions)
            }
            else
            {
                # Create login without password for Windows logins, Certificate, and AsymmetricKey
                $loginObject.Create()
            }

            # Disable login if requested
            if ($Disabled.IsPresent)
            {
                $loginObject.Disable()
            }

            Write-Verbose -Message ($script:localizedData.Login_Add_LoginCreated -f $Name, $ServerObject.InstanceName)

            if ($PassThru.IsPresent)
            {
                return $loginObject
            }
        }
    }
}
#EndRegion '.\Public\New-SqlDscLogin.ps1' 377
#Region '.\Public\New-SqlDscRole.ps1' -1

<#
    .SYNOPSIS
        Creates a new server role in a SQL Server Database Engine instance.

    .DESCRIPTION
        This command creates a new server role in a SQL Server Database Engine instance.

    .PARAMETER ServerObject
        Specifies current server connection object.

    .PARAMETER Name
        Specifies the name of the server role to be created.

    .PARAMETER Owner
        Specifies the owner of the server role. If not specified, the role
        will be owned by the login that creates it.

    .PARAMETER Force
        Specifies that the role should be created without any confirmation.

    .PARAMETER Refresh
        Specifies that the **ServerObject**'s roles should be refreshed before
        creating the role object. This is helpful when roles could have been
        modified outside of the **ServerObject**, for example through T-SQL. But
        on instances with a large amount of roles it might be better to make
        sure the **ServerObject** is recent enough.

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine -InstanceName 'MyInstance'
        $serverObject | New-SqlDscRole -Name 'MyCustomRole'

        Creates a new server role named **MyCustomRole**.

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine -InstanceName 'MyInstance'
        $serverObject | New-SqlDscRole -Name 'MyCustomRole' -Owner 'MyOwner' -Force

        Creates a new server role named **MyCustomRole** with the specified owner
        without prompting for confirmation.

    .OUTPUTS
        `[Microsoft.SqlServer.Management.Smo.ServerRole]`
#>
function New-SqlDscRole
{
    [System.Diagnostics.CodeAnalysis.SuppressMessageAttribute('UseSyntacticallyCorrectExamples', '', Justification = 'Because the rule does not yet support parsing the code when a parameter type is not available. The ScriptAnalyzer rule UseSyntacticallyCorrectExamples will always error in the editor due to https://github.com/indented-automation/Indented.ScriptAnalyzerRules/issues/8.')]
    [OutputType([Microsoft.SqlServer.Management.Smo.ServerRole])]
    [CmdletBinding(SupportsShouldProcess = $true, ConfirmImpact = 'Medium')]
    param
    (
        [Parameter(Mandatory = $true, ValueFromPipeline = $true)]
        [Microsoft.SqlServer.Management.Smo.Server]
        $ServerObject,

        [Parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [System.String]
        $Name,

        [Parameter()]
        [System.String]
        $Owner,

        [Parameter()]
        [System.Management.Automation.SwitchParameter]
        $Force,

        [Parameter()]
        [System.Management.Automation.SwitchParameter]
        $Refresh
    )

    begin
    {
        if ($Force.IsPresent -and -not $Confirm)
        {
            $ConfirmPreference = 'None'
        }
    }

    process
    {
        if ($Refresh.IsPresent)
        {
            # Refresh the server object's roles collection
            $ServerObject.Roles.Refresh()
        }

        Write-Verbose -Message ($script:localizedData.Role_Create -f $Name, $ServerObject.InstanceName)

        # Check if the role already exists
        if ($ServerObject.Roles[$Name])
        {
            $errorMessage = $script:localizedData.Role_AlreadyExists -f $Name, $ServerObject.InstanceName

            $PSCmdlet.ThrowTerminatingError(
                [System.Management.Automation.ErrorRecord]::new(
                    [System.InvalidOperationException]::new($errorMessage),
                    'NSDR0001', # cspell: disable-line
                    [System.Management.Automation.ErrorCategory]::ResourceExists,
                    $Name
                )
            )
        }

        $descriptionMessage = $script:localizedData.Role_Create_ShouldProcessDescription -f $Name, $ServerObject.InstanceName
        $confirmationMessage = $script:localizedData.Role_Create_ShouldProcessConfirmation -f $Name
        $captionMessage = $script:localizedData.Role_Create_ShouldProcessCaption

        if ($PSCmdlet.ShouldProcess($descriptionMessage, $confirmationMessage, $captionMessage))
        {
            try
            {
                $serverRole = New-Object -TypeName Microsoft.SqlServer.Management.Smo.ServerRole -ArgumentList $ServerObject, $Name

                if ($PSBoundParameters.ContainsKey('Owner'))
                {
                    $serverRole.Owner = $Owner
                }

                $serverRole.Create()

                return $serverRole
            }
            catch
            {
                $errorMessage = $script:localizedData.Role_CreateFailed -f $Name, $ServerObject.InstanceName

                $PSCmdlet.ThrowTerminatingError(
                    [System.Management.Automation.ErrorRecord]::new(
                        [System.InvalidOperationException]::new($errorMessage, $_.Exception),
                        'NSDR0002', # cspell: disable-line
                        [System.Management.Automation.ErrorCategory]::InvalidOperation,
                        $Name
                    )
                )
            }
        }
    }
}
#EndRegion '.\Public\New-SqlDscRole.ps1' 141
#Region '.\Public\Remove-SqlDscAgentAlert.ps1' -1

<#
    .SYNOPSIS
        Removes a SQL Agent Alert.

    .DESCRIPTION
        This command removes a SQL Agent Alert from a SQL Server Database Engine instance.

    .PARAMETER ServerObject
        Specifies current server connection object.

    .PARAMETER AlertObject
        Specifies an alert object to remove.

    .PARAMETER Name
        Specifies the name of the SQL Agent Alert to remove.

    .PARAMETER Force
        Specifies that the alert should be removed without any confirmation.

    .PARAMETER Refresh
        Specifies that the **ServerObject**'s alerts should be refreshed before
        trying to remove the alert object. This is helpful when alerts could have
        been modified outside of the **ServerObject**, for example through T-SQL.

    .INPUTS
        Microsoft.SqlServer.Management.Smo.Server

        SQL Server Database Engine instance object.

        Microsoft.SqlServer.Management.Smo.Agent.Alert

        SQL Agent Alert object to remove.

    .OUTPUTS
        None.

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine -InstanceName 'MyInstance'
        $alertObject = $serverObject | Get-SqlDscAgentAlert -Name 'MyAlert'
        $alertObject | Remove-SqlDscAgentAlert

        Removes the alert named **MyAlert**.

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine -InstanceName 'MyInstance'
        $serverObject | Remove-SqlDscAgentAlert -Name 'MyAlert'

        Removes the alert named **MyAlert**.

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine -InstanceName 'MyInstance'
        $serverObject | Remove-SqlDscAgentAlert -Name 'MyAlert' -Force

        Removes the alert named **MyAlert** without confirmation.
#>
function Remove-SqlDscAgentAlert
{
    [System.Diagnostics.CodeAnalysis.SuppressMessageAttribute('UseSyntacticallyCorrectExamples', '', Justification = 'Because the rule does not yet support parsing the code when a parameter type is not available. The ScriptAnalyzer rule UseSyntacticallyCorrectExamples will always error in the editor due to https://github.com/indented-automation/Indented.ScriptAnalyzerRules/issues/8.')]
    [OutputType()]
    [CmdletBinding(SupportsShouldProcess = $true, ConfirmImpact = 'High')]
    param
    (
        [Parameter(ParameterSetName = 'ServerObject', Mandatory = $true, ValueFromPipeline = $true)]
        [Microsoft.SqlServer.Management.Smo.Server]
        $ServerObject,

        [Parameter(ParameterSetName = 'AlertObject', Mandatory = $true, ValueFromPipeline = $true)]
        [Microsoft.SqlServer.Management.Smo.Agent.Alert]
        $AlertObject,

        [Parameter(ParameterSetName = 'ServerObject', Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [System.String]
        $Name,

        [Parameter()]
        [System.Management.Automation.SwitchParameter]
        $Force,

        [Parameter(ParameterSetName = 'ServerObject')]
        [System.Management.Automation.SwitchParameter]
        $Refresh
    )

    # cSpell: ignore RSAA
    process
    {
        if ($Force.IsPresent -and -not $Confirm)
        {
            $ConfirmPreference = 'None'
        }

        if ($PSCmdlet.ParameterSetName -eq 'ServerObject')
        {
            if ($Refresh.IsPresent)
            {
                Write-Verbose -Message ($script:localizedData.Remove_SqlDscAgentAlert_RefreshingServerObject)
                $ServerObject.JobServer.Alerts.Refresh()
            }

            $alertObjectToRemove = Get-AgentAlertObject -ServerObject $ServerObject -Name $Name

            if (-not $alertObjectToRemove)
            {
                Write-Verbose -Message ($script:localizedData.Remove_SqlDscAgentAlert_AlertNotFound -f $Name)
                return
            }
        }
        else
        {
            $alertObjectToRemove = $AlertObject
        }

        $verboseDescriptionMessage = $script:localizedData.Remove_SqlDscAgentAlert_RemoveShouldProcessVerboseDescription -f $alertObjectToRemove.Name, $alertObjectToRemove.Parent.Parent.InstanceName
        $verboseWarningMessage = $script:localizedData.Remove_SqlDscAgentAlert_RemoveShouldProcessVerboseWarning -f $alertObjectToRemove.Name
        $captionMessage = $script:localizedData.Remove_SqlDscAgentAlert_RemoveShouldProcessCaption

        if ($PSCmdlet.ShouldProcess($verboseDescriptionMessage, $verboseWarningMessage, $captionMessage))
        {
            Write-Verbose -Message ($script:localizedData.Remove_SqlDscAgentAlert_RemovingAlert -f $alertObjectToRemove.Name)

            try
            {
                $originalErrorActionPreference = $ErrorActionPreference

                $ErrorActionPreference = 'Stop'

                $alertObjectToRemove.Drop()

                Write-Verbose -Message ($script:localizedData.Remove_SqlDscAgentAlert_AlertRemoved -f $alertObjectToRemove.Name)
            }
            catch
            {
                $errorMessage = $script:localizedData.Remove_SqlDscAgentAlert_RemoveFailed -f $alertObjectToRemove.Name

                $PSCmdlet.ThrowTerminatingError(
                    [System.Management.Automation.ErrorRecord]::new(
                        [System.InvalidOperationException]::new($errorMessage, $_.Exception),
                        'RSAA0005', # cspell: disable-line
                        [System.Management.Automation.ErrorCategory]::InvalidOperation,
                        $alertObjectToRemove
                    )
                )
            }
            finally
            {
                $ErrorActionPreference = $originalErrorActionPreference
            }
        }
    }
}
#EndRegion '.\Public\Remove-SqlDscAgentAlert.ps1' 152
#Region '.\Public\Remove-SqlDscAgentOperator.ps1' -1

<#
    .SYNOPSIS
        Removes a SQL Agent Operator.

    .DESCRIPTION
        This command removes a SQL Agent Operator from a SQL Server Database Engine instance.

    .PARAMETER ServerObject
        Specifies current server connection object.

    .PARAMETER OperatorObject
        Specifies the SQL Agent Operator object to remove.

    .PARAMETER Name
        Specifies the name of the SQL Agent Operator to remove.

    .PARAMETER Force
        Specifies that the operator should be removed without any confirmation.

    .PARAMETER Refresh
        Specifies that the SQL Agent Operator object should be refreshed before removal.
        This is only used when specifying the operator by name.

    .INPUTS
        Microsoft.SqlServer.Management.Smo.Server

        SQL Server Database Engine instance object.

    .INPUTS
        Microsoft.SqlServer.Management.Smo.Agent.Operator

        SQL Agent Operator object.

    .OUTPUTS
        None.

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine -InstanceName 'MyInstance'
        Remove-SqlDscAgentOperator -ServerObject $serverObject -Name 'MyOperator'

        Removes the SQL Agent Operator named 'MyOperator'.

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine -InstanceName 'MyInstance'
        $serverObject | Remove-SqlDscAgentOperator -Name 'MyOperator'

        Removes the SQL Agent Operator using pipeline input.

    .EXAMPLE
        $operatorObject = Get-SqlDscAgentOperator -ServerObject $serverObject -Name 'MyOperator'
        $operatorObject | Remove-SqlDscAgentOperator

        Removes the SQL Agent Operator using operator object pipeline input.

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine -InstanceName 'MyInstance'
        Remove-SqlDscAgentOperator -ServerObject $serverObject -Name 'MyOperator' -Refresh

        Removes the SQL Agent Operator named 'MyOperator' with explicit refresh of the operator object.
#>
function Remove-SqlDscAgentOperator
{
    [System.Diagnostics.CodeAnalysis.SuppressMessageAttribute('UseSyntacticallyCorrectExamples', '', Justification = 'Because the rule does not yet support parsing the code when a parameter type is not available. The ScriptAnalyzer rule UseSyntacticallyCorrectExamples will always error in the editor due to https://github.com/indented-automation/Indented.ScriptAnalyzerRules/issues/8.')]
    [CmdletBinding(SupportsShouldProcess = $true, ConfirmImpact = 'High', DefaultParameterSetName = 'ByName')]
    [OutputType()]
    param
    (
        [Parameter(Mandatory = $true, ValueFromPipeline = $true, ParameterSetName = 'ByName')]
        [Microsoft.SqlServer.Management.Smo.Server]
        $ServerObject,

        [Parameter(Mandatory = $true, ValueFromPipeline = $true, ParameterSetName = 'ByObject')]
        [Microsoft.SqlServer.Management.Smo.Agent.Operator]
        $OperatorObject,

        [Parameter(Mandatory = $true, ParameterSetName = 'ByName')]
        [ValidateNotNullOrEmpty()]
        [System.String]
        $Name,

        [Parameter()]
        [System.Management.Automation.SwitchParameter]
        $Force,

        [Parameter(ParameterSetName = 'ByName')]
        [System.Management.Automation.SwitchParameter]
        $Refresh
    )

    # cSpell: ignore RSAO
    process
    {
        if ($Force.IsPresent -and -not $Confirm)
        {
            $ConfirmPreference = 'None'
        }
        if ($PSCmdlet.ParameterSetName -eq 'ByName')
        {
            # Get the operator by name, throws when ErrorAction preference is Stop.
            $OperatorObject = Get-AgentOperatorObject -ServerObject $ServerObject -Name $Name -Refresh:$Refresh -ErrorAction $ErrorActionPreference

            if (-not $OperatorObject)
            {
                Write-Verbose -Message ($script:localizedData.Remove_SqlDscAgentOperator_OperatorNotFound -f $Name)

                return
            }
        }

        $verboseDescriptionMessage = $script:localizedData.Remove_SqlDscAgentOperator_RemoveShouldProcessVerboseDescription -f $OperatorObject.Name, $OperatorObject.Parent.Parent.InstanceName
        $verboseWarningMessage = $script:localizedData.Remove_SqlDscAgentOperator_RemoveShouldProcessVerboseWarning -f $OperatorObject.Name
        $captionMessage = $script:localizedData.Remove_SqlDscAgentOperator_RemoveShouldProcessCaption

        if ($PSCmdlet.ShouldProcess($verboseDescriptionMessage, $verboseWarningMessage, $captionMessage))
        {
            try
            {
                $OperatorObject.Drop()
            }
            catch
            {
                $errorMessage = $script:localizedData.Remove_SqlDscAgentOperator_RemoveFailed -f $OperatorObject.Name

                $PSCmdlet.ThrowTerminatingError(
                    [System.Management.Automation.ErrorRecord]::new(
                        [System.InvalidOperationException]::new($errorMessage, $_.Exception),
                        'RSAO0001', # cspell: disable-line
                        [System.Management.Automation.ErrorCategory]::InvalidOperation,
                        $OperatorObject
                    )
                )
            }
        }
    }
}
#EndRegion '.\Public\Remove-SqlDscAgentOperator.ps1' 136
#Region '.\Public\Remove-SqlDscAudit.ps1' -1

<#
    .SYNOPSIS
        Removes a server audit.

    .DESCRIPTION
        This command removes a server audit from a SQL Server Database Engine instance.

    .PARAMETER ServerObject
        Specifies current server connection object.

    .PARAMETER AuditObject
        Specifies an audit object to remove.

    .PARAMETER Name
        Specifies the name of the server audit to be removed.

    .PARAMETER Force
        Specifies that the audit should be removed without any confirmation.

    .PARAMETER Refresh
        Specifies that the **ServerObject**'s audits should be refreshed before
        trying removing the audit object. This is helpful when audits could have
        been modified outside of the **ServerObject**, for example through T-SQL.
        But on instances with a large amount of audits it might be better to make
        sure the **ServerObject** is recent enough, or pass in **AuditObject**.

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine -InstanceName 'MyInstance'
        $auditObject = $sqlServerObject | Get-SqlDscAudit -Name 'MyFileAudit'
        $auditObject | Remove-SqlDscAudit

        Removes the audit named **MyFileAudit**.

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine -InstanceName 'MyInstance'
        $sqlServerObject | Remove-SqlDscAudit -Name 'MyFileAudit'

        Removes the audit named **MyFileAudit**.

    .OUTPUTS
        None.
#>
function Remove-SqlDscAudit
{
    [System.Diagnostics.CodeAnalysis.SuppressMessageAttribute('UseSyntacticallyCorrectExamples', '', Justification = 'Because the rule does not yet support parsing the code when a parameter type is not available. The ScriptAnalyzer rule UseSyntacticallyCorrectExamples will always error in the editor due to https://github.com/indented-automation/Indented.ScriptAnalyzerRules/issues/8.')]
    [OutputType()]
    [CmdletBinding(SupportsShouldProcess = $true, ConfirmImpact = 'High')]
    param
    (
        [Parameter(ParameterSetName = 'ServerObject', Mandatory = $true, ValueFromPipeline = $true)]
        [Microsoft.SqlServer.Management.Smo.Server]
        $ServerObject,

        [Parameter(ParameterSetName = 'AuditObject', Mandatory = $true, ValueFromPipeline = $true)]
        [Microsoft.SqlServer.Management.Smo.Audit]
        $AuditObject,

        [Parameter(ParameterSetName = 'ServerObject', Mandatory = $true)]
        [System.String]
        $Name,

        [Parameter()]
        [System.Management.Automation.SwitchParameter]
        $Force,

        [Parameter(ParameterSetName = 'ServerObject')]
        [System.Management.Automation.SwitchParameter]
        $Refresh
    )

    process
    {
        if ($Force.IsPresent -and -not $Confirm)
        {
            $ConfirmPreference = 'None'
        }

        if ($PSCmdlet.ParameterSetName -eq 'ServerObject')
        {
            $getSqlDscAuditParameters = @{
                ServerObject = $ServerObject
                Name         = $Name
                Refresh      = $Refresh
                ErrorAction  = 'Stop'
            }

            # If this command does not find the audit it will throw an exception.
            $auditObjectArray = Get-SqlDscAudit @getSqlDscAuditParameters

            # Pick the only object in the array.
            $AuditObject = $auditObjectArray | Select-Object -First 1
        }

        $verboseDescriptionMessage = $script:localizedData.Audit_Remove_ShouldProcessVerboseDescription -f $AuditObject.Name, $AuditObject.Parent.InstanceName
        $verboseWarningMessage = $script:localizedData.Audit_Remove_ShouldProcessVerboseWarning -f $AuditObject.Name
        $captionMessage = $script:localizedData.Audit_Remove_ShouldProcessCaption

        if ($PSCmdlet.ShouldProcess($verboseDescriptionMessage, $verboseWarningMessage, $captionMessage))
        {
            <#
                If the passed audit object has already been dropped, then we silently
                do nothing, using the method DropIfExist(), since the job is done.
            #>
            $AuditObject.DropIfExists()
        }
    }
}
#EndRegion '.\Public\Remove-SqlDscAudit.ps1' 108
#Region '.\Public\Remove-SqlDscDatabase.ps1' -1

<#
    .SYNOPSIS
        Removes a database from a SQL Server Database Engine instance.

    .DESCRIPTION
        This command removes a database from a SQL Server Database Engine instance.

    .PARAMETER ServerObject
        Specifies current server connection object.

    .PARAMETER DatabaseObject
        Specifies a database object to remove.

    .PARAMETER Name
        Specifies the name of the database to be removed.

    .PARAMETER Force
        Specifies that the database should be removed without any confirmation.

    .PARAMETER Refresh
        Specifies that the **ServerObject**'s databases should be refreshed before
        trying to remove the database object. This is helpful when databases could have been
        modified outside of the **ServerObject**, for example through T-SQL. But
        on instances with a large amount of databases it might be better to make
        sure the **ServerObject** is recent enough, or pass in **DatabaseObject**.

    .PARAMETER DropConnections
        Specifies that all active connections to the database should be dropped
        before removing the database. This sets the database to single-user mode
        with immediate rollback of active transactions, which forcibly disconnects
        all users and allows the database to be removed even when there are
        active connections.

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine -InstanceName 'MyInstance'
        $databaseObject = $serverObject | Get-SqlDscDatabase -Name 'MyDatabase'
        $databaseObject | Remove-SqlDscDatabase

        Removes the database named **MyDatabase**.

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine -InstanceName 'MyInstance'
        $serverObject | Remove-SqlDscDatabase -Name 'MyDatabase'

        Removes the database named **MyDatabase**.

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine -InstanceName 'MyInstance'
        $serverObject | Remove-SqlDscDatabase -Name 'MyDatabase' -Force

        Removes the database named **MyDatabase** without prompting for confirmation.

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine -InstanceName 'MyInstance'
        $serverObject | Remove-SqlDscDatabase -Name 'MyDatabase' -DropConnections -Force

        Drops all active connections to the database named **MyDatabase** and then removes it
        without prompting for confirmation. This is useful when the database has active
        connections that prevent removal.

    .OUTPUTS
        None.
#>
function Remove-SqlDscDatabase
{
    [System.Diagnostics.CodeAnalysis.SuppressMessageAttribute('UseSyntacticallyCorrectExamples', '', Justification = 'Because the rule does not yet support parsing the code when a parameter type is not available. The ScriptAnalyzer rule UseSyntacticallyCorrectExamples will always error in the editor due to https://github.com/indented-automation/Indented.ScriptAnalyzerRules/issues/8.')]
    [OutputType()]
    [CmdletBinding(SupportsShouldProcess = $true, ConfirmImpact = 'High')]
    param
    (
        [Parameter(ParameterSetName = 'ServerObject', Mandatory = $true, ValueFromPipeline = $true)]
        [Microsoft.SqlServer.Management.Smo.Server]
        $ServerObject,

        [Parameter(ParameterSetName = 'DatabaseObject', Mandatory = $true, ValueFromPipeline = $true)]
        [Microsoft.SqlServer.Management.Smo.Database]
        $DatabaseObject,

        [Parameter(ParameterSetName = 'ServerObject', Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [System.String]
        $Name,

        [Parameter()]
        [System.Management.Automation.SwitchParameter]
        $Force,

        [Parameter(ParameterSetName = 'ServerObject')]
        [System.Management.Automation.SwitchParameter]
        $Refresh,

        [Parameter()]
        [System.Management.Automation.SwitchParameter]
        $DropConnections
    )

    begin
    {
        if ($Force.IsPresent -and -not $Confirm)
        {
            $ConfirmPreference = 'None'
        }
    }

    process
    {
        if ($PSCmdlet.ParameterSetName -eq 'ServerObject')
        {
            if ($Refresh.IsPresent)
            {
                # Refresh the server object's databases collection
                $ServerObject.Databases.Refresh()
            }

            # Get the database object
            $DatabaseObject = $ServerObject.Databases[$Name]

            if (-not $DatabaseObject)
            {
                $errorMessage = $script:localizedData.Remove_SqlDscDatabase_NotFound -f $Name

                $PSCmdlet.ThrowTerminatingError(
                    [System.Management.Automation.ErrorRecord]::new(
                        [System.Management.Automation.ItemNotFoundException]::new($errorMessage),
                        'RSDD0002', # cspell: disable-line
                        [System.Management.Automation.ErrorCategory]::ObjectNotFound,
                        $Name
                    )
                )
            }
        }
        else
        {
            $Name = $DatabaseObject.Name
        }

        # Check if the database is a system database (cannot be dropped)
        if ($Name -in @('master', 'model', 'msdb', 'tempdb'))
        {
            $errorMessage = $script:localizedData.Database_CannotRemoveSystem -f $Name

            $PSCmdlet.ThrowTerminatingError(
                [System.Management.Automation.ErrorRecord]::new(
                    [System.InvalidOperationException]::new($errorMessage),
                    'RSDD0001', # cspell: disable-line
                    [System.Management.Automation.ErrorCategory]::InvalidOperation,
                    $Name
                )
            )
        }

        $descriptionMessage = $script:localizedData.Database_Remove_ShouldProcessDescription -f $Name, $DatabaseObject.Parent.InstanceName
        $confirmationMessage = $script:localizedData.Database_Remove_ShouldProcessConfirmation -f $Name
        $captionMessage = $script:localizedData.Database_Remove_ShouldProcessCaption

        if ($PSCmdlet.ShouldProcess($descriptionMessage, $confirmationMessage, $captionMessage))
        {
            # Drop all active connections if requested
            if ($DropConnections.IsPresent)
            {
                Write-Verbose -Message ($script:localizedData.Database_DroppingConnections -f $Name)

                try
                {
                    $DatabaseObject.UserAccess = [Microsoft.SqlServer.Management.Smo.DatabaseUserAccess]::Single
                    $DatabaseObject.Alter([Microsoft.SqlServer.Management.Smo.TerminationClause]::RollbackTransactionsImmediately)
                }
                catch
                {
                    $errorMessage = $script:localizedData.Database_DropConnectionsFailed -f $Name

                    $PSCmdlet.ThrowTerminatingError(
                        [System.Management.Automation.ErrorRecord]::new(
                            [System.InvalidOperationException]::new($errorMessage, $_.Exception),
                            'RSDD0004', # cspell: disable-line
                            [System.Management.Automation.ErrorCategory]::InvalidOperation,
                            $DatabaseObject
                        )
                    )
                }
            }

            try
            {
                $DatabaseObject.Drop()
            }
            catch
            {
                $errorMessage = $script:localizedData.Database_RemoveFailed -f $Name, $DatabaseObject.Parent.InstanceName

                $PSCmdlet.ThrowTerminatingError(
                    [System.Management.Automation.ErrorRecord]::new(
                        [System.InvalidOperationException]::new($errorMessage, $_.Exception),
                        'RSDD0005', # cspell: disable-line
                        [System.Management.Automation.ErrorCategory]::InvalidOperation,
                        $DatabaseObject
                    )
                )
            }
        }
    }
}
#EndRegion '.\Public\Remove-SqlDscDatabase.ps1' 203
#Region '.\Public\Remove-SqlDscLogin.ps1' -1

<#
    .SYNOPSIS
        Removes a SQL Server login.

    .DESCRIPTION
        This command removes a SQL Server login from a SQL Server Database Engine instance.

    .PARAMETER ServerObject
        Specifies current server connection object.

    .PARAMETER LoginObject
        Specifies a login object to remove.

    .PARAMETER Name
        Specifies the name of the server login to be removed.

    .PARAMETER Force
        Specifies that the login should be removed without any confirmation.

    .PARAMETER Refresh
        Specifies that the **ServerObject**'s logins should be refreshed before
        trying to remove the login object. This is helpful when logins could have
        been modified outside of the **ServerObject**, for example through T-SQL.
        But on instances with a large number of logins it might be better to make
        sure the **ServerObject** is recent enough, or pass in **LoginObject**.
    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine -InstanceName 'MyInstance'
        $loginObject = $serverObject | Get-SqlDscLogin -Name 'MyLogin'
        $loginObject | Remove-SqlDscLogin

        Removes the login named **MyLogin**.

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine -InstanceName 'MyInstance'
        $serverObject | Remove-SqlDscLogin -Name 'MyLogin'

        Removes the login named **MyLogin**.

    .INPUTS
        Microsoft.SqlServer.Management.Smo.Server

        Specifies a server connection object.

    .INPUTS
        Microsoft.SqlServer.Management.Smo.Login

        Specifies a login object.

    .OUTPUTS
        None.
#>
function Remove-SqlDscLogin
{
    [System.Diagnostics.CodeAnalysis.SuppressMessageAttribute('UseSyntacticallyCorrectExamples', '', Justification = 'Because the rule does not yet support parsing the code when a parameter type is not available. The ScriptAnalyzer rule UseSyntacticallyCorrectExamples will always error in the editor due to https://github.com/indented-automation/Indented.ScriptAnalyzerRules/issues/8.')]
    [OutputType([System.Void])]
    [CmdletBinding(SupportsShouldProcess = $true, ConfirmImpact = 'High')]
    param
    (
        [Parameter(ParameterSetName = 'ServerObject', Mandatory = $true, ValueFromPipeline = $true)]
        [Microsoft.SqlServer.Management.Smo.Server]
        $ServerObject,

        [Parameter(ParameterSetName = 'LoginObject', Mandatory = $true, ValueFromPipeline = $true)]
        [Microsoft.SqlServer.Management.Smo.Login]
        $LoginObject,

        [Parameter(ParameterSetName = 'ServerObject', Mandatory = $true)]
        [System.String]
        $Name,

        [Parameter()]
        [System.Management.Automation.SwitchParameter]
        $Force,

        [Parameter(ParameterSetName = 'ServerObject')]
        [System.Management.Automation.SwitchParameter]
        $Refresh
    )

    process
    {
        if ($Force.IsPresent -and -not $Confirm)
        {
            $ConfirmPreference = 'None'
        }

        if ($PSCmdlet.ParameterSetName -eq 'ServerObject')
        {
            $getSqlDscLoginParameters = @{
                ServerObject = $ServerObject
                Name         = $Name
                Refresh      = $Refresh
                ErrorAction  = 'Stop'
            }

            # If this command does not find the login it will throw an exception.
            $loginObjectArray = Get-SqlDscLogin @getSqlDscLoginParameters

            # Pick the only object in the array.
            $LoginObject = $loginObjectArray | Select-Object -First 1
        }

        $verboseDescriptionMessage = $script:localizedData.Login_Remove_ShouldProcessVerboseDescription -f $LoginObject.Name, $LoginObject.Parent.InstanceName
        $verboseWarningMessage = $script:localizedData.Login_Remove_ShouldProcessVerboseWarning -f $LoginObject.Name
        $captionMessage = $script:localizedData.Login_Remove_ShouldProcessCaption

        if ($PSCmdlet.ShouldProcess($verboseDescriptionMessage, $verboseWarningMessage, $captionMessage))
        {
            try
            {
                $originalErrorActionPreference = $ErrorActionPreference

                $ErrorActionPreference = 'Stop'

                $LoginObject.Drop()
            }
            catch
            {
                $errorMessage = $script:localizedData.Login_Remove_Failed -f $LoginObject.Name

                $PSCmdlet.ThrowTerminatingError(
                    [System.Management.Automation.ErrorRecord]::new(
                        [System.InvalidOperationException]::new($errorMessage, $_.Exception),
                        'RSDL0001', # cspell: disable-line
                        [System.Management.Automation.ErrorCategory]::InvalidOperation,
                        $LoginObject
                    )
                )
            }
            finally
            {
                $ErrorActionPreference = $originalErrorActionPreference
            }
        }
    }
}
#EndRegion '.\Public\Remove-SqlDscLogin.ps1' 137
#Region '.\Public\Remove-SqlDscNode.ps1' -1

<#
    .SYNOPSIS
        Removes a SQL Server node from an Failover Cluster instance (FCI).

    .DESCRIPTION
        Removes a SQL Server node from an Failover Cluster instance (FCI).

        See the link in the commands help for information on each parameter. The
        link points to SQL Server command line setup documentation.

    .PARAMETER MediaPath
        Specifies the path where to find the SQL Server installation media. On this
        path the SQL Server setup executable must be found.

    .PARAMETER Timeout
        Specifies how long to wait for the setup process to finish. Default value
        is `7200` seconds (2 hours). If the setup process does not finish before
        this time, an exception will be thrown.

    .PARAMETER Force
        If specified the command will not ask for confirmation. Same as if Confirm:$false
        is used.

    .PARAMETER InstanceName
        See the notes section for more information.

    .PARAMETER ConfirmIPDependencyChange
        See the notes section for more information.

    .LINK
        https://docs.microsoft.com/en-us/sql/database-engine/install-windows/install-sql-server-from-the-command-prompt

    .OUTPUTS
        None.

    .EXAMPLE
        Remove-SqlDscNode -InstanceName 'MyInstance' -MediaPath 'E:\'

        Removes the current node's SQL Server instance 'MyInstance' from the
        Failover Cluster instance.

    .NOTES
        All parameters has intentionally not been added to this comment-based help
        since it would take a lot of effort to keep them up to date. Instead there is
        a link in the comment-based help that points to the SQL Server command line
        setup documentation which will stay relevant.
#>
function Remove-SqlDscNode
{
    [System.Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSShouldProcess', '', Justification = 'Because ShouldProcess is used in Invoke-SetupAction')]
    [CmdletBinding(SupportsShouldProcess = $true, ConfirmImpact = 'High')]
    [OutputType()]
    param
    (
        [Parameter(Mandatory = $true)]
        [System.String]
        $MediaPath,

        [Parameter(Mandatory = $true)]
        [System.String]
        $InstanceName,

        [Parameter()]
        [System.Management.Automation.SwitchParameter]
        $ConfirmIPDependencyChange,

        [Parameter()]
        [System.UInt32]
        $Timeout = 7200,

        [Parameter()]
        [System.Management.Automation.SwitchParameter]
        $Force
    )

    Invoke-SetupAction -RemoveNode @PSBoundParameters
}
#EndRegion '.\Public\Remove-SqlDscNode.ps1' 78
#Region '.\Public\Remove-SqlDscRole.ps1' -1

<#
    .SYNOPSIS
        Removes a server role from a SQL Server Database Engine instance.

    .DESCRIPTION
        This command removes a server role from a SQL Server Database Engine instance.

    .PARAMETER ServerObject
        Specifies current server connection object.

    .PARAMETER RoleObject
        Specifies a server role object to remove.

    .PARAMETER Name
        Specifies the name of the server role to be removed.

    .PARAMETER Force
        Specifies that the role should be removed without any confirmation.

    .PARAMETER Refresh
        Specifies that the **ServerObject**'s roles should be refreshed before
        trying to remove the role object. This is helpful when roles could have been
        modified outside of the **ServerObject**, for example through T-SQL. But
        on instances with a large amount of roles it might be better to make
        sure the **ServerObject** is recent enough, or pass in **RoleObject**.

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine -InstanceName 'MyInstance'
        $roleObject = $serverObject | Get-SqlDscRole -Name 'MyCustomRole'
        $roleObject | Remove-SqlDscRole

        Removes the role named **MyCustomRole**.

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine -InstanceName 'MyInstance'
        $serverObject | Remove-SqlDscRole -Name 'MyCustomRole'

        Removes the role named **MyCustomRole**.

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine -InstanceName 'MyInstance'
        $serverObject | Remove-SqlDscRole -Name 'MyCustomRole' -Force

        Removes the role named **MyCustomRole** without prompting for confirmation.

    .OUTPUTS
        None.
#>
function Remove-SqlDscRole
{
    [System.Diagnostics.CodeAnalysis.SuppressMessageAttribute('UseSyntacticallyCorrectExamples', '', Justification = 'Because the rule does not yet support parsing the code when a parameter type is not available. The ScriptAnalyzer rule UseSyntacticallyCorrectExamples will always error in the editor due to https://github.com/indented-automation/Indented.ScriptAnalyzerRules/issues/8.')]
    [OutputType()]
    [CmdletBinding(SupportsShouldProcess = $true, ConfirmImpact = 'High')]
    param
    (
        [Parameter(ParameterSetName = 'ServerObject', Mandatory = $true, ValueFromPipeline = $true)]
        [Microsoft.SqlServer.Management.Smo.Server]
        $ServerObject,

        [Parameter(ParameterSetName = 'RoleObject', Mandatory = $true, ValueFromPipeline = $true)]
        [Microsoft.SqlServer.Management.Smo.ServerRole]
        $RoleObject,

        [Parameter(ParameterSetName = 'ServerObject', Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [System.String]
        $Name,

        [Parameter()]
        [System.Management.Automation.SwitchParameter]
        $Force,

        [Parameter(ParameterSetName = 'ServerObject')]
        [System.Management.Automation.SwitchParameter]
        $Refresh
    )

    begin
    {
        if ($Force.IsPresent -and -not $Confirm)
        {
            $ConfirmPreference = 'None'
        }
    }

    process
    {
        if ($PSCmdlet.ParameterSetName -eq 'ServerObject')
        {
            if ($Refresh.IsPresent)
            {
                # Refresh the server object's roles collection
                $ServerObject.Roles.Refresh()
            }

            Write-Verbose -Message ($script:localizedData.Role_Remove -f $Name, $ServerObject.InstanceName)

            # Get the role object
            $RoleObject = $ServerObject.Roles[$Name]

            if (-not $RoleObject)
            {
                $errorMessage = $script:localizedData.Remove_SqlDscRole_NotFound -f $Name

                $PSCmdlet.ThrowTerminatingError(
                    [System.Management.Automation.ErrorRecord]::new(
                        [System.Management.Automation.ItemNotFoundException]::new($errorMessage),
                        'RSDR0001', # cspell: disable-line
                        [System.Management.Automation.ErrorCategory]::ObjectNotFound,
                        $Name
                    )
                )
            }
        }
        else
        {
            $Name = $RoleObject.Name
            Write-Verbose -Message ($script:localizedData.Role_Remove -f $Name, $RoleObject.Parent.InstanceName)
        }

        # Check if the role is a built-in role (cannot be dropped)
        if ($RoleObject.IsFixedRole)
        {
            $errorMessage = $script:localizedData.Role_CannotRemoveBuiltIn -f $Name

            $PSCmdlet.ThrowTerminatingError(
                [System.Management.Automation.ErrorRecord]::new(
                    [System.InvalidOperationException]::new($errorMessage),
                    'RSDR0002', # cspell: disable-line
                    [System.Management.Automation.ErrorCategory]::InvalidOperation,
                    $RoleObject
                )
            )
        }

        $descriptionMessage = $script:localizedData.Role_Remove_ShouldProcessDescription -f $Name, $RoleObject.Parent.InstanceName
        $confirmationMessage = $script:localizedData.Role_Remove_ShouldProcessConfirmation -f $Name
        $captionMessage = $script:localizedData.Role_Remove_ShouldProcessCaption

        if ($PSCmdlet.ShouldProcess($descriptionMessage, $confirmationMessage, $captionMessage))
        {
            try
            {
                $RoleObject.Drop()
            }
            catch
            {
                $errorMessage = $script:localizedData.Role_RemoveFailed -f $Name, $RoleObject.Parent.InstanceName

                $PSCmdlet.ThrowTerminatingError(
                    [System.Management.Automation.ErrorRecord]::new(
                        [System.InvalidOperationException]::new($errorMessage, $_.Exception),
                        'RSDR0003', # cspell: disable-line
                        [System.Management.Automation.ErrorCategory]::InvalidOperation,
                        $RoleObject
                    )
                )
            }
        }
    }
}
#EndRegion '.\Public\Remove-SqlDscRole.ps1' 162
#Region '.\Public\Remove-SqlDscTraceFlag.ps1' -1

<#
    .SYNOPSIS
        Removes trace flags from a Database Engine instance.

    .DESCRIPTION
        Removes trace flags from a Database Engine instance, keeping any other
        trace flags currently set.

    .PARAMETER ServiceObject
        Specifies the Service object on which to remove the trace flags.

    .PARAMETER ServerName
        Specifies the server name where the instance exist.

    .PARAMETER InstanceName
       Specifies the instance name on which to remove the trace flags.

    .PARAMETER TraceFlag
        Specifies the trace flags to remove.

    .PARAMETER Force
        Specifies that the trace flag should be removed without any confirmation.

    .EXAMPLE
        Remove-SqlDscTraceFlag -TraceFlag 4199

        Removes the trace flag 4199 from the Database Engine default instance
        on the server where the command in run.

    .EXAMPLE
        $serviceObject = Get-SqlDscManagedComputerService -ServiceType 'DatabaseEngine'
        Remove-SqlDscTraceFlag -ServiceObject $serviceObject -TraceFlag 4199

        Removes the trace flag 4199 from the Database Engine default instance
        on the server where the command in run.

    .EXAMPLE
        Remove-SqlDscTraceFlag -InstanceName 'SQL2022' -TraceFlag 4199,3226

        Removes the trace flags 4199 and 3226 from the Database Engine instance
        'SQL2022' on the server where the command in run.

    .EXAMPLE
        $serviceObject = Get-SqlDscManagedComputerService -ServiceType 'DatabaseEngine' -InstanceName 'SQL2022'
        Remove-SqlDscTraceFlag -ServiceObject $serviceObject -TraceFlag 4199,3226

        Removes the trace flags 4199 and 3226 from the Database Engine instance
        'SQL2022' on the server where the command in run.

    .OUTPUTS
        None.
#>
function Remove-SqlDscTraceFlag
{
    [System.Diagnostics.CodeAnalysis.SuppressMessageAttribute('UseSyntacticallyCorrectExamples', '', Justification = 'Because the rule does not yet support parsing the code when a parameter type is not available. The ScriptAnalyzer rule UseSyntacticallyCorrectExamples will always error in the editor due to https://github.com/indented-automation/Indented.ScriptAnalyzerRules/issues/8.')]
    [OutputType()]
    [CmdletBinding(DefaultParameterSetName = 'ByServerName', SupportsShouldProcess = $true, ConfirmImpact = 'High')]
    param
    (
        [Parameter(ParameterSetName = 'ByServiceObject', Mandatory = $true, ValueFromPipeline = $true)]
        [Microsoft.SqlServer.Management.Smo.Wmi.Service]
        $ServiceObject,

        [Parameter(ParameterSetName = 'ByServerName')]
        [ValidateNotNullOrEmpty()]
        [System.String]
        $ServerName = (Get-ComputerName),

        [Parameter(ParameterSetName = 'ByServerName')]
        [ValidateNotNullOrEmpty()]
        [System.String]
        $InstanceName = 'MSSQLSERVER',

        [Parameter(Mandatory = $true)]
        [System.UInt32[]]
        $TraceFlag,

        [Parameter()]
        [System.Management.Automation.SwitchParameter]
        $Force
    )

    begin
    {
        if ($Force.IsPresent -and -not $Confirm)
        {
            $ConfirmPreference = 'None'
        }
    }

    process
    {
        if ($PSCmdlet.ParameterSetName -eq 'ByServiceObject')
        {
            $InstanceName = $ServiceObject.Name -replace '^MSSQL\$'
        }

        # Copy $PSBoundParameters to keep it intact.
        $getSqlDscTraceFlagParameters = Remove-CommonParameter -Hashtable $PSBoundParameters

        # Remove parameters that Get-SqlDscTraceFlag does not have/support.
        @('Force', 'TraceFlag') |
            ForEach-Object -Process {
                $getSqlDscTraceFlagParameters.Remove($_)
            }

        $originalErrorActionPreference = $ErrorActionPreference

        $ErrorActionPreference = 'Stop'

        $currentTraceFlags = Get-SqlDscTraceFlag @getSqlDscTraceFlagParameters -ErrorAction 'Stop'

        $ErrorActionPreference = $originalErrorActionPreference

        if ($currentTraceFlags)
        {
            # Must always return an array. An empty array when removing the last value.
            $desiredTraceFlags = [System.UInt32[]] @(
                $currentTraceFlags |
                    ForEach-Object -Process {
                        # Keep values that should not be removed.
                        if ($_ -notin $TraceFlag)
                        {
                            $_
                        }
                    }
            )

            # Short-circuit if removal results in no effective change
            if (-not (Compare-Object -ReferenceObject $currentTraceFlags -DifferenceObject $desiredTraceFlags))
            {
                Write-Debug -Message $script:localizedData.TraceFlag_Remove_NoChange
                return
            }

            $verboseDescriptionMessage = $script:localizedData.TraceFlag_Remove_ShouldProcessVerboseDescription -f $InstanceName, ($TraceFlag -join ', ')
            $verboseWarningMessage = $script:localizedData.TraceFlag_Remove_ShouldProcessVerboseWarning -f $InstanceName
            $captionMessage = $script:localizedData.TraceFlag_Remove_ShouldProcessCaption

            if ($PSCmdlet.ShouldProcess($verboseDescriptionMessage, $verboseWarningMessage, $captionMessage))
            {
                # Copy $PSBoundParameters to keep it intact.
                $setSqlDscTraceFlagParameters = Remove-CommonParameter -Hashtable $PSBoundParameters

                $setSqlDscTraceFlagParameters.TraceFlag = $desiredTraceFlags

                $originalErrorActionPreference = $ErrorActionPreference

                $ErrorActionPreference = 'Stop'

                Set-SqlDscTraceFlag @setSqlDscTraceFlagParameters -ErrorAction 'Stop'

                $ErrorActionPreference = $originalErrorActionPreference
            }
        }
        else
        {
            Write-Debug -Message $script:localizedData.TraceFlag_Remove_NoCurrentTraceFlags
        }
    }
}
#EndRegion '.\Public\Remove-SqlDscTraceFlag.ps1' 162
#Region '.\Public\Repair-SqlDscBIReportServer.ps1' -1

<#
    .SYNOPSIS
        Repairs an existing SQL Server Power BI Report Server installation.

    .DESCRIPTION
        Repairs an existing SQL Server Power BI Report Server installation using
        the provided setup executable.

    .PARAMETER AcceptLicensingTerms
        Required parameter to be able to run unattended repair. By specifying this
        parameter you acknowledge the acceptance of all license terms and notices for
        the specified features, the terms and notices that the setup executable
        normally asks for.

    .PARAMETER MediaPath
        Specifies the path where to find the SQL Server installation media. On this
        path the SQL Server setup executable must be found.

    .PARAMETER ProductKey
        Specifies the product key to use for the repair, e.g. '12345-12345-12345-12345-12345'.
        This parameter is mutually exclusive with the parameter Edition.

    .PARAMETER EditionUpgrade
        Upgrades the edition of the installed product. Requires that either the
        ProductKey or the Edition parameter is also assigned. By default no edition
        upgrade is performed.

    .PARAMETER Edition
        Specifies a free custom edition to use for the repair. This parameter
        is mutually exclusive with the parameter ProductKey.

    .PARAMETER LogPath
        Specifies the file path where to write the log files, e.g. 'C:\Logs\Repair.log'.
        By default log files are created under %TEMP%.

    .PARAMETER InstallFolder
        Specifies the folder where to install the product, e.g. 'C:\Program Files\Power BI Report Server'.
        By default the product is installed under the default installation folder.

        PI Report Server: %ProgramFiles%\Microsoft Power BI Report Server

    .PARAMETER SuppressRestart
        Suppresses the restart of the computer after the repair is finished.
        By default the computer is restarted after the repair is finished.

    .PARAMETER Timeout
        Specifies how long to wait for the setup process to finish. Default value
        is `7200` seconds (2 hours). If the setup process does not finish before
        this time, an exception will be thrown.

    .PARAMETER Force
        If specified the command will not ask for confirmation. Same as if Confirm:$false
        is used.

    .PARAMETER PassThru
        If specified the command will return the setup process exit code.

    .OUTPUTS
        When PassThru is specified the function will return the setup process exit
        code as System.Int32. Otherwise, the function does not generate any output.

    .EXAMPLE
        Repair-SqlDscBIReportServer -AcceptLicensingTerms -MediaPath 'E:\PowerBIReportServer.exe'

        Repairs Power BI Report Server with default settings.

    .EXAMPLE
        Repair-SqlDscBIReportServer -AcceptLicensingTerms -MediaPath 'E:\PowerBIReportServer.exe' -ProductKey '12345-12345-12345-12345-12345' -EditionUpgrade

        Repairs Power BI Report Server and upgrades the edition using a
        product key.

    .EXAMPLE
        Repair-SqlDscBIReportServer -AcceptLicensingTerms -MediaPath 'E:\PowerBIReportServer.exe' -LogPath 'C:\Logs\PowerBIReportServer_Repair.log'

        Repairs Power BI Report Server and specifies a custom log path.

    .EXAMPLE
        $exitCode = Repair-SqlDscBIReportServer -AcceptLicensingTerms -MediaPath 'E:\PowerBIReportServer.exe' -PassThru

        Repairs Power BI Report Server with default settings and returns the setup exit code.
#>
function Repair-SqlDscBIReportServer
{
    [System.Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSShouldProcess', '', Justification = 'Because ShouldProcess is used in Invoke-SetupAction')]
    [CmdletBinding(SupportsShouldProcess = $true, ConfirmImpact = 'High')]
    [OutputType([System.Int32])]
    param
    (
        [Parameter(Mandatory = $true)]
        [System.Management.Automation.SwitchParameter]
        $AcceptLicensingTerms,

        [Parameter(Mandatory = $true)]
        [System.String]
        $MediaPath,

        [Parameter()]
        [System.String]
        $ProductKey,

        [Parameter()]
        [System.Management.Automation.SwitchParameter]
        $EditionUpgrade,

        [Parameter()]
        [ValidateSet('Developer', 'Evaluation', 'ExpressAdvanced')]
        [System.String]
        $Edition,

        [Parameter()]
        [System.String]
        $LogPath,

        [Parameter()]
        [System.String]
        $InstallFolder,

        [Parameter()]
        [System.Management.Automation.SwitchParameter]
        $SuppressRestart,

        [Parameter()]
        [System.UInt32]
        $Timeout = 7200,

        [Parameter()]
        [System.Management.Automation.SwitchParameter]
        $Force,

        [Parameter()]
        [System.Management.Automation.SwitchParameter]
        $PassThru
    )

    $exitCode = Invoke-ReportServerSetupAction -Repair @PSBoundParameters

    if ($PassThru.IsPresent)
    {
        return $exitCode
    }
}
#EndRegion '.\Public\Repair-SqlDscBIReportServer.ps1' 143
#Region '.\Public\Repair-SqlDscReportingService.ps1' -1

<#
    .SYNOPSIS
        Repairs an existing SQL Server Reporting Services or Power BI Report Server
        installation.

    .DESCRIPTION
        Repairs an existing SQL Server Reporting Services or Power BI Report Server
        installation using the provided setup executable.

    .PARAMETER AcceptLicensingTerms
        Required parameter to be able to run unattended repair. By specifying this
        parameter you acknowledge the acceptance of all license terms and notices for
        the specified features, the terms and notices that the setup executable
        normally asks for.

    .PARAMETER MediaPath
        Specifies the path where to find the SQL Server installation media. On this
        path the SQL Server setup executable must be found.

    .PARAMETER ProductKey
        Specifies the product key to use for the repair, e.g. '12345-12345-12345-12345-12345'.
        This parameter is mutually exclusive with the parameter Edition.

    .PARAMETER EditionUpgrade
        Upgrades the edition of the installed product. Requires that either the
        ProductKey or the Edition parameter is also assigned. By default no edition
        upgrade is performed.

    .PARAMETER Edition
        Specifies a free custom edition to use for the repair. This parameter
        is mutually exclusive with the parameter ProductKey.

    .PARAMETER LogPath
        Specifies the file path where to write the log files, e.g. 'C:\Logs\Repair.log'.
        By default log files are created under %TEMP%.

    .PARAMETER InstallFolder
        Specifies the folder where to install the product, e.g. 'C:\Program Files\SSRS'.
        By default the product is installed under the default installation folder.

        Reporting Services: %ProgramFiles%\Microsoft SQL Server Reporting Services
        PI Report Server: %ProgramFiles%\Microsoft Power BI Report Server

    .PARAMETER SuppressRestart
        Suppresses the restart of the computer after the repair is finished.
        By default the computer is restarted after the repair is finished.

    .PARAMETER Timeout
        Specifies how long to wait for the setup process to finish. Default value
        is `7200` seconds (2 hours). If the setup process does not finish before
        this time, an exception will be thrown.

    .PARAMETER Force
        If specified the command will not ask for confirmation. Same as if Confirm:$false
        is used.

    .PARAMETER PassThru
        If specified the command will return the setup process exit code.

    .OUTPUTS
        When PassThru is specified the function will return the setup process exit
        code as System.Int32. Otherwise, the function does not generate any output.

    .EXAMPLE
        Repair-SqlDscReportingService -AcceptLicensingTerms -MediaPath 'E:\SQLServerReportingServices.exe'

        Repairs SQL Server Reporting Services with default settings.

    .EXAMPLE
        Repair-SqlDscReportingService -AcceptLicensingTerms -MediaPath 'E:\SQLServerReportingServices.exe' -ProductKey '12345-12345-12345-12345-12345' -EditionUpgrade

        Repairs SQL Server Reporting Services and upgrades the edition using a
        product key.

    .EXAMPLE
        Repair-SqlDscReportingService -AcceptLicensingTerms -MediaPath 'E:\PowerBIReportServer.exe' -LogPath 'C:\Logs\PowerBIReportServer_Repair.log'

        Repairs Power BI Report Server and specifies a custom log path.

    .EXAMPLE
        $exitCode = Repair-SqlDscReportingService -AcceptLicensingTerms -MediaPath 'E:\SQLServerReportingServices.exe' -PassThru

        Repairs SQL Server Reporting Services with default settings and returns the setup exit code.
#>
function Repair-SqlDscReportingService
{
    [System.Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSShouldProcess', '', Justification = 'Because ShouldProcess is used in Invoke-SetupAction')]
    [CmdletBinding(SupportsShouldProcess = $true, ConfirmImpact = 'High')]
    [OutputType([System.Int32])]
    param
    (
        [Parameter(Mandatory = $true)]
        [System.Management.Automation.SwitchParameter]
        $AcceptLicensingTerms,

        [Parameter(Mandatory = $true)]
        [System.String]
        $MediaPath,

        [Parameter()]
        [System.String]
        $ProductKey,

        [Parameter()]
        [System.Management.Automation.SwitchParameter]
        $EditionUpgrade,

        [Parameter()]
        [ValidateSet('Developer', 'Evaluation', 'ExpressAdvanced')]
        [System.String]
        $Edition,

        [Parameter()]
        [System.String]
        $LogPath,

        [Parameter()]
        [System.String]
        $InstallFolder,

        [Parameter()]
        [System.Management.Automation.SwitchParameter]
        $SuppressRestart,

        [Parameter()]
        [System.UInt32]
        $Timeout = 7200,

        [Parameter()]
        [System.Management.Automation.SwitchParameter]
        $Force,

        [Parameter()]
        [System.Management.Automation.SwitchParameter]
        $PassThru
    )

    $exitCode = Invoke-ReportServerSetupAction -Repair @PSBoundParameters

    if ($PassThru.IsPresent)
    {
        return $exitCode
    }
}
#EndRegion '.\Public\Repair-SqlDscReportingService.ps1' 145
#Region '.\Public\Repair-SqlDscServer.ps1' -1

<#
    .SYNOPSIS
        Executes an setup action using Microsoft SQL Server setup executable.

    .DESCRIPTION
        Executes an setup action using Microsoft SQL Server setup executable.

        See the link in the commands help for information on each parameter. The
        link points to SQL Server command line setup documentation.

    .PARAMETER MediaPath
        Specifies the path where to find the SQL Server installation media. On this
        path the SQL Server setup executable must be found.

    .PARAMETER Timeout
        Specifies how long to wait for the setup process to finish. Default value
        is `7200` seconds (2 hours). If the setup process does not finish before
        this time, an exception will be thrown.

    .PARAMETER Force
        If specified the command will not ask for confirmation. Same as if Confirm:$false
        is used.

    .PARAMETER InstanceName
        See the notes section for more information.

    .PARAMETER Enu
        See the notes section for more information.

    .PARAMETER PBEngSvcAccount
        See the notes section for more information.

    .PARAMETER PBEngSvcPassword
        See the notes section for more information.

    .PARAMETER PBEngSvcStartupType
        See the notes section for more information.

    .PARAMETER PBStartPortRange
        See the notes section for more information.

    .PARAMETER PBEndPortRange
        See the notes section for more information.

    .PARAMETER PBScaleOut
        See the notes section for more information.

    .LINK
        https://docs.microsoft.com/en-us/sql/database-engine/install-windows/install-sql-server-from-the-command-prompt

    .OUTPUTS
        None.

    .EXAMPLE
        Repair-SqlDscServer -InstanceName 'MyInstance' -MediaPath 'E:\'

        Repairs all installed features of the instance 'MyInstance'.

    .NOTES
        The parameters are intentionally not described since it would take a lot
        of effort to keep them up to date. Instead there is a link that points to
        the SQL Server command line setup documentation which will stay relevant.

        SQL Server Repair action does not accept the FEATURES parameter. Although
        Microsoft's documentation lists /FEATURES as required for the Repair action,
        the actual SQL Server setup executable (tested with SQL Server 2017 and
        SQL Server 2022) rejects this parameter with the error: "The setting
        'FEATURES' is not allowed when the value of setting 'ACTION' is 'Repair'."
        SQL Server automatically repairs all installed features during a repair
        operation.
#>
function Repair-SqlDscServer
{
    # cSpell: ignore AZUREEXTENSION
    [System.Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSShouldProcess', '', Justification = 'Because ShouldProcess is used in Invoke-SetupAction')]
    [CmdletBinding(SupportsShouldProcess = $true, ConfirmImpact = 'High')]
    [OutputType()]
    param
    (
        [Parameter(Mandatory = $true)]
        [System.String]
        $MediaPath,

        [Parameter(Mandatory = $true)]
        [System.String]
        $InstanceName,

        [Parameter()]
        [System.Management.Automation.SwitchParameter]
        $Enu,

        [Parameter()]
        [System.String]
        $PBEngSvcAccount,

        [Parameter()]
        [System.Security.SecureString]
        $PBEngSvcPassword,

        [Parameter()]
        [ValidateSet('Automatic', 'Disabled', 'Manual')]
        [System.String]
        $PBEngSvcStartupType,

        [Parameter()]
        [System.UInt16]
        $PBStartPortRange,

        [Parameter()]
        [System.UInt16]
        $PBEndPortRange,

        [Parameter()]
        [System.Management.Automation.SwitchParameter]
        $PBScaleOut,

        [Parameter()]
        [System.UInt32]
        $Timeout = 7200,

        [Parameter()]
        [System.Management.Automation.SwitchParameter]
        $Force
    )

    Invoke-SetupAction -Repair @PSBoundParameters
}
#EndRegion '.\Public\Repair-SqlDscServer.ps1' 128
#Region '.\Public\Revoke-SqlDscServerPermission.ps1' -1

<#
    .SYNOPSIS
        Removes (revokes) server permissions from a principal on a SQL Server Database Engine instance.

    .DESCRIPTION
        This command removes (revokes) server permissions from an existing principal on
        a SQL Server Database Engine instance. The principal can be specified as either
        a Login object (from Get-SqlDscLogin) or a ServerRole object (from Get-SqlDscRole).

    .PARAMETER Login
        Specifies the Login object for which the permissions are revoked.
        This parameter accepts pipeline input.

    .PARAMETER ServerRole
        Specifies the ServerRole object for which the permissions are revoked.
        This parameter accepts pipeline input.

    .PARAMETER Permission
        Specifies the permissions to revoke. Specify multiple permissions by
        providing an array of SqlServerPermission enum values.

    .PARAMETER WithGrant
        Specifies that the right to grant the permission should also be revoked,
        and the revocation will cascade to other principals that the grantee has
        granted the same permission to.

    .PARAMETER Force
        Specifies that the permissions should be revoked without any confirmation.

    .OUTPUTS
        None.

    .EXAMPLE
        $serverInstance = Connect-SqlDscDatabaseEngine
        $login = $serverInstance | Get-SqlDscLogin -Name 'MyLogin'

        Revoke-SqlDscServerPermission -Login $login -Permission ConnectSql, ViewServerState

        Revokes the specified permissions from the login 'MyLogin'.

    .EXAMPLE
        $serverInstance = Connect-SqlDscDatabaseEngine
        $role = $serverInstance | Get-SqlDscRole -Name 'MyRole'

        $role | Revoke-SqlDscServerPermission -Permission AlterAnyDatabase -WithGrant -Force

        Revokes the specified permissions and the right to grant them from the role 'MyRole' with cascading effect, without prompting for confirmation.

    .NOTES
        The Login or ServerRole object must come from the same SQL Server instance
        where the permissions will be revoked. If specifying `-ErrorAction 'SilentlyContinue'`
        then the command will silently continue if any errors occur. If specifying
        `-ErrorAction 'Stop'` the command will throw an error on any failure.

        When revoking permission with -WithGrant, both the
        grantee and all the other users the grantee has granted the same permission
        to, will also get their permission revoked.
#>
function Revoke-SqlDscServerPermission
{
    [System.Diagnostics.CodeAnalysis.SuppressMessageAttribute('UseSyntacticallyCorrectExamples', '', Justification = 'Because the rule does not yet support parsing the code when a parameter type is not available. The ScriptAnalyzer rule UseSyntacticallyCorrectExamples will always error in the editor due to https://github.com/indented-automation/Indented.ScriptAnalyzerRules/issues/8.')]
    [System.Diagnostics.CodeAnalysis.SuppressMessageAttribute('AvoidThrowOutsideOfTry', '', Justification = 'Because the code throws based on an prior expression')]
    [CmdletBinding(SupportsShouldProcess = $true, ConfirmImpact = 'High')]
    [OutputType()]
    param
    (
        [Parameter(Mandatory = $true, ValueFromPipeline = $true, ParameterSetName = 'Login')]
        [Microsoft.SqlServer.Management.Smo.Login]
        $Login,

        [Parameter(Mandatory = $true, ValueFromPipeline = $true, ParameterSetName = 'ServerRole')]
        [Microsoft.SqlServer.Management.Smo.ServerRole]
        $ServerRole,

        [Parameter(Mandatory = $true)]
        [SqlServerPermission[]]
        $Permission,

        [Parameter()]
        [System.Management.Automation.SwitchParameter]
        $WithGrant,

        [Parameter()]
        [System.Management.Automation.SwitchParameter]
        $Force
    )

    process
    {
        if ($Force.IsPresent -and -not $Confirm)
        {
            $ConfirmPreference = 'None'
        }

        # Determine which principal object we're working with
        if ($PSCmdlet.ParameterSetName -eq 'Login')
        {
            $principalName = $Login.Name
            $serverObject = $Login.Parent
        }
        else
        {
            $principalName = $ServerRole.Name
            $serverObject = $ServerRole.Parent
        }

        $verboseDescriptionMessage = $script:localizedData.ServerPermission_Revoke_ShouldProcessVerboseDescription -f $principalName, $serverObject.InstanceName, ($Permission -join ',')
        $verboseWarningMessage = $script:localizedData.ServerPermission_Revoke_ShouldProcessVerboseWarning -f $principalName
        $captionMessage = $script:localizedData.ServerPermission_Revoke_ShouldProcessCaption

        if ($PSCmdlet.ShouldProcess($verboseDescriptionMessage, $verboseWarningMessage, $captionMessage))
        {
            # Convert enum array to ServerPermissionSet object
            $permissionSet = [Microsoft.SqlServer.Management.Smo.ServerPermissionSet]::new()
            foreach ($permissionName in $Permission)
            {
                $permissionSet.$permissionName = $true
            }

            try
            {
                if ($WithGrant.IsPresent)
                {
                    $serverObject.Revoke($permissionSet, $principalName, $false, $true)
                }
                else
                {
                    $serverObject.Revoke($permissionSet, $principalName)
                }
            }
            catch
            {
                $errorMessage = $script:localizedData.ServerPermission_Revoke_FailedToRevokePermission -f $principalName, $serverObject.InstanceName, ($Permission -join ',')

                $exception = [System.InvalidOperationException]::new($errorMessage, $_.Exception)

                $PSCmdlet.ThrowTerminatingError(
                    [System.Management.Automation.ErrorRecord]::new(
                        $exception,
                        'RSDSP0001', # cSpell: disable-line
                        [System.Management.Automation.ErrorCategory]::InvalidOperation,
                        $principalName
                    )
                )
            }
        }
    }
}
#EndRegion '.\Public\Revoke-SqlDscServerPermission.ps1' 149
#Region '.\Public\Save-SqlDscSqlServerMediaFile.ps1' -1

<#
    .SYNOPSIS
        Downloads SQL Server media from a provided URL and saves the downloaded
        media file to the specified file path

    .DESCRIPTION
        The Save-SqlDscSqlServerMediaFile function downloads SQL Server media from a
        provided URL and saves the downloaded media file to the specified file path.

        If the URL ends with ".exe", it is treated as an executable that downloads
        an ISO. If it doesn't, it is treated as a direct link to an ISO.

        The function also prints the SHA1 hash of the downloaded file.

    .PARAMETER Url
        The URL of the SQL Server media to download.

    .PARAMETER DestinationPath
        The file path where the downloaded media file should be saved.

    .PARAMETER FileName
        The file name of the downloaded media file. Defaults to media.iso if not
        provided.

    .PARAMETER Language
        The language parameter specifies the language of the downloaded iso. This
        parameter is only used when the provided URL is an executable file. Defaults
        to 'en-US' if not provided.

    .PARAMETER Quiet
        Disables verbose progress output during the download process.

    .PARAMETER Force
        Forces the download of the media file even if the file already exists at the
        specified destination path.

    .PARAMETER SkipExecution
        When specified, and the URL points to an executable (.exe), the function will
        download the executable file without executing it. The file will be saved using
        the provided FileName parameter.

    .EXAMPLE
        Save-SqlDscSqlServerMediaFile -Url 'https://download.microsoft.com/download/c/c/9/cc9c6797-383c-4b24-8920-dc057c1de9d3/SQL2022-SSEI-Dev.exe' -DestinationPath 'C:\path\to\destination'

        This downloads the SQL Server 2022 media and saves it to the specified destination path.

    .EXAMPLE
        Save-SqlDscSqlServerMediaFile -Url 'https://download.microsoft.com/download/c/c/9/cc9c6797-383c-4b24-8920-dc057c1de9d3/SQL2022-SSEI-Dev.exe' -DestinationPath 'C:\path\to\destination' -SkipExecution

        This downloads the SQL Server 2022 installer executable but does not execute it to extract the ISO.

    .EXAMPLE
        Save-SqlDscSqlServerMediaFile -Url 'https://download.microsoft.com/download/d/a/2/da259851-b941-459d-989c-54a18a5d44dd/SQL2019-SSEI-Dev.exe' -DestinationPath 'C:\path\to\destination'

        This downloads the SQL Server 2019 media and saves it to the specified destination path.

    .EXAMPLE
        Save-SqlDscSqlServerMediaFile -Url 'https://download.microsoft.com/download/E/F/2/EF23C21D-7860-4F05-88CE-39AA114B014B/SQLServer2017-x64-ENU.iso' -DestinationPath 'C:\path\to\destination'

        This downloads the SQL Server 2017 media and saves it to the specified destination path.

    .EXAMPLE
        Save-SqlDscSqlServerMediaFile -Url 'https://download.microsoft.com/download/9/0/7/907AD35F-9F9C-43A5-9789-52470555DB90/ENU/SQLServer2016SP1-FullSlipstream-x64-ENU.iso' -DestinationPath 'C:\path\to\destination'

        This downloads the SQL Server 2016 media and saves it to the specified destination path.
#>
function Save-SqlDscSqlServerMediaFile
{
    [CmdletBinding(SupportsShouldProcess = $true, ConfirmImpact = 'High')]
    [OutputType([System.IO.FileInfo])]
    param
    (
        [Parameter(Mandatory = $true)]
        [System.String]
        $Url,

        [Parameter(Mandatory = $true)]
        [System.IO.FileInfo]
        [ValidateScript({ Test-Path $_ -PathType 'Container' })]
        $DestinationPath,

        [Parameter()]
        [System.String]
        $FileName = 'media.iso',

        [Parameter()]
        # Supported by SQL Server version 2019 and 2022.
        [ValidateSet('zh-CN', 'zh-TW', 'en-US', 'fr-FR', 'de-DE', 'it-IT', 'ja-JP', 'ko-KR', 'pt-BR', 'ru-RU', 'es-ES')]
        [System.String]
        $Language = 'en-US',

        [Parameter()]
        [System.Management.Automation.SwitchParameter]
        $Quiet,

        [Parameter()]
        [System.Management.Automation.SwitchParameter]
        $Force,

        [Parameter()]
        [System.Management.Automation.SwitchParameter]
        $SkipExecution
    )

    if ($Force.IsPresent -and -not $Confirm)
    {
        $ConfirmPreference = 'None'
    }

    $destinationFilePath = Join-Path -Path $DestinationPath -ChildPath $FileName

    # Handle target file if it exists - Force parameter controls overwrite behavior
    if ((Test-Path -Path $destinationFilePath))
    {
        $verboseDescriptionMessage = $script:localizedData.SqlServerMediaFile_Save_ShouldProcessVerboseDescription -f $destinationFilePath
        $verboseWarningMessage = $script:localizedData.SqlServerMediaFile_Save_ShouldProcessVerboseWarning -f $destinationFilePath
        $captionMessage = $script:localizedData.SqlServerMediaFile_Save_ShouldProcessCaption

        if ($PSCmdlet.ShouldProcess($verboseDescriptionMessage, $verboseWarningMessage, $captionMessage))
        {
            Remove-Item -Path $destinationFilePath -Force
        }
        else
        {
            return
        }
    }

    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

    $isExecutable = $false

    if ($Url -match '\.exe$')
    {
        $isExecutable = $true

        # Change the file extension of the destination file path to .exe
        $destinationExecutableFilePath = [System.IO.Path]::ChangeExtension($destinationFilePath, 'exe')

        $downloadedFilePath = $destinationExecutableFilePath
    }
    else
    {
        $downloadedFilePath = $destinationFilePath
    }

    if ($Quiet.IsPresent)
    {
        <#
            By switching to 'SilentlyContinue' it removes the progress bar of
            Invoke-WebRequest and should also theoretically increase the download
            speed.
        #>
        $previousProgressPreference = $ProgressPreference
        $ProgressPreference = 'SilentlyContinue'
    }

    Write-Verbose -Message ($script:localizedData.SqlServerMediaFile_Save_DownloadingInformation -f $Url)

    # Download the URL content.
    Invoke-WebRequest -Uri $Url -OutFile $downloadedFilePath | Out-Null

    if ($Quiet.IsPresent)
    {
        # Revert the progress preference back to the previous value.
        $ProgressPreference = $previousProgressPreference
    }

    if ($isExecutable -and -not $SkipExecution)
    {
        Write-Verbose -Message $script:localizedData.SqlServerMediaFile_Save_IsExecutable

        $executableArguments = @(
            '/Quiet'
        )

        if ($VerbosePreference -eq 'SilentlyContinue')
        {
            $executableArguments += @(
                '/HideProgressBar'
            )
        }
        else
        {
            $executableArguments += @(
                '/Verbose'
            )
        }

        $executableArguments += @(
            '/Action=Download',
            "/Language=$Language",
            '/MediaType=ISO',
            "/MediaPath=$destinationPath"
        )

        $startProcessArgumentList = $executableArguments -join ' '

        # Download ISO media using the downloaded executable.
        Start-Process -FilePath $destinationExecutableFilePath -ArgumentList $startProcessArgumentList -Wait

        Write-Verbose -Message $script:localizedData.SqlServerMediaFile_Save_RemovingExecutable

        # Remove the downloaded executable.
        Remove-Item -Path $destinationExecutableFilePath -Force

        # Get all the iso files in the destination path and if there are more than one throw an error.
        $isoFile = Get-Item -Path "$DestinationPath/*.iso" -Force

        if ($isoFile.Count -gt 1)
        {
            $writeErrorParameters = @{
                Message      = $script:localizedData.SqlServerMediaFile_Save_MultipleFilesFoundAfterDownload
                Category     = 'InvalidOperation'
                ErrorId      = 'SSDSSM0002' # CSpell: disable-line
                TargetObject = $DestinationPath
            }

            Write-Error @writeErrorParameters
            return
        }

        Write-Verbose -Message ($script:localizedData.SqlServerMediaFile_Save_RenamingFile -f $isoFile.Name, $FileName)

        # Rename the iso file in the destination path.
        Rename-Item -Path $isoFile.FullName -NewName $FileName -Force
    }

    return (Get-Item -Path $destinationFilePath)
}
#EndRegion '.\Public\Save-SqlDscSqlServerMediaFile.ps1' 231
#Region '.\Public\Set-SqlDscAgentAlert.ps1' -1

<#
    .SYNOPSIS
        Updates a SQL Agent Alert.

    .DESCRIPTION
        This command updates an existing SQL Agent Alert on a SQL Server Database Engine
        instance.

    .PARAMETER ServerObject
        Specifies current server connection object.

    .PARAMETER AlertObject
        Specifies an alert object to update.

    .PARAMETER Name
        Specifies the name of the SQL Agent Alert to update.

    .PARAMETER Severity
        Specifies the severity level for the SQL Agent Alert. Valid range is 0 to 25.
        Cannot be used together with MessageId.

    .PARAMETER MessageId
        Specifies the message ID for the SQL Agent Alert. Valid range is 0 to 2147483647.
        Cannot be used together with Severity.

    .PARAMETER PassThru
        Specifies whether the updated alert object will be returned.

    .PARAMETER Refresh
        Specifies that the alert object should be refreshed before updating. This
        is helpful when alerts could have been modified outside of the **ServerObject**,
        for example through T-SQL.

    .PARAMETER Force
        Specifies that the alert should be updated without prompting for confirmation.

    .INPUTS
        Microsoft.SqlServer.Management.Smo.Server

        SQL Server Database Engine instance object.

        Microsoft.SqlServer.Management.Smo.Agent.Alert

        SQL Agent Alert object to update.

    .OUTPUTS
        Microsoft.SqlServer.Management.Smo.Agent.Alert
            Returned when parameter **PassThru** is specified.

        None
            No output is returned unless **PassThru** is specified.
    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine -InstanceName 'MyInstance'
        Set-SqlDscAgentAlert -ServerObject $serverObject -Name 'MyAlert' -Severity 16

        Updates the SQL Agent Alert named 'MyAlert' to severity level 16.

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine -InstanceName 'MyInstance'
        $alertObject = $serverObject | Get-SqlDscAgentAlert -Name 'MyAlert'
        $alertObject | Set-SqlDscAgentAlert -MessageId 50001

        Updates the SQL Agent Alert using pipeline input with alert object.

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine -InstanceName 'MyInstance'
        $updatedAlert = $serverObject | Set-SqlDscAgentAlert -Name 'MyAlert' -Severity 16 -PassThru

        Updates the alert and returns the updated object.

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine -InstanceName 'MyInstance'
        Set-SqlDscAgentAlert -ServerObject $serverObject -Name 'MyAlert' -Severity 16 -Force

        Updates the SQL Agent Alert named 'MyAlert' to severity level 16 without prompting for confirmation.
#>
function Set-SqlDscAgentAlert
{
    [System.Diagnostics.CodeAnalysis.SuppressMessageAttribute('UseSyntacticallyCorrectExamples', '', Justification = 'Because the rule does not yet support parsing the code when a parameter type is not available. The ScriptAnalyzer rule UseSyntacticallyCorrectExamples will always error in the editor due to https://github.com/indented-automation/Indented.ScriptAnalyzerRules/issues/8.')]
    [CmdletBinding(SupportsShouldProcess = $true, ConfirmImpact = 'High')]
    [OutputType([Microsoft.SqlServer.Management.Smo.Agent.Alert])]
    param
    (
        [Parameter(ParameterSetName = 'ServerObject', Mandatory = $true, ValueFromPipeline = $true)]
        [Microsoft.SqlServer.Management.Smo.Server]
        $ServerObject,

        [Parameter(ParameterSetName = 'AlertObject', Mandatory = $true, ValueFromPipeline = $true)]
        [Microsoft.SqlServer.Management.Smo.Agent.Alert]
        $AlertObject,

        [Parameter(ParameterSetName = 'ServerObject', Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [System.String]
        $Name,

        [Parameter()]
        [ValidateRange(0, 25)]
        [System.Int32]
        $Severity,

        [Parameter()]
        [ValidateRange(0, 2147483647)]
        [System.Int32]
        $MessageId,

        [Parameter()]
        [System.Management.Automation.SwitchParameter]
        $PassThru,

        [Parameter(ParameterSetName = 'ServerObject')]
        [System.Management.Automation.SwitchParameter]
        $Refresh,

        [Parameter()]
        [System.Management.Automation.SwitchParameter]
        $Force
    )

    # cSpell: ignore SSAA
    process
    {
        if ($Force.IsPresent -and -not $Confirm)
        {
            $ConfirmPreference = 'None'
        }

        # Validate that both Severity and MessageId are not specified
        Assert-BoundParameter -BoundParameterList $PSBoundParameters -MutuallyExclusiveList1 @('Severity') -MutuallyExclusiveList2 @('MessageId')

        if ($PSCmdlet.ParameterSetName -eq 'ServerObject')
        {
            if ($Refresh.IsPresent)
            {
                Write-Verbose -Message ($script:localizedData.Set_SqlDscAgentAlert_RefreshingServerObject)
                $ServerObject.JobServer.Alerts.Refresh()
            }

            $alertObjectToUpdate = Get-AgentAlertObject -ServerObject $ServerObject -Name $Name

            if ($null -eq $alertObjectToUpdate)
            {
                $errorMessage = $script:localizedData.Set_SqlDscAgentAlert_AlertNotFound -f $Name

                $PSCmdlet.ThrowTerminatingError(
                    [System.Management.Automation.ErrorRecord]::new(
                        [System.Management.Automation.ItemNotFoundException]::new($errorMessage),
                        'SSAA0002', # cspell: disable-line
                        [System.Management.Automation.ErrorCategory]::ObjectNotFound,
                        $Name
                    )
                )
            }
        }
        else
        {
            $alertObjectToUpdate = $AlertObject
        }

        $verboseDescriptionMessage = $script:localizedData.Set_SqlDscAgentAlert_UpdateShouldProcessVerboseDescription -f $alertObjectToUpdate.Name, $alertObjectToUpdate.Parent.Parent.InstanceName
        $verboseWarningMessage = $script:localizedData.Set_SqlDscAgentAlert_UpdateShouldProcessVerboseWarning -f $alertObjectToUpdate.Name
        $captionMessage = $script:localizedData.Set_SqlDscAgentAlert_UpdateShouldProcessCaption

        if ($PSCmdlet.ShouldProcess($verboseDescriptionMessage, $verboseWarningMessage, $captionMessage))
        {
            try
            {
                Write-Verbose -Message ($script:localizedData.Set_SqlDscAgentAlert_UpdatingAlert -f $alertObjectToUpdate.Name)

                $hasChanges = $false

                if ($PSBoundParameters.ContainsKey('Severity'))
                {
                    if ($alertObjectToUpdate.Severity -ne $Severity)
                    {
                        Write-Verbose -Message ($script:localizedData.Set_SqlDscAgentAlert_SettingSeverity -f $Severity, $alertObjectToUpdate.Name)
                        $alertObjectToUpdate.Severity = $Severity
                        $alertObjectToUpdate.MessageId = 0 # Must set any conflicting properties to 0
                        $hasChanges = $true
                    }
                    else
                    {
                        Write-Verbose -Message ($script:localizedData.Set_SqlDscAgentAlert_SeverityAlreadyCorrect -f $Severity, $alertObjectToUpdate.Name)
                    }
                }

                if ($PSBoundParameters.ContainsKey('MessageId'))
                {
                    if ($alertObjectToUpdate.MessageId -ne $MessageId)
                    {
                        Write-Verbose -Message ($script:localizedData.Set_SqlDscAgentAlert_SettingMessageId -f $MessageId, $alertObjectToUpdate.Name)
                        $alertObjectToUpdate.MessageId = $MessageId
                        $alertObjectToUpdate.Severity = 0 # Must set any conflicting properties to 0
                        $hasChanges = $true
                    }
                    else
                    {
                        Write-Verbose -Message ($script:localizedData.Set_SqlDscAgentAlert_MessageIdAlreadyCorrect -f $MessageId, $alertObjectToUpdate.Name)
                    }
                }

                if ($hasChanges)
                {
                    $alertObjectToUpdate.Alter()
                    Write-Verbose -Message ($script:localizedData.Set_SqlDscAgentAlert_AlertUpdated -f $alertObjectToUpdate.Name)
                }
                else
                {
                    Write-Verbose -Message ($script:localizedData.Set_SqlDscAgentAlert_NoChangesNeeded -f $alertObjectToUpdate.Name)
                }

                if ($PassThru.IsPresent)
                {
                    return $alertObjectToUpdate
                }
            }
            catch
            {
                $errorMessage = $script:localizedData.Set_SqlDscAgentAlert_UpdateFailed -f $alertObjectToUpdate.Name

                $PSCmdlet.ThrowTerminatingError(
                    [System.Management.Automation.ErrorRecord]::new(
                        [System.InvalidOperationException]::new($errorMessage, $_.Exception),
                        'SSAA0008', # cspell: disable-line
                        [System.Management.Automation.ErrorCategory]::InvalidOperation,
                        $alertObjectToUpdate
                    )
                )
            }
        }
    }
}
#EndRegion '.\Public\Set-SqlDscAgentAlert.ps1' 233
#Region '.\Public\Set-SqlDscAgentOperator.ps1' -1

<#
    .SYNOPSIS
        Updates properties of a SQL Agent Operator.

    .DESCRIPTION
        This command updates properties of an existing SQL Agent Operator on a SQL Server Database Engine instance.

    .PARAMETER ServerObject
        Specifies current server connection object.

    .PARAMETER OperatorObject
        Specifies the SQL Agent Operator object to update.

    .PARAMETER Name
        Specifies the name of the SQL Agent Operator to update.

    .PARAMETER EmailAddress
        Specifies the email address for the SQL Agent Operator.

    .PARAMETER CategoryName
        Specifies the category name for the SQL Agent Operator.

    .PARAMETER NetSendAddress
        Specifies the net send address for the SQL Agent Operator.

    .PARAMETER PagerAddress
        Specifies the pager address for the SQL Agent Operator.

    .PARAMETER PagerDays
        Specifies the days when pager notifications are active for the SQL Agent Operator.

    .PARAMETER SaturdayPagerEndTime
        Specifies the Saturday pager end time for the SQL Agent Operator.

    .PARAMETER SaturdayPagerStartTime
        Specifies the Saturday pager start time for the SQL Agent Operator.

    .PARAMETER SundayPagerEndTime
        Specifies the Sunday pager end time for the SQL Agent Operator.

    .PARAMETER SundayPagerStartTime
        Specifies the Sunday pager start time for the SQL Agent Operator.

    .PARAMETER WeekdayPagerEndTime
        Specifies the weekday pager end time for the SQL Agent Operator.

    .PARAMETER WeekdayPagerStartTime
        Specifies the weekday pager start time for the SQL Agent Operator.

    .PARAMETER Force
        Specifies that the operator should be updated without any confirmation.

    .INPUTS
        Microsoft.SqlServer.Management.Smo.Server

        SQL Server Database Engine instance object.

    .INPUTS
        Microsoft.SqlServer.Management.Smo.Agent.Operator

        SQL Agent Operator object.

    .OUTPUTS
        None.

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine -InstanceName 'MyInstance'
        Set-SqlDscAgentOperator -ServerObject $serverObject -Name 'MyOperator' -EmailAddress 'admin@contoso.com'

        Updates the email address of the SQL Agent Operator named 'MyOperator'.

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine -InstanceName 'MyInstance'
        $serverObject | Set-SqlDscAgentOperator -Name 'MyOperator' -EmailAddress 'admin@contoso.com'

        Updates the email address of the SQL Agent Operator using pipeline input.

    .EXAMPLE
        $operatorObject = Get-SqlDscAgentOperator -ServerObject $serverObject -Name 'MyOperator'
        $operatorObject | Set-SqlDscAgentOperator -EmailAddress 'admin@contoso.com'

        Updates the email address of the SQL Agent Operator using operator object pipeline input.
#>
function Set-SqlDscAgentOperator
{
    [System.Diagnostics.CodeAnalysis.SuppressMessageAttribute('UseSyntacticallyCorrectExamples', '', Justification = 'Because the rule does not yet support parsing the code when a parameter type is not available. The ScriptAnalyzer rule UseSyntacticallyCorrectExamples will always error in the editor due to https://github.com/indented-automation/Indented.ScriptAnalyzerRules/issues/8.')]
    [CmdletBinding(SupportsShouldProcess = $true, ConfirmImpact = 'High', DefaultParameterSetName = 'ByName')]
    [OutputType()]
    param
    (
        [Parameter(Mandatory = $true, ValueFromPipeline = $true, ParameterSetName = 'ByName')]
        [Microsoft.SqlServer.Management.Smo.Server]
        $ServerObject,

        [Parameter(Mandatory = $true, ValueFromPipeline = $true, ParameterSetName = 'ByObject')]
        [Microsoft.SqlServer.Management.Smo.Agent.Operator]
        $OperatorObject,

        [Parameter(Mandatory = $true, ParameterSetName = 'ByName')]
        [ValidateNotNullOrEmpty()]
        [System.String]
        $Name,

        [Parameter()]
        [System.String]
        $EmailAddress,

        [Parameter()]
        [System.String]
        $CategoryName,

        [Parameter()]
        [System.String]
        $NetSendAddress,

        [Parameter()]
        [System.String]
        $PagerAddress,

        [Parameter()]
        [Microsoft.SqlServer.Management.Smo.Agent.WeekDays]
        $PagerDays,

        [Parameter()]
        [System.TimeSpan]
        $SaturdayPagerEndTime,

        [Parameter()]
        [System.TimeSpan]
        $SaturdayPagerStartTime,

        [Parameter()]
        [System.TimeSpan]
        $SundayPagerEndTime,

        [Parameter()]
        [System.TimeSpan]
        $SundayPagerStartTime,

        [Parameter()]
        [System.TimeSpan]
        $WeekdayPagerEndTime,

        [Parameter()]
        [System.TimeSpan]
        $WeekdayPagerStartTime,

        [Parameter()]
        [System.Management.Automation.SwitchParameter]
        $Force
    )

    begin
    {
        # Dynamically get settable properties by filtering out common parameters and control parameters
        $settableProperties = Get-CommandParameter -Command $MyInvocation.MyCommand -Exclude @('ServerObject', 'OperatorObject', 'Name', 'Force')

        Assert-BoundParameter -BoundParameterList $PSBoundParameters -AtLeastOneList $settableProperties
    }

    # cSpell: ignore SSAO
    process
    {
        if ($Force.IsPresent -and -not $Confirm)
        {
            $ConfirmPreference = 'None'
        }
        if ($PSCmdlet.ParameterSetName -eq 'ByName')
        {
            Write-Verbose -Message ($script:localizedData.Set_SqlDscAgentOperator_RefreshingServerObject)

            $ServerObject.JobServer.Operators.Refresh()

            $originalErrorActionPreference = $ErrorActionPreference
            $ErrorActionPreference = 'Stop'
            $OperatorObject = Get-AgentOperatorObject -ServerObject $ServerObject -Name $Name -ErrorAction 'Stop'
            $ErrorActionPreference = $originalErrorActionPreference
        }

        # Build description of parameters being set for ShouldProcess
        $excludeParameters = @('ServerObject', 'OperatorObject', 'Name', 'Force')
        $parametersText = ConvertTo-FormattedParameterDescription -BoundParameters $PSBoundParameters -Exclude $excludeParameters

        $verboseDescriptionMessage = $script:localizedData.Set_SqlDscAgentOperator_UpdateShouldProcessVerboseDescription -f $OperatorObject.Name, $OperatorObject.Parent.Parent.InstanceName, $parametersText
        $verboseWarningMessage = $script:localizedData.Set_SqlDscAgentOperator_UpdateShouldProcessVerboseWarning -f $OperatorObject.Name
        $captionMessage = $script:localizedData.Set_SqlDscAgentOperator_UpdateShouldProcessCaption

        if ($PSCmdlet.ShouldProcess($verboseDescriptionMessage, $verboseWarningMessage, $captionMessage))
        {
            try
            {
                if ($PSBoundParameters.ContainsKey('EmailAddress'))
                {
                    $OperatorObject.EmailAddress = $EmailAddress
                }

                if ($PSBoundParameters.ContainsKey('CategoryName'))
                {
                    $OperatorObject.CategoryName = $CategoryName
                }

                if ($PSBoundParameters.ContainsKey('NetSendAddress'))
                {
                    $OperatorObject.NetSendAddress = $NetSendAddress
                }

                if ($PSBoundParameters.ContainsKey('PagerAddress'))
                {
                    $OperatorObject.PagerAddress = $PagerAddress
                }

                if ($PSBoundParameters.ContainsKey('PagerDays'))
                {
                    $OperatorObject.PagerDays = $PagerDays
                }

                if ($PSBoundParameters.ContainsKey('SaturdayPagerEndTime'))
                {
                    $OperatorObject.SaturdayPagerEndTime = $SaturdayPagerEndTime
                }

                if ($PSBoundParameters.ContainsKey('SaturdayPagerStartTime'))
                {
                    $OperatorObject.SaturdayPagerStartTime = $SaturdayPagerStartTime
                }

                if ($PSBoundParameters.ContainsKey('SundayPagerEndTime'))
                {
                    $OperatorObject.SundayPagerEndTime = $SundayPagerEndTime
                }

                if ($PSBoundParameters.ContainsKey('SundayPagerStartTime'))
                {
                    $OperatorObject.SundayPagerStartTime = $SundayPagerStartTime
                }

                if ($PSBoundParameters.ContainsKey('WeekdayPagerEndTime'))
                {
                    $OperatorObject.WeekdayPagerEndTime = $WeekdayPagerEndTime
                }

                if ($PSBoundParameters.ContainsKey('WeekdayPagerStartTime'))
                {
                    $OperatorObject.WeekdayPagerStartTime = $WeekdayPagerStartTime
                }

                $OperatorObject.Alter()
            }
            catch
            {
                $errorMessage = $script:localizedData.Set_SqlDscAgentOperator_UpdateFailed -f $OperatorObject.Name

                $PSCmdlet.ThrowTerminatingError(
                    [System.Management.Automation.ErrorRecord]::new(
                        [System.InvalidOperationException]::new($errorMessage, $_.Exception),
                        'SSAO0001', # cspell: disable-line
                        [System.Management.Automation.ErrorCategory]::InvalidOperation,
                        $OperatorObject
                    )
                )
            }
        }
    }
}
#EndRegion '.\Public\Set-SqlDscAgentOperator.ps1' 265
#Region '.\Public\Set-SqlDscAudit.ps1' -1

<#
    .SYNOPSIS
        Updates a server audit.

    .DESCRIPTION
        This command updates an existing server audit on a SQL Server Database Engine
        instance.

    .PARAMETER ServerObject
        Specifies current server connection object.

    .PARAMETER AuditObject
        Specifies an audit object to update.

    .PARAMETER Name
        Specifies the name of the server audit to be updated.

    .PARAMETER AuditFilter
        Specifies the filter that should be used on the audit. See [predicate expression](https://docs.microsoft.com/en-us/sql/t-sql/statements/create-server-audit-transact-sql)
        how to write the syntax for the filter.

    .PARAMETER OnFailure
        Specifies what should happen when writing events to the store fails.
        This can be 'Continue', 'FailOperation', or 'Shutdown'.

    .PARAMETER QueueDelay
        Specifies the maximum delay before a event is written to the store.
        When set to low this could impact server performance.
        When set to high events could be missing when a server crashes.

    .PARAMETER AuditGuid
        Specifies the GUID found in the mirrored database. To support scenarios such
        as database mirroring an audit needs a specific GUID.

    .PARAMETER AllowAuditGuidChange
        Specifies that the audit GUID can be changed by dropping and recreating the
        audit. This parameter is required when modifying the AuditGuid property because
        SQL Server does not allow direct modification of the audit GUID. When specified,
        the audit will be dropped and recreated with all existing properties plus the
        new GUID value. This is a destructive operation that requires explicit opt-in.

    .PARAMETER Force
        Specifies that the audit should be updated without any confirmation.

    .PARAMETER Refresh
        Specifies that the audit object should be refreshed before updating. This
        is helpful when audits could have been modified outside of the **ServerObject**,
        for example through T-SQL. But on instances with a large amount of audits
        it might be better to make sure the ServerObject is recent enough.

    .PARAMETER Path
        Specifies the location where the log files will be placed.

    .PARAMETER ReserveDiskSpace
        Specifies if the needed file space should be reserved. To use this parameter
        the parameter **MaximumFiles** must also be used.

    .PARAMETER MaximumFiles
        Specifies the number of files on disk.

    .PARAMETER MaximumFileSize
        Specifies the maximum file size in units by parameter MaximumFileSizeUnit.
        Minimum allowed value is 2 (MB). It also allowed to set the value to 0 which
        mean unlimited file size.

    .PARAMETER MaximumFileSizeUnit
        Specifies the unit used for the file size. This can be Megabyte, Gigabyte,
        or Terabyte.

    .PARAMETER MaximumRolloverFiles
        Specifies the amount of files on disk before SQL Server starts reusing
        the files. If not specified then it is set to unlimited.

    .PARAMETER PassThru
        If specified the changed audit object will be returned.

    .OUTPUTS
        `[Microsoft.SqlServer.Management.Smo.Audit]` is passing parameter **PassThru**,
         otherwise none.

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine -InstanceName 'MyInstance'
        $serverObject | Set-SqlDscAudit -Name 'MyFileAudit' -Path 'E:\auditFolder' -QueueDelay 1000

        Updates the file audit named **MyFileAudit** by setting the path to 'E:\auditFolder'
        and the queue delay to 1000.

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine -InstanceName 'MyInstance'
        $serverObject | New-SqlDscAudit -Name 'MyAppLogAudit' -QueueDelay 1000

        Updates the application log audit named **MyAppLogAudit** by setting the
        queue delay to 1000.

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine -InstanceName 'MyInstance'
        $serverObject | Set-SqlDscAudit -Name 'MyFileAudit' -Path 'E:\auditFolder' -QueueDelay 1000 -PassThru

        Updates the file audit named **MyFileAudit** by setting the path to ''E:\auditFolder'
        and the queue delay to 1000, and returns the Audit object.

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine -InstanceName 'MyInstance'
        $serverObject | Set-SqlDscAudit -Name 'MyFileAudit' -AuditGuid '12345678-1234-1234-1234-123456789012' -AllowAuditGuidChange

        Changes the audit GUID by dropping and recreating the audit with the specified GUID.

    .NOTES
        This command has the confirm impact level set to high since an audit is
        unknown to be enable at the point when the command is issued.

        See the SQL Server documentation for more information for the possible
        parameter values to pass to this command: https://docs.microsoft.com/en-us/sql/t-sql/statements/create-server-audit-transact-sql
#>
function Set-SqlDscAudit
{
    [System.Diagnostics.CodeAnalysis.SuppressMessageAttribute('UseSyntacticallyCorrectExamples', '', Justification = 'Because the rule does not yet support parsing the code when a parameter type is not available. The ScriptAnalyzer rule UseSyntacticallyCorrectExamples will always error in the editor due to https://github.com/indented-automation/Indented.ScriptAnalyzerRules/issues/8.')]
    [OutputType([Microsoft.SqlServer.Management.Smo.Audit])]
    [CmdletBinding(SupportsShouldProcess = $true, ConfirmImpact = 'High')]
    param
    (
        [Parameter(ParameterSetName = 'ServerObject', Mandatory = $true, ValueFromPipeline = $true)]
        [Parameter(ParameterSetName = 'ServerObjectWithSize', Mandatory = $true, ValueFromPipeline = $true)]
        [Parameter(ParameterSetName = 'ServerObjectWithMaxFiles', Mandatory = $true, ValueFromPipeline = $true)]
        [Parameter(ParameterSetName = 'ServerObjectWithMaxRolloverFiles', Mandatory = $true, ValueFromPipeline = $true)]
        [Parameter(ParameterSetName = 'ServerObjectWithSizeAndMaxFiles', Mandatory = $true, ValueFromPipeline = $true)]
        [Parameter(ParameterSetName = 'ServerObjectWithSizeAndMaxRolloverFiles', Mandatory = $true, ValueFromPipeline = $true)]
        [Microsoft.SqlServer.Management.Smo.Server]
        $ServerObject,

        [Parameter(ParameterSetName = 'AuditObject', Mandatory = $true, ValueFromPipeline = $true)]
        [Parameter(ParameterSetName = 'AuditObjectWithSize', Mandatory = $true, ValueFromPipeline = $true)]
        [Parameter(ParameterSetName = 'AuditObjectWithMaxFiles', Mandatory = $true, ValueFromPipeline = $true)]
        [Parameter(ParameterSetName = 'AuditObjectWithMaxRolloverFiles', Mandatory = $true, ValueFromPipeline = $true)]
        [Parameter(ParameterSetName = 'AuditObjectWithSizeAndMaxFiles', Mandatory = $true, ValueFromPipeline = $true)]
        [Parameter(ParameterSetName = 'AuditObjectWithSizeAndMaxRolloverFiles', Mandatory = $true, ValueFromPipeline = $true)]
        [Microsoft.SqlServer.Management.Smo.Audit]
        $AuditObject,

        [Parameter(ParameterSetName = 'ServerObject', Mandatory = $true)]
        [Parameter(ParameterSetName = 'ServerObjectWithSize', Mandatory = $true)]
        [Parameter(ParameterSetName = 'ServerObjectWithMaxFiles', Mandatory = $true)]
        [Parameter(ParameterSetName = 'ServerObjectWithMaxRolloverFiles', Mandatory = $true)]
        [Parameter(ParameterSetName = 'ServerObjectWithSizeAndMaxFiles', Mandatory = $true)]
        [Parameter(ParameterSetName = 'ServerObjectWithSizeAndMaxRolloverFiles', Mandatory = $true)]
        [System.String]
        $Name,

        [Parameter()]
        [System.String]
        $AuditFilter,

        [Parameter()]
        [ValidateSet('Continue', 'FailOperation', 'Shutdown')]
        [System.String]
        $OnFailure,

        [Parameter()]
        [ValidateScript({
                if ($_ -in 1..999 -or $_ -gt 2147483647)
                {
                    throw ($script:localizedData.Audit_QueueDelayParameterValueInvalid -f $_)
                }

                return $true
            })]
        [System.UInt32]
        $QueueDelay,

        [Parameter()]
        [ValidatePattern('^[0-9a-fA-F]{8}-(?:[0-9a-fA-F]{4}-){3}[0-9a-fA-F]{12}$')]
        [System.String]
        $AuditGuid,

        [Parameter()]
        [System.Management.Automation.SwitchParameter]
        $AllowAuditGuidChange,

        [Parameter()]
        [System.Management.Automation.SwitchParameter]
        $Force,

        [Parameter()]
        [System.Management.Automation.SwitchParameter]
        $Refresh,

        [Parameter()]
        [System.Management.Automation.SwitchParameter]
        $PassThru,

        [Parameter(ParameterSetName = 'ServerObject')]
        [Parameter(ParameterSetName = 'ServerObjectWithSize')]
        [Parameter(ParameterSetName = 'ServerObjectWithMaxFiles')]
        [Parameter(ParameterSetName = 'ServerObjectWithMaxRolloverFiles')]
        [Parameter(ParameterSetName = 'ServerObjectWithSizeAndMaxFiles')]
        [Parameter(ParameterSetName = 'ServerObjectWithSizeAndMaxRolloverFiles')]
        [Parameter(ParameterSetName = 'AuditObject')]
        [Parameter(ParameterSetName = 'AuditObjectWithSize')]
        [Parameter(ParameterSetName = 'AuditObjectWithMaxFiles')]
        [Parameter(ParameterSetName = 'AuditObjectWithMaxRolloverFiles')]
        [Parameter(ParameterSetName = 'AuditObjectWithSizeAndMaxFiles')]
        [Parameter(ParameterSetName = 'AuditObjectWithSizeAndMaxRolloverFiles')]
        [ValidateScript({
                if (-not (Test-Path -Path $_))
                {
                    throw ($script:localizedData.Audit_PathParameterValueInvalid -f $_)
                }

                return $true
            })]
        [System.String]
        $Path,

        [Parameter(ParameterSetName = 'ServerObjectWithSize', Mandatory = $true)]
        [Parameter(ParameterSetName = 'ServerObjectWithSizeAndMaxFiles', Mandatory = $true)]
        [Parameter(ParameterSetName = 'ServerObjectWithSizeAndMaxRolloverFiles', Mandatory = $true)]
        [Parameter(ParameterSetName = 'AuditObjectWithSize', Mandatory = $true)]
        [Parameter(ParameterSetName = 'AuditObjectWithSizeAndMaxFiles', Mandatory = $true)]
        [Parameter(ParameterSetName = 'AuditObjectWithSizeAndMaxRolloverFiles', Mandatory = $true)]
        [ValidateScript({
                if ($_ -eq 1 -or $_ -gt 2147483647)
                {
                    throw ($script:localizedData.Audit_MaximumFileSizeParameterValueInvalid -f $_)
                }

                return $true
            })]
        [System.UInt32]
        $MaximumFileSize,

        [Parameter(ParameterSetName = 'ServerObjectWithSize', Mandatory = $true)]
        [Parameter(ParameterSetName = 'ServerObjectWithSizeAndMaxFiles', Mandatory = $true)]
        [Parameter(ParameterSetName = 'ServerObjectWithSizeAndMaxRolloverFiles', Mandatory = $true)]
        [Parameter(ParameterSetName = 'AuditObjectWithSize', Mandatory = $true)]
        [Parameter(ParameterSetName = 'AuditObjectWithSizeAndMaxFiles', Mandatory = $true)]
        [Parameter(ParameterSetName = 'AuditObjectWithSizeAndMaxRolloverFiles', Mandatory = $true)]
        [ValidateSet('Megabyte', 'Gigabyte', 'Terabyte')]
        [System.String]
        $MaximumFileSizeUnit,

        [Parameter(ParameterSetName = 'ServerObjectWithMaxFiles', Mandatory = $true)]
        [Parameter(ParameterSetName = 'ServerObjectWithSizeAndMaxFiles', Mandatory = $true)]
        [Parameter(ParameterSetName = 'AuditObjectWithMaxFiles', Mandatory = $true)]
        [Parameter(ParameterSetName = 'AuditObjectWithSizeAndMaxFiles', Mandatory = $true)]
        [System.UInt32]
        $MaximumFiles,

        [Parameter(ParameterSetName = 'ServerObjectWithMaxFiles')]
        [Parameter(ParameterSetName = 'ServerObjectWithSizeAndMaxFiles')]
        [Parameter(ParameterSetName = 'AuditObjectWithMaxFiles')]
        [Parameter(ParameterSetName = 'AuditObjectWithSizeAndMaxFiles')]
        [System.Management.Automation.SwitchParameter]
        $ReserveDiskSpace,

        [Parameter(ParameterSetName = 'ServerObjectWithMaxRolloverFiles', Mandatory = $true)]
        [Parameter(ParameterSetName = 'ServerObjectWithSizeAndMaxRolloverFiles', Mandatory = $true)]
        [Parameter(ParameterSetName = 'AuditObjectWithMaxRolloverFiles', Mandatory = $true)]
        [Parameter(ParameterSetName = 'AuditObjectWithSizeAndMaxRolloverFiles', Mandatory = $true)]
        [ValidateRange(0, 2147483647)]
        [System.UInt32]
        $MaximumRolloverFiles
    )

    process
    {
        if ($Force.IsPresent -and -not $Confirm)
        {
            $ConfirmPreference = 'None'
        }

        if ($PSCmdlet.ParameterSetName -match '^ServerObject')
        {
            $getSqlDscAuditParameters = @{
                ServerObject = $ServerObject
                Name         = $Name
                Refresh      = $Refresh
                ErrorAction  = 'Stop'
            }

            # If this command does not find the audit it will throw an exception.
            $auditObjectArray = Get-SqlDscAudit @getSqlDscAuditParameters

            # Pick the only object in the array.
            $AuditObject = $auditObjectArray | Select-Object -First 1
        }

        if ($Refresh.IsPresent)
        {
            $AuditObject.Refresh()
        }

        $descriptionMessage = $script:localizedData.Audit_Update_ShouldProcessVerboseDescription -f $AuditObject.Name, $AuditObject.Parent.InstanceName
        $confirmationMessage = $script:localizedData.Audit_Update_ShouldProcessVerboseWarning -f $AuditObject.Name
        $captionMessage = $script:localizedData.Audit_Update_ShouldProcessCaption

        if ($PSCmdlet.ShouldProcess($descriptionMessage, $confirmationMessage, $captionMessage))
        {
            # Check if GUID change is requested early, before any other modifications
            if ($PSBoundParameters.ContainsKey('AuditGuid') -and $AuditObject.Guid -ne $AuditGuid)
            {
                # Validate that AllowAuditGuidChange is present
                if (-not $AllowAuditGuidChange.IsPresent)
                {
                    $errorMessage = $script:localizedData.Audit_AuditGuidChangeRequiresAllowParameter -f $AuditObject.Name

                    $PSCmdlet.ThrowTerminatingError(
                        [System.Management.Automation.ErrorRecord]::new(
                            $errorMessage,
                            'SSDA0001', # cspell: disable-line
                            [System.Management.Automation.ErrorCategory]::InvalidOperation,
                            $AuditObject.Name
                        )
                    )
                }

                Write-Debug -Message ($script:localizedData.Audit_RecreatingAuditForGuidChange -f $AuditObject.Name, $AuditObject.Parent.InstanceName, $AuditGuid)

                # Convert audit properties to parameters for New-SqlDscAudit
                $newAuditParameters = ConvertTo-AuditNewParameterSet -AuditObject $AuditObject -AuditGuid $AuditGuid

                # Drop the existing audit using Remove-SqlDscAudit
                # Use -Confirm:$false since we're already in a confirmed ShouldProcess context
                $AuditObject | Remove-SqlDscAudit -Confirm:$false

                # Create new audit with the same properties using New-SqlDscAudit
                # Use -Confirm:$false and -PassThru since we're already in a confirmed context and need the object
                $AuditObject = New-SqlDscAudit @newAuditParameters -Confirm:$false -PassThru

                # Remove parameters that should not be passed to recursive call
                $null = $PSBoundParameters.Remove('AuditGuid')
                $null = $PSBoundParameters.Remove('AllowAuditGuidChange')
                $null = $PSBoundParameters.Remove('ServerObject')
                $null = $PSBoundParameters.Remove('Name')
                $null = $PSBoundParameters.Remove('Force')
                $null = $PSBoundParameters.Remove('Refresh')
                $null = $PSBoundParameters.Remove('PassThru')

                # Remove common parameters and get the resulting hashtable
                $remainingParameters = Remove-CommonParameter -Hashtable $PSBoundParameters

                # If there are other property-changing parameters to apply, recursively call Set-SqlDscAudit
                if ($remainingParameters.Count -gt 0)
                {
                    # Add the new AuditObject parameter
                    $remainingParameters['AuditObject'] = $AuditObject

                    # Recursively call to apply remaining changes
                    $AuditObject = Set-SqlDscAudit @remainingParameters -Confirm:$false -PassThru
                }
            }
            else
            {
                # No GUID change (or GUID is the same), proceed with normal property updates

                # Apply other parameter changes
                if ($PSBoundParameters.ContainsKey('Path'))
                {
                    $AuditObject.FilePath = $Path
                }

                if ($PSCmdlet.ParameterSetName -match 'WithSize')
                {
                    $queryMaximumFileSizeUnit = (
                        @{
                            Megabyte = 'MB'
                            Gigabyte = 'GB'
                            Terabyte = 'TB'
                        }
                    ).$MaximumFileSizeUnit

                    $AuditObject.MaximumFileSize = $MaximumFileSize
                    $AuditObject.MaximumFileSizeUnit = $queryMaximumFileSizeUnit
                }

                if ($PSCmdlet.ParameterSetName -match 'MaxFiles')
                {
                    if ($AuditObject.MaximumRolloverFiles)
                    {
                        # Switching to MaximumFiles instead of MaximumRolloverFiles.
                        $AuditObject.MaximumRolloverFiles = 0

                        # Must run method Alter() before setting MaximumFiles.
                        $AuditObject.Alter()
                    }

                    $AuditObject.MaximumFiles = $MaximumFiles

                    if ($PSBoundParameters.ContainsKey('ReserveDiskSpace'))
                    {
                        $AuditObject.ReserveDiskSpace = $ReserveDiskSpace.IsPresent
                    }
                }

                if ($PSCmdlet.ParameterSetName -match 'MaxRolloverFiles')
                {
                    if ($AuditObject.MaximumFiles)
                    {
                        # Switching to MaximumRolloverFiles instead of MaximumFiles.
                        $AuditObject.MaximumFiles = 0

                        # Must run method Alter() before setting MaximumRolloverFiles.
                        $AuditObject.Alter()
                    }

                    $AuditObject.MaximumRolloverFiles = $MaximumRolloverFiles
                }

                if ($PSBoundParameters.ContainsKey('OnFailure'))
                {
                    $AuditObject.OnFailure = $OnFailure
                }

                if ($PSBoundParameters.ContainsKey('QueueDelay'))
                {
                    $AuditObject.QueueDelay = $QueueDelay
                }

                if ($PSBoundParameters.ContainsKey('AuditFilter'))
                {
                    $AuditObject.Filter = $AuditFilter
                }

                $AuditObject.Alter()
            }

            if ($PassThru.IsPresent)
            {
                return $AuditObject
            }
        }
    }
}
#EndRegion '.\Public\Set-SqlDscAudit.ps1' 433
#Region '.\Public\Set-SqlDscConfigurationOption.ps1' -1

<#
    .SYNOPSIS
        Set server configuration option value.

    .DESCRIPTION
        This command sets the value of a SQL Server Database Engine configuration option
        using SQL Server Management Objects (SMO). The function validates that the option
        exists and that the provided value is within the option's minimum and maximum range.

    .PARAMETER ServerObject
        Specifies current server connection object.

    .PARAMETER Name
        Specifies the name of the configuration option to set.

    .PARAMETER Value
        Specifies the value to set for the configuration option.

    .PARAMETER Force
        Suppresses prompts and overrides restrictions that would normally prevent the command from completing.
        When specified, the command will not prompt for confirmation before making changes.

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine -InstanceName 'MyInstance'
        $serverObject | Set-SqlDscConfigurationOption -Name "Agent XPs" -Value 1

        Sets the "Agent XPs" configuration option to enabled (1).

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine -InstanceName 'MyInstance'
        Set-SqlDscConfigurationOption -ServerObject $serverObject -Name "cost threshold for parallelism" -Value 50

        Sets the "cost threshold for parallelism" configuration option to 50.

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine -InstanceName 'MyInstance'
        $serverObject | Set-SqlDscConfigurationOption -Name "max degree of parallelism" -Value 4 -WhatIf

        Shows what would happen if the "max degree of parallelism" option was set to 4, without actually making the change.

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine -InstanceName 'MyInstance'
        $serverObject | Set-SqlDscConfigurationOption -Name "cost threshold for parallelism" -Value 25 -Force

        Sets the "cost threshold for parallelism" configuration option to 25 without prompting for confirmation.

    .INPUTS
        Microsoft.SqlServer.Management.Smo.Server
        SQL Server Management Objects (SMO) Server object representing a SQL Server instance.

    .OUTPUTS
        None.

    .NOTES
        This function supports ShouldProcess, allowing the use of -WhatIf and -Confirm parameters.
#>
function Set-SqlDscConfigurationOption
{
    [System.Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSReviewUnusedParameter', '', Justification = 'Because we pass parameters in the argument completer that are not yet used.')]
    [System.Diagnostics.CodeAnalysis.SuppressMessageAttribute('UseSyntacticallyCorrectExamples', '', Justification = 'Because the rule does not yet support parsing the code when a parameter type is not available. The ScriptAnalyzer rule UseSyntacticallyCorrectExamples will always error in the editor due to https://github.com/indented-automation/Indented.ScriptAnalyzerRules/issues/8.')]
    [OutputType()]
    [CmdletBinding(SupportsShouldProcess = $true, ConfirmImpact = 'High')]
    param
    (
        [Parameter(Mandatory = $true, ValueFromPipeline = $true)]
        [Microsoft.SqlServer.Management.Smo.Server]
        $ServerObject,

        [Parameter(Mandatory = $true)]
        [ArgumentCompleter({
                param
                (
                    [Parameter()]
                    $commandName,

                    [Parameter()]
                    $parameterName,

                    [Parameter()]
                    $wordToComplete,

                    [Parameter()]
                    $commandAst,

                    [Parameter()]
                    $fakeBoundParameters
                )

                # Get ServerObject from bound parameters only
                $serverObject = $null

                if ($FakeBoundParameters.ContainsKey('ServerObject'))
                {
                    $serverObject = $FakeBoundParameters['ServerObject']
                }

                if ($serverObject -and $serverObject -is [Microsoft.SqlServer.Management.Smo.Server])
                {
                    try
                    {
                        $options = $serverObject.Configuration.Properties | Where-Object {
                            $_.DisplayName -like "*$WordToComplete*"
                        } | Sort-Object DisplayName

                        foreach ($option in $options)
                        {
                            $tooltip = "Current: $($option.ConfigValue), Run: $($option.RunValue), Range: $($option.Minimum)-$($option.Maximum)"
                            [System.Management.Automation.CompletionResult]::new(
                                "'$($option.DisplayName)'",
                                $option.DisplayName,
                                'ParameterValue',
                                $tooltip
                            )
                        }
                    }
                    catch
                    {
                        # Return empty if there's an error accessing the server
                        @()
                    }
                }
                else
                {
                    # Return empty array if no server object available
                    @()
                }
            })]
        [System.String]
        $Name,

        [Parameter(Mandatory = $true)]
        [ArgumentCompleter({
                param
                (
                    [Parameter()]
                    $commandName,

                    [Parameter()]
                    $parameterName,

                    [Parameter()]
                    $wordToComplete,

                    [Parameter()]
                    $commandAst,

                    [Parameter()]
                    $fakeBoundParameters
                )

                # Get ServerObject and Name from bound parameters
                $serverObject = $null
                $optionName = $null

                if ($FakeBoundParameters.ContainsKey('ServerObject'))
                {
                    $serverObject = $FakeBoundParameters['ServerObject']
                }

                if ($FakeBoundParameters.ContainsKey('Name'))
                {
                    $optionName = $FakeBoundParameters['Name']
                }

                if ($serverObject -and $serverObject -is [Microsoft.SqlServer.Management.Smo.Server] -and $optionName)
                {
                    try
                    {
                        $option = $serverObject.Configuration.Properties | Where-Object {
                            $_.DisplayName -eq $optionName
                        }

                        if ($option)
                        {
                            $suggestions = @()

                            # Add current values
                            $suggestions += [PSCustomObject]@{
                                Value   = $option.ConfigValue
                                Tooltip = "Current ConfigValue: $($option.ConfigValue)"
                            }

                            $suggestions += [PSCustomObject]@{
                                Value   = $option.RunValue
                                Tooltip = "Current RunValue: $($option.RunValue)"
                            }

                            # Add min/max values
                            $suggestions += [PSCustomObject]@{
                                Value   = $option.Minimum
                                Tooltip = "Minimum allowed value: $($option.Minimum)"
                            }

                            $suggestions += [PSCustomObject]@{
                                Value   = $option.Maximum
                                Tooltip = "Maximum allowed value: $($option.Maximum)"
                            }

                            # If it's a boolean option (0-1), suggest both values
                            if ($option.Minimum -eq 0 -and $option.Maximum -eq 1)
                            {
                                $suggestions += [PSCustomObject]@{
                                    Value   = 0
                                    Tooltip = 'Disabled (0)'
                                }

                                $suggestions += [PSCustomObject]@{
                                    Value   = 1
                                    Tooltip = 'Enabled (1)'
                                }
                            }

                            # Remove duplicates and filter by word to complete
                            $uniqueSuggestions = $suggestions | Group-Object Value | ForEach-Object { $_.Group[0] }
                            $filteredSuggestions = $uniqueSuggestions | Where-Object {
                                $_.Value -like "*$WordToComplete*"
                            } | Sort-Object Value

                            foreach ($suggestion in $filteredSuggestions)
                            {
                                [System.Management.Automation.CompletionResult]::new(
                                    $suggestion.Value.ToString(),
                                    $suggestion.Value.ToString(),
                                    'ParameterValue',
                                    $suggestion.Tooltip
                                )
                            }
                        }
                    }
                    catch
                    {
                        # Return empty if there's an error
                        @()
                    }
                }
                else
                {
                    # Return empty array if prerequisites not met
                    @()
                }
            })]
        [System.Int32]
        $Value,

        [Parameter()]
        [System.Management.Automation.SwitchParameter]
        $Force
    )

    begin
    {
        if ($Force.IsPresent -and -not $Confirm)
        {
            $ConfirmPreference = 'None'
        }
    }

    process
    {
        # Find the configuration option by name
        $configurationOption = $ServerObject.Configuration.Properties |
            Where-Object {
                $_.DisplayName -eq $Name
            }

        if (-not $configurationOption)
        {
            $missingConfigurationOptionMessage = $script:localizedData.ConfigurationOption_Set_Missing -f $Name

            $writeErrorParameters = @{
                Message      = $missingConfigurationOptionMessage
                Category     = 'InvalidOperation'
                ErrorId      = 'SSDCO0001' # cspell: disable-line
                TargetObject = $Name
            }

            Write-Error @writeErrorParameters
            return
        }

        # Validate that the option value is within the allowed range
        if ($Value -lt $configurationOption.Minimum -or $Value -gt $configurationOption.Maximum)
        {
            $invalidValueMessage = $script:localizedData.ConfigurationOption_Set_InvalidValue -f $Name, $Value, $configurationOption.Minimum, $configurationOption.Maximum

            $writeErrorParameters = @{
                Message      = $invalidValueMessage
                Category     = 'InvalidArgument'
                ErrorId      = 'SSDCO0002' # cspell: disable-line
                TargetObject = $Value
            }

            Write-Error @writeErrorParameters
            return
        }

        # Prepare ShouldProcess messages
        $descriptionMessage = $script:localizedData.ConfigurationOption_Set_ShouldProcessDescription -f $Name, $Value, $ServerObject.Name
        $confirmationMessage = $script:localizedData.ConfigurationOption_Set_ShouldProcessConfirmation -f $Name, $Value
        $captionMessage = $script:localizedData.ConfigurationOption_Set_ShouldProcessCaption

        if ($PSCmdlet.ShouldProcess($descriptionMessage, $confirmationMessage, $captionMessage))
        {
            try
            {
                # Set the new configuration value
                $configurationOption.ConfigValue = $Value

                # Apply the configuration change
                $ServerObject.Configuration.Alter()

                Write-Information -MessageData ($script:localizedData.ConfigurationOption_Set_Success -f $Name, $Value, $ServerObject.Name)
            }
            catch
            {
                $setConfigurationOptionFailedMessage = $script:localizedData.ConfigurationOption_Set_Failed -f $Name, $Value, $_.Exception.Message

                $writeErrorParameters = @{
                    Message      = $setConfigurationOptionFailedMessage
                    Category     = 'InvalidOperation'
                    ErrorId      = 'SSDCO0003' # cspell: disable-line
                    TargetObject = $Name
                    Exception    = $_.Exception
                }

                Write-Error @writeErrorParameters
                return
            }
        }
    }
}
#EndRegion '.\Public\Set-SqlDscConfigurationOption.ps1' 332
#Region '.\Public\Set-SqlDscDatabaseDefault.ps1' -1

<#
    .SYNOPSIS
        Sets default objects of a database in a SQL Server Database Engine instance.

    .DESCRIPTION
        This command sets default objects of a database in a SQL Server Database Engine instance.
        It can set the default filegroup, default FILESTREAM filegroup, and default Full-Text catalog
        using SMO methods.

    .PARAMETER ServerObject
        Specifies current server connection object.

    .PARAMETER DatabaseObject
        Specifies a database object to modify.

    .PARAMETER Name
        Specifies the name of the database to be modified.

    .PARAMETER DefaultFileGroup
        Sets the default filegroup for the database. The filegroup must exist in the database.

    .PARAMETER DefaultFileStreamFileGroup
        Sets the default FILESTREAM filegroup for the database. The filegroup must exist in the database.

    .PARAMETER DefaultFullTextCatalog
        Sets the default Full-Text catalog for the database. The catalog must exist in the database.

    .PARAMETER Force
        Specifies that the database defaults should be modified without any confirmation.

    .PARAMETER Refresh
        Specifies that the **ServerObject**'s databases should be refreshed before
        modifying the database object. This is helpful when databases could have been
        modified outside of the **ServerObject**, for example through T-SQL. But
        on instances with a large amount of databases it might be better to make
        sure the **ServerObject** is recent enough, or pass in **DatabaseObject**.

    .PARAMETER PassThru
        Specifies that the database object should be returned after modification.

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine -InstanceName 'MyInstance'
        $databaseObject = $serverObject | Get-SqlDscDatabase -Name 'MyDatabase'
        $databaseObject | Set-SqlDscDatabaseDefault -DefaultFileGroup 'MyFileGroup'

        Sets the default filegroup of the database named **MyDatabase** to **MyFileGroup**.

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine -InstanceName 'MyInstance'
        $serverObject | Set-SqlDscDatabaseDefault -Name 'MyDatabase' -DefaultFullTextCatalog 'MyCatalog' -Force

        Sets the default Full-Text catalog of the database named **MyDatabase** to **MyCatalog** without prompting for confirmation.

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine -InstanceName 'MyInstance'
        $databaseObject = $serverObject | Get-SqlDscDatabase -Name 'MyDatabase'
        $databaseObject | Set-SqlDscDatabaseDefault -DefaultFileGroup 'DataFileGroup' -DefaultFileStreamFileGroup 'FileStreamFileGroup' -DefaultFullTextCatalog 'FTCatalog'

        Sets multiple default objects for the database named **MyDatabase**.

    .INPUTS
        Microsoft.SqlServer.Management.Smo.Server
        Server object accepted from the pipeline (ServerObject parameter set).

        Microsoft.SqlServer.Management.Smo.Database
        Database object accepted from the pipeline (DatabaseObject parameter set).

    .OUTPUTS
        None. But when **PassThru** is specified the output is `[Microsoft.SqlServer.Management.Smo.Database]`.
#>
function Set-SqlDscDatabaseDefault
{
    [System.Diagnostics.CodeAnalysis.SuppressMessageAttribute('UseSyntacticallyCorrectExamples', '', Justification = 'Because the rule does not yet support parsing the code when a parameter type is not available. The ScriptAnalyzer rule UseSyntacticallyCorrectExamples will always error in the editor due to https://github.com/indented-automation/Indented.ScriptAnalyzerRules/issues/8.')]
    [OutputType([Microsoft.SqlServer.Management.Smo.Database])]
    [CmdletBinding(SupportsShouldProcess = $true, ConfirmImpact = 'Medium')]
    param
    (
        [Parameter(ParameterSetName = 'ServerObject', Mandatory = $true, ValueFromPipeline = $true)]
        [Microsoft.SqlServer.Management.Smo.Server]
        $ServerObject,

        [Parameter(ParameterSetName = 'DatabaseObject', Mandatory = $true, ValueFromPipeline = $true)]
        [Microsoft.SqlServer.Management.Smo.Database]
        $DatabaseObject,

        [Parameter(ParameterSetName = 'ServerObject', Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [System.String]
        $Name,

        [Parameter()]
        [ValidateNotNullOrEmpty()]
        [System.String]
        $DefaultFileGroup,

        [Parameter()]
        [ValidateNotNullOrEmpty()]
        [System.String]
        $DefaultFileStreamFileGroup,

        [Parameter()]
        [ValidateNotNullOrEmpty()]
        [System.String]
        $DefaultFullTextCatalog,

        [Parameter()]
        [System.Management.Automation.SwitchParameter]
        $Force,

        [Parameter(ParameterSetName = 'ServerObject')]
        [System.Management.Automation.SwitchParameter]
        $Refresh,

        [Parameter()]
        [System.Management.Automation.SwitchParameter]
        $PassThru
    )

    process
    {
        if ($PSCmdlet.ParameterSetName -eq 'ServerObject')
        {
            # Get the database object
            $previousErrorActionPreference = $ErrorActionPreference
            $ErrorActionPreference = 'Stop'

            $DatabaseObject = $ServerObject | Get-SqlDscDatabase -Name $Name -Refresh:$Refresh.IsPresent -ErrorAction 'Stop'

            $ErrorActionPreference = $previousErrorActionPreference
        }
        else
        {
            $Name = $DatabaseObject.Name
            $ServerObject = $DatabaseObject.Parent
        }

        Write-Verbose -Message ($script:localizedData.DatabaseDefault_Set -f $Name, $ServerObject.InstanceName)

        if ($Force.IsPresent -and -not $Confirm)
        {
            $ConfirmPreference = 'None'
        }

        try
        {
            $wasUpdate = $false

            if ($PSBoundParameters.ContainsKey('DefaultFileGroup'))
            {
                $descriptionMessage = $script:localizedData.DatabaseDefault_SetFileGroup_ShouldProcessVerboseDescription -f $Name, $DefaultFileGroup, $ServerObject.InstanceName
                $confirmationMessage = $script:localizedData.DatabaseDefault_SetFileGroup_ShouldProcessVerboseWarning -f $Name, $DefaultFileGroup
                $captionMessage = $script:localizedData.DatabaseDefault_SetFileGroup_ShouldProcessCaption

                if ($PSCmdlet.ShouldProcess($descriptionMessage, $confirmationMessage, $captionMessage))
                {
                    $DatabaseObject.SetDefaultFileGroup($DefaultFileGroup)
                    $wasUpdate = $true
                }
            }

            if ($PSBoundParameters.ContainsKey('DefaultFileStreamFileGroup'))
            {
                $descriptionMessage = $script:localizedData.DatabaseDefault_SetFileStreamFileGroup_ShouldProcessVerboseDescription -f $Name, $DefaultFileStreamFileGroup, $ServerObject.InstanceName
                $confirmationMessage = $script:localizedData.DatabaseDefault_SetFileStreamFileGroup_ShouldProcessVerboseWarning -f $Name, $DefaultFileStreamFileGroup
                $captionMessage = $script:localizedData.DatabaseDefault_SetFileStreamFileGroup_ShouldProcessCaption

                if ($PSCmdlet.ShouldProcess($descriptionMessage, $confirmationMessage, $captionMessage))
                {
                    $DatabaseObject.SetDefaultFileStreamFileGroup($DefaultFileStreamFileGroup)
                    $wasUpdate = $true
                }
            }

            if ($PSBoundParameters.ContainsKey('DefaultFullTextCatalog'))
            {
                $descriptionMessage = $script:localizedData.DatabaseDefault_SetFullTextCatalog_ShouldProcessVerboseDescription -f $Name, $DefaultFullTextCatalog, $ServerObject.InstanceName
                $confirmationMessage = $script:localizedData.DatabaseDefault_SetFullTextCatalog_ShouldProcessVerboseWarning -f $Name, $DefaultFullTextCatalog
                $captionMessage = $script:localizedData.DatabaseDefault_SetFullTextCatalog_ShouldProcessCaption

                if ($PSCmdlet.ShouldProcess($descriptionMessage, $confirmationMessage, $captionMessage))
                {
                    $DatabaseObject.SetDefaultFullTextCatalog($DefaultFullTextCatalog)
                    $wasUpdate = $true
                }
            }

            if ($wasUpdate)
            {
                Write-Verbose -Message ($script:localizedData.DatabaseDefault_Updated -f $Name)
            }

            if ($PassThru.IsPresent)
            {
                return $DatabaseObject
            }
        }
        catch
        {
            $errorMessage = $script:localizedData.DatabaseDefault_SetFailed -f $Name, $ServerObject.InstanceName

            $exception = [System.InvalidOperationException]::new($errorMessage, $_.Exception)

            $PSCmdlet.ThrowTerminatingError(
                [System.Management.Automation.ErrorRecord]::new(
                    $exception,
                    'SSDDD0003', # cSpell: disable-line
                    [System.Management.Automation.ErrorCategory]::InvalidOperation,
                    $Name
                )
            )
        }
    }
}
#EndRegion '.\Public\Set-SqlDscDatabaseDefault.ps1' 214
#Region '.\Public\Set-SqlDscDatabaseOwner.ps1' -1

<#
    .SYNOPSIS
        Sets the owner of a database in a SQL Server Database Engine instance.

    .DESCRIPTION
        This command sets the owner of a database in a SQL Server Database Engine instance.

        The owner must be a valid login on the SQL Server instance. The command uses
        the SetOwner() method on the SMO Database object to change the ownership.

    .PARAMETER ServerObject
        Specifies current server connection object.

    .PARAMETER Name
        Specifies the name of the database to modify.

    .PARAMETER DatabaseObject
        Specifies the database object to modify (from Get-SqlDscDatabase).

    .PARAMETER Refresh
        Specifies that the **ServerObject**'s databases should be refreshed before
        trying to get the database object. This is helpful when databases could have been
        modified outside of the **ServerObject**, for example through T-SQL. But
        on instances with a large amount of databases it might be better to make
        sure the **ServerObject** is recent enough.

        This parameter is only used when setting owner using **ServerObject** and
        **Name** parameters.

    .PARAMETER OwnerName
        Specifies the name of the login that should be the owner of the database.

    .PARAMETER DropExistingUser
        Specifies whether to drop any existing database users mapped to the specified
        login before changing the owner. This is required if a non-dbo user account
        already exists for the login being set as the new owner.

    .PARAMETER Force
        Specifies that the database owner should be modified without any confirmation.

    .PARAMETER PassThru
        Specifies that the database object should be returned after modification.

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine -InstanceName 'MyInstance'
        Set-SqlDscDatabaseOwner -ServerObject $serverObject -Name 'MyDatabase' -OwnerName 'sa'

        Sets the owner of the database named **MyDatabase** to **sa**.

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine -InstanceName 'MyInstance'
        Set-SqlDscDatabaseOwner -ServerObject $serverObject -Name 'MyDatabase' -OwnerName 'sa' -DropExistingUser

        Sets the owner of the database named **MyDatabase** to **sa**, dropping any existing
        user account mapped to the **sa** login before changing the owner.

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine -InstanceName 'MyInstance'
        $databaseObject = $serverObject | Get-SqlDscDatabase -Name 'MyDatabase'
        Set-SqlDscDatabaseOwner -DatabaseObject $databaseObject -OwnerName 'DOMAIN\SqlAdmin' -Force

        Sets the owner of the database using a database object without prompting for confirmation.

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine -InstanceName 'MyInstance'
        Set-SqlDscDatabaseOwner -ServerObject $serverObject -Name 'MyDatabase' -OwnerName 'sa' -PassThru

        Sets the owner and returns the updated database object.

    .INPUTS
        Microsoft.SqlServer.Management.Smo.Database

        The database object to modify (from Get-SqlDscDatabase).

    .OUTPUTS
        None.

        When PassThru is specified the output is [Microsoft.SqlServer.Management.Smo.Database].
#>
function Set-SqlDscDatabaseOwner
{
    [System.Diagnostics.CodeAnalysis.SuppressMessageAttribute('UseSyntacticallyCorrectExamples', '', Justification = 'Because the rule does not yet support parsing the code when a parameter type is not available. The ScriptAnalyzer rule UseSyntacticallyCorrectExamples will always error in the editor due to https://github.com/indented-automation/Indented.ScriptAnalyzerRules/issues.')]
    [OutputType()]
    [OutputType([Microsoft.SqlServer.Management.Smo.Database])]
    [CmdletBinding(DefaultParameterSetName = 'ServerObjectSet', SupportsShouldProcess = $true, ConfirmImpact = 'Medium')]
    param
    (
        [Parameter(ParameterSetName = 'ServerObjectSet', Mandatory = $true)]
        [Microsoft.SqlServer.Management.Smo.Server]
        $ServerObject,

        [Parameter(ParameterSetName = 'ServerObjectSet', Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [System.String]
        $Name,

        [Parameter(ParameterSetName = 'ServerObjectSet')]
        [System.Management.Automation.SwitchParameter]
        $Refresh,

        [Parameter(ParameterSetName = 'DatabaseObjectSet', Mandatory = $true, ValueFromPipeline = $true)]
        [Microsoft.SqlServer.Management.Smo.Database]
        $DatabaseObject,

        [Parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [System.String]
        $OwnerName,

        [Parameter()]
        [System.Management.Automation.SwitchParameter]
        $DropExistingUser,

        [Parameter()]
        [System.Management.Automation.SwitchParameter]
        $Force,

        [Parameter()]
        [System.Management.Automation.SwitchParameter]
        $PassThru
    )

    begin
    {
        if ($Force.IsPresent -and -not $Confirm)
        {
            $ConfirmPreference = 'None'
        }
    }

    process
    {
        # Get the database object based on the parameter set
        switch ($PSCmdlet.ParameterSetName)
        {
            'ServerObjectSet'
            {
                $previousErrorActionPreference = $ErrorActionPreference
                $ErrorActionPreference = 'Stop'

                $sqlDatabaseObject = $ServerObject |
                    Get-SqlDscDatabase -Name $Name -Refresh:$Refresh -ErrorAction 'Stop'

                $ErrorActionPreference = $previousErrorActionPreference
            }

            'DatabaseObjectSet'
            {
                $sqlDatabaseObject = $DatabaseObject
            }
        }

        $verboseDescriptionMessage = $script:localizedData.DatabaseOwner_Set_ShouldProcessVerboseDescription -f $sqlDatabaseObject.Name, $OwnerName, $sqlDatabaseObject.Parent.InstanceName
        $verboseWarningMessage = $script:localizedData.DatabaseOwner_Set_ShouldProcessVerboseWarning -f $sqlDatabaseObject.Name, $OwnerName
        $captionMessage = $script:localizedData.DatabaseOwner_Set_ShouldProcessCaption

        if ($PSCmdlet.ShouldProcess($verboseDescriptionMessage, $verboseWarningMessage, $captionMessage))
        {
            # Check if the owner is already correct (idempotence)
            if ($sqlDatabaseObject.Owner -eq $OwnerName)
            {
                Write-Debug -Message ($script:localizedData.DatabaseOwner_OwnerAlreadyCorrect -f $sqlDatabaseObject.Name, $OwnerName)
            }
            else
            {
                Write-Debug -Message ($script:localizedData.DatabaseOwner_Updating -f $sqlDatabaseObject.Name, $OwnerName)

                try
                {
                    if ($DropExistingUser.IsPresent)
                    {
                        $sqlDatabaseObject.SetOwner($OwnerName, $true)
                    }
                    else
                    {
                        $sqlDatabaseObject.SetOwner($OwnerName)
                    }
                }
                catch
                {
                    $errorMessage = $script:localizedData.DatabaseOwner_SetFailed -f $sqlDatabaseObject.Name, $OwnerName

                    $PSCmdlet.ThrowTerminatingError(
                        [System.Management.Automation.ErrorRecord]::new(
                            [System.InvalidOperationException]::new($errorMessage, $_.Exception),
                            'SSDDO0004', # cspell: disable-line
                            [System.Management.Automation.ErrorCategory]::InvalidOperation,
                            $sqlDatabaseObject
                        )
                    )
                }

                Write-Debug -Message ($script:localizedData.DatabaseOwner_Updated -f $sqlDatabaseObject.Name, $OwnerName)
            }

            <#
                Refresh the database object to get the updated owner property if:
                - PassThru is specified (user wants the updated object back)
                - Using DatabaseObject parameter set (user's object reference should be updated)

                Refresh even if no change was made to ensure the object is up to date.
            #>
            if ($PassThru.IsPresent -or $PSCmdlet.ParameterSetName -eq 'DatabaseObjectSet')
            {
                $sqlDatabaseObject.Refresh()
            }

            if ($PassThru.IsPresent)
            {
                return $sqlDatabaseObject
            }
        }
    }
}
#EndRegion '.\Public\Set-SqlDscDatabaseOwner.ps1' 215
#Region '.\Public\Set-SqlDscDatabasePermission.ps1' -1

<#
    .SYNOPSIS
        Set permission for a database principal.

    .DESCRIPTION
        Set permission for a database principal.

    .PARAMETER ServerObject
        Specifies current server connection object.

    .PARAMETER DatabaseName
        Specifies the database name.

    .PARAMETER Name
        Specifies the name of the database principal for which the permissions are
        set.

    .PARAMETER State
        Specifies the state of the permission.

    .PARAMETER Permission
        Specifies the permissions.

    .PARAMETER WithGrant
        Specifies that the principal should also be granted the right to grant
        other principals the same permission. This parameter is only valid when
        parameter **State** is set to `Grant` or `Revoke`. When the parameter
        **State** is set to `Revoke` the right to grant will also be revoked,
        and the revocation will cascade.

    .PARAMETER Force
        Specifies that the permissions should be set without any confirmation.

    .OUTPUTS
        None.

    .EXAMPLE
        $serverInstance = Connect-SqlDscDatabaseEngine

        $setPermission = [Microsoft.SqlServer.Management.Smo.DatabasePermissionSet] @{
            Connect = $true
            Update = $true
        }

        Set-SqlDscDatabasePermission -ServerObject $serverInstance -DatabaseName 'MyDatabase' -Name 'MyPrincipal' -State 'Grant' -Permission $setPermission

        Sets the permissions for the principal 'MyPrincipal'.

    .NOTES
        This command excludes fixed roles like _db_datareader_ by default, and will
        always throw a non-terminating error if a fixed role is specified as **Name**.

        If specifying `-ErrorAction 'SilentlyContinue'` then the command will silently
        ignore if the database (parameter **DatabaseName**) is not present or the
        database principal is not present. If specifying `-ErrorAction 'Stop'` the
        command will throw an error if the database or database principal is missing.
#>
function Set-SqlDscDatabasePermission
{
    [System.Diagnostics.CodeAnalysis.SuppressMessageAttribute('UseSyntacticallyCorrectExamples', '', Justification = 'Because the rule does not yet support parsing the code when a parameter type is not available. The ScriptAnalyzer rule UseSyntacticallyCorrectExamples will always error in the editor due to https://github.com/indented-automation/Indented.ScriptAnalyzerRules/issues/8.')]
    [System.Diagnostics.CodeAnalysis.SuppressMessageAttribute('AvoidThrowOutsideOfTry', '', Justification = 'Because the code throws based on an prior expression')]
    [CmdletBinding(SupportsShouldProcess = $true, ConfirmImpact = 'High')]
    [OutputType()]
    param
    (
        [Parameter(Mandatory = $true, ValueFromPipeline = $true)]
        [Microsoft.SqlServer.Management.Smo.Server]
        $ServerObject,

        [Parameter(Mandatory = $true)]
        [System.String]
        $DatabaseName,

        [Parameter(Mandatory = $true)]
        [System.String]
        $Name,

        [Parameter(Mandatory = $true)]
        [ValidateSet('Grant', 'Deny', 'Revoke')]
        [System.String]
        $State,

        [Parameter(Mandatory = $true)]
        [Microsoft.SqlServer.Management.Smo.DatabasePermissionSet]
        $Permission,

        [Parameter()]
        [System.Management.Automation.SwitchParameter]
        $WithGrant,

        [Parameter()]
        [System.Management.Automation.SwitchParameter]
        $Force
    )

    process
    {
        if ($State -eq 'Deny' -and $WithGrant.IsPresent)
        {
            Write-Warning -Message $script:localizedData.DatabasePermission_IgnoreWithGrantForStateDeny
        }

        if ($Force.IsPresent -and -not $Confirm)
        {
            $ConfirmPreference = 'None'
        }

        $sqlDatabaseObject = $null

        if ($ServerObject.Databases)
        {
            $sqlDatabaseObject = $ServerObject.Databases[$DatabaseName]
        }

        if ($sqlDatabaseObject)
        {
            $testSqlDscIsDatabasePrincipalParameters = @{
                ServerObject      = $ServerObject
                DatabaseName      = $DatabaseName
                Name              = $Name
                ExcludeFixedRoles = $true
            }

            $isDatabasePrincipal = Test-SqlDscIsDatabasePrincipal @testSqlDscIsDatabasePrincipalParameters

            if ($isDatabasePrincipal)
            {
                # Get the permissions names that are set to $true in the DatabasePermissionSet.
                $permissionName = $Permission |
                    Get-Member -MemberType 'Property' |
                    Select-Object -ExpandProperty 'Name' |
                    Where-Object -FilterScript {
                        $Permission.$_
                    }

                $verboseDescriptionMessage = $script:localizedData.DatabasePermission_ChangePermissionShouldProcessVerboseDescription -f $Name, $DatabaseName, $ServerObject.InstanceName
                $verboseWarningMessage = $script:localizedData.DatabasePermission_ChangePermissionShouldProcessVerboseWarning -f $Name
                $captionMessage = $script:localizedData.DatabasePermission_ChangePermissionShouldProcessCaption

                if (-not $PSCmdlet.ShouldProcess($verboseDescriptionMessage, $verboseWarningMessage, $captionMessage))
                {
                    # Return without doing anything if the user did not want to continue processing.
                    return
                }

                switch ($State)
                {
                    'Grant'
                    {
                        Write-Verbose -Message (
                            $script:localizedData.DatabasePermission_GrantPermission -f ($permissionName -join ','), $Name
                        )

                        if ($WithGrant.IsPresent)
                        {
                            $sqlDatabaseObject.Grant($Permission, $Name, $true)
                        }
                        else
                        {
                            $sqlDatabaseObject.Grant($Permission, $Name)
                        }
                    }

                    'Deny'
                    {
                        Write-Verbose -Message (
                            $script:localizedData.DatabasePermission_DenyPermission -f ($permissionName -join ','), $Name
                        )

                        $sqlDatabaseObject.Deny($Permission, $Name)
                    }

                    'Revoke'
                    {
                        Write-Verbose -Message (
                            $script:localizedData.DatabasePermission_RevokePermission -f ($permissionName -join ','), $Name
                        )

                        if ($WithGrant.IsPresent)
                        {
                            $sqlDatabaseObject.Revoke($Permission, $Name, $false, $true)
                        }
                        else
                        {
                            $sqlDatabaseObject.Revoke($Permission, $Name)
                        }
                    }
                }
            }
            else
            {
                $missingPrincipalMessage = $script:localizedData.DatabasePermission_MissingPrincipal -f $Name, $DatabaseName

                $PSCmdlet.ThrowTerminatingError(
                    [System.Management.Automation.ErrorRecord]::new(
                        $missingPrincipalMessage,
                        'GSDDP0001', # cSpell: disable-line
                        [System.Management.Automation.ErrorCategory]::InvalidOperation,
                        $Name
                    )
                )
            }
        }
        else
        {
            $missingDatabaseMessage = $script:localizedData.DatabasePermission_MissingDatabase -f $DatabaseName

            $PSCmdlet.ThrowTerminatingError(
                [System.Management.Automation.ErrorRecord]::new(
                    $missingDatabaseMessage,
                    'GSDDP0002', # cSpell: disable-line
                    [System.Management.Automation.ErrorCategory]::InvalidOperation,
                    $DatabaseName
                )
            )
        }
    }
}
#EndRegion '.\Public\Set-SqlDscDatabasePermission.ps1' 219
#Region '.\Public\Set-SqlDscDatabaseProperty.ps1' -1

<#
    .SYNOPSIS
        Sets properties of a database in a SQL Server Database Engine instance.

    .DESCRIPTION
        This command sets properties of a database in a SQL Server Database Engine instance.

        The command supports a comprehensive set of settable database properties including
        configuration settings, security properties, performance settings, and state
        information. Users can set one or multiple properties in a single command execution.

        All properties correspond directly to Microsoft SQL Server Management Objects (SMO)
        Database class properties and support the same data types and values as the
        underlying SMO implementation.

    .PARAMETER ServerObject
        Specifies current server connection object.

    .PARAMETER Name
        Specifies the name of the database to modify.

    .PARAMETER DatabaseObject
        Specifies the database object to modify (from Get-SqlDscDatabase).

    .PARAMETER Refresh
        Specifies that the **ServerObject**'s databases should be refreshed before
        trying to get the database object. This is helpful when databases could have been
        modified outside of the **ServerObject**, for example through T-SQL. But
        on instances with a large amount of databases it might be better to make
        sure the **ServerObject** is recent enough.

        This parameter is only used when setting properties using **ServerObject** and
        **Name** parameters.

    .PARAMETER Collation
        Specifies the default collation for the database.

    .PARAMETER RecoveryModel
        Specifies the database recovery model (FULL, BULK_LOGGED, SIMPLE).

    .PARAMETER CompatibilityLevel
        Specifies the database compatibility level (affects query processor behavior and features).

    .PARAMETER AcceleratedRecoveryEnabled
        Specifies whether Accelerated Database Recovery (ADR) is enabled for the database.

    .PARAMETER AnsiNullDefault
        Specifies whether new columns allow NULL by default unless explicitly specified (when ON).

    .PARAMETER AnsiNullsEnabled
        Specifies whether comparisons to NULL follow ANSI SQL behavior (when ON, x = NULL yields UNKNOWN).

    .PARAMETER AnsiPaddingEnabled
        Specifies whether padding for variable-length columns (e.g., CHAR/VARCHAR) follows ANSI rules.

    .PARAMETER AnsiWarningsEnabled
        Specifies whether ANSI warnings are generated for certain conditions (when ON, e.g., divide by zero).

    .PARAMETER ArithmeticAbortEnabled
        Specifies whether a query is terminated when an overflow or divide-by-zero error occurs.

    .PARAMETER AutoClose
        Specifies whether the database closes after the last user exits.

    .PARAMETER AutoCreateIncrementalStatisticsEnabled
        Specifies whether creation of incremental statistics on partitioned tables is allowed.

    .PARAMETER AutoCreateStatisticsEnabled
        Specifies whether single-column statistics are automatically created for query optimization.

    .PARAMETER AutoShrink
        Specifies whether the database automatically shrinks files when free space is detected.

    .PARAMETER AutoUpdateStatisticsAsync
        Specifies whether statistics are updated asynchronously, allowing queries to proceed with old stats.

    .PARAMETER AutoUpdateStatisticsEnabled
        Specifies whether statistics are automatically updated when they are out-of-date.

    .PARAMETER BrokerEnabled
        Specifies whether Service Broker is enabled for the database.

    .PARAMETER ChangeTrackingAutoCleanUp
        Specifies whether automatic cleanup of change tracking information is enabled.

    .PARAMETER ChangeTrackingEnabled
        Specifies whether change tracking is enabled for the database.

    .PARAMETER ChangeTrackingRetentionPeriod
        Specifies the retention period value for change tracking information.

    .PARAMETER ChangeTrackingRetentionPeriodUnits
        Specifies the units for the retention period (e.g., DAYS, HOURS).

    .PARAMETER CloseCursorsOnCommitEnabled
        Specifies whether open cursors are closed when a transaction is committed.

    .PARAMETER ConcatenateNullYieldsNull
        Specifies whether concatenation with NULL results in NULL (when ON).

    .PARAMETER ContainmentType
        Specifies the containment level of the database (NONE or PARTIAL).

    .PARAMETER DatabaseOwnershipChaining
        Specifies whether ownership chaining across objects within the database is enabled.

    .PARAMETER DataRetentionEnabled
        Specifies whether SQL Server data retention policy is enabled at the database level.

    .PARAMETER DateCorrelationOptimization
        Specifies whether date correlation optimization is enabled to speed up temporal joins.

    .PARAMETER DefaultFullTextLanguage
        Specifies the LCID of the default full-text language.

    .PARAMETER DefaultLanguage
        Specifies the ID of the default language for the database.


    .PARAMETER DelayedDurability
        Specifies the delayed durability setting for the database (DISABLED, ALLOWED, FORCED).

    .PARAMETER EncryptionEnabled
        Specifies whether Transparent Data Encryption (TDE) is enabled.

    .PARAMETER FilestreamDirectoryName
        Specifies the directory name used for FILESTREAM data.

    .PARAMETER FilestreamNonTransactedAccess
        Specifies the FILESTREAM access level for non-transactional access.

    .PARAMETER HonorBrokerPriority
        Specifies whether honoring Service Broker conversation priority is enabled.

    .PARAMETER IsFullTextEnabled
        Specifies whether full-text search is enabled.

    .PARAMETER IsParameterizationForced
        Specifies whether forced parameterization is enabled for the database.

    .PARAMETER IsReadCommittedSnapshotOn
        Specifies whether READ_COMMITTED_SNAPSHOT isolation is ON.

    .PARAMETER IsSqlDw
        Specifies whether the database is a SQL Data Warehouse database.

    .PARAMETER IsVarDecimalStorageFormatEnabled
        Specifies whether vardecimal compression is enabled.

    .PARAMETER LegacyCardinalityEstimation
        Specifies whether the legacy cardinality estimator is enabled for the primary.

    .PARAMETER LegacyCardinalityEstimationForSecondary
        Specifies whether the legacy cardinality estimator is enabled for secondary replicas.

    .PARAMETER LocalCursorsDefault
        Specifies whether cursors are local by default instead of global (when ON).

    .PARAMETER MaxDop
        Specifies the MAXDOP database-scoped configuration for primary replicas.

    .PARAMETER MaxDopForSecondary
        Specifies the MAXDOP database-scoped configuration for secondary replicas.

    .PARAMETER MaxSizeInBytes
        Specifies the maximum size of the database in bytes.

    .PARAMETER MirroringPartner
        Specifies the mirroring partner server name (if configured).

    .PARAMETER MirroringPartnerInstance
        Specifies the mirroring partner instance name (if configured).

    .PARAMETER MirroringRedoQueueMaxSize
        Specifies the redo queue maximum size for mirroring/AGs.

    .PARAMETER MirroringSafetyLevel
        Specifies the mirroring safety level (FULL/Off/HighPerformance).

    .PARAMETER MirroringTimeout
        Specifies the timeout in seconds for mirroring sessions.

    .PARAMETER MirroringWitness
        Specifies the mirroring witness server (if used).

    .PARAMETER NestedTriggersEnabled
        Specifies whether triggers are allowed to fire other triggers (nested triggers).

    .PARAMETER NumericRoundAbortEnabled
        Specifies whether an error is raised on loss of precision due to rounding (when ON).

    .PARAMETER PageVerify
        Specifies the page verification setting (NONE, TORN_PAGE_DETECTION, CHECKSUM).

    .PARAMETER ParameterSniffing
        Specifies whether parameter sniffing behavior is enabled on the primary.

    .PARAMETER ParameterSniffingForSecondary
        Specifies whether parameter sniffing is enabled on secondary replicas.

    .PARAMETER PersistentVersionStoreFileGroup
        Specifies the filegroup used for the Persistent Version Store (PVS).

    .PARAMETER PrimaryFilePath
        Specifies the path of the primary data files directory.

    .PARAMETER QueryOptimizerHotfixes
        Specifies whether query optimizer hotfixes are enabled on the primary.

    .PARAMETER QueryOptimizerHotfixesForSecondary
        Specifies whether query optimizer hotfixes are enabled on secondary replicas.

    .PARAMETER QuotedIdentifiersEnabled
        Specifies whether identifiers can be delimited by double quotes (when ON).

    .PARAMETER ReadOnly
        Specifies whether the database is in read-only mode.

    .PARAMETER RecursiveTriggersEnabled
        Specifies whether a trigger is allowed to fire itself recursively.

    .PARAMETER RemoteDataArchiveCredential
        Specifies the credential name for Stretch Database/remote data archive.

    .PARAMETER RemoteDataArchiveEnabled
        Specifies whether Stretch Database (remote data archive) is enabled.

    .PARAMETER RemoteDataArchiveEndpoint
        Specifies the endpoint URL for remote data archive.

    .PARAMETER RemoteDataArchiveLinkedServer
        Specifies the linked server used by remote data archive.

    .PARAMETER RemoteDataArchiveUseFederatedServiceAccount
        Specifies whether to use federated service account for remote data archive.

    .PARAMETER RemoteDatabaseName
        Specifies the remote database name for remote data archive.

    .PARAMETER TargetRecoveryTime
        Specifies the target recovery time (seconds) for indirect checkpointing.

    .PARAMETER TemporalHistoryRetentionEnabled
        Specifies whether automatic cleanup of system-versioned temporal history is enabled.

    .PARAMETER TransformNoiseWords
        Specifies how full-text noise word behavior is controlled during queries.

    .PARAMETER Trustworthy
        Specifies whether implicit access to external resources by modules is allowed (use with caution).

    .PARAMETER TwoDigitYearCutoff
        Specifies the two-digit year cutoff used for date conversion.

    .PARAMETER UserAccess
        Specifies the database user access mode (MULTI_USER, RESTRICTED_USER, SINGLE_USER).

    .PARAMETER Force
        Specifies that the database should be modified without any confirmation.

    .PARAMETER PassThru
        Specifies that the database object should be returned after modification.

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine -InstanceName 'MyInstance'
        Set-SqlDscDatabaseProperty -ServerObject $serverObject -Name 'MyDatabase' -RecoveryModel 'Simple'

        Sets the recovery model of the database named **MyDatabase** to **Simple**.

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine -InstanceName 'MyInstance'
        $databaseObject = $serverObject | Get-SqlDscDatabase -Name 'MyDatabase'
        Set-SqlDscDatabaseProperty -DatabaseObject $databaseObject -ReadOnly $false -AutoClose $false

        Sets multiple database properties at once using a database object.

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine -InstanceName 'MyInstance'
        Set-SqlDscDatabaseProperty -ServerObject $serverObject -Name 'MyDatabase' -CompatibilityLevel 'Version160' -Trustworthy $false -Force

        Sets the compatibility level and trustworthy property of the database without prompting for confirmation.

    .INPUTS
        `[Microsoft.SqlServer.Management.Smo.Database]`

        The database object to modify (from Get-SqlDscDatabase).

    .OUTPUTS
        None.

        When PassThru is not specified, no output is returned.

    .OUTPUTS
        Microsoft.SqlServer.Management.Smo.Database

        When PassThru is specified, returns the updated database object.

    .NOTES
        The following database properties are read-only after creation and cannot be modified
        using this command:

        - **CatalogCollation**: The catalog-level collation used for metadata and temporary
          objects. This property is marked as ReadOnlyAfterCreation in the SMO Database
          class and can only be set during database creation (e.g., using `New-SqlDscDatabase`
          or CREATE DATABASE statements).

        - **DatabaseSnapshotBaseName**: The base name of the source database for a database
          snapshot. This property is marked as ReadOnlyAfterCreation in the SMO Database
          class. To create database snapshots, use the `New-SqlDscDatabaseSnapshot` or
          `New-SqlDscDatabase` command with the `-DatabaseSnapshotBaseName` parameter.

        - **IsLedger**: Specifies whether the database is a ledger database. Ledger
          status can only be set during database creation using the `New-SqlDscDatabase`
          command with the `-IsLedger` parameter. Once a database is created, its ledger
          status cannot be changed.

        There are some database properties that require method calls instead of direct
        property assignment and will be supported through separate commands, e.g.
        `Set-SqlDscDatabaseDefaultFileGroup`.

        Azure SQL Database service tier and service objective changes should be managed
        using Azure management cmdlets (e.g., `Set-AzSqlDatabase` with `-Edition` and
        `-RequestedServiceObjectiveName` parameters) rather than through SMO.
#>
function Set-SqlDscDatabaseProperty
{
    [System.Diagnostics.CodeAnalysis.SuppressMessageAttribute('UseSyntacticallyCorrectExamples', '', Justification = 'Because the rule does not yet support parsing the code when a parameter type is not available. The ScriptAnalyzer rule UseSyntacticallyCorrectExamples will always error in the editor due to https://github.com/indented-automation/Indented.ScriptAnalyzerRules/issues.')]
    [System.Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingPlainTextForPassword', '', Justification = 'This is not a password but a credential name reference.')]
    [OutputType()]
    [OutputType([Microsoft.SqlServer.Management.Smo.Database])]
    [CmdletBinding(DefaultParameterSetName = 'ServerObjectSet', SupportsShouldProcess = $true, ConfirmImpact = 'Medium')]
    param
    (
        [Parameter(ParameterSetName = 'ServerObjectSet', Mandatory = $true)]
        [Microsoft.SqlServer.Management.Smo.Server]
        $ServerObject,

        [Parameter(ParameterSetName = 'ServerObjectSet', Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [System.String]
        $Name,

        [Parameter(ParameterSetName = 'ServerObjectSet')]
        [System.Management.Automation.SwitchParameter]
        $Refresh,

        [Parameter(ParameterSetName = 'DatabaseObjectSet', Mandatory = $true, ValueFromPipeline = $true)]
        [Microsoft.SqlServer.Management.Smo.Database]
        $DatabaseObject,

        # Boolean Properties
        [Parameter()]
        [System.Boolean]
        $AcceleratedRecoveryEnabled,

        [Parameter()]
        [System.Boolean]
        $AnsiNullDefault,

        [Parameter()]
        [System.Boolean]
        $AnsiNullsEnabled,

        [Parameter()]
        [System.Boolean]
        $AnsiPaddingEnabled,

        [Parameter()]
        [System.Boolean]
        $AnsiWarningsEnabled,

        [Parameter()]
        [System.Boolean]
        $ArithmeticAbortEnabled,

        [Parameter()]
        [System.Boolean]
        $AutoClose,

        [Parameter()]
        [System.Boolean]
        $AutoCreateIncrementalStatisticsEnabled,

        [Parameter()]
        [System.Boolean]
        $AutoCreateStatisticsEnabled,

        [Parameter()]
        [System.Boolean]
        $AutoShrink,

        [Parameter()]
        [System.Boolean]
        $AutoUpdateStatisticsAsync,

        [Parameter()]
        [System.Boolean]
        $AutoUpdateStatisticsEnabled,

        [Parameter()]
        [System.Boolean]
        $BrokerEnabled,

        [Parameter()]
        [System.Boolean]
        $ChangeTrackingAutoCleanUp,

        [Parameter()]
        [System.Boolean]
        $ChangeTrackingEnabled,

        [Parameter()]
        [System.Boolean]
        $CloseCursorsOnCommitEnabled,

        [Parameter()]
        [System.Boolean]
        $ConcatenateNullYieldsNull,

        [Parameter()]
        [System.Boolean]
        $DatabaseOwnershipChaining,

        [Parameter()]
        [System.Boolean]
        $DataRetentionEnabled,

        [Parameter()]
        [System.Boolean]
        $DateCorrelationOptimization,

        [Parameter()]
        [System.Boolean]
        $EncryptionEnabled,

        [Parameter()]
        [System.Boolean]
        $HonorBrokerPriority,

        [Parameter()]
        [System.Boolean]
        $IsFullTextEnabled,

        [Parameter()]
        [System.Boolean]
        $IsParameterizationForced,

        [Parameter()]
        [System.Boolean]
        $IsReadCommittedSnapshotOn,

        [Parameter()]
        [System.Boolean]
        $IsSqlDw,

        [Parameter()]
        [System.Boolean]
        $IsVarDecimalStorageFormatEnabled,

        [Parameter()]
        [System.Boolean]
        $LegacyCardinalityEstimation,

        [Parameter()]
        [System.Boolean]
        $LegacyCardinalityEstimationForSecondary,

        [Parameter()]
        [System.Boolean]
        $LocalCursorsDefault,

        [Parameter()]
        [System.Boolean]
        $NestedTriggersEnabled,

        [Parameter()]
        [System.Boolean]
        $NumericRoundAbortEnabled,

        [Parameter()]
        [System.Boolean]
        $ParameterSniffing,

        [Parameter()]
        [System.Boolean]
        $ParameterSniffingForSecondary,

        [Parameter()]
        [System.Boolean]
        $QueryOptimizerHotfixes,

        [Parameter()]
        [System.Boolean]
        $QueryOptimizerHotfixesForSecondary,

        [Parameter()]
        [System.Boolean]
        $QuotedIdentifiersEnabled,

        [Parameter()]
        [System.Boolean]
        $ReadOnly,

        [Parameter()]
        [System.Boolean]
        $RecursiveTriggersEnabled,

        [Parameter()]
        [System.Boolean]
        $RemoteDataArchiveEnabled,

        [Parameter()]
        [System.Boolean]
        $RemoteDataArchiveUseFederatedServiceAccount,

        [Parameter()]
        [System.Boolean]
        $TemporalHistoryRetentionEnabled,

        [Parameter()]
        [System.Boolean]
        $TransformNoiseWords,

        [Parameter()]
        [System.Boolean]
        $Trustworthy,

        # Integer Properties
        [Parameter()]
        [System.Int32]
        $ChangeTrackingRetentionPeriod,

        [Parameter()]
        [System.Int32]
        $DefaultFullTextLanguage,

        [Parameter()]
        [System.Int32]
        $DefaultLanguage,

        [Parameter()]
        [System.Int32]
        $MaxDop,

        [Parameter()]
        [System.Int32]
        $MaxDopForSecondary,

        [Parameter()]
        [System.Int32]
        $MirroringRedoQueueMaxSize,

        [Parameter()]
        [System.Int32]
        $MirroringTimeout,

        [Parameter()]
        [System.Int32]
        $TargetRecoveryTime,

        [Parameter()]
        [System.Int32]
        $TwoDigitYearCutoff,

        # Long Integer Properties
        [Parameter()]
        [System.Double]
        $MaxSizeInBytes,

        # String Properties
        [Parameter()]
        [ValidateNotNullOrEmpty()]
        [System.String]
        $Collation,

        [Parameter()]
        [System.String]
        $FilestreamDirectoryName,

        [Parameter()]
        [System.String]
        $MirroringPartner,

        [Parameter()]
        [System.String]
        $MirroringPartnerInstance,

        [Parameter()]
        [System.String]
        $MirroringWitness,

        [Parameter()]
        [System.String]
        $PersistentVersionStoreFileGroup,

        [Parameter()]
        [System.String]
        $PrimaryFilePath,

        [Parameter()]
        [System.String]
        $RemoteDataArchiveCredential,

        [Parameter()]
        [System.String]
        $RemoteDataArchiveEndpoint,

        [Parameter()]
        [System.String]
        $RemoteDataArchiveLinkedServer,

        [Parameter()]
        [System.String]
        $RemoteDatabaseName,

        # Enum Properties
        [Parameter()]
        [Microsoft.SqlServer.Management.Smo.RetentionPeriodUnits]
        $ChangeTrackingRetentionPeriodUnits,

        [Parameter()]
        [Microsoft.SqlServer.Management.Smo.CompatibilityLevel]
        $CompatibilityLevel,

        [Parameter()]
        [Microsoft.SqlServer.Management.Smo.ContainmentType]
        $ContainmentType,

        [Parameter()]
        [Microsoft.SqlServer.Management.Smo.DelayedDurability]
        $DelayedDurability,

        [Parameter()]
        [Microsoft.SqlServer.Management.Smo.FilestreamNonTransactedAccessType]
        $FilestreamNonTransactedAccess,

        [Parameter()]
        [Microsoft.SqlServer.Management.Smo.MirroringSafetyLevel]
        $MirroringSafetyLevel,

        [Parameter()]
        [Microsoft.SqlServer.Management.Smo.PageVerify]
        $PageVerify,

        [Parameter()]
        [Microsoft.SqlServer.Management.Smo.RecoveryModel]
        $RecoveryModel,

        [Parameter()]
        [Microsoft.SqlServer.Management.Smo.DatabaseUserAccess]
        $UserAccess,

        # Control Parameters
        [Parameter()]
        [System.Management.Automation.SwitchParameter]
        $Force,

        [Parameter()]
        [System.Management.Automation.SwitchParameter]
        $PassThru
    )

    begin
    {
        if ($Force.IsPresent -and -not $Confirm)
        {
            $ConfirmPreference = 'None'
        }

        # Get the server object based on parameter set
        $serverInstance = if ($PSCmdlet.ParameterSetName -eq 'DatabaseObjectSet')
        {
            $DatabaseObject.Parent
        }
        else
        {
            $ServerObject
        }

        # Validate compatibility level if specified
        if ($PSBoundParameters.ContainsKey('CompatibilityLevel'))
        {
            $supportedCompatibilityLevels = $serverInstance | Get-SqlDscCompatibilityLevel

            if ($CompatibilityLevel -notin $supportedCompatibilityLevels)
            {
                $errorMessage = $script:localizedData.Set_SqlDscDatabaseProperty_InvalidCompatibilityLevel -f $CompatibilityLevel, $serverInstance.InstanceName

                $PSCmdlet.ThrowTerminatingError(
                    [System.Management.Automation.ErrorRecord]::new(
                        [System.ArgumentException]::new($errorMessage),
                        'SSDD0002', # SQL Server Database - Invalid compatibility level
                        [System.Management.Automation.ErrorCategory]::InvalidArgument,
                        $CompatibilityLevel
                    )
                )
            }
        }

        # Validate collation if specified
        if ($PSBoundParameters.ContainsKey('Collation'))
        {
            if ($Collation -notin $serverInstance.EnumCollations().Name)
            {
                $errorMessage = $script:localizedData.Set_SqlDscDatabaseProperty_InvalidCollation -f $Collation, $serverInstance.InstanceName

                $PSCmdlet.ThrowTerminatingError(
                    [System.Management.Automation.ErrorRecord]::new(
                        [System.ArgumentException]::new($errorMessage),
                        'SSDD0003', # SQL Server Database - Invalid collation
                        [System.Management.Automation.ErrorCategory]::InvalidArgument,
                        $Collation
                    )
                )
            }
        }
    }

    process
    {
        # Get the database object based on the parameter set
        switch ($PSCmdlet.ParameterSetName)
        {
            'ServerObjectSet'
            {
                Write-Verbose -Message ($script:localizedData.Database_Set -f $Name, $ServerObject.InstanceName)

                $previousErrorActionPreference = $ErrorActionPreference
                $ErrorActionPreference = 'Stop'

                $sqlDatabaseObject = $ServerObject |
                    Get-SqlDscDatabase -Name $Name -Refresh:$Refresh -ErrorAction 'Stop'

                $ErrorActionPreference = $previousErrorActionPreference
            }

            'DatabaseObjectSet'
            {
                Write-Verbose -Message ($script:localizedData.Database_Set -f $DatabaseObject.Name, $DatabaseObject.Parent.InstanceName)

                $sqlDatabaseObject = $DatabaseObject
            }
        }

        # Remove common parameters and function-specific parameters, leaving only database properties
        $boundParameters = Remove-CommonParameter -Hashtable $PSBoundParameters

        # Remove function-specific parameters
        foreach ($parameterToRemove in @('ServerObject', 'Name', 'DatabaseObject', 'Refresh', 'Force', 'PassThru'))
        {
            $boundParameters.Remove($parameterToRemove)
        }

        $verboseDescriptionMessage = $script:localizedData.Database_Set_ShouldProcessVerboseDescription -f $sqlDatabaseObject.Name, $sqlDatabaseObject.Parent.InstanceName
        $verboseWarningMessage = $script:localizedData.Database_Set_ShouldProcessVerboseWarning -f $sqlDatabaseObject.Name
        $captionMessage = $script:localizedData.Database_Set_ShouldProcessCaption

        if ($PSCmdlet.ShouldProcess($verboseDescriptionMessage, $verboseWarningMessage, $captionMessage))
        {
            $wasUpdated = $false

            # Set each specified property
            foreach ($parameterName in $boundParameters.Keys)
            {
                # Check if property exists on the database object
                if ($sqlDatabaseObject.PSObject.Properties.Name -notcontains $parameterName)
                {
                    Write-Error -Message ($script:localizedData.Set_SqlDscDatabaseProperty_PropertyNotFound -f $parameterName, $sqlDatabaseObject.Name) -Category ([System.Management.Automation.ErrorCategory]::InvalidArgument) -ErrorId 'SSDDP0010' -TargetObject $sqlDatabaseObject
                    continue
                }

                $currentValue = $sqlDatabaseObject.$parameterName
                $newValue = $boundParameters.$parameterName

                # Only update if the value is different
                if ($currentValue -ne $newValue)
                {
                    Write-Debug -Message ($script:localizedData.Database_UpdatingProperty -f $parameterName, $newValue)
                    $sqlDatabaseObject.$parameterName = $newValue
                    $wasUpdated = $true
                }
                else
                {
                    Write-Debug -Message ($script:localizedData.Database_PropertyAlreadySet -f $parameterName, $currentValue)
                }
            }

            # Apply changes if any properties were updated
            if ($wasUpdated)
            {
                Write-Debug -Message ($script:localizedData.Database_Updating -f $sqlDatabaseObject.Name)

                try
                {
                    $sqlDatabaseObject.Alter()
                }
                catch
                {
                    $errorMessage = $script:localizedData.Database_SetFailed -f $sqlDatabaseObject.Name, $sqlDatabaseObject.Parent.InstanceName

                    $PSCmdlet.ThrowTerminatingError(
                        [System.Management.Automation.ErrorRecord]::new(
                            [System.InvalidOperationException]::new($errorMessage, $_.Exception),
                            'SSDD0004', # SQL Server Database - Set failed
                            [System.Management.Automation.ErrorCategory]::InvalidOperation,
                            $sqlDatabaseObject
                        )
                    )
                }
                Write-Debug -Message ($script:localizedData.Database_Updated -f $sqlDatabaseObject.Name)
            }
            else
            {
                Write-Debug -Message ($script:localizedData.Database_NoPropertiesChanged -f $sqlDatabaseObject.Name)
            }

            if ($PassThru.IsPresent)
            {
                return $sqlDatabaseObject
            }
        }
    }
}
#EndRegion '.\Public\Set-SqlDscDatabaseProperty.ps1' 824
#Region '.\Public\Set-SqlDscServerPermission.ps1' -1

<#
    .SYNOPSIS
        Set permission for a server principal.

    .DESCRIPTION
        This command sets the permissions for a existing principal on a SQL Server
        Database Engine instance.

    .PARAMETER ServerObject
        Specifies current server connection object.

    .PARAMETER Name
        Specifies the name of the principal for which the permissions are set.

    .PARAMETER State
        Specifies the state of the permission.

    .PARAMETER Permission
        Specifies the permissions.

    .PARAMETER WithGrant
        Specifies that the principal should also be granted the right to grant
        other principals the same permission. This parameter is only valid when
        parameter **State** is set to `Grant` or `Revoke`. When the parameter
        **State** is set to `Revoke` the right to grant will also be revoked,
        and the revocation will cascade.

    .PARAMETER Force
        Specifies that the permissions should be set without any confirmation.

    .OUTPUTS
        None.

    .EXAMPLE
        $serverInstance = Connect-SqlDscDatabaseEngine

        $setPermission = [Microsoft.SqlServer.Management.Smo.ServerPermissionSet] @{
            Connect = $true
            Update = $true
        }

        Set-SqlDscServerPermission -ServerObject $serverInstance -Name 'MyPrincipal' -State 'Grant' -Permission $setPermission

        Sets the permissions for the principal 'MyPrincipal'.

    .NOTES
        If specifying `-ErrorAction 'SilentlyContinue'` then the command will silently
        ignore if the principal is not present. If specifying `-ErrorAction 'Stop'` the
        command will throw an error if the principal is missing.
#>
function Set-SqlDscServerPermission
{
    [System.Diagnostics.CodeAnalysis.SuppressMessageAttribute('UseSyntacticallyCorrectExamples', '', Justification = 'Because the rule does not yet support parsing the code when a parameter type is not available. The ScriptAnalyzer rule UseSyntacticallyCorrectExamples will always error in the editor due to https://github.com/indented-automation/Indented.ScriptAnalyzerRules/issues/8.')]
    [System.Diagnostics.CodeAnalysis.SuppressMessageAttribute('AvoidThrowOutsideOfTry', '', Justification = 'Because the code throws based on an prior expression')]
    [CmdletBinding(SupportsShouldProcess = $true, ConfirmImpact = 'High')]
    [OutputType()]
    param
    (
        [Parameter(Mandatory = $true, ValueFromPipeline = $true)]
        [Microsoft.SqlServer.Management.Smo.Server]
        $ServerObject,

        [Parameter(Mandatory = $true)]
        [System.String]
        $Name,

        [Parameter(Mandatory = $true)]
        [ValidateSet('Grant', 'Deny', 'Revoke')]
        [System.String]
        $State,

        [Parameter(Mandatory = $true)]
        [Microsoft.SqlServer.Management.Smo.ServerPermissionSet]
        $Permission,

        [Parameter()]
        [System.Management.Automation.SwitchParameter]
        $WithGrant,

        [Parameter()]
        [System.Management.Automation.SwitchParameter]
        $Force
    )

    process
    {
        if ($State -eq 'Deny' -and $WithGrant.IsPresent)
        {
            Write-Warning -Message $script:localizedData.ServerPermission_IgnoreWithGrantForStateDeny
        }

        if ($Force.IsPresent -and -not $Confirm)
        {
            $ConfirmPreference = 'None'
        }

        $testSqlDscIsPrincipalParameters = @{
            ServerObject = $ServerObject
            Name         = $Name
        }

        $isLogin = Test-SqlDscIsLogin @testSqlDscIsPrincipalParameters
        $isRole = Test-SqlDscIsRole @testSqlDscIsPrincipalParameters

        if ($isLogin -or $isRole)
        {
            # Get the permissions names that are set to $true in the ServerPermissionSet.
            $permissionName = $Permission |
                Get-Member -MemberType 'Property' |
                Select-Object -ExpandProperty 'Name' |
                Where-Object -FilterScript {
                    $Permission.$_
                }

            $verboseDescriptionMessage = $script:localizedData.ServerPermission_ChangePermissionShouldProcessVerboseDescription -f $Name, $ServerObject.InstanceName
            $verboseWarningMessage = $script:localizedData.ServerPermission_ChangePermissionShouldProcessVerboseWarning -f $Name
            $captionMessage = $script:localizedData.ServerPermission_ChangePermissionShouldProcessCaption

            if (-not $PSCmdlet.ShouldProcess($verboseDescriptionMessage, $verboseWarningMessage, $captionMessage))
            {
                # Return without doing anything if the user did not want to continue processing.
                return
            }

            switch ($State)
            {
                'Grant'
                {
                    Write-Verbose -Message (
                        $script:localizedData.ServerPermission_GrantPermission -f ($permissionName -join ','), $Name
                    )

                    if ($WithGrant.IsPresent)
                    {
                        $ServerObject.Grant($Permission, $Name, $true)
                    }
                    else
                    {
                        $ServerObject.Grant($Permission, $Name)
                    }
                }

                'Deny'
                {
                    Write-Verbose -Message (
                        $script:localizedData.ServerPermission_DenyPermission -f ($permissionName -join ','), $Name
                    )

                    $ServerObject.Deny($Permission, $Name)
                }

                'Revoke'
                {
                    Write-Verbose -Message (
                        $script:localizedData.ServerPermission_RevokePermission -f ($permissionName -join ','), $Name
                    )

                    if ($WithGrant.IsPresent)
                    {
                        $ServerObject.Revoke($Permission, $Name, $false, $true)
                    }
                    else
                    {
                        $ServerObject.Revoke($Permission, $Name)
                    }
                }
            }
        }
        else
        {
            $missingPrincipalMessage = $script:localizedData.ServerPermission_MissingPrincipal -f $Name, $ServerObject.InstanceName

            $PSCmdlet.ThrowTerminatingError(
                [System.Management.Automation.ErrorRecord]::new(
                    $missingPrincipalMessage,
                    'GSDDP0001', # cSpell: disable-line
                    [System.Management.Automation.ErrorCategory]::InvalidOperation,
                    $Name
                )
            )
        }
    }
}
#EndRegion '.\Public\Set-SqlDscServerPermission.ps1' 184
#Region '.\Public\Set-SqlDscStartupParameter.ps1' -1

<#
    .SYNOPSIS
        Sets startup parameters on a Database Engine instance.

    .DESCRIPTION
        Sets startup parameters on a Database Engine instance.

    .PARAMETER ServiceObject
        Specifies the Service object on which to set the startup parameters.

    .PARAMETER ServerName
        Specifies the server name where the instance exist.

    .PARAMETER InstanceName
       Specifies the instance name on which to set the startup parameters.

    .PARAMETER TraceFlag
        Specifies the trace flags to set.

    .PARAMETER InternalTraceFlag
        Specifies the internal trace flags to set.

        From the [Database Engine Service Startup Options](https://learn.microsoft.com/en-us/sql/database-engine/configure-windows/database-engine-service-startup-options)
        documentation: "...this sets other internal trace flags that are required
        only by SQL Server support engineers."

    .PARAMETER Force
        Specifies that the startup parameters should be set without any confirmation.

    .EXAMPLE
        Set-SqlDscStartupParameters -TraceFlag 4199

        Replaces the trace flags with 4199 on the Database Engine default instance
        on the server where the command in run.

    .EXAMPLE
        $serviceObject = Get-SqlDscManagedComputerService -ServiceType 'DatabaseEngine'
        Set-SqlDscTraceFlag -ServiceObject $serviceObject -TraceFlag 4199

        Replaces the trace flags with 4199 on the Database Engine default instance
        on the server where the command in run.

    .EXAMPLE
        Set-SqlDscTraceFlag -InstanceName 'SQL2022' -TraceFlag @()

        Removes all the trace flags from the Database Engine instance 'SQL2022'
        on the server where the command in run.

    .OUTPUTS
        None.

    .NOTES
        This command should support setting the values according to this documentation:
        https://learn.microsoft.com/en-us/sql/database-engine/configure-windows/database-engine-service-startup-options
#>
function Set-SqlDscStartupParameter
{
    [System.Diagnostics.CodeAnalysis.SuppressMessageAttribute('UseSyntacticallyCorrectExamples', '', Justification = 'Because the rule does not yet support parsing the code when a parameter type is not available. The ScriptAnalyzer rule UseSyntacticallyCorrectExamples will always error in the editor due to https://github.com/indented-automation/Indented.ScriptAnalyzerRules/issues/8.')]
    [OutputType()]
    [CmdletBinding(DefaultParameterSetName = 'ByServerName', SupportsShouldProcess = $true, ConfirmImpact = 'High')]
    param
    (
        [Parameter(ParameterSetName = 'ByServiceObject', Mandatory = $true, ValueFromPipeline = $true)]
        [Microsoft.SqlServer.Management.Smo.Wmi.Service]
        $ServiceObject,

        [Parameter(ParameterSetName = 'ByServerName')]
        [ValidateNotNullOrEmpty()]
        [System.String]
        $ServerName = (Get-ComputerName),

        [Parameter(ParameterSetName = 'ByServerName')]
        [ValidateNotNullOrEmpty()]
        [System.String]
        $InstanceName = 'MSSQLSERVER',

        [Parameter()]
        [AllowEmptyCollection()]
        [System.UInt32[]]
        $TraceFlag,

        [Parameter()]
        [AllowEmptyCollection()]
        [System.UInt32[]]
        $InternalTraceFlag,

        [Parameter()]
        [System.Management.Automation.SwitchParameter]
        $Force
    )

    begin
    {
        $originalErrorActionPreference = $ErrorActionPreference

        $ErrorActionPreference = 'Stop'

        Assert-ElevatedUser -ErrorAction 'Stop'

        $ErrorActionPreference = $originalErrorActionPreference

        if ($Force.IsPresent -and -not $Confirm)
        {
            $ConfirmPreference = 'None'
        }
    }

    process
    {
        if ($PSCmdlet.ParameterSetName -eq 'ByServiceObject')
        {
            $ServiceObject | Assert-ManagedServiceType -ServiceType 'DatabaseEngine'

            $InstanceName = $ServiceObject.Name -replace '^MSSQL\$'
        }

        if ($PSCmdlet.ParameterSetName -eq 'ByServerName')
        {
            $getSqlDscManagedComputerServiceParameters = @{
                ServerName   = $ServerName
                InstanceName = $InstanceName
                ServiceType  = 'DatabaseEngine'
                ErrorAction  = 'SilentlyContinue'
            }

            $ServiceObject = Get-SqlDscManagedComputerService @getSqlDscManagedComputerServiceParameters

            if (-not $ServiceObject)
            {
                $writeErrorParameters = @{
                    Message      = $script:localizedData.StartupParameter_Set_FailedToFindServiceObject
                    Category     = 'InvalidOperation'
                    ErrorId      = 'SSDSP0002' # CSpell: disable-line
                    TargetObject = $ServiceObject
                }

                Write-Error @writeErrorParameters
            }
        }

        if ($ServiceObject)
        {
            $verboseDescriptionMessage = $script:localizedData.StartupParameter_Set_ShouldProcessVerboseDescription -f $InstanceName
            $verboseWarningMessage = $script:localizedData.StartupParameter_Set_ShouldProcessVerboseWarning -f $InstanceName
            $captionMessage = $script:localizedData.StartupParameter_Set_ShouldProcessCaption

            if ($PSCmdlet.ShouldProcess($verboseDescriptionMessage, $verboseWarningMessage, $captionMessage))
            {
                $startupParameters = [StartupParameters]::Parse($ServiceObject.StartupParameters)

                if ($PSBoundParameters.ContainsKey('TraceFlag'))
                {
                    $startupParameters.TraceFlag = $TraceFlag
                }

                if ($PSBoundParameters.ContainsKey('InternalTraceFlag'))
                {
                    $startupParameters.InternalTraceFlag = $InternalTraceFlag
                }

                $ServiceObject.StartupParameters = $startupParameters.ToString()
                $ServiceObject.Alter()
            }
        }
    }
}
#EndRegion '.\Public\Set-SqlDscStartupParameter.ps1' 167
#Region '.\Public\Set-SqlDscTraceFlag.ps1' -1

<#
    .SYNOPSIS
        Sets trace flags on a Database Engine instance.

    .DESCRIPTION
        Sets trace flags on a Database Engine instance, replacing any trace flags
        currently set.

    .PARAMETER ServiceObject
        Specifies the Service object on which to set the trace flags.

    .PARAMETER ServerName
        Specifies the server name where the instance exist.

    .PARAMETER InstanceName
       Specifies the instance name on which to set the trace flags.

    .PARAMETER TraceFlag
        Specifies the trace flags to set.

    .PARAMETER Force
        Specifies that the trace flag should be set without any confirmation.

    .EXAMPLE
        Set-SqlDscTraceFlag -TraceFlag 4199

        Replaces the trace flags with 4199 on the Database Engine default instance
        on the server where the command in run.

    .EXAMPLE
        $serviceObject = Get-SqlDscManagedComputerService -ServiceType 'DatabaseEngine'
        Set-SqlDscTraceFlag -ServiceObject $serviceObject -TraceFlag 4199

        Replaces the trace flags with 4199 on the Database Engine default instance
        on the server where the command in run.

    .EXAMPLE
        Set-SqlDscTraceFlag -InstanceName 'SQL2022' -TraceFlag 4199,3226

        Replaces the trace flags with 4199 and 3226 on the Database Engine instance
        'SQL2022' on the server where the command in run.

    .EXAMPLE
        $serviceObject = Get-SqlDscManagedComputerService -ServiceType 'DatabaseEngine' -InstanceName 'SQL2022'
        Set-SqlDscTraceFlag -ServiceObject $serviceObject -TraceFlag 4199,3226

        Replaces the trace flags with 4199 and 3226 on the Database Engine instance
        'SQL2022' on the server where the command in run.

    .EXAMPLE
        Set-SqlDscTraceFlag -InstanceName 'SQL2022' -TraceFlag @()

        Removes all the trace flags from the Database Engine instance 'SQL2022'
        on the server where the command in run.

    .OUTPUTS
        None.
#>
function Set-SqlDscTraceFlag
{
    [System.Diagnostics.CodeAnalysis.SuppressMessageAttribute('UseSyntacticallyCorrectExamples', '', Justification = 'Because the rule does not yet support parsing the code when a parameter type is not available. The ScriptAnalyzer rule UseSyntacticallyCorrectExamples will always error in the editor due to https://github.com/indented-automation/Indented.ScriptAnalyzerRules/issues/8.')]
    [OutputType()]
    [CmdletBinding(DefaultParameterSetName = 'ByServerName', SupportsShouldProcess = $true, ConfirmImpact = 'High')]
    param
    (
        [Parameter(ParameterSetName = 'ByServiceObject', Mandatory = $true, ValueFromPipeline = $true)]
        [Microsoft.SqlServer.Management.Smo.Wmi.Service]
        $ServiceObject,

        [Parameter(ParameterSetName = 'ByServerName')]
        [ValidateNotNullOrEmpty()]
        [System.String]
        $ServerName = (Get-ComputerName),

        [Parameter(ParameterSetName = 'ByServerName')]
        [ValidateNotNullOrEmpty()]
        [System.String]
        $InstanceName = 'MSSQLSERVER',

        [Parameter(Mandatory = $true)]
        [AllowEmptyCollection()]
        [System.UInt32[]]
        $TraceFlag,

        [Parameter()]
        [System.Management.Automation.SwitchParameter]
        $Force
    )

    begin
    {
        if ($Force.IsPresent -and -not $Confirm)
        {
            $ConfirmPreference = 'None'
        }
    }

    process
    {
        if ($PSCmdlet.ParameterSetName -eq 'ByServiceObject')
        {
            $InstanceName = $ServiceObject.Name -replace '^MSSQL\$'
        }

        $verboseDescriptionMessage = $script:localizedData.TraceFlag_Set_ShouldProcessVerboseDescription -f $InstanceName, ($TraceFlag -join ', ')
        $verboseWarningMessage = $script:localizedData.TraceFlag_Set_ShouldProcessVerboseWarning -f $InstanceName
        $captionMessage = $script:localizedData.TraceFlag_Set_ShouldProcessCaption

        if ($PSCmdlet.ShouldProcess($verboseDescriptionMessage, $verboseWarningMessage, $captionMessage))
        {
            Set-SqlDscStartupParameter @PSBoundParameters
        }
    }
}
#EndRegion '.\Public\Set-SqlDscTraceFlag.ps1' 115
#Region '.\Public\Test-SqlDscAgentAlertProperty.ps1' -1

<#
    .SYNOPSIS
        Tests if a SQL Agent Alert has the specified properties.

    .DESCRIPTION
        This command tests if a SQL Agent Alert on a SQL Server Database Engine
        instance has the specified properties. At least one property parameter
        must be specified.

    .PARAMETER ServerObject
        Specifies current server connection object.

    .PARAMETER Name
        Specifies the name of the SQL Agent Alert to test.

    .PARAMETER AlertObject
        Specifies the SQL Agent Alert object to test.

    .PARAMETER Severity
        Specifies the expected severity level for the SQL Agent Alert. Valid range is 0 to 25.
        If specified, the command will return $true only if the alert exists and has this severity.

    .PARAMETER MessageId
        Specifies the expected message ID for the SQL Agent Alert. Valid range is 0 to 2147483647.
        If specified, the command will return $true only if the alert exists and has this message ID.

    .INPUTS
        Microsoft.SqlServer.Management.Smo.Server

        SQL Server Database Engine instance object.

    .INPUTS
        Microsoft.SqlServer.Management.Smo.Agent.Alert

        SQL Agent Alert object.

    .OUTPUTS
        [System.Boolean]

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine -InstanceName 'MyInstance'
        Test-SqlDscAgentAlertProperty -ServerObject $serverObject -Name 'MyAlert' -Severity 16

        Tests if the SQL Agent Alert named 'MyAlert' exists and has severity level 16.

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine -InstanceName 'MyInstance'
        $serverObject | Test-SqlDscAgentAlertProperty -Name 'MyAlert' -MessageId 50001

        Tests if the SQL Agent Alert named 'MyAlert' exists and has message ID 50001.

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine -InstanceName 'MyInstance'
        $alertObject = $serverObject | Get-SqlDscAgentAlert -Name 'MyAlert'
        $alertObject | Test-SqlDscAgentAlertProperty -Severity 16

        Tests if the SQL Agent Alert has severity level 16 using alert object pipeline input.
#>
function Test-SqlDscAgentAlertProperty
{
    [System.Diagnostics.CodeAnalysis.SuppressMessageAttribute('UseSyntacticallyCorrectExamples', '', Justification = 'Because the rule does not yet support parsing the code when a parameter type is not available. The ScriptAnalyzer rule UseSyntacticallyCorrectExamples will always error in the editor due to https://github.com/indented-automation/Indented.ScriptAnalyzerRules/issues/8.')]
    [CmdletBinding(DefaultParameterSetName = 'ByServerAndName')]
    [OutputType([System.Boolean])]
    param
    (
        [Parameter(ParameterSetName = 'ByServerAndName', Mandatory = $true, ValueFromPipeline = $true)]
        [Microsoft.SqlServer.Management.Smo.Server]
        $ServerObject,

        [Parameter(ParameterSetName = 'ByServerAndName', Mandatory = $true)]
        [System.String]
        $Name,

        [Parameter(ParameterSetName = 'ByAlertObject', Mandatory = $true, ValueFromPipeline = $true)]
        [Microsoft.SqlServer.Management.Smo.Agent.Alert]
        $AlertObject,

        [Parameter()]
        [ValidateRange(0, 25)]
        [System.Int32]
        $Severity,

        [Parameter()]
        [ValidateRange(0, 2147483647)]
        [System.Int32]
        $MessageId
    )

    # cSpell: ignore TSAAP
    process
    {
        # Ensure at least one property parameter is specified
        Assert-BoundParameter -BoundParameterList $PSBoundParameters -AtLeastOneList @('Severity', 'MessageId')

        # Validate that both Severity and MessageId are not specified
        Assert-BoundParameter -BoundParameterList $PSBoundParameters -MutuallyExclusiveList1 @('Severity') -MutuallyExclusiveList2 @('MessageId')

        if ($PSCmdlet.ParameterSetName -eq 'ByAlertObject')
        {
            $alertObject = $AlertObject
        }
        else
        {
            $alertObject = Get-AgentAlertObject -ServerObject $ServerObject -Name $Name

            if ($null -eq $alertObject)
            {
                $errorMessage = $script:localizedData.Test_SqlDscAgentAlertProperty_AlertNotFound -f $Name

                Write-Error -Message $errorMessage -Category 'ObjectNotFound' -ErrorId 'TSDAAP0001' -TargetObject $Name

                return $false
            }
        }

        # Test severity if specified
        if ($PSBoundParameters.ContainsKey('Severity'))
        {
            if ($alertObject.Severity -ne $Severity)
            {
                return $false
            }
        }

        # Test message ID if specified
        if ($PSBoundParameters.ContainsKey('MessageId'))
        {
            if ($alertObject.MessageId -ne $MessageId)
            {
                return $false
            }
        }

        return $true
    }
}
#EndRegion '.\Public\Test-SqlDscAgentAlertProperty.ps1' 137
#Region '.\Public\Test-SqlDscConfigurationOption.ps1' -1

<#
    .SYNOPSIS
        Test if server configuration option has the specified value.

    .DESCRIPTION
        This command tests whether a SQL Server Database Engine configuration option
        has the specified value using SQL Server Management Objects (SMO). The function
        validates that the option exists and compares the current value with the expected value.

    .PARAMETER ServerObject
        Specifies current server connection object.

    .PARAMETER Name
        Specifies the name of the configuration option to test.

    .PARAMETER Value
        Specifies the expected value for the configuration option.

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine -InstanceName 'MyInstance'
        $serverObject | Test-SqlDscConfigurationOption -Name "Agent XPs" -Value 1

        Tests if the "Agent XPs" configuration option is enabled (1).

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine -InstanceName 'MyInstance'
        Test-SqlDscConfigurationOption -ServerObject $serverObject -Name "cost threshold for parallelism" -Value 50

        Tests if the "cost threshold for parallelism" configuration option is set to 50.

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine -InstanceName 'MyInstance'
        $serverObject | Test-SqlDscConfigurationOption -Name "max degree of parallelism" -Value 4

        Tests if the "max degree of parallelism" option is set to 4.

    .INPUTS
        Microsoft.SqlServer.Management.Smo.Server
        SQL Server Management Objects (SMO) Server object representing a SQL Server instance.

    .OUTPUTS
        System.Boolean
        Returns $true if the configuration option has the specified value, $false otherwise.

    .NOTES
        This function does not support ShouldProcess as it is a read-only operation.
#>
function Test-SqlDscConfigurationOption
{
    [System.Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSReviewUnusedParameter', '', Justification = 'Because we pass parameters in the argument completer that are not yet used.')]
    [System.Diagnostics.CodeAnalysis.SuppressMessageAttribute('UseSyntacticallyCorrectExamples', '', Justification = 'Because the rule does not yet support parsing the code when a parameter type is not available. The ScriptAnalyzer rule UseSyntacticallyCorrectExamples will always error in the editor due to https://github.com/indented-automation/Indented.ScriptAnalyzerRules/issues/8.')]
    [OutputType([System.Boolean])]
    [CmdletBinding()]
    param
    (
        [Parameter(Mandatory = $true, ValueFromPipeline = $true)]
        [Microsoft.SqlServer.Management.Smo.Server]
        $ServerObject,

        [Parameter(Mandatory = $true)]
        [ArgumentCompleter({
                param
                (
                    [Parameter()]
                    $commandName,

                    [Parameter()]
                    $parameterName,

                    [Parameter()]
                    $wordToComplete,

                    [Parameter()]
                    $commandAst,

                    [Parameter()]
                    $fakeBoundParameters
                )

                # Get ServerObject from bound parameters only
                $serverObject = $null

                if ($FakeBoundParameters.ContainsKey('ServerObject'))
                {
                    $serverObject = $FakeBoundParameters['ServerObject']
                }

                if ($serverObject -and $serverObject -is [Microsoft.SqlServer.Management.Smo.Server])
                {
                    try
                    {
                        $options = $serverObject.Configuration.Properties | Where-Object {
                            $_.DisplayName -like "*$WordToComplete*"
                        } | Sort-Object DisplayName

                        foreach ($option in $options)
                        {
                            $tooltip = "Current: $($option.ConfigValue), Run: $($option.RunValue), Range: $($option.Minimum)-$($option.Maximum)"
                            [System.Management.Automation.CompletionResult]::new(
                                "'$($option.DisplayName)'",
                                $option.DisplayName,
                                'ParameterValue',
                                $tooltip
                            )
                        }
                    }
                    catch
                    {
                        # Return empty if there's an error accessing the server
                        @()
                    }
                }
                else
                {
                    # Return empty array if no server object available
                    @()
                }
            })]
        [System.String]
        $Name,

        [Parameter(Mandatory = $true)]
        [ArgumentCompleter({
                param
                (
                    [Parameter()]
                    $commandName,

                    [Parameter()]
                    $parameterName,

                    [Parameter()]
                    $wordToComplete,

                    [Parameter()]
                    $commandAst,

                    [Parameter()]
                    $fakeBoundParameters
                )

                # Get ServerObject and Name from bound parameters
                $serverObject = $null
                $optionName = $null

                if ($FakeBoundParameters.ContainsKey('ServerObject'))
                {
                    $serverObject = $FakeBoundParameters['ServerObject']
                }

                if ($FakeBoundParameters.ContainsKey('Name'))
                {
                    $optionName = $FakeBoundParameters['Name']
                }

                if ($serverObject -and $serverObject -is [Microsoft.SqlServer.Management.Smo.Server] -and $optionName)
                {
                    try
                    {
                        $option = $serverObject.Configuration.Properties | Where-Object {
                            $_.DisplayName -eq $optionName
                        }

                        if ($option)
                        {
                            $suggestions = @()

                            # Add current values
                            $suggestions += [PSCustomObject]@{
                                Value   = $option.ConfigValue
                                Tooltip = "Current ConfigValue: $($option.ConfigValue)"
                            }

                            $suggestions += [PSCustomObject]@{
                                Value   = $option.RunValue
                                Tooltip = "Current RunValue: $($option.RunValue)"
                            }

                            # Add min/max values
                            $suggestions += [PSCustomObject]@{
                                Value   = $option.Minimum
                                Tooltip = "Minimum allowed value: $($option.Minimum)"
                            }

                            $suggestions += [PSCustomObject]@{
                                Value   = $option.Maximum
                                Tooltip = "Maximum allowed value: $($option.Maximum)"
                            }

                            # If it's a boolean option (0-1), suggest both values
                            if ($option.Minimum -eq 0 -and $option.Maximum -eq 1)
                            {
                                $suggestions += [PSCustomObject]@{
                                    Value   = 0
                                    Tooltip = 'Disabled (0)'
                                }

                                $suggestions += [PSCustomObject]@{
                                    Value   = 1
                                    Tooltip = 'Enabled (1)'
                                }
                            }

                            # Remove duplicates and filter by word to complete
                            $uniqueSuggestions = $suggestions | Group-Object Value | ForEach-Object { $_.Group[0] }
                            $filteredSuggestions = $uniqueSuggestions | Where-Object {
                                $_.Value -like "*$WordToComplete*"
                            } | Sort-Object Value

                            foreach ($suggestion in $filteredSuggestions)
                            {
                                [System.Management.Automation.CompletionResult]::new(
                                    $suggestion.Value.ToString(),
                                    $suggestion.Value.ToString(),
                                    'ParameterValue',
                                    $suggestion.Tooltip
                                )
                            }
                        }
                    }
                    catch
                    {
                        # Return empty if there's an error
                        @()
                    }
                }
                else
                {
                    # Return empty array if prerequisites not met
                    @()
                }
            })]
        [System.Int32]
        $Value
    )

    process
    {
        # Find the configuration option by name
        $configurationOption = $ServerObject.Configuration.Properties |
            Where-Object {
                $_.DisplayName -eq $Name
            }

        if (-not $configurationOption)
        {
            $missingConfigurationOptionMessage = $script:localizedData.ConfigurationOption_Test_Missing -f $Name

            $writeErrorParameters = @{
                Message      = $missingConfigurationOptionMessage
                Category     = 'InvalidOperation'
                ErrorId      = 'TSDCO0001' # cspell: disable-line
                TargetObject = $Name
            }

            Write-Error @writeErrorParameters
            return $false
        }

        # Compare the current configuration value with the expected value
        $currentValue = $configurationOption.ConfigValue
        $isMatch = $currentValue -eq $Value

        Write-Verbose -Message ($script:localizedData.ConfigurationOption_Test_Result -f $Name, $currentValue, $Value, $isMatch, $ServerObject.Name)

        return $isMatch
    }
}
#EndRegion '.\Public\Test-SqlDscConfigurationOption.ps1' 269
#Region '.\Public\Test-SqlDscDatabaseProperty.ps1' -1

<#
    .SYNOPSIS
        Tests if database properties on a SQL Server Database Engine instance are
        in the desired state.

    .DESCRIPTION
        This command tests if database properties on a SQL Server Database Engine
        instance are in the desired state.

        The command supports a comprehensive set of database properties including
        configuration settings, metadata, security properties, performance settings,
        and state information. Users can test one or multiple properties in a
        single command execution.

        All properties correspond directly to Microsoft SQL Server Management Objects (SMO)
        Database class properties and support the same data types and values as the
        underlying SMO implementation.

    .PARAMETER ServerObject
        Specifies current server connection object.

    .PARAMETER Name
        Specifies the name of the database to test properties for. The logical
        database name as it appears in SQL Server.

    .PARAMETER DatabaseObject
        Specifies the database object to test properties for (from Get-SqlDscDatabase).

    .PARAMETER Refresh
        Specifies that the **ServerObject**'s databases should be refreshed before
        trying to get the database object. This is helpful when databases could have been
        modified outside of the **ServerObject**, for example through T-SQL. But
        on instances with a large amount of databases it might be better to make
        sure the **ServerObject** is recent enough.

        This parameter is only used when testing properties using **ServerObject** and
        **Name** parameters.

    .PARAMETER Collation
        Specifies the default collation for the database.

    .PARAMETER RecoveryModel
        Specifies the database recovery model (FULL, BULK_LOGGED, SIMPLE).

    .PARAMETER CompatibilityLevel
        Specifies the database compatibility level (affects query processor behavior and features).

    .PARAMETER Owner
        Specifies the owner (login) of the database.

    .PARAMETER ReadOnly
        Specifies whether the database is in read-only mode.

    .PARAMETER Trustworthy
        Specifies whether implicit access to external resources by modules is allowed (use with caution).

    .PARAMETER AcceleratedRecoveryEnabled
        Specifies whether Accelerated Database Recovery (ADR) is enabled for the database.

    .PARAMETER ActiveConnections
        Specifies the number of active connections to the database (as observed by SMO).

    .PARAMETER ActiveDirectory
        Specifies whether the database participates in Active Directory integration features.

    .PARAMETER AnsiNullDefault
        Specifies whether new columns allow NULL by default unless explicitly specified (when ON).

    .PARAMETER AnsiNullsEnabled
        Specifies whether comparisons to NULL follow ANSI SQL behavior (when ON, x = NULL yields UNKNOWN).

    .PARAMETER AnsiPaddingEnabled
        Specifies whether padding for variable-length columns (e.g., CHAR/VARCHAR) follows ANSI rules.

    .PARAMETER AnsiWarningsEnabled
        Specifies whether ANSI warnings are generated for certain conditions (when ON, e.g., divide by zero).

    .PARAMETER ArithmeticAbortEnabled
        Specifies whether a query is terminated when an overflow or divide-by-zero error occurs.

    .PARAMETER AutoClose
        Specifies whether the database closes after the last user exits.

    .PARAMETER AutoCreateIncrementalStatisticsEnabled
        Specifies whether creation of incremental statistics on partitioned tables is allowed.

    .PARAMETER AutoCreateStatisticsEnabled
        Specifies whether single-column statistics are automatically created for query optimization.

    .PARAMETER AutoShrink
        Specifies whether the database automatically shrinks files when free space is detected.

    .PARAMETER AutoUpdateStatisticsAsync
        Specifies whether statistics are updated asynchronously, allowing queries to proceed with old stats.

    .PARAMETER AutoUpdateStatisticsEnabled
        Specifies whether statistics are automatically updated when they are out-of-date.

    .PARAMETER AvailabilityDatabaseSynchronizationState
        Specifies the synchronization state of the database in an Availability Group.

    .PARAMETER AvailabilityGroupName
        Specifies the name of the Availability Group to which the database belongs, if any.

    .PARAMETER AzureEdition
        Specifies the Azure SQL Database edition (e.g., Basic/Standard/Premium/GeneralPurpose/BusinessCritical).

    .PARAMETER AzureServiceObjective
        Specifies the Azure SQL Database service objective (e.g., S3, P1, GP_Gen5_4).

    .PARAMETER BrokerEnabled
        Specifies whether Service Broker is enabled for the database.

    .PARAMETER CaseSensitive
        Specifies whether the database collation is case-sensitive.

    .PARAMETER CatalogCollation
        Specifies the catalog-level collation used for metadata and temporary objects.

    .PARAMETER ChangeTrackingAutoCleanUp
        Specifies whether automatic cleanup of change tracking information is enabled.

    .PARAMETER ChangeTrackingEnabled
        Specifies whether change tracking is enabled for the database.

    .PARAMETER ChangeTrackingRetentionPeriod
        Specifies the retention period value for change tracking information.

    .PARAMETER ChangeTrackingRetentionPeriodUnits
        Specifies the units for the retention period (e.g., DAYS, HOURS).

    .PARAMETER CloseCursorsOnCommitEnabled
        Specifies whether open cursors are closed when a transaction is committed.

    .PARAMETER ConcatenateNullYieldsNull
        Specifies whether concatenation with NULL results in NULL (when ON).

    .PARAMETER ContainmentType
        Specifies the containment level of the database (NONE or PARTIAL).

    .PARAMETER CreateDate
        Specifies the date and time that the database was created.

    .PARAMETER DatabaseEngineEdition
        Specifies the edition of the database engine hosting the database.

    .PARAMETER DatabaseEngineType
        Specifies the engine type (e.g., Standalone, AzureSqlDatabase, SqlOnDemand).

    .PARAMETER DatabaseGuid
        Specifies the unique identifier (GUID) of the database.

    .PARAMETER DatabaseOwnershipChaining
        Specifies whether ownership chaining across objects within the database is enabled.

    .PARAMETER DataRetentionEnabled
        Specifies whether SQL Server data retention policy is enabled at the database level.

    .PARAMETER DateCorrelationOptimization
        Specifies whether date correlation optimization is enabled to speed up temporal joins.

    .PARAMETER DboLogin
        Specifies the login that owns the database (dbo).

    .PARAMETER DefaultFileGroup
        Specifies the name of the default filegroup for the database.

    .PARAMETER DefaultFileStreamFileGroup
        Specifies the name of the default FILESTREAM filegroup.

    .PARAMETER DefaultFullTextCatalog
        Specifies the default full-text catalog used for full-text indexes.

    .PARAMETER DefaultFullTextLanguage
        Specifies the LCID of the default full-text language.

    .PARAMETER DefaultLanguage
        Specifies the ID of the default language for the database.

    .PARAMETER DefaultSchema
        Specifies the default schema name for users without an explicit default schema.

    .PARAMETER DelayedDurability
        Specifies whether delayed transaction log flushes are enabled to improve throughput.

    .PARAMETER EncryptionEnabled
        Specifies whether Transparent Data Encryption (TDE) is enabled.

    .PARAMETER FilestreamDirectoryName
        Specifies the directory name used for FILESTREAM data.

    .PARAMETER FilestreamNonTransactedAccess
        Specifies the FILESTREAM access level for non-transactional access.

    .PARAMETER HasDatabaseEncryptionKey
        Specifies whether the database has a database encryption key (TDE).

    .PARAMETER HasFileInCloud
        Specifies whether the database has one or more files in Azure Storage.

    .PARAMETER HasMemoryOptimizedObjects
        Specifies whether the database contains memory-optimized (In-Memory OLTP) objects.

    .PARAMETER HonorBrokerPriority
        Specifies whether honoring Service Broker conversation priority is enabled.

    .PARAMETER ID
        Specifies the database ID (DB_ID). Unique numeric identifier assigned to the database by SQL Server.

    .PARAMETER IndexSpaceUsage
        Specifies the space used by indexes in KB.

    .PARAMETER IsAccessible
        Specifies whether the database is accessible to the current connection.

    .PARAMETER IsDatabaseSnapshot
        Specifies whether the database is a database snapshot.

    .PARAMETER IsDatabaseSnapshotBase
        Specifies whether the database is the source (base) of one or more snapshots.

    .PARAMETER IsDbAccessAdmin
        Specifies whether the caller is member of db_accessadmin for this database.

    .PARAMETER IsDbBackupOperator
        Specifies whether the caller is member of db_backupoperator.

    .PARAMETER IsDbDataReader
        Specifies whether the caller is member of db_datareader.

    .PARAMETER IsDbDataWriter
        Specifies whether the caller is member of db_datawriter.

    .PARAMETER IsDbDdlAdmin
        Specifies whether the caller is member of db_ddladmin.

    .PARAMETER IsDbDenyDataReader
        Specifies whether the caller is member of db_denydatareader.

    .PARAMETER IsDbDenyDataWriter
        Specifies whether the caller is member of db_denydatawriter.

    .PARAMETER IsDbManager
        Specifies whether the caller is member of db_manager (Azure role).

    .PARAMETER IsDbOwner
        Specifies whether the caller is member of db_owner.

    .PARAMETER IsDbSecurityAdmin
        Specifies whether the caller is member of db_securityadmin.

    .PARAMETER IsFabricDatabase
        Specifies whether the database is a Microsoft Fabric SQL database.

    .PARAMETER IsFullTextEnabled
        Specifies whether full-text search is enabled.

    .PARAMETER IsLedger
        Specifies whether the database is enabled for SQL Ledger features.

    .PARAMETER IsLoginManager
        Specifies whether the caller is member of the login manager role (Azure).

    .PARAMETER IsMailHost
        Specifies whether Database Mail host features are configured on this database.

    .PARAMETER IsManagementDataWarehouse
        Specifies whether the database is configured as the Management Data Warehouse.

    .PARAMETER IsMaxSizeApplicable
        Specifies whether MaxSizeInBytes is enforced for the database.

    .PARAMETER IsMirroringEnabled
        Specifies whether database mirroring is configured.

    .PARAMETER IsParameterizationForced
        Specifies whether parameterization of queries is forced by default (when ON).

    .PARAMETER IsReadCommittedSnapshotOn
        Specifies whether READ_COMMITTED_SNAPSHOT isolation is ON.

    .PARAMETER IsSqlDw
        Specifies whether the database is an Azure Synapse (SQL DW) database.

    .PARAMETER IsSqlDwEdition
        Specifies whether the edition corresponds to Azure Synapse (DW).

    .PARAMETER IsSystemObject
        Specifies whether the database is a system database (master, model, msdb, tempdb).

    .PARAMETER IsVarDecimalStorageFormatEnabled
        Specifies whether vardecimal storage format is enabled.

    .PARAMETER IsVarDecimalStorageFormatSupported
        Specifies whether vardecimal storage format is supported by the server.

    .PARAMETER LastBackupDate
        Specifies the timestamp of the last full database backup.

    .PARAMETER LastDifferentialBackupDate
        Specifies the timestamp of the last differential backup.

    .PARAMETER LastGoodCheckDbTime
        Specifies the timestamp when DBCC CHECKDB last completed successfully.

    .PARAMETER LastLogBackupDate
        Specifies the timestamp of the last transaction log backup.

    .PARAMETER LegacyCardinalityEstimation
        Specifies whether the legacy cardinality estimator is enabled for the primary.

    .PARAMETER LegacyCardinalityEstimationForSecondary
        Specifies whether the legacy cardinality estimator is enabled for secondary replicas.

    .PARAMETER LocalCursorsDefault
        Specifies whether cursors are local by default instead of global (when ON).

    .PARAMETER LogReuseWaitStatus
        Specifies the reason why the transaction log cannot be reused.

    .PARAMETER MaxDop
        Specifies the MAXDOP database-scoped configuration for primary replicas.

    .PARAMETER MaxDopForSecondary
        Specifies the MAXDOP database-scoped configuration for secondary replicas.

    .PARAMETER MaxSizeInBytes
        Specifies the maximum size of the database in bytes.

    .PARAMETER MemoryAllocatedToMemoryOptimizedObjectsInKB
        Specifies the memory allocated to memory-optimized objects (KB).

    .PARAMETER MemoryUsedByMemoryOptimizedObjectsInKB
        Specifies the memory used by memory-optimized objects (KB).

    .PARAMETER MirroringFailoverLogSequenceNumber
        Specifies the mirroring failover LSN (if mirroring configured).

    .PARAMETER MirroringID
        Specifies the unique mirroring ID for the database.

    .PARAMETER MirroringPartner
        Specifies the mirroring partner server name (if configured).

    .PARAMETER MirroringPartnerInstance
        Specifies the mirroring partner instance name (if configured).

    .PARAMETER MirroringRedoQueueMaxSize
        Specifies the redo queue maximum size for mirroring/AGs.

    .PARAMETER MirroringRoleSequence
        Specifies the sequence number for mirroring role transitions.

    .PARAMETER MirroringSafetyLevel
        Specifies the mirroring safety level (FULL/Off/HighPerformance).

    .PARAMETER MirroringSafetySequence
        Specifies the sequence for mirroring safety changes.

    .PARAMETER MirroringStatus
        Specifies the current mirroring state of the database.

    .PARAMETER MirroringTimeout
        Specifies the timeout in seconds for mirroring sessions.

    .PARAMETER MirroringWitness
        Specifies the mirroring witness server (if used).

    .PARAMETER MirroringWitnessStatus
        Specifies the status of the mirroring witness.

    .PARAMETER NestedTriggersEnabled
        Specifies whether triggers are allowed to fire other triggers (nested triggers).

    .PARAMETER NumericRoundAbortEnabled
        Specifies whether an error is raised on loss of precision due to rounding (when ON).

    .PARAMETER PageVerify
        Specifies the page verification setting (NONE, TORN_PAGE_DETECTION, CHECKSUM).

    .PARAMETER ParameterSniffing
        Specifies whether parameter sniffing behavior is enabled on the primary.

    .PARAMETER ParameterSniffingForSecondary
        Specifies whether parameter sniffing is enabled on secondary replicas.

    .PARAMETER PersistentVersionStoreFileGroup
        Specifies the filegroup used for the Persistent Version Store (PVS).

    .PARAMETER PersistentVersionStoreSizeKB
        Specifies the size of the Persistent Version Store in KB.

    .PARAMETER PrimaryFilePath
        Specifies the path of the primary data files directory.

    .PARAMETER QueryOptimizerHotfixes
        Specifies whether query optimizer hotfixes are enabled on the primary.

    .PARAMETER QueryOptimizerHotfixesForSecondary
        Specifies whether query optimizer hotfixes are enabled on secondary replicas.

    .PARAMETER QuotedIdentifiersEnabled
        Specifies whether identifiers can be delimited by double quotes (when ON).

    .PARAMETER RecoveryForkGuid
        Specifies the GUID for the current recovery fork of the database.

    .PARAMETER RecursiveTriggersEnabled
        Specifies whether a trigger is allowed to fire itself recursively.

    .PARAMETER RemoteDataArchiveCredential
        Specifies the credential name for Stretch Database/remote data archive.

    .PARAMETER RemoteDataArchiveEnabled
        Specifies whether Stretch Database (remote data archive) is enabled.

    .PARAMETER RemoteDataArchiveEndpoint
        Specifies the endpoint URL for remote data archive.

    .PARAMETER RemoteDataArchiveLinkedServer
        Specifies the linked server used by remote data archive.

    .PARAMETER RemoteDataArchiveUseFederatedServiceAccount
        Specifies whether to use federated service account for remote data archive.

    .PARAMETER RemoteDatabaseName
        Specifies the remote database name for remote data archive.

    .PARAMETER ReplicationOptions
        Specifies the replication options that are enabled for the database.

    .PARAMETER ServiceBrokerGuid
        Specifies the unique Service Broker identifier for the database.

    .PARAMETER Size
        Specifies the approximate size of the database in MB (as reported by SMO).

    .PARAMETER SnapshotIsolationState
        Specifies whether SNAPSHOT isolation is OFF/ON/IN_TRANSITION.

    .PARAMETER SpaceAvailable
        Specifies the free space available in the database (KB).

    .PARAMETER State
        Specifies the general state of the SMO object.

    .PARAMETER Status
        Specifies the operational status of the database as reported by SMO.

    .PARAMETER TargetRecoveryTime
        Specifies the target recovery time (seconds) for indirect checkpointing.

    .PARAMETER TemporalHistoryRetentionEnabled
        Specifies whether automatic cleanup of system-versioned temporal history is enabled.

    .PARAMETER TransformNoiseWords
        Specifies how full-text noise word behavior is controlled during queries.

    .PARAMETER TwoDigitYearCutoff
        Specifies the two-digit year cutoff used for date conversion.

    .PARAMETER UserAccess
        Specifies the database user access mode (MULTI_USER, RESTRICTED_USER, SINGLE_USER).

    .PARAMETER UserName
        Specifies the user name for the current connection context (as seen by SMO).

    .PARAMETER Version
        Specifies the internal version number of the database.

    .PARAMETER WarnOnRename
        Specifies whether a warning is emitted when objects are renamed.

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine -InstanceName 'MyInstance'
        Test-SqlDscDatabaseProperty -ServerObject $serverObject -Name 'MyDatabase' -Collation 'SQL_Latin1_General_CP1_CI_AS'

        Tests if the database named **MyDatabase** has the specified collation.

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine -InstanceName 'MyInstance'
        $databaseObject = $serverObject | Get-SqlDscDatabase -Name 'MyDatabase'
        Test-SqlDscDatabaseProperty -DatabaseObject $databaseObject -RecoveryModel 'Simple' -CompatibilityLevel 'Version160'

        Tests if the database has the specified recovery model and compatibility level using a database object.

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine -InstanceName 'MyInstance'
        Test-SqlDscDatabaseProperty -ServerObject $serverObject -Name 'MyDatabase' -Owner 'sa' -AutoClose $false -Trustworthy $false

        Tests multiple database properties at once.

    .INPUTS
        `[Microsoft.SqlServer.Management.Smo.Database]`

        The database object to test properties for (from Get-SqlDscDatabase).

    .OUTPUTS
        `[System.Boolean]`
#>
function Test-SqlDscDatabaseProperty
{
    [System.Diagnostics.CodeAnalysis.SuppressMessageAttribute('UseSyntacticallyCorrectExamples', '', Justification = 'Because the rule does not yet support parsing the code when a parameter type is not available. The ScriptAnalyzer rule UseSyntacticallyCorrectExamples will always error in the editor due to https://github.com/indented-automation/Indented.ScriptAnalyzerRules/issues.')]
    [System.Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingPlainTextForPassword', '', Justification = 'This is not a password but a credential name reference.')]
    [OutputType([System.Boolean])]
    [CmdletBinding(DefaultParameterSetName = 'ServerObjectSet')]
    param
    (
        [Parameter(ParameterSetName = 'ServerObjectSet', Mandatory = $true)]
        [Microsoft.SqlServer.Management.Smo.Server]
        $ServerObject,

        [Parameter(ParameterSetName = 'ServerObjectSet', Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [System.String]
        $Name,

        [Parameter(ParameterSetName = 'ServerObjectSet')]
        [System.Management.Automation.SwitchParameter]
        $Refresh,

        [Parameter(ParameterSetName = 'DatabaseObjectSet', Mandatory = $true, ValueFromPipeline = $true)]
        [Microsoft.SqlServer.Management.Smo.Database]
        $DatabaseObject,

        # Boolean Properties
        [Parameter()]
        [System.Boolean]
        $AcceleratedRecoveryEnabled,

        [Parameter()]
        [System.Boolean]
        $ActiveDirectory,

        [Parameter()]
        [System.Boolean]
        $AnsiNullDefault,

        [Parameter()]
        [System.Boolean]
        $AnsiNullsEnabled,

        [Parameter()]
        [System.Boolean]
        $AnsiPaddingEnabled,

        [Parameter()]
        [System.Boolean]
        $AnsiWarningsEnabled,

        [Parameter()]
        [System.Boolean]
        $ArithmeticAbortEnabled,

        [Parameter()]
        [System.Boolean]
        $AutoClose,

        [Parameter()]
        [System.Boolean]
        $AutoCreateIncrementalStatisticsEnabled,

        [Parameter()]
        [System.Boolean]
        $AutoCreateStatisticsEnabled,

        [Parameter()]
        [System.Boolean]
        $AutoShrink,

        [Parameter()]
        [System.Boolean]
        $AutoUpdateStatisticsAsync,

        [Parameter()]
        [System.Boolean]
        $AutoUpdateStatisticsEnabled,

        [Parameter()]
        [System.Boolean]
        $BrokerEnabled,

        [Parameter()]
        [System.Boolean]
        $CaseSensitive,

        [Parameter()]
        [System.Boolean]
        $ChangeTrackingAutoCleanUp,

        [Parameter()]
        [System.Boolean]
        $ChangeTrackingEnabled,

        [Parameter()]
        [System.Boolean]
        $CloseCursorsOnCommitEnabled,

        [Parameter()]
        [System.Boolean]
        $ConcatenateNullYieldsNull,

        [Parameter()]
        [System.Boolean]
        $DatabaseOwnershipChaining,

        [Parameter()]
        [System.Boolean]
        $DataRetentionEnabled,

        [Parameter()]
        [System.Boolean]
        $DateCorrelationOptimization,

        [Parameter()]
        [System.Boolean]
        $DelayedDurability,

        [Parameter()]
        [System.Boolean]
        $EncryptionEnabled,

        [Parameter()]
        [System.Boolean]
        $HasDatabaseEncryptionKey,

        [Parameter()]
        [System.Boolean]
        $HasFileInCloud,

        [Parameter()]
        [System.Boolean]
        $HasMemoryOptimizedObjects,

        [Parameter()]
        [System.Boolean]
        $HonorBrokerPriority,

        [Parameter()]
        [System.Boolean]
        $IsAccessible,

        [Parameter()]
        [System.Boolean]
        $IsDatabaseSnapshot,

        [Parameter()]
        [System.Boolean]
        $IsDatabaseSnapshotBase,

        [Parameter()]
        [System.Boolean]
        $IsDbAccessAdmin,

        [Parameter()]
        [System.Boolean]
        $IsDbBackupOperator,

        [Parameter()]
        [System.Boolean]
        $IsDbDataReader,

        [Parameter()]
        [System.Boolean]
        $IsDbDataWriter,

        [Parameter()]
        [System.Boolean]
        $IsDbDdlAdmin,

        [Parameter()]
        [System.Boolean]
        $IsDbDenyDataReader,

        [Parameter()]
        [System.Boolean]
        $IsDbDenyDataWriter,

        [Parameter()]
        [System.Boolean]
        $IsDbManager,

        [Parameter()]
        [System.Boolean]
        $IsDbOwner,

        [Parameter()]
        [System.Boolean]
        $IsDbSecurityAdmin,

        [Parameter()]
        [System.Boolean]
        $IsFabricDatabase,

        [Parameter()]
        [System.Boolean]
        $IsFullTextEnabled,

        [Parameter()]
        [System.Boolean]
        $IsLedger,

        [Parameter()]
        [System.Boolean]
        $IsLoginManager,

        [Parameter()]
        [System.Boolean]
        $IsMailHost,

        [Parameter()]
        [System.Boolean]
        $IsManagementDataWarehouse,

        [Parameter()]
        [System.Boolean]
        $IsMaxSizeApplicable,

        [Parameter()]
        [System.Boolean]
        $IsMirroringEnabled,

        [Parameter()]
        [System.Boolean]
        $IsParameterizationForced,

        [Parameter()]
        [System.Boolean]
        $IsReadCommittedSnapshotOn,

        [Parameter()]
        [System.Boolean]
        $IsSqlDw,

        [Parameter()]
        [System.Boolean]
        $IsSqlDwEdition,

        [Parameter()]
        [System.Boolean]
        $IsSystemObject,

        [Parameter()]
        [System.Boolean]
        $IsVarDecimalStorageFormatEnabled,

        [Parameter()]
        [System.Boolean]
        $IsVarDecimalStorageFormatSupported,

        [Parameter()]
        [System.Boolean]
        $LegacyCardinalityEstimation,

        [Parameter()]
        [System.Boolean]
        $LegacyCardinalityEstimationForSecondary,

        [Parameter()]
        [System.Boolean]
        $LocalCursorsDefault,

        [Parameter()]
        [System.Boolean]
        $NestedTriggersEnabled,

        [Parameter()]
        [System.Boolean]
        $NumericRoundAbortEnabled,

        [Parameter()]
        [System.Boolean]
        $ParameterSniffing,

        [Parameter()]
        [System.Boolean]
        $ParameterSniffingForSecondary,

        [Parameter()]
        [System.Boolean]
        $QueryOptimizerHotfixes,

        [Parameter()]
        [System.Boolean]
        $QueryOptimizerHotfixesForSecondary,

        [Parameter()]
        [System.Boolean]
        $QuotedIdentifiersEnabled,

        [Parameter()]
        [System.Boolean]
        $ReadOnly,

        [Parameter()]
        [System.Boolean]
        $RecursiveTriggersEnabled,

        [Parameter()]
        [System.Boolean]
        $RemoteDataArchiveEnabled,

        [Parameter()]
        [System.Boolean]
        $RemoteDataArchiveUseFederatedServiceAccount,

        [Parameter()]
        [System.Boolean]
        $TemporalHistoryRetentionEnabled,

        [Parameter()]
        [System.Boolean]
        $TransformNoiseWords,

        [Parameter()]
        [System.Boolean]
        $Trustworthy,

        [Parameter()]
        [System.Boolean]
        $WarnOnRename,

        # Integer Properties
        [Parameter()]
        [System.Int32]
        $ActiveConnections,

        [Parameter()]
        [System.Int32]
        $ChangeTrackingRetentionPeriod,

        [Parameter()]
        [System.Int32]
        $DefaultFullTextLanguage,

        [Parameter()]
        [System.Int32]
        $DefaultLanguage,

        [Parameter()]
        [System.Int32]
        $ID,

        [Parameter()]
        [System.Int32]
        $MaxDop,

        [Parameter()]
        [System.Int32]
        $MaxDopForSecondary,

        [Parameter()]
        [System.Int32]
        $MirroringRedoQueueMaxSize,

        [Parameter()]
        [System.Int32]
        $MirroringRoleSequence,

        [Parameter()]
        [System.Int32]
        $MirroringSafetySequence,

        [Parameter()]
        [System.Int32]
        $MirroringTimeout,

        [Parameter()]
        [System.Int32]
        $TargetRecoveryTime,

        [Parameter()]
        [System.Int32]
        $TwoDigitYearCutoff,

        [Parameter()]
        [System.Int32]
        $Version,

        # Long Integer Properties
        [Parameter()]
        [System.Int64]
        $IndexSpaceUsage,

        [Parameter()]
        [System.Int64]
        $MaxSizeInBytes,

        [Parameter()]
        [System.Int64]
        $MemoryAllocatedToMemoryOptimizedObjectsInKB,

        [Parameter()]
        [System.Int64]
        $MemoryUsedByMemoryOptimizedObjectsInKB,

        [Parameter()]
        [System.Int64]
        $MirroringFailoverLogSequenceNumber,

        [Parameter()]
        [System.Int64]
        $PersistentVersionStoreSizeKB,

        [Parameter()]
        [System.Int64]
        $SpaceAvailable,

        # Double Properties
        [Parameter()]
        [System.Double]
        $Size,

        # String Properties
        [Parameter()]
        [System.String]
        $AvailabilityGroupName,

        [Parameter()]
        [System.String]
        $AzureServiceObjective,

        [Parameter()]
        [System.String]
        $CatalogCollation,

        [Parameter()]
        [System.String]
        $Collation,

        [Parameter()]
        [System.String]
        $DboLogin,

        [Parameter()]
        [System.String]
        $DefaultFileGroup,

        [Parameter()]
        [System.String]
        $DefaultFileStreamFileGroup,

        [Parameter()]
        [System.String]
        $DefaultFullTextCatalog,

        [Parameter()]
        [System.String]
        $DefaultSchema,

        [Parameter()]
        [System.String]
        $FilestreamDirectoryName,

        [Parameter()]
        [System.String]
        $MirroringPartner,

        [Parameter()]
        [System.String]
        $MirroringPartnerInstance,

        [Parameter()]
        [System.String]
        $MirroringWitness,

        [Parameter()]
        [System.String]
        $Owner,

        [Parameter()]
        [System.String]
        $PersistentVersionStoreFileGroup,

        [Parameter()]
        [System.String]
        $PrimaryFilePath,

        [Parameter()]
        [System.String]
        $RemoteDataArchiveCredential,

        [Parameter()]
        [System.String]
        $RemoteDataArchiveEndpoint,

        [Parameter()]
        [System.String]
        $RemoteDataArchiveLinkedServer,

        [Parameter()]
        [System.String]
        $RemoteDatabaseName,

        [Parameter()]
        [System.String]
        $UserName,

        [Parameter()]
        [System.String]
        $AzureEdition,

        # DateTime Properties
        [Parameter()]
        [System.DateTime]
        $CreateDate,

        [Parameter()]
        [System.DateTime]
        $LastBackupDate,

        [Parameter()]
        [System.DateTime]
        $LastDifferentialBackupDate,

        [Parameter()]
        [System.DateTime]
        $LastGoodCheckDbTime,

        [Parameter()]
        [System.DateTime]
        $LastLogBackupDate,

        # GUID Properties
        [Parameter()]
        [System.Guid]
        $DatabaseGuid,

        [Parameter()]
        [System.Guid]
        $MirroringID,

        [Parameter()]
        [System.Guid]
        $RecoveryForkGuid,

        [Parameter()]
        [System.Guid]
        $ServiceBrokerGuid,

        # Enum Properties (as strings for simplicity)
        [Parameter()]
        [Microsoft.SqlServer.Management.Smo.AvailabilityDatabaseSynchronizationState]
        $AvailabilityDatabaseSynchronizationState,

        [Parameter()]
        [Microsoft.SqlServer.Management.Smo.RetentionPeriodUnits]
        $ChangeTrackingRetentionPeriodUnits,

        [Parameter()]
        [Microsoft.SqlServer.Management.Smo.CompatibilityLevel]
        $CompatibilityLevel,

        [Parameter()]
        [Microsoft.SqlServer.Management.Smo.ContainmentType]
        $ContainmentType,

        [Parameter()]
        [Microsoft.SqlServer.Management.Common.DatabaseEngineEdition]
        $DatabaseEngineEdition,

        [Parameter()]
        [Microsoft.SqlServer.Management.Common.DatabaseEngineType]
        $DatabaseEngineType,

        [Parameter()]
        [Microsoft.SqlServer.Management.Smo.FilestreamNonTransactedAccessType]
        $FilestreamNonTransactedAccess,

        [Parameter()]
        [Microsoft.SqlServer.Management.Smo.LogReuseWaitStatus]
        $LogReuseWaitStatus,

        [Parameter()]
        [Microsoft.SqlServer.Management.Smo.MirroringSafetyLevel]
        $MirroringSafetyLevel,

        [Parameter()]
        [Microsoft.SqlServer.Management.Smo.MirroringStatus]
        $MirroringStatus,

        [Parameter()]
        [Microsoft.SqlServer.Management.Smo.MirroringWitnessStatus]
        $MirroringWitnessStatus,

        [Parameter()]
        [Microsoft.SqlServer.Management.Smo.PageVerify]
        $PageVerify,

        [Parameter()]
        [Microsoft.SqlServer.Management.Smo.RecoveryModel]
        $RecoveryModel,

        [Parameter()]
        [Microsoft.SqlServer.Management.Smo.ReplicationOptions]
        $ReplicationOptions,

        [Parameter()]
        [Microsoft.SqlServer.Management.Smo.SnapshotIsolationState]
        $SnapshotIsolationState,

        [Parameter()]
        [Microsoft.SqlServer.Management.Smo.SqlSmoState]
        $State,

        [Parameter()]
        [Microsoft.SqlServer.Management.Smo.DatabaseStatus]
        $Status,

        [Parameter()]
        [Microsoft.SqlServer.Management.Smo.DatabaseUserAccess]
        $UserAccess
    )

    process
    {
        # Get the database object based on the parameter set
        switch ($PSCmdlet.ParameterSetName)
        {
            'ServerObjectSet'
            {
                Write-Verbose -Message ($script:localizedData.DatabaseProperty_TestingProperties -f $Name, $ServerObject.InstanceName)

                $previousErrorActionPreference = $ErrorActionPreference
                $ErrorActionPreference = 'Stop'
                $sqlDatabaseObject = $ServerObject | Get-SqlDscDatabase -Name $Name -Refresh:$Refresh -ErrorAction 'Stop'
                $ErrorActionPreference = $previousErrorActionPreference
            }

            'DatabaseObjectSet'
            {
                Write-Verbose -Message ($script:localizedData.DatabaseProperty_TestingPropertiesFromObject -f $DatabaseObject.Name, $DatabaseObject.Parent.InstanceName)

                $sqlDatabaseObject = $DatabaseObject
            }
        }

        $isInDesiredState = $true

        # Remove common parameters and function-specific parameters, leaving only database properties
        $boundParameters = Remove-CommonParameter -Hashtable $PSBoundParameters

        # Remove function-specific parameters
        foreach ($parameterToRemove in @('ServerObject', 'Name', 'DatabaseObject', 'Refresh'))
        {
            $boundParameters.Remove($parameterToRemove)
        }

        # Test each specified property
        foreach ($parameterName in $boundParameters.Keys)
        {
            if ($sqlDatabaseObject.PSObject.Properties.Name -notcontains $parameterName)
            {
                Write-Error -Message ($script:localizedData.DatabaseProperty_PropertyNotFound -f $parameterName, $sqlDatabaseObject.Name) -Category 'InvalidArgument' -ErrorId 'TSDDP0001' -TargetObject $parameterName
                continue
            }

            $expectedValue = $boundParameters.$parameterName
            $actualValue = $sqlDatabaseObject.$parameterName

            # Use a robust comparison that handles empty strings, nulls, and different types
            $valuesMatch = $false

            # Check if both values are null or empty strings (treat them as equivalent)
            $actualIsNullOrEmpty = [System.String]::IsNullOrEmpty($actualValue)
            $expectedIsNullOrEmpty = [System.String]::IsNullOrEmpty($expectedValue)

            if ($actualIsNullOrEmpty -and $expectedIsNullOrEmpty)
            {
                # Both are null or empty, consider them equal
                $valuesMatch = $true
            }
            elseif ($actualIsNullOrEmpty -or $expectedIsNullOrEmpty)
            {
                # One is null/empty and the other is not
                $valuesMatch = $false
            }
            else
            {
                # Both have values, compare them directly
                $valuesMatch = $actualValue -eq $expectedValue
            }

            if (-not $valuesMatch)
            {
                Write-Verbose -Message ($script:localizedData.DatabaseProperty_PropertyWrong -f $sqlDatabaseObject.Name, $parameterName, $actualValue, $expectedValue)
                $isInDesiredState = $false
            }
            else
            {
                Write-Verbose -Message ($script:localizedData.DatabaseProperty_PropertyCorrect -f $sqlDatabaseObject.Name, $parameterName, $actualValue)
            }
        }

        return $isInDesiredState
    }
}
#EndRegion '.\Public\Test-SqlDscDatabaseProperty.ps1' 1198
#Region '.\Public\Test-SqlDscIsAgentAlert.ps1' -1

<#
    .SYNOPSIS
        Tests if a SQL Agent Alert exists.

    .DESCRIPTION
        This command tests if a SQL Agent Alert exists on a SQL Server Database Engine
        instance.

    .PARAMETER ServerObject
        Specifies current server connection object.

    .PARAMETER Name
        Specifies the name of the SQL Agent Alert to test.

    .INPUTS
        Microsoft.SqlServer.Management.Smo.Server

        SQL Server Database Engine instance object.

    .OUTPUTS
        [System.Boolean]

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine -InstanceName 'MyInstance'
        Test-SqlDscIsAgentAlert -ServerObject $serverObject -Name 'MyAlert'

        Tests if the SQL Agent Alert named 'MyAlert' exists.

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine -InstanceName 'MyInstance'
        $serverObject | Test-SqlDscIsAgentAlert -Name 'MyAlert'

        Tests if the SQL Agent Alert named 'MyAlert' exists using pipeline input.
#>
function Test-SqlDscIsAgentAlert
{
    [System.Diagnostics.CodeAnalysis.SuppressMessageAttribute('UseSyntacticallyCorrectExamples', '', Justification = 'Because the rule does not yet support parsing the code when a parameter type is not available. The ScriptAnalyzer rule UseSyntacticallyCorrectExamples will always error in the editor due to https://github.com/indented-automation/Indented.ScriptAnalyzerRules/issues/8.')]
    [Alias('Test-SqlDscAgentAlert')]
    [CmdletBinding()]
    [OutputType([System.Boolean])]
    param
    (
        [Parameter(Mandatory = $true, ValueFromPipeline = $true)]
        [Microsoft.SqlServer.Management.Smo.Server]
        $ServerObject,

        [Parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [System.String]
        $Name
    )

    process
    {
        Write-Verbose -Message ($script:localizedData.Test_SqlDscIsAgentAlert_TestingAlert -f $Name)

        $alertObject = Get-AgentAlertObject -ServerObject $ServerObject -Name $Name -ErrorAction 'SilentlyContinue'

        if ($null -eq $alertObject)
        {
            Write-Verbose -Message ($script:localizedData.Test_SqlDscIsAgentAlert_AlertNotFound -f $Name)

            return $false
        }

        Write-Verbose -Message ($script:localizedData.Test_SqlDscIsAgentAlert_AlertFound -f $Name)

        return $true
    }
}
#EndRegion '.\Public\Test-SqlDscIsAgentAlert.ps1' 71
#Region '.\Public\Test-SqlDscIsAgentOperator.ps1' -1

<#
    .SYNOPSIS
        Tests for the existence of a SQL Agent Operator.

    .DESCRIPTION
        This command tests if a SQL Agent Operator exists on a SQL Server Database Engine instance.

    .PARAMETER ServerObject
        Specifies current server connection object.

    .PARAMETER Name
        Specifies the name of the SQL Agent Operator to test.

    .PARAMETER Refresh
        Specifies that the **ServerObject**'s operators should be refreshed before
        testing the operator. This is helpful when operators could have
        been modified outside of the **ServerObject**, for example through T-SQL.
        But on instances with a large amount of operators it might be better to make
        sure the **ServerObject** is recent enough.

    .INPUTS
        Microsoft.SqlServer.Management.Smo.Server

        SQL Server Database Engine instance object.

    .OUTPUTS
        System.Boolean

        Returns $true if the operator exists, $false otherwise.

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine -InstanceName 'MyInstance'
        Test-SqlDscIsAgentOperator -ServerObject $serverObject -Name 'MyOperator'

        Tests if the SQL Agent Operator named 'MyOperator' exists.

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine -InstanceName 'MyInstance'
        $serverObject | Test-SqlDscIsAgentOperator -Name 'MyOperator'

        Tests if the SQL Agent Operator named 'MyOperator' exists using pipeline input.

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine -InstanceName 'MyInstance'
        $serverObject | Test-SqlDscIsAgentOperator -Name 'MyOperator' -Refresh

        Refreshes the server operators collection before testing if **MyOperator** exists.
#>
function Test-SqlDscIsAgentOperator
{
    [System.Diagnostics.CodeAnalysis.SuppressMessageAttribute('UseSyntacticallyCorrectExamples', '', Justification = 'Because the rule does not yet support parsing the code when a parameter type is not available. The ScriptAnalyzer rule UseSyntacticallyCorrectExamples will always error in the editor due to https://github.com/indented-automation/Indented.ScriptAnalyzerRules/issues/8.')]
    [CmdletBinding()]
    [OutputType([System.Boolean])]
    param
    (
        [Parameter(Mandatory = $true, ValueFromPipeline = $true)]
        [Microsoft.SqlServer.Management.Smo.Server]
        $ServerObject,

        [Parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [System.String]
        $Name,

        [Parameter()]
        [System.Management.Automation.SwitchParameter]
        $Refresh
    )

    # cSpell: ignore TISAO
    process
    {
        Write-Verbose -Message ($script:localizedData.Test_SqlDscIsAgentOperator_TestingOperator -f $Name)

        $operatorObject = Get-AgentOperatorObject -ServerObject $ServerObject -Name $Name -Refresh:$Refresh -ErrorAction 'SilentlyContinue'

        if (-not $operatorObject)
        {
            Write-Verbose -Message ($script:localizedData.Test_SqlDscIsAgentOperator_OperatorNotFound -f $Name)
            return $false
        }

        Write-Verbose -Message ($script:localizedData.Test_SqlDscIsAgentOperator_OperatorFound -f $Name)

        return $true
    }
}
#EndRegion '.\Public\Test-SqlDscIsAgentOperator.ps1' 88
#Region '.\Public\Test-SqlDscIsDatabase.ps1' -1

<#
    .SYNOPSIS
        Tests if a database exists on a SQL Server Database Engine instance.

    .DESCRIPTION
        This command tests if a database exists on a SQL Server Database Engine instance.

    .PARAMETER ServerObject
        Specifies current server connection object.

    .PARAMETER Name
        Specifies the name of the database to test for existence.

    .PARAMETER Refresh
        Specifies that the **ServerObject**'s databases should be refreshed before
        testing the database existence. This is helpful when databases could have been
        modified outside of the **ServerObject**, for example through T-SQL. But
        on instances with a large amount of databases it might be better to make
        sure the **ServerObject** is recent enough.

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine -InstanceName 'MyInstance'
        $serverObject | Test-SqlDscIsDatabase -Name 'MyDatabase'

        Tests if the database named **MyDatabase** exists on the instance.

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine -InstanceName 'MyInstance'
        Test-SqlDscIsDatabase -ServerObject $serverObject -Name 'MyDatabase' -Refresh

        Tests if the database named **MyDatabase** exists on the instance, refreshing
        the server object's databases collection first.

    .OUTPUTS
        `[System.Boolean]`

        Returns `$true` if the target object is a database; otherwise, `$false`.

    .INPUTS
        `[Microsoft.SqlServer.Management.Smo.Server]`

        The server object can be provided via the pipeline to **ServerObject**.
#>
function Test-SqlDscIsDatabase
{
    [System.Diagnostics.CodeAnalysis.SuppressMessageAttribute('UseSyntacticallyCorrectExamples', '', Justification = 'Because the rule does not yet support parsing the code when a parameter type is not available. The ScriptAnalyzer rule UseSyntacticallyCorrectExamples will always error in the editor due to https://github.com/indented-automation/Indented.ScriptAnalyzerRules/issues/8.')]
    [OutputType([System.Boolean])]
    [CmdletBinding()]
    param
    (
        [Parameter(Mandatory = $true, ValueFromPipeline = $true)]
        [Microsoft.SqlServer.Management.Smo.Server]
        $ServerObject,

        [Parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [System.String]
        $Name,

        [Parameter()]
        [System.Management.Automation.SwitchParameter]
        $Refresh
    )

    process
    {
        Write-Verbose -Message ($script:localizedData.IsDatabase_Test -f $Name, $ServerObject.InstanceName)

        # Check if database exists using Get-SqlDscDatabase
        $sqlDatabaseObject = Get-SqlDscDatabase -ServerObject $ServerObject -Name $Name -Refresh:$Refresh -ErrorAction 'SilentlyContinue'

        if ($sqlDatabaseObject)
        {
            return $true
        }
        else
        {
            return $false
        }
    }
}
#EndRegion '.\Public\Test-SqlDscIsDatabase.ps1' 82
#Region '.\Public\Test-SqlDscIsDatabasePrincipal.ps1' -1

<#
    .SYNOPSIS
        Returns whether the database principal exist.

    .DESCRIPTION
        Returns whether the database principal exist.

    .PARAMETER ServerObject
        Specifies current server connection object.

    .PARAMETER DatabaseName
        Specifies the SQL database name.

    .PARAMETER Name
        Specifies the name of the database principal.

    .PARAMETER ExcludeUsers
        Specifies that database users should not be evaluated.

    .PARAMETER ExcludeRoles
        Specifies that database roles should not be evaluated for the specified
        name. This will also exclude fixed roles.

    .PARAMETER ExcludeFixedRoles
        Specifies that fixed roles should not be evaluated for the specified name.

    .PARAMETER ExcludeApplicationRoles
        Specifies that fixed application roles should not be evaluated for the
        specified name.

    .PARAMETER Refresh
        Specifies that the database's principal collections (Users, Roles, and
        ApplicationRoles) should be refreshed before testing if the principal exists.
        This is helpful when principals could have been modified outside of the
        **ServerObject**, for example through T-SQL. But on databases with a large
        amount of principals it might be better to make sure the **ServerObject**
        is recent enough. When exclude parameters are specified (e.g., **ExcludeUsers**,
        **ExcludeRoles**, **ExcludeApplicationRoles**), only the collections that will
        be used are refreshed to improve performance.

    .OUTPUTS
        [System.Boolean]

    .EXAMPLE
        $serverInstance = Connect-SqlDscDatabaseEngine
        Test-SqlDscIsDatabasePrincipal -ServerObject $serverInstance -DatabaseName 'MyDatabase' -Name 'MyPrincipal'

        Returns $true if the principal exist in the database, if not $false is returned.

    .EXAMPLE
        $serverInstance = Connect-SqlDscDatabaseEngine
        Test-SqlDscIsDatabasePrincipal -ServerObject $serverInstance -DatabaseName 'MyDatabase' -Name 'MyPrincipal' -ExcludeUsers

        Returns $true if the principal exist in the database and is not a user, if not $false is returned.

    .EXAMPLE
        $serverInstance = Connect-SqlDscDatabaseEngine
        Test-SqlDscIsDatabasePrincipal -ServerObject $serverInstance -DatabaseName 'MyDatabase' -Name 'MyPrincipal' -ExcludeRoles

        Returns $true if the principal exist in the database and is not a role, if not $false is returned.

    .EXAMPLE
        $serverInstance = Connect-SqlDscDatabaseEngine
        Test-SqlDscIsDatabasePrincipal -ServerObject $serverInstance -DatabaseName 'MyDatabase' -Name 'MyPrincipal' -ExcludeFixedRoles

        Returns $true if the principal exist in the database and is not a fixed role, if not $false is returned.

    .EXAMPLE
        $serverInstance = Connect-SqlDscDatabaseEngine
        Test-SqlDscIsDatabasePrincipal -ServerObject $serverInstance -DatabaseName 'MyDatabase' -Name 'MyPrincipal' -ExcludeApplicationRoles

        Returns $true if the principal exist in the database and is not a application role, if not $false is returned.

    .EXAMPLE
        $serverInstance = Connect-SqlDscDatabaseEngine
        Test-SqlDscIsDatabasePrincipal -ServerObject $serverInstance -DatabaseName 'MyDatabase' -Name 'MyPrincipal' -Refresh

        Returns $true if the principal exist in the database, if not $false is returned.
        The database's principal collections are refreshed before testing.
#>
function Test-SqlDscIsDatabasePrincipal
{
    [System.Diagnostics.CodeAnalysis.SuppressMessageAttribute('UseSyntacticallyCorrectExamples', '', Justification = 'Because the rule does not yet support parsing the code when a parameter type is not available. The ScriptAnalyzer rule UseSyntacticallyCorrectExamples will always error in the editor due to https://github.com/indented-automation/Indented.ScriptAnalyzerRules/issues/8.')]
    [CmdletBinding()]
    [OutputType([System.Boolean])]
    param
    (
        [Parameter(Mandatory = $true, ValueFromPipeline = $true)]
        [Microsoft.SqlServer.Management.Smo.Server]
        $ServerObject,

        [Parameter(Mandatory = $true)]
        [System.String]
        $DatabaseName,

        [Parameter(Mandatory = $true)]
        [System.String]
        $Name,

        [Parameter()]
        [System.Management.Automation.SwitchParameter]
        $ExcludeUsers,

        [Parameter()]
        [System.Management.Automation.SwitchParameter]
        $ExcludeRoles,

        [Parameter()]
        [System.Management.Automation.SwitchParameter]
        $ExcludeFixedRoles,

        [Parameter()]
        [System.Management.Automation.SwitchParameter]
        $ExcludeApplicationRoles,

        [Parameter()]
        [System.Management.Automation.SwitchParameter]
        $Refresh
    )

    process
    {
        $principalExist = $false

        if ($Refresh.IsPresent)
        {
            # Refresh the server's databases collection to ensure we have current data
            $ServerObject.Databases.Refresh()
        }

        $sqlDatabaseObject = $ServerObject.Databases[$DatabaseName]

        if ($Refresh.IsPresent -and $sqlDatabaseObject)
        {
            # Refresh the database object's collections to ensure we have current data
            # Only refresh collections that will be used based on exclude parameters
            if (-not $ExcludeRoles.IsPresent)
            {
                $sqlDatabaseObject.Roles.Refresh()
            }

            if (-not $ExcludeUsers.IsPresent)
            {
                $sqlDatabaseObject.Users.Refresh()
            }

            if (-not $ExcludeApplicationRoles.IsPresent)
            {
                $sqlDatabaseObject.ApplicationRoles.Refresh()
            }
        }

        if (-not $sqlDatabaseObject)
        {
            $PSCmdlet.ThrowTerminatingError(
                [System.Management.Automation.ErrorRecord]::new(
                    ($script:localizedData.IsDatabasePrincipal_DatabaseMissing -f $DatabaseName),
                    'TSDISO0001', # cSpell: disable-line
                    [System.Management.Automation.ErrorCategory]::InvalidOperation,
                    $DatabaseName
                )
            )
        }

        if (-not $ExcludeUsers.IsPresent -and $sqlDatabaseObject.Users[$Name])
        {
            $principalExist = $true
        }

        if (-not $ExcludeRoles.IsPresent)
        {
            $userDefinedRole = if ($ExcludeFixedRoles.IsPresent)
            {
                # Skip fixed roles like db_datareader.
                $sqlDatabaseObject.Roles | Where-Object -FilterScript {
                    -not $_.IsFixedRole -and $_.Name -eq $Name
                }
            }
            else
            {
                $sqlDatabaseObject.Roles[$Name]
            }

            if ($userDefinedRole)
            {
                $principalExist = $true
            }
        }

        if (-not $ExcludeApplicationRoles.IsPresent -and $sqlDatabaseObject.ApplicationRoles[$Name])
        {
            $principalExist = $true
        }

        return $principalExist
    }
}
#EndRegion '.\Public\Test-SqlDscIsDatabasePrincipal.ps1' 198
#Region '.\Public\Test-SqlDscIsLogin.ps1' -1

<#
    .SYNOPSIS
        Returns whether the server principal exist and is a login.

    .DESCRIPTION
        Returns whether the server principal exist and is a login.

    .PARAMETER ServerObject
        Specifies current server connection object.

    .PARAMETER Name
        Specifies the name of the server principal.

    .OUTPUTS
        [System.Boolean]

    .EXAMPLE
        $serverInstance = Connect-SqlDscDatabaseEngine
        Test-SqlDscIsLogin -ServerObject $serverInstance -Name 'MyPrincipal'

        Returns $true if the principal exist as a login, if not $false is returned.
#>
function Test-SqlDscIsLogin
{
    [System.Diagnostics.CodeAnalysis.SuppressMessageAttribute('UseSyntacticallyCorrectExamples', '', Justification = 'Because the rule does not yet support parsing the code when a parameter type is not available. The ScriptAnalyzer rule UseSyntacticallyCorrectExamples will always error in the editor due to https://github.com/indented-automation/Indented.ScriptAnalyzerRules/issues/8.')]
    [CmdletBinding()]
    [OutputType([System.Boolean])]
    param
    (
        [Parameter(Mandatory = $true, ValueFromPipeline = $true)]
        [Microsoft.SqlServer.Management.Smo.Server]
        $ServerObject,

        [Parameter(Mandatory = $true)]
        [System.String]
        $Name
    )

    process
    {
        $loginExist = $false

        if ($ServerObject.Logins[$Name])
        {
            $loginExist = $true
        }

        return $loginExist
    }
}
#EndRegion '.\Public\Test-SqlDscIsLogin.ps1' 51
#Region '.\Public\Test-SqlDscIsLoginEnabled.ps1' -1

<#
    .SYNOPSIS
        Returns whether the server login is enabled or disabled.

    .DESCRIPTION
        Tests the state of a SQL Server login and returns a Boolean result.
        When a Server object is provided, the login is resolved using
        Get-SqlDscLogin (optionally refreshing the server logins first).
        When a Login object is provided, its current state is evaluated directly.
    .PARAMETER ServerObject
        Specifies current server connection object.

    .PARAMETER LoginObject
        Specifies a login object to test.

    .PARAMETER Name
        Specifies the name of the server login to test.

    .PARAMETER Refresh
        Specifies that the **ServerObject**'s logins should be refreshed before
        trying to test the login object. This is helpful when logins could have
        been modified outside of the **ServerObject**, for example through T-SQL.
        But on instances with a large amount of logins it might be better to make
        sure the **ServerObject** is recent enough, or pass in **LoginObject**.

    .INPUTS
        [Microsoft.SqlServer.Management.Smo.Server]

        Server object accepted from the pipeline.

        [Microsoft.SqlServer.Management.Smo.Login]

        Login object accepted from the pipeline.

    .OUTPUTS
        [System.Boolean]

        Returns $true if the login is enabled, $false if the login is disabled.

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine -InstanceName 'MyInstance'
        Test-SqlDscIsLoginEnabled -ServerObject $serverObject -Name 'MyLogin'

        Returns $true if the login is enabled, if not $false is returned.

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine -InstanceName 'MyInstance'
        $loginObject = $serverObject | Get-SqlDscLogin -Name 'MyLogin'
        Test-SqlDscIsLoginEnabled -LoginObject $loginObject

        Returns $true if the login is enabled, if not $false is returned.

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine -InstanceName 'MyInstance'
        $result = $serverObject | Test-SqlDscIsLoginEnabled -Name 'MyLogin'

        Demonstrates pipeline usage with ServerObject. Returns $true if the login is enabled, if not $false is returned.

    .EXAMPLE
        $serverObject = Connect-SqlDscDatabaseEngine -InstanceName 'MyInstance'
        $loginObject = $serverObject | Get-SqlDscLogin -Name 'MyLogin'
        $result = $loginObject | Test-SqlDscIsLoginEnabled

        Demonstrates pipeline usage with LoginObject. Returns $true if the login is enabled, if not $false is returned.
#>
function Test-SqlDscIsLoginEnabled
{
    [System.Diagnostics.CodeAnalysis.SuppressMessageAttribute('UseSyntacticallyCorrectExamples', '', Justification = 'Because the rule does not yet support parsing the code when a parameter type is not available. The ScriptAnalyzer rule UseSyntacticallyCorrectExamples will always error in the editor due to https://github.com/indented-automation/Indented.ScriptAnalyzerRules/issues/8.')]
    [CmdletBinding()]
    [OutputType([System.Boolean])]
    param
    (
        [Parameter(ParameterSetName = 'ServerObject', Mandatory = $true, ValueFromPipeline = $true)]
        [Microsoft.SqlServer.Management.Smo.Server]
        $ServerObject,

        [Parameter(ParameterSetName = 'LoginObject', Mandatory = $true, ValueFromPipeline = $true)]
        [Microsoft.SqlServer.Management.Smo.Login]
        $LoginObject,

        [Parameter(ParameterSetName = 'ServerObject', Mandatory = $true)]
        [System.String]
        $Name,

        [Parameter(ParameterSetName = 'ServerObject')]
        [System.Management.Automation.SwitchParameter]
        $Refresh
    )

    process
    {
        if ($PSCmdlet.ParameterSetName -eq 'ServerObject')
        {
            $getSqlDscLoginParameters = @{
                ServerObject = $ServerObject
                Name         = $Name
                Refresh      = $Refresh
                ErrorAction  = 'Stop'
            }

            # If this command does not find the login it will throw an exception.
            $loginObjectArray = Get-SqlDscLogin @getSqlDscLoginParameters

            # Pick the only object in the array.
            $LoginObject = $loginObjectArray
        }

        $loginEnabled = -not $LoginObject.IsDisabled

        return $loginEnabled
    }
}
#EndRegion '.\Public\Test-SqlDscIsLoginEnabled.ps1' 113
#Region '.\Public\Test-SqlDscIsRole.ps1' -1

<#
    .SYNOPSIS
        Returns whether the server principal exists and is a server role.

    .DESCRIPTION
        Returns whether the server principal exist and is a server role.

    .PARAMETER ServerObject
        Specifies current server connection object.

    .PARAMETER Name
        Specifies the name of the server principal.

    .OUTPUTS
        [System.Boolean]

    .EXAMPLE
        $serverInstance = Connect-SqlDscDatabaseEngine
        Test-SqlDscIsRole -ServerObject $serverInstance -Name 'MyPrincipal'

        Returns $true if the principal exist as a server role, if not $false is returned.
#>
function Test-SqlDscIsRole
{
    [System.Diagnostics.CodeAnalysis.SuppressMessageAttribute('UseSyntacticallyCorrectExamples', '', Justification = 'Because the rule does not yet support parsing the code when a parameter type is not available. The ScriptAnalyzer rule UseSyntacticallyCorrectExamples will always error in the editor due to https://github.com/indented-automation/Indented.ScriptAnalyzerRules/issues/8.')]
    [CmdletBinding()]
    [OutputType([System.Boolean])]
    param
    (
        [Parameter(Mandatory = $true, ValueFromPipeline = $true)]
        [Microsoft.SqlServer.Management.Smo.Server]
        $ServerObject,

        [Parameter(Mandatory = $true)]
        [System.String]
        $Name
    )

    process
    {
        $principalExist = $false

        if ($ServerObject.Roles[$Name])
        {
            $principalExist = $true
        }

        return $principalExist
    }
}
#EndRegion '.\Public\Test-SqlDscIsRole.ps1' 51
#Region '.\Public\Test-SqlDscIsSupportedFeature.ps1' -1

<#
    .SYNOPSIS
        Tests that a feature is supported by a Microsoft SQL Server major version.

    .DESCRIPTION
        Tests that a feature is supported by a Microsoft SQL Server major version.

    .PARAMETER Feature
       Specifies the feature to evaluate.

    .PARAMETER ProductVersion
       Specifies the product version of the Microsoft SQL Server. At minimum the
       major version must be provided.

    .EXAMPLE
        Test-SqlDscIsSupportedFeature -Feature 'RS' -ProductVersion '13'

        Returns $true if the feature is supported.

    .OUTPUTS
        [System.Boolean]
#>
function Test-SqlDscIsSupportedFeature
{
    [OutputType([System.Boolean])]
    [CmdletBinding()]
    param
    (
        [Parameter(Mandatory = $true, ValueFromPipeline = $true)]
        [System.String]
        $Feature,

        [Parameter(Mandatory = $true)]
        [System.String]
        $ProductVersion
    )

    begin
    {
        $targetMajorVersion = ($ProductVersion -split '\.')[0]

        <#
            List of features that was removed from a specific major version (and later).
            Feature list: https://learn.microsoft.com/en-us/sql/database-engine/install-windows/install-sql-server-from-the-command-prompt#Feature
        #>
        $removedFeaturesPerMajorVersion = @{
            13 = @('ADV_SSMS', 'SSMS') # cSpell: disable-line
            14 = @('RS', 'RS_SHP', 'RS_SHPWFE') # cSpell: disable-line
            16 = @('Tools', 'BC', 'CONN', 'BC', 'DREPLAY_CTLR', 'DREPLAY_CLT', 'SNAC_SDK', 'SDK', 'PolyBaseJava', 'SQL_INST_MR', 'SQL_INST_MPY', 'SQL_SHARED_MPY', 'SQL_SHARED_MR') # cSpell: disable-line
        }

        <#
            List of features that was added to a specific major version.
            Feature list: https://learn.microsoft.com/en-us/sql/database-engine/install-windows/install-sql-server-from-the-command-prompt#Feature
        #>
        $addedFeaturesPerMajorVersion = @{
            13 = @('SQL_INST_MR', 'SQL_INST_MPY', 'SQL_INST_JAVA')
            15 = @('PolyBaseCore', 'PolyBaseJava', 'SQL_INST_JAVA') # cSpell: disable-line
        }

        # Evaluate features that was removed and are unsupported for the target's major version.
        $targetUnsupportedFeatures = $removedFeaturesPerMajorVersion.Keys |
            Where-Object -FilterScript {
                $_ -le $targetMajorVersion
            } |
            ForEach-Object -Process {
                $removedFeaturesPerMajorVersion.$_
            }

        <#
            Evaluate features that was added to higher major versions than the
            target's major version which will be unsupported for the target's
            major version.
        #>
        $targetUnsupportedFeatures += $addedFeaturesPerMajorVersion.Keys |
            Where-Object -FilterScript {
                $_ -gt $targetMajorVersion
            } |
            ForEach-Object -Process {
                $addedFeaturesPerMajorVersion.$_
            }

        $supported = $true
    }

    process
    {
        # This does case-insensitive match against the list of unsupported features.
        if ($targetUnsupportedFeatures -and $Feature -in $targetUnsupportedFeatures)
        {
            $supported = $false
        }
    }

    end
    {
        return $supported
    }
}
#EndRegion '.\Public\Test-SqlDscIsSupportedFeature.ps1' 100
#Region '.\Public\Test-SqlDscRSInstalled.ps1' -1

<#
    .SYNOPSIS
        Tests if a SQL Server Reporting Services or Power BI Report Server instance
        is installed.

    .DESCRIPTION
        Tests if a SQL Server Reporting Services or Power BI Report Server instance
        is installed on the local server. The command returns $true if the specified
        instance exists and $false if it does not.

    .PARAMETER InstanceName
        Specifies the name of the SQL Server Reporting Services or Power BI Report Server
        instance to check for. This parameter is required.

    .EXAMPLE
        Test-SqlDscRSInstalled -InstanceName 'SSRS'

        Tests if a SQL Server Reporting Services instance named 'SSRS' is installed.
        Returns $true if the instance exists and $false if it does not.

    .EXAMPLE
        Test-SqlDscRSInstalled -InstanceName 'PBIRS'

        Tests if a Power BI Report Server instance named 'PBIRS' is installed.
        Returns $true if the instance exists and $false if it does not.

    .OUTPUTS
        System.Boolean

        Returns $true if the specified instance exists and $false if it does not.
#>
function Test-SqlDscRSInstalled
{
    # cSpell: ignore PBIRS
    [CmdletBinding()]
    [OutputType([System.Boolean])]
    param
    (
        [Parameter(Mandatory = $true)]
        [System.String]
        $InstanceName
    )

    Write-Verbose -Message ($script:localizedData.Test_SqlDscRSInstalled_Checking -f $InstanceName)

    $reportingServices = Get-SqlDscRSSetupConfiguration -InstanceName $InstanceName -ErrorAction 'SilentlyContinue'

    if ($reportingServices)
    {
        Write-Verbose -Message ($script:localizedData.Test_SqlDscRSInstalled_Found -f $InstanceName)

        return $true
    }
    else
    {
        Write-Verbose -Message ($script:localizedData.Test_SqlDscRSInstalled_NotFound -f $InstanceName)

        return $false
    }
}
#EndRegion '.\Public\Test-SqlDscRSInstalled.ps1' 61
#Region '.\Public\Test-SqlDscServerPermission.ps1' -1

<#
    .SYNOPSIS
        Tests if server permissions for a principal are in the desired state.

    .DESCRIPTION
        This command tests if server permissions for an existing principal on a SQL Server
        Database Engine instance are in the desired state. The principal can be specified as either
        a Login object (from Get-SqlDscLogin) or a ServerRole object (from Get-SqlDscRole).

    .PARAMETER Login
        Specifies the Login object for which the permissions are tested.
        This parameter accepts pipeline input.

    .PARAMETER ServerRole
        Specifies the ServerRole object for which the permissions are tested.
        This parameter accepts pipeline input.

    .PARAMETER Grant
        Specifies that the test should verify if the permissions are granted to the principal.

    .PARAMETER Deny
        Specifies that the test should verify if the permissions are denied to the principal.

    .PARAMETER Permission
        Specifies the desired permissions. Specify multiple permissions by
        providing an array of SqlServerPermission enum values that should be present in the
        specified state. An empty collection can be specified to test that no permissions
        are set for the principal.

    .PARAMETER WithGrant
        Specifies that the principal should have the right to grant other principals
        the same permission. This parameter is only valid when parameter **Grant** is
        used. When this parameter is used, the effective state tested will
        be 'GrantWithGrant'.

    .PARAMETER ExactMatch
        Specifies that the test should verify that only the specified permissions
        are present and no additional permissions exist in the specified state.
        When this parameter is not used, the test will return true if the specified
        permissions are present, regardless of any additional permissions.

    .OUTPUTS
        [System.Boolean]

    .EXAMPLE
        $serverInstance = Connect-SqlDscDatabaseEngine
        $login = $serverInstance | Get-SqlDscLogin -Name 'MyLogin'

        $isInDesiredState = Test-SqlDscServerPermission -Login $login -Grant -Permission ConnectSql, ViewServerState

        Tests if the specified permissions are granted to the login 'MyLogin'.

    .EXAMPLE
        $serverInstance = Connect-SqlDscDatabaseEngine
        $role = $serverInstance | Get-SqlDscRole -Name 'MyRole'

        $isInDesiredState = $role | Test-SqlDscServerPermission -Grant -Permission AlterAnyDatabase -WithGrant

        Tests if the specified permissions are granted with grant option to the role 'MyRole'.

    .EXAMPLE
        $serverInstance = Connect-SqlDscDatabaseEngine
        $login = $serverInstance | Get-SqlDscLogin -Name 'MyLogin'

        $isInDesiredState = Test-SqlDscServerPermission -Login $login -Grant -Permission @()

        Tests if the login 'MyLogin' has no permissions granted (empty permission set).

    .NOTES
        The Login or ServerRole object must come from the same SQL Server instance
        where the permissions will be tested. If specifying `-ErrorAction 'SilentlyContinue'`
        then the command will silently continue if any errors occur. If specifying
        `-ErrorAction 'Stop'` the command will throw an error on any failure.
#>
function Test-SqlDscServerPermission
{
    [System.Diagnostics.CodeAnalysis.SuppressMessageAttribute('UseSyntacticallyCorrectExamples', '', Justification = 'Because the rule does not yet support parsing the code when a parameter type is not available. The ScriptAnalyzer rule UseSyntacticallyCorrectExamples will always error in the editor due to https://github.com/indented-automation/Indented.ScriptAnalyzerRules/issues/8.')]
    [System.Diagnostics.CodeAnalysis.SuppressMessageAttribute('AvoidThrowOutsideOfTry', '', Justification = 'Because the code throws based on an prior expression')]
    [CmdletBinding()]
    [OutputType([System.Boolean])]
    param
    (
        [Parameter(Mandatory = $true, ValueFromPipeline = $true, ParameterSetName = 'LoginGrant')]
        [Parameter(Mandatory = $true, ValueFromPipeline = $true, ParameterSetName = 'LoginDeny')]
        [Microsoft.SqlServer.Management.Smo.Login]
        $Login,

        [Parameter(Mandatory = $true, ValueFromPipeline = $true, ParameterSetName = 'ServerRoleGrant')]
        [Parameter(Mandatory = $true, ValueFromPipeline = $true, ParameterSetName = 'ServerRoleDeny')]
        [Microsoft.SqlServer.Management.Smo.ServerRole]
        $ServerRole,

        [Parameter(Mandatory = $true, ParameterSetName = 'LoginGrant')]
        [Parameter(Mandatory = $true, ParameterSetName = 'ServerRoleGrant')]
        [System.Management.Automation.SwitchParameter]
        $Grant,

        [Parameter(Mandatory = $true, ParameterSetName = 'LoginDeny')]
        [Parameter(Mandatory = $true, ParameterSetName = 'ServerRoleDeny')]
        [System.Management.Automation.SwitchParameter]
        $Deny,

        [Parameter(Mandatory = $true)]
        [AllowEmptyCollection()]
        [SqlServerPermission[]]
        $Permission,

        [Parameter(ParameterSetName = 'LoginGrant')]
        [Parameter(ParameterSetName = 'ServerRoleGrant')]
        [Parameter(ParameterSetName = 'LoginDeny')]
        [Parameter(ParameterSetName = 'ServerRoleDeny')]
        [System.Management.Automation.SwitchParameter]
        $WithGrant,

        [Parameter(ParameterSetName = 'LoginGrant')]
        [Parameter(ParameterSetName = 'ServerRoleGrant')]
        [Parameter(ParameterSetName = 'LoginDeny')]
        [Parameter(ParameterSetName = 'ServerRoleDeny')]
        [System.Management.Automation.SwitchParameter]
        $ExactMatch
    )

    process
    {
        # Determine which principal object we're working with
        if ($Login)
        {
            $principalName = $Login.Name
            $serverObject = $Login.Parent
        }
        else
        {
            $principalName = $ServerRole.Name
            $serverObject = $ServerRole.Parent
        }

        Write-Verbose -Message (
            $script:localizedData.ServerPermission_TestingDesiredState -f $principalName, $serverObject.InstanceName
        )

        try
        {
            # Determine the state based on the parameter set
            if ($Grant.IsPresent)
            {
                $evaluateState = 'Grant'
            }
            elseif ($Deny.IsPresent)
            {
                $evaluateState = 'Deny'
            }

            # Handle WithGrant parameter by adjusting the effective state
            if ($WithGrant.IsPresent -and $evaluateState -eq 'Grant')
            {
                $evaluateState = 'GrantWithGrant'
            }

            $originalErrorActionPreference = $ErrorActionPreference

            $ErrorActionPreference = 'Stop'

            # Get current permissions for the principal
            $getSqlDscServerPermissionParameters = @{
                ServerObject = $serverObject
                Name         = $principalName
                ErrorAction  = 'Stop'
            }

            $serverPermissionInfo = Get-SqlDscServerPermission @getSqlDscServerPermissionParameters

            $ErrorActionPreference = $originalErrorActionPreference

            if (-not $serverPermissionInfo)
            {
                Write-Debug -Message (
                    $script:localizedData.ServerPermission_Test_NoPermissionsFound -f $principalName
                )

                # If no permissions exist and none are desired, that's the desired state
                if ($Permission.Count -eq 0)
                {
                    return $true
                }
                else
                {
                    return $false
                }
            }

            # Convert current permissions to ServerPermission objects
            $currentPermissions = $serverPermissionInfo | ConvertTo-SqlDscServerPermission

            # Output verbose information about current permissions as compressed JSON
            $currentPermissionsJson = $currentPermissions | ConvertTo-Json -Compress

            Write-Debug -Message (
                $script:localizedData.ServerPermission_Test_CurrentPermissions -f $principalName, $currentPermissionsJson
            )

            # Handle empty Permission collection - check that no permissions are set
            if ($Permission.Count -eq 0)
            {
                # Check if there are any permissions set for any state
                $hasAnyPermissions = $currentPermissions | Where-Object -FilterScript {
                    $_.Permission.Count -gt 0
                }

                if ($hasAnyPermissions)
                {
                    return $false
                }
                else
                {
                    return $true
                }
            }

            # Find the current permission for the desired state
            $currentPermissionForState = $currentPermissions |
                Where-Object -FilterScript {
                    $_.State -eq $evaluateState
                }

            if (-not $currentPermissionForState)
            {
                return $false
            }

            # Check if all desired permissions are present in current state
            foreach ($permissionName in $Permission)
            {
                if ($permissionName.ToString() -notin $currentPermissionForState.Permission)
                {
                    return $false
                }
            }

            # Check that no unexpected permissions are present (only if ExactMatch is specified)
            if ($ExactMatch.IsPresent)
            {
                $desiredPermissionNames = $Permission | ForEach-Object -Process { $_.ToString() }
                foreach ($currentPermissionName in $currentPermissionForState.Permission)
                {
                    if ($currentPermissionName -notin $desiredPermissionNames)
                    {
                        return $false
                    }
                }
            }

            return $true
        }
        catch
        {
            # If the principal doesn't exist or there's another error, return false
            Write-Verbose -Message (
                $script:localizedData.ServerPermission_Test_TestFailed -f $principalName, $_.Exception.Message
            )

            return $false
        }
    }
}
#EndRegion '.\Public\Test-SqlDscServerPermission.ps1' 265
#Region '.\Public\Uninstall-SqlDscBIReportServer.ps1' -1

<#
    .SYNOPSIS
        Uninstalls SQL Server Power BI Report Server.

    .DESCRIPTION
        Uninstalls SQL Server Power BI Report Server using the provided setup executable.

    .PARAMETER MediaPath
        Specifies the path where to find the SQL Server installation media. On this
        path the SQL Server setup executable must be found.

    .PARAMETER LogPath
        Specifies the file path where to write the log files, e.g. 'C:\Logs\Uninstall.log'.
        By default log files are created under %TEMP%.

    .PARAMETER SuppressRestart
        Suppresses the restart of the computer after the uninstallation is finished.
        By default the computer is restarted after the uninstallation is finished.

    .PARAMETER Timeout
        Specifies how long to wait for the setup process to finish. Default value
        is `7200` seconds (2 hours). If the setup process does not finish before
        this time, an exception will be thrown.

    .PARAMETER Force
        If specified the command will not ask for confirmation. Same as if Confirm:$false
        is used.

    .PARAMETER PassThru
        If specified the command will return the setup process exit code.

    .OUTPUTS
        When PassThru is specified the function will return the setup process exit
        code as System.Int32. Otherwise, the function does not generate any output.

    .EXAMPLE
        Uninstall-SqlDscBIReportServer -MediaPath 'E:\PowerBIReportServer.exe'

        Uninstalls Power BI Report Server.

    .EXAMPLE
        Uninstall-SqlDscBIReportServer -MediaPath 'E:\PowerBIReportServer.exe' -LogPath 'C:\Logs\PowerBIReportServer_Uninstall.log'

        Uninstalls Power BI Report Server and specifies a custom log path.

    .EXAMPLE
        Uninstall-SqlDscBIReportServer -MediaPath 'E:\PowerBIReportServer.exe' -Force

        Uninstalls Power BI Report Server without prompting for confirmation.

    .EXAMPLE
        $exitCode = Uninstall-SqlDscBIReportServer -MediaPath 'E:\PowerBIReportServer.exe' -PassThru

        Uninstalls Power BI Report Server and returns the setup exit code.
#>
function Uninstall-SqlDscBIReportServer
{
    [System.Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSShouldProcess', '', Justification = 'Because ShouldProcess is used in Invoke-SetupAction')]
    [CmdletBinding(SupportsShouldProcess = $true, ConfirmImpact = 'High')]
    [OutputType([System.Int32])]
    param
    (
        [Parameter(Mandatory = $true)]
        [System.String]
        $MediaPath,

        [Parameter()]
        [System.String]
        $LogPath,

        [Parameter()]
        [System.Management.Automation.SwitchParameter]
        $SuppressRestart,

        [Parameter()]
        [System.UInt32]
        $Timeout = 7200,

        [Parameter()]
        [System.Management.Automation.SwitchParameter]
        $Force,

        [Parameter()]
        [System.Management.Automation.SwitchParameter]
        $PassThru
    )

    $exitCode = Invoke-ReportServerSetupAction -Uninstall @PSBoundParameters

    if ($PassThru.IsPresent)
    {
        return $exitCode
    }
}
#EndRegion '.\Public\Uninstall-SqlDscBIReportServer.ps1' 95
#Region '.\Public\Uninstall-SqlDscReportingService.ps1' -1

<#
    .SYNOPSIS
        Uninstalls SQL Server Reporting Services or Power BI Report Server.

    .DESCRIPTION
        Uninstalls SQL Server Reporting Services or Power BI Report Server using
        the provided setup executable.

    .PARAMETER MediaPath
        Specifies the path where to find the SQL Server installation media. On this
        path the SQL Server setup executable must be found.

    .PARAMETER LogPath
        Specifies the file path where to write the log files, e.g. 'C:\Logs\Uninstall.log'.
        By default log files are created under %TEMP%.

    .PARAMETER SuppressRestart
        Specifies whether to suppress the restart of the computer after the uninstallation is finished.
        By default the computer is restarted after the uninstallation is finished.

    .PARAMETER Timeout
        Specifies how long to wait for the setup process to finish. Default value
        is `7200` seconds (2 hours). If the setup process does not finish before
        this time, an exception will be thrown.

    .PARAMETER Force
        Specifies whether the command will not ask for confirmation. Same as if '-Confirm:$false'
        is used.

    .PARAMETER PassThru
        Specifies whether the command will return the setup process exit code.

    .OUTPUTS
        When PassThru is specified the function will return the setup process exit
        code as System.Int32. Otherwise, the function does not generate any output.

    .EXAMPLE
        Uninstall-SqlDscReportingService -MediaPath 'E:\SQLServerReportingServices.exe'

        Uninstalls SQL Server Reporting Services.

    .EXAMPLE
        Uninstall-SqlDscReportingService -MediaPath 'E:\PowerBIReportServer.exe' -LogPath 'C:\Logs\PowerBIReportServer_Uninstall.log'

        Uninstalls Power BI Report Server and specifies a custom log path.

    .EXAMPLE
        Uninstall-SqlDscReportingService -MediaPath 'E:\SQLServerReportingServices.exe' -Force

        Uninstalls SQL Server Reporting Services without prompting for confirmation.

    .EXAMPLE
        $exitCode = Uninstall-SqlDscReportingService -MediaPath 'E:\SQLServerReportingServices.exe' -PassThru

        Uninstalls SQL Server Reporting Services and returns the setup exit code.
#>
function Uninstall-SqlDscReportingService
{
    [System.Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSShouldProcess', '', Justification = 'Because ShouldProcess is used in Invoke-SetupAction')]
    [CmdletBinding(SupportsShouldProcess = $true, ConfirmImpact = 'High')]
    [OutputType([System.Int32])]
    param
    (
        [Parameter(Mandatory = $true)]
        [System.String]
        $MediaPath,

        [Parameter()]
        [System.String]
        $LogPath,

        [Parameter()]
        [System.Management.Automation.SwitchParameter]
        $SuppressRestart,

        [Parameter()]
        [System.UInt32]
        $Timeout = 7200,

        [Parameter()]
        [System.Management.Automation.SwitchParameter]
        $Force,

        [Parameter()]
        [System.Management.Automation.SwitchParameter]
        $PassThru
    )

    $exitCode = Invoke-ReportServerSetupAction -Uninstall @PSBoundParameters

    if ($PassThru.IsPresent)
    {
        return $exitCode
    }
}
#EndRegion '.\Public\Uninstall-SqlDscReportingService.ps1' 96
#Region '.\Public\Uninstall-SqlDscServer.ps1' -1

<#
    .SYNOPSIS
        Uninstall features from a Microsoft SQL Server instance.

    .DESCRIPTION
        Uninstall features from a Microsoft SQL Server instance.

        See the link in the commands help for information on each parameter for
        the setup action Uninstall. The link points to SQL Server command line
        setup documentation.

    .PARAMETER MediaPath
        Specifies the path where to find the SQL Server installation media. On this
        path the SQL Server setup executable must be found.

    .PARAMETER Timeout
        Specifies how long to wait for the setup process to finish. Default value
        is `7200` seconds (2 hours). If the setup process does not finish before
        this time, an exception will be thrown.

    .PARAMETER Force
        If specified the command will not ask for confirmation. Same as if Confirm:$false
        is used.

    .PARAMETER InstanceName
        See the notes section for more information.

    .PARAMETER Features
        See the notes section for more information.

    .PARAMETER SuppressPrivacyStatementNotice
        See the notes section for more information.

    .LINK
        https://docs.microsoft.com/en-us/sql/database-engine/install-windows/install-sql-server-from-the-command-prompt

    .OUTPUTS
        None.

    .EXAMPLE
        Uninstall-SqlDscServer -InstanceName 'MyInstance' -Features 'SQLENGINE' -MediaPath 'E:\'

        Uninstalls the database engine from the named instance MyInstance.

    .NOTES
        The parameters are intentionally not described since it would take a lot
        of effort to keep them up to date. Instead there is a link that points to
        the SQL Server command line setup documentation which will stay relevant.
#>
function Uninstall-SqlDscServer
{
    # cSpell: ignore AZUREEXTENSION
    [System.Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSShouldProcess', '', Justification = 'Because ShouldProcess is used in Invoke-SetupAction')]
    [CmdletBinding(SupportsShouldProcess = $true, ConfirmImpact = 'High')]
    [OutputType()]
    param
    (
        [Parameter(Mandatory = $true)]
        [System.String]
        $MediaPath,

        [Parameter(Mandatory = $true)]
        [System.String]
        $InstanceName,

        [Parameter()]
        [ValidateSet(
            'SQL',
            'SQLEngine', # Part of parent feature SQL
            'Replication', # Part of parent feature SQL
            'FullText', # Part of parent feature SQL
            'DQ', # Part of parent feature SQL
            'PolyBase', # Part of parent feature SQL
            'PolyBaseCore', # Part of parent feature SQL
            'PolyBaseJava', # Part of parent feature SQL
            'AdvancedAnalytics', # Part of parent feature SQL
            'SQL_INST_MR', # Part of parent feature SQL
            'SQL_INST_MPY', # Part of parent feature SQL
            'SQL_INST_JAVA', # Part of parent feature SQL
            'AS',
            'RS',
            'RS_SHP',
            'RS_SHPWFE', # cspell: disable-line
            'DQC',
            'IS',
            'IS_Master', # Part of parent feature IS
            'IS_Worker', # Part of parent feature IS
            'MDS',
            'SQL_SHARED_MPY',
            'SQL_SHARED_MR',
            'Tools',
            'BC', # Part of parent feature Tools
            'Conn', # Part of parent feature Tools
            'DREPLAY_CTLR', # Part of parent feature Tools (cspell: disable-line)
            'DREPLAY_CLT', # Part of parent feature Tools (cspell: disable-line)
            'SNAC_SDK', # Part of parent feature Tools (cspell: disable-line)
            'SDK', # Part of parent feature Tools
            'LocalDB', # Part of parent feature Tools
            'AZUREEXTENSION'
        )]
        [System.String[]]
        $Features,

        [Parameter()]
        [System.UInt32]
        $Timeout = 7200,

        [Parameter()]
        [System.Management.Automation.SwitchParameter]
        $Force,

        [Parameter()]
        [System.Management.Automation.SwitchParameter]
        $SuppressPrivacyStatementNotice
    )

    Invoke-SetupAction -Uninstall @PSBoundParameters
}
#EndRegion '.\Public\Uninstall-SqlDscServer.ps1' 119
#Region '.\suffix.ps1' -1

<#
    This check is made so that the real SqlServer or SQLPS module is not loaded into
    the session when the CI runs unit tests of SqlServerDsc. It would conflict with
    the stub types and stub commands used in the unit tests. This is a workaround
    because we cannot set a specific module as a nested module in the module manifest,
    the user must be able to choose to use either SQLPS or SqlServer.
#>
if (-not $env:SqlServerDscCI)
{
    try
    {
        <#
            Import SQL commands and types into the session, so that types used
            by commands can be parsed.
        #>
        Import-SqlDscPreferredModule -ErrorAction 'Stop'
    }
    catch
    {
        <#
            It is not possible to throw the error from Import-SqlDscPreferredModule
            since it will just fail the command Import-Module with an obscure error.
        #>
        Write-Verbose -Message $_.Exception.Message
    }
}
#EndRegion '.\suffix.ps1' 27
